@echo off
setlocal
title Tahta Yonetim Sistemi - Kurulum
cd /d "%~dp0"
if not exist "%~dp0program\kur.ps1" (
  echo.
  echo  [X] Program klasoru bulunamadi.
  echo      ZIP dosyasini once "Tumunu ayikla" ile bir klasore cikarin,
  echo      sonra o klasordeki KUR.bat dosyasini calistirin.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0program\kur.ps1"
echo.
pause
