@echo off
setlocal
title Tahta Yonetim Sistemi - Kaldirma
set "PS1=%LOCALAPPDATA%\TahtaYonetim\program\kur.ps1"
if not exist "%PS1%" set "PS1=%ProgramFiles%\TahtaYonetim\kur.ps1"
if not exist "%PS1%" set "PS1=%~dp0program\kur.ps1"
if not exist "%PS1%" (
  echo Tahta Yonetim Sistemi bu bilgisayarda kurulu degil.
  pause
  exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Kaldir
echo.
pause
