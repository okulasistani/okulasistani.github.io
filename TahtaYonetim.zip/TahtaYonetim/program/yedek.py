# -*- coding: utf-8 -*-
"""
Tahta Yönetim Sistemi — Yedek yönetim bilgisayarı (sıcak yedek)
----------------------------------------------------------------
Ana yönetim bilgisayarı kapalıyken de panelin ve tahtaların çalışmasını sağlar.

Nasıl çalışır?
  * Her yönetim bilgisayarının bir SIRASI vardır: ana bilgisayar 0, yedekler 1, 2, 3...
  * Aynı anda yalnızca BİR bilgisayar "aktif"tir (tahtalara ve panele o hizmet verir).
    Aktif olan, açık olanlar arasında sırası en küçük olandır.
  * Yedek bilgisayarlar, aktif olandan her dakika bir kopya alır: veritabanı (ayarlar,
    şifreler, tahta listesi, zil programı...) ve dosyalar (Ortak Klasör, zil sesleri...).
  * Sırası daha küçük olan hiç görünmezse (45 sn) sıradaki yedek kendiliğinden aktif olur.
    Tahtalar yeni adresi ağdaki yayından ya da kayıtlı adres listesinden bulur.
  * Ana bilgisayar açılınca yedekte yapılan değişiklikleri geri alır, yedeği pasife çevirir
    ve görevi yeniden üstlenir. Hiçbir ayar veya dosya kaybolmaz.
"""
import os
import re
import json
import time
import stat
import gzip
import uuid
import shutil
import sqlite3
import socket
import logging
import tempfile
import threading
import urllib.request
import urllib.error
from pathlib import Path
from urllib.parse import quote

import ortak as ortak_mod

log = logging.getLogger("tys")

ARALIK = int(os.environ.get("TYS_YEDEK_ARALIK", "10"))            # eşleri yoklama aralığı (sn)
DEVRALMA_SN = int(os.environ.get("TYS_YEDEK_DEVRALMA", "45"))     # sırası küçük olan bu kadar süre görünmezse devral
KOPYA_ARALIK = int(os.environ.get("TYS_YEDEK_KOPYA", "60"))       # kopya alma aralığı (sn)
YOKLAMA_ZAMAN = 2.5  # tek yoklama için zaman aşımı (sn)
KOPYA_SAYISI = 5     # geri alma öncesi saklanan veritabanı yedeği sayısı

KLASOR_ADLARI = ("ortak", "cop", "surum", "ses", "dosya")
GECERSIZ_KAR = re.compile(r'[<>:"|?*\x00-\x1f]')
ADRES_DESEN = re.compile(r"^https?://[A-Za-z0-9.\-]+(:\d+)?$")

ACIK = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class YedekHata(Exception):
    pass


def adres_temiz(a):
    a = (a or "").strip().rstrip("/")
    return a if ADRES_DESEN.match(a) else ""


def goreli_dogrula(y):
    if not isinstance(y, str) or not y or len(y) > 400:
        raise YedekHata("Geçersiz yol")
    parcalar = y.replace("\\", "/").split("/")
    for p in parcalar:
        if p in ("", ".", "..") or GECERSIZ_KAR.search(p) or p.endswith((" ", ".")):
            raise YedekHata("Geçersiz yol")
    return "/".join(parcalar)


def uygun_ad(ad, ortak_mi):
    if ad.startswith(".tys-"):
        return False
    if ortak_mi:
        return not ortak_mod.ad_hatasi(ad)
    return ad not in (".", "..") and not GECERSIZ_KAR.search(ad) and not ad.endswith((" ", "."))


def liste_uret(kok, ortak_mi=False):
    """Bir klasördeki dosya ve alt klasörlerin listesini verir (kopya için)."""
    cikti = []
    kok = str(kok)
    if not os.path.isdir(kok):
        return cikti
    for dizin, altlar, dosyalar in os.walk(kok):
        rel = os.path.relpath(dizin, kok)
        rel = "" if rel == "." else rel.replace(os.sep, "/")
        tut = []
        for d in altlar:
            y = rel + "/" + d if rel else d
            if len(y) > 400 or os.path.islink(os.path.join(dizin, d)) or not uygun_ad(d, ortak_mi):
                continue
            tut.append(d)
            cikti.append({"y": y, "t": "d", "b": 0, "m": 0})
        altlar[:] = tut
        for f in dosyalar:
            y = rel + "/" + f if rel else f
            if len(y) > 400 or not uygun_ad(f, ortak_mi):
                continue
            try:
                st = os.lstat(os.path.join(dizin, f))
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode):
                cikti.append({"y": y, "t": "f", "b": st.st_size, "m": st.st_mtime})
    return cikti


def http(adres, yol, anahtar=None, govde=None, zaman=YOKLAMA_ZAMAN, ek=None):
    r = urllib.request.Request(adres + yol, data=govde, method="POST" if govde is not None else "GET")
    if anahtar:
        r.add_header("X-Yedek", anahtar)
    for k, v in (ek or {}).items():
        r.add_header(k, v)
    if govde is not None:
        r.add_header("Content-Type", "application/json")
    return ACIK.open(r, timeout=zaman)


def adres_ad_port(adres):
    m = re.match(r"^https?://([^:/]+)(?::(\d+))?$", adres or "")
    return (m.group(1), m.group(2) or "8765") if m else ("", "8765")


class Dugum:
    """Bu bilgisayarın yönetim düğümü: sırası, durumu, eşleri ve kopya işlemleri."""

    def __init__(self, t):
        self.t = t                          # tys modülü
        self.dosya = Path(t.VERI) / "dugum.json"
        self.kilit = threading.RLock()
        a = self._oku()
        self.id = a.get("id") or uuid.uuid4().hex[:12]
        self.rank = int(a.get("rank") or 0)
        self.ana = adres_temiz(a.get("ana"))
        self.ana_ad = re.sub(r"[^A-Za-z0-9.\-]", "", str(a.get("ana_ad") or ""))[:60]
        self.pasif_ilk = {}                 # eş adresi -> pasif görünmeye başladığı an
        self.isaretler = {}                 # ağ yayınından öğrenilen adresler: adres -> zaman
        self.anahtar = a.get("anahtar") or ""
        self.kimlik0 = a.get("kimlik") or ""
        self.ad = a.get("ad") or socket.gethostname()
        self.kopya_zaman = float(a.get("kopya_zaman") or 0)
        self.epoch = int(a.get("epoch") or 0)
        self.kaldirildi = bool(a.get("kaldirildi"))
        self.durum = "pasif"                # pasif | gecis | aktif
        self.es = {}                        # adres -> son yoklama sonucu
        self.yalniz_sn = 0.0
        self.son_tick = 0.0
        self.son_kopya_deneme = 0.0
        self.kopya_calisiyor = False
        self.kopya_hata = ""
        self.geri_hata = 0
        self.yaz()

    # ── kalıcı bilgi ─────────────────────────────────────────────────────────
    def _oku(self):
        try:
            return json.loads(self.dosya.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def yaz(self):
        try:
            self.dosya.parent.mkdir(parents=True, exist_ok=True)
            gecici = self.dosya.with_suffix(".tmp")
            gecici.write_text(json.dumps({
                "id": self.id, "rank": self.rank, "ana": self.ana, "ana_ad": self.ana_ad, "anahtar": self.anahtar,
                "kimlik": self.kimlik0, "ad": self.ad, "kopya_zaman": self.kopya_zaman,
                "epoch": self.epoch, "kaldirildi": self.kaldirildi}, ensure_ascii=False), encoding="utf-8")
            os.replace(str(gecici), str(self.dosya))
        except OSError as e:
            log.warning("dugum.json yazılamadı: %s", e)

    # ── durum ────────────────────────────────────────────────────────────────
    def aktif(self):
        return self.durum == "aktif"

    def yedek_mi(self):
        return self.rank > 0

    def kimlik(self):
        return self.t.db.ayar("kimlik") or self.kimlik0

    def anahtar_al(self):
        return self.t.db.ayar("yedek_anahtar") or self.anahtar

    def anahtar_dogru(self, a):
        import hmac
        for x in (self.t.db.ayar("yedek_anahtar"), self.anahtar):
            if x and a and hmac.compare_digest(str(a), str(x)):
                return True
        return False

    def kayitlar(self):
        return self.t.db.ayar("yedekler") or []

    def saglik(self, host=None):
        return {"ok": True, "surum": self.t.SURUM, "uygulama": "TahtaYonetim", "ad": socket.gethostname(),
                "durum": "kaldirildi" if self.kaldirildi else self.durum,
                "rank": 99 if self.kaldirildi else self.rank, "epoch": self.epoch, "dugum": self.id,
                "kimlik": self.kimlik(), "kopya": self.kopya_zaman, "sunucular": self.sunucular(host)}

    def sunucular(self, host=None):
        """Ana ve yedek bilgisayarların adresleri (ajanlar ana kapanınca yedeğe geçebilsin diye)."""
        liste = []

        def ekle(u):
            u = adres_temiz(u)
            if u and u not in liste:
                liste.append(u)

        # IP adresi değişse de bulunabilsin diye her bilgisayar hem IP hem bilgisayar adıyla yazılır
        ben = socket.gethostname()
        if self.rank == 0:
            if host and re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
                ekle("http://" + (host if ":" in host else "{}:{}".format(host, self.t.PORT)))
            ekle("http://{}:{}".format(ben, self.t.PORT))
        else:
            ekle(self.ana)
            if self.ana_ad:
                ekle("http://{}:{}".format(self.ana_ad, adres_ad_port(self.ana)[1]))
        try:
            for y in sorted(self.kayitlar(), key=lambda x: x.get("rank", 99)):
                ekle(y.get("adres"))
                if y.get("host"):
                    ekle("http://{}:{}".format(y["host"], adres_ad_port(y.get("adres"))[1]))
        except Exception:
            pass
        if self.rank > 0:
            ekle("http://{}:{}".format(ben, self.t.PORT))
        return liste

    def tani(self):
        """Bekleme sayfasında gösterilecek durum özeti."""
        return {"rank": self.rank, "durum": self.durum, "kopya": self.kopya_zaman, "hata": self.kopya_hata,
                "kaldirildi": self.kaldirildi, "ana": self.ana,
                "es": [{"ad": p.get("ad", ""), "rank": p.get("rank", 99), "durum": p.get("durum") if p.get("ok") else "kapali",
                        "adres": p.get("adres", ""), "kopya": p.get("kopya", 0)} for p in
                       sorted(self.es.values(), key=lambda p: p.get("rank", 99))]}

    def aktif_adres(self):
        """Şu an aktif görünen diğer bilgisayarın adresi (bekleme sayfası yönlendirmesi için)."""
        for p in sorted(self.es.values(), key=lambda p: p.get("rank", 99)):
            if p.get("ok") and p.get("durum") == "aktif" and time.time() - p.get("zaman", 0) < 40:
                return p.get("adres")
        return None

    # ── eşleri yoklama ───────────────────────────────────────────────────────
    def esler(self):
        liste = []
        yayin = [a for a, z in self.isaretler.items() if time.time() - z < 90]   # şu an yayın yapan (aktif) bilgisayar
        if self.ana:
            adresler = [self.ana]
            if self.ana_ad:
                adresler.append(adres_temiz("http://{}:{}".format(self.ana_ad, adres_ad_port(self.ana)[1])))
            liste.append({"id": "", "ad": "Yönetim bilgisayarı", "adresler": [a for a in adresler if a], "ana": True})
        for y in self.kayitlar():
            if y.get("id") == self.id:
                continue
            adresler = [adres_temiz(y.get("adres"))]
            if y.get("host"):
                adresler.append(adres_temiz("http://{}:{}".format(y["host"], adres_ad_port(y.get("adres"))[1])))
            liste.append({"id": y.get("id", ""), "ad": y.get("ad", ""), "adresler": [a for a in adresler if a]})
        if yayin:     # IP değişmiş olabilir: yayından öğrenilen adresler her eşe son aday olarak eklenir
            for e in liste:
                e["adresler"] = e["adresler"] + [a for a in yayin if a not in e["adresler"]]
        return liste

    def _adres_ogren(self, e, adres, d):
        """Bir eş bulunduğu adres, bildiğimizden farklıysa (IP değişmiş) yeni adresi kaydeder."""
        try:
            ad, port = adres_ad_port(adres)
            if e.get("ana") and int(d.get("rank", 99)) == 0 and self.rank > 0:
                ana_ip = adres if re.match(r"^\d+\.\d+\.\d+\.\d+$", ad) else self.ana
                if ana_ip != self.ana or (d.get("ad") and d["ad"] != self.ana_ad):
                    self.ana = ana_ip
                    self.ana_ad = re.sub(r"[^A-Za-z0-9.\-]", "", str(d.get("ad") or ""))[:60]
                    self.yaz()
                    log.info("Ana yönetim bilgisayarının adresi güncellendi: %s", self.ana)
            elif e.get("id") and self.aktif() and re.match(r"^\d+\.\d+\.\d+\.\d+$", ad):
                self.adres_guncelle(e["id"], adres)
        except Exception:
            pass

    def isaret_dinle(self):
        """Aktif yönetim bilgisayarının ağ yayınını dinler (IP değişince yeni adresi buradan öğreniriz)."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", self.t.KESIF_PORT))
        except OSError as e:
            log.info("Yayın dinleyicisi açılamadı: %s", e)
            return
        while True:
            try:
                veri, (ip, _) = s.recvfrom(512)
                p = veri.decode("utf-8", "replace").split()
                if len(p) >= 3 and p[0] == "TYS1" and p[1] == self.kimlik() and p[2].isdigit():
                    self.isaretler["http://{}:{}".format(ip, int(p[2]))] = time.time()
                    for a in [a for a, z in self.isaretler.items() if time.time() - z > 300]:
                        self.isaretler.pop(a, None)
            except Exception:
                time.sleep(1)

    def _yokla_biri(self, e, sonuc):
        for adres in e["adresler"]:
            try:
                with http(adres, "/api/saglik") as y:
                    d = json.loads(y.read().decode("utf-8", "replace"))
            except Exception:
                continue
            if d.get("uygulama") != "TahtaYonetim" or d.get("dugum") == self.id:
                continue
            k = self.kimlik()
            if k and d.get("kimlik") and d["kimlik"] != k and self.kopya_zaman:
                continue
            self._adres_ogren(e, adres, d)
            sonuc.append({"ok": True, "adres": adres, "rank": int(d.get("rank", 99)), "durum": d.get("durum", "?"),
                          "epoch": int(d.get("epoch") or 0), "id": d.get("dugum", ""), "ad": d.get("ad") or e["ad"],
                          "kopya": d.get("kopya") or 0, "zaman": time.time(), "kayit_id": e["id"]})
            return

    def yokla(self):
        sonuc = []
        isler = [threading.Thread(target=self._yokla_biri, args=(e, sonuc), daemon=True) for e in self.esler()]
        for i in isler:
            i.start()
        for i in isler:
            i.join(YOKLAMA_ZAMAN * 2 + 1)
        yeni = {}
        for p in list(sonuc):
            yeni[p["adres"]] = p
        # görünmeyenleri de kaydet (panelde "kapalı" görünsün)
        for e in self.esler():
            if not any(a in yeni for a in e["adresler"]):
                eski = next((self.es[a] for a in e["adresler"] if a in self.es), None)
                yeni[e["adresler"][0]] = {"ok": False, "adres": e["adresler"][0], "rank": (eski or {}).get("rank", 99),
                                          "durum": "kapali", "epoch": (eski or {}).get("epoch", 0), "id": e["id"],
                                          "ad": e["ad"], "kopya": 0, "zaman": time.time(), "kayit_id": e["id"]}
        return yeni

    # ── karar döngüsü ────────────────────────────────────────────────────────
    def baslat(self):
        if not self.esler():
            if not self.yedek_mi():
                self.etkinlestir(sessiz=True)       # eşi olmayan ana bilgisayar: eskisi gibi hemen başlar
        threading.Thread(target=self.isaret_dinle, daemon=True).start()
        threading.Thread(target=self.dongu, daemon=True).start()

    def dongu(self):
        ilk = True
        while True:
            try:
                self.tick(ilk)
            except Exception:
                log.exception("yedek sunucu döngüsü")
            ilk = False
            time.sleep(ARALIK)

    def tick(self, ilk=False):
        n = time.time()
        gecen = min(n - self.son_tick, 60.0) if self.son_tick else 0.0
        self.son_tick = n
        if self.kaldirildi:
            self.durum = "pasif"
            return
        es = self.yokla()
        self.es = es
        canli = [p for p in es.values() if p["ok"]]
        # sırası bizden küçük olan aktif bir eşi görürsek kendi epoch'umuzu güncel tutarız
        for p in canli:
            if p["durum"] == "aktif":
                self.epoch = max(self.epoch, p["epoch"])
        for p in canli:
            if p["durum"] == "aktif":
                self.pasif_ilk.pop(p["adres"], None)
            else:
                self.pasif_ilk.setdefault(p["adres"], n)

        def gecerli(p):
            """Hizmet vermeyen bir kıdemli, devralmayı engellememeli (kilitlenme olmasın)."""
            if p["durum"] == "aktif":
                return True
            if p["rank"] > 0 and not p.get("kopya"):
                return False                         # hiç kopyası olmayan yedek devralamaz
            return n - self.pasif_ilk.get(p["adres"], n) < 120   # 2 dakikadır hizmet vermiyorsa takılmıştır

        kidemli = [p for p in canli if p["rank"] < self.rank and gecerli(p)]
        aktifler = sorted([p for p in canli if p["durum"] == "aktif" and p["rank"] != self.rank], key=lambda p: p["rank"])

        if self.durum == "aktif":
            kidemsiz = [p for p in aktifler if p["rank"] > self.rank]
            if kidemsiz:
                self.geri_al(kidemsiz[0])
            return                                   # sırası küçük olan aktif görünüyorsa o bizi pasifleştirir

        if self.durum == "gecis":
            return

        # pasifiz
        if kidemli:
            self.yalniz_sn = 0.0
            if not self.kopya_calisiyor and n - self.son_kopya_deneme >= KOPYA_ARALIK:
                kaynaklar = [p for p in kidemli if p["durum"] == "aktif"]
                if kaynaklar:
                    self.son_kopya_deneme = n
                    k = min(kaynaklar, key=lambda p: p["rank"])
                    threading.Thread(target=self.kopya_is, args=(k,), daemon=True).start()
            return
        if self.rank > 0 and not self.kopya_zaman:
            return                                   # henüz hiç kopya alınmadı; boş veriyle devralınmaz
        if not ilk:
            self.yalniz_sn += gecen
        if self.rank > 0 and self.yalniz_sn < DEVRALMA_SN:
            return                                   # ana bilgisayar yeniden açılıyor olabilir; biraz bekle
        if aktifler:
            if self.geri_al(aktifler[0]):
                return
            self.geri_hata += 1
            if self.geri_hata < 3:
                return
            log.warning("Aktif yedekten veri alınamadı; mevcut verilerle devam ediliyor")
        self.etkinlestir()

    # ── durum geçişleri ──────────────────────────────────────────────────────
    def etkinlestir(self, sessiz=False):
        with self.kilit:
            if self.durum == "aktif":
                return
            self.epoch += 1
            self.durum = "aktif"
            self.yalniz_sn = 0.0
            self.geri_hata = 0
            self.yaz()
        log.info("Bu bilgisayar AKTİF oldu (sıra %s, kuşak %s)", self.rank, self.epoch)
        try:
            self.t.depo.yenile()
            if self.yedek_mi() and not sessiz:
                self.t.olay("", "sistem", "Yönetim bilgisayarı ({}) tahtalara hizmet vermeye başladı: öncekine ulaşılamıyor"
                            .format(socket.gethostname()))
            elif not sessiz and self.epoch > 1:
                self.t.olay("", "sistem", "Yönetim bilgisayarı ({}) tahtalara yeniden hizmet vermeye başladı".format(socket.gethostname()))
            self.t.isaret_yayinla()
        except Exception:
            log.exception("etkinleştirme")

    def pasiflestir(self, neden=""):
        """Sırası küçük olan bilgisayar görevi geri alırken çağrılır."""
        with self.kilit:
            if self.durum != "aktif":
                return
            self.durum = "gecis"
        try:
            self.t.kullanim_yaz()
            self.t.araliklari_yaz()
        except Exception:
            log.exception("pasifleştirme")
        with self.kilit:
            self.durum = "pasif"
            self.yalniz_sn = 0.0
            self.son_kopya_deneme = 0.0
        log.info("Bu bilgisayar PASİF oldu (%s)", neden)

    def geri_al(self, p):
        """Sırası bizden büyük olan aktif bilgisayardan verileri alıp görevi geri üstlenir."""
        adres = p["adres"]
        with self.kilit:
            onceki = self.durum
            self.durum = "gecis"
        log.info("Görev geri alınıyor: %s (sıra %s, kuşak %s)", adres, p["rank"], p["epoch"])
        try:
            try:
                http(adres, "/api/y/devret", self.anahtar_al(),
                     json.dumps({"rank": self.rank, "epoch": self.epoch}).encode(), zaman=15).read()
            except Exception as e:
                log.warning("Devir isteği başarısız: %s", e)
                with self.kilit:
                    self.durum = onceki
                return False
            ok = False
            if p["epoch"] >= self.epoch:
                for _ in range(3):
                    try:
                        self.kopyala(p, yedekle=True)
                        ok = True
                        break
                    except Exception as e:
                        self.kopya_hata = str(e)
                        log.warning("Geri alma kopyası başarısız: %s", e)
                        time.sleep(5)
            else:
                ok = True                            # yedeğin verisi bizimkinden eski; yalnızca pasifleştirildi
            self.epoch = max(self.epoch, p["epoch"])
            with self.kilit:
                self.durum = "pasif"
            self.etkinlestir()
            return ok
        except Exception:
            log.exception("geri alma")
            with self.kilit:
                if self.durum == "gecis":
                    self.durum = "pasif"
            return False

    # ── kopya alma ───────────────────────────────────────────────────────────
    def kopya_is(self, kaynak):
        with self.kilit:
            if self.kopya_calisiyor:
                return
            self.kopya_calisiyor = True
        try:
            self.kopyala(kaynak)
            self.kopya_hata = ""
        except Exception as e:
            self.kopya_hata = str(e)
            log.warning("Kopya alınamadı (%s): %s", kaynak.get("adres"), e)
        finally:
            self.kopya_calisiyor = False

    def kokler(self):
        t = self.t
        return {"ortak": Path(t.depo.kok), "cop": Path(t.VERI) / "ortak_cop", "surum": Path(t.VERI) / "ortak_surum",
                "ses": Path(t.VERI) / "sesler", "dosya": Path(t.VERI) / "dosyalar"}

    def ek_basliklar(self):
        return {"X-Dugum": self.id, "X-Rank": str(self.rank), "X-Port": str(self.t.PORT),
                "X-Ad": quote(socket.gethostname())}

    def kopyala(self, p, yedekle=False):
        """Kaynak bilgisayardan veritabanı ve dosyaların kopyasını alır; en sonda veritabanını değiştirir."""
        t = self.t
        adres, anahtar = p["adres"], self.anahtar_al()
        ek = self.ek_basliklar()
        veri = Path(t.VERI)
        yeni = veri / "kopya.db.yeni"
        # 1) veritabanı anlık görüntüsü
        with http(adres, "/api/y/anlik", anahtar, zaman=180, ek=ek) as y:
            ham = y.read()
        try:
            ham = gzip.decompress(ham)
        except OSError:
            raise YedekHata("Veritabanı kopyası bozuk geldi")
        yeni.write_bytes(ham)
        try:
            c = sqlite3.connect(str(yeni))
            try:
                if c.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise YedekHata("Veritabanı kopyası doğrulanamadı")
                kimlik_k = json.loads((c.execute("SELECT deger FROM ayar WHERE anahtar='kimlik'").fetchone() or ["\"\""])[0])
                kayit = json.loads((c.execute("SELECT deger FROM ayar WHERE anahtar='yedekler'").fetchone() or ["[]"])[0])
            finally:
                c.close()
        except sqlite3.DatabaseError as e:
            raise YedekHata("Veritabanı kopyası okunamadı: {}".format(e))
        k = self.kimlik()
        if self.kopya_zaman and k and kimlik_k and k != kimlik_k:
            raise YedekHata("Kaynak başka bir kuruluma ait")
        # 2) dosyalar
        self.dosyalari_esitle(adres, anahtar, ek, sil=not yedekle)
        # 3) değiştir
        with self.kilit:
            if self.durum == "aktif" and not yedekle:
                try:
                    yeni.unlink()
                except OSError:
                    pass
                return                               # bu arada aktif olduk; kopyayı uygulama
            t.db.degistir(yeni, yedekle=yedekle)
            t.depo.yenile()
            self.kopya_zaman = time.time()
            self.epoch = max(self.epoch, p.get("epoch", 0))
            if self.rank > 0:
                if kimlik_k:
                    self.kimlik0 = kimlik_k
                if not any(y.get("id") == self.id for y in kayit):
                    if not self.kaldirildi:
                        log.warning("Bu yedek bilgisayar ana bilgisayarın listesinden silinmiş; devralma kapatıldı")
                    self.kaldirildi = True
            self.yaz()
        log.info("Kopya alındı: %s", adres)

    def dosyalari_esitle(self, adres, anahtar, ek, sil=True):
        with http(adres, "/api/y/liste", anahtar, zaman=120, ek=ek) as y:
            liste = json.loads(y.read().decode("utf-8"))
        kokler = self.kokler()
        istenen = {k: set() for k in KLASOR_ADLARI}
        for g in liste.get("girdiler", []):
            k = g.get("k")
            kok = kokler.get(k)
            if kok is None:
                continue
            try:
                rel = goreli_dogrula(g.get("y"))
            except YedekHata:
                continue
            istenen[k].add(rel.lower())
            hedef = kok.joinpath(*rel.split("/"))
            if g.get("t") == "d":
                hedef.mkdir(parents=True, exist_ok=True)
                continue
            boyut, mt = int(g.get("b") or 0), float(g.get("m") or 0)
            try:
                st = hedef.stat()
                if hedef.is_file() and st.st_size == boyut and abs(st.st_mtime - mt) < 2:
                    continue
            except OSError:
                pass
            self.dosya_indir(adres, anahtar, ek, k, rel, hedef, boyut, mt)
        if not sil:
            return          # görevi geri alırken yerel dosyalar silinmez (veri kaybı olmasın); Gezgin taraması bulur
        # kaynakta olmayan yerel kayıtları sil (kopya, kaynakla aynı kalsın)
        for k, kok in kokler.items():
            yerel = liste_uret(kok, ortak_mi=(k == "ortak"))
            for e in sorted(yerel, key=lambda e: e["y"].count("/"), reverse=True):
                if e["y"].lower() in istenen[k]:
                    continue
                yol = kok.joinpath(*e["y"].split("/"))
                try:
                    if e["t"] == "d":
                        shutil.rmtree(str(yol), ignore_errors=True)
                    else:
                        yol.unlink()
                except OSError:
                    pass

    def dosya_indir(self, adres, anahtar, ek, k, rel, hedef, boyut, mt):
        hedef.parent.mkdir(parents=True, exist_ok=True)
        gecici = hedef.parent / (".tys-kopya-" + uuid.uuid4().hex[:8])
        try:
            with http(adres, "/api/y/dosya?k={}&y={}".format(k, quote(rel)), anahtar, zaman=300, ek=ek) as y, \
                    open(str(gecici), "wb") as f:
                toplam = 0
                while True:
                    parca = y.read(1 << 20)
                    if not parca:
                        break
                    f.write(parca)
                    toplam += len(parca)
            if boyut and toplam != boyut:
                raise YedekHata("Dosya eksik indi: " + rel)
            os.replace(str(gecici), str(hedef))
            if mt:
                try:
                    os.utime(str(hedef), (mt, mt))
                except OSError:
                    pass
        finally:
            try:
                gecici.unlink()
            except OSError:
                pass

    # ── ana bilgisayar tarafı: kopya verme ───────────────────────────────────
    def anlik_gz(self):
        """Veritabanının tutarlı bir kopyasını sıkıştırılmış olarak verir."""
        t = self.t
        if self.aktif():
            try:
                t.kullanim_yaz()
                t.araliklari_yaz()
            except Exception:
                pass
        gecici = Path(tempfile.gettempdir()) / ("tys-anlik-" + uuid.uuid4().hex[:8] + ".db")
        try:
            hedef = sqlite3.connect(str(gecici))
            try:
                with t.db.k:
                    t.db.c.backup(hedef)
            finally:
                hedef.close()
            return gzip.compress(gecici.read_bytes(), 3)
        finally:
            for ek in ("", "-wal", "-shm", "-journal"):
                try:
                    os.remove(str(gecici) + ek)
                except OSError:
                    pass

    def liste_ver(self):
        girdiler = []
        for k, kok in self.kokler().items():
            for e in liste_uret(kok, ortak_mi=(k == "ortak")):
                e["k"] = k
                girdiler.append(e)
        return {"girdiler": girdiler, "zaman": time.time()}

    def dosya_yolu(self, k, y):
        kok = self.kokler().get(k)
        if kok is None:
            raise YedekHata("Geçersiz klasör")
        rel = goreli_dogrula(y)
        p = kok
        for parca in rel.split("/")[:-1]:
            p = p / parca
            if p.is_symlink():
                raise YedekHata("Geçersiz yol")
        p = kok.joinpath(*rel.split("/"))
        if not p.is_file() or p.is_symlink():
            raise YedekHata("Dosya bulunamadı")
        return p

    # ── kayıt defteri (ana bilgisayarda) ─────────────────────────────────────
    def yedek_ekle(self, ad, adres, host):
        with self.kilit:
            liste = self.kayitlar()
            for y in liste:
                if y.get("host") and host and y["host"].lower() == host.lower():
                    y.update({"ad": ad, "adres": adres})      # aynı bilgisayar yeniden kuruluyor
                    self.t.db.ayar_yaz("yedekler", liste)
                    return y
            if len(liste) >= 30:
                raise YedekHata("En fazla 30 yönetim bilgisayarı eklenebilir")
            yeni = {"id": uuid.uuid4().hex[:10], "ad": ad, "adres": adres, "host": host,
                    "rank": max([y.get("rank", 0) for y in liste] + [0]) + 1, "eklenme": time.time()}
            liste.append(yeni)
            self.t.db.ayar_yaz("yedekler", liste)
            return yeni

    def yedek_sil(self, yid):
        with self.kilit:
            liste = self.kayitlar()
            if not any(y.get("id") == yid for y in liste):
                raise YedekHata("Yedek bilgisayar bulunamadı")
            self.t.db.ayar_yaz("yedekler", [y for y in liste if y.get("id") != yid])

    def adres_guncelle(self, yid, adres):
        if not yid or not adres_temiz(adres) or not self.aktif():
            return
        with self.kilit:
            liste = self.kayitlar()
            for y in liste:
                if y.get("id") == yid and y.get("adres") != adres:
                    y["adres"] = adres
                    self.t.db.ayar_yaz("yedekler", liste)
                    return

    def panel_ozeti(self):
        """Panelde gösterilecek düğüm listesi."""
        ben = {"id": self.id, "ad": socket.gethostname(), "rank": self.rank, "durum": self.durum, "ben": True,
               "adres": "", "kopya": self.kopya_zaman, "epoch": self.epoch, "kaldirildi": self.kaldirildi}
        liste = [ben]
        goruldu = set()
        for p in self.es.values():
            kid = p.get("kayit_id") or ""
            goruldu.add(p["adres"])
            liste.append({"id": p.get("id") or kid, "kayit_id": kid, "ad": p.get("ad", ""), "rank": p.get("rank", 99),
                          "durum": p.get("durum") if p.get("ok") else "kapali", "ben": False, "adres": p["adres"],
                          "kopya": p.get("kopya", 0), "epoch": p.get("epoch", 0)})
        return {"dugumler": sorted(liste, key=lambda x: x["rank"]), "kayitlar": self.kayitlar(),
                "kopya_hata": self.kopya_hata, "ben": ben["id"]}


# ─────────────────────────────────────────────────────────────────────────────
# Bekleme sayfası (yedek bilgisayar pasifken tarayıcıya gösterilir)
# ─────────────────────────────────────────────────────────────────────────────

def bekleme_sayfasi(hedef, yol, rank, tani=None):
    import html
    e = lambda x: html.escape(str(x), quote=True)
    if hedef:
        git = hedef + (yol if yol.startswith("/") else "/")
        govde = ('<meta http-equiv="refresh" content="1;url={u}"><p>Panel şu bilgisayarda çalışıyor:</p>'
                 '<p><a href="{u}">{u}</a></p><p>Yönlendiriliyorsunuz…</p>').format(u=e(git))
        return _sayfa('', govde)
    tani = tani or {}
    es = tani.get("es") or []
    kopya = tani.get("kopya") or 0
    if tani.get("kaldirildi"):
        giris = "<p>Bu bilgisayar yönetim bilgisayarları listesinden <b>kaldırılmış</b>; tahtalara hizmet vermez.</p>"
    elif rank == 0:
        giris = "<p>Yönetim sunucusu hazırlanıyor…</p>"
    else:
        giris = ("<p>Bu bilgisayar <b>yönetim bilgisayarı</b>. Şu an hizmet veren bir yönetim bilgisayarı görünmüyor; "
                 "hazırsa bu bilgisayar yaklaşık bir dakika içinde devralır.</p>")
    durumlar = {"aktif": "hizmet veriyor", "pasif": "bekliyor", "gecis": "görev devrediliyor", "kapali": "ulaşılamıyor",
                "kaldirildi": "listeden kaldırılmış"}
    satirlar = "".join("<li>{} ({}): <b>{}</b></li>".format(e(x.get("ad") or x.get("adres")), e(x.get("adres")),
                                                          e(durumlar.get(x.get("durum"), x.get("durum")))) for x in es)
    if not es:
        neden = "Başka yönetim bilgisayarı kayıtlı değil veya henüz yoklanmadı."
    elif not any(x.get("durum") != "kapali" for x in es):
        neden = ("Diğer yönetim bilgisayarlarına <b>ulaşılamıyor</b>: kapalı olabilir, farklı ağda olabilir ya da "
                 "Windows güvenlik duvarı engelliyor olabilir.")
    elif not kopya and rank > 0:
        neden = ("Bu bilgisayar henüz <b>hiç kopya alamadığı</b> için hizmet veremez. Hizmet veren bir yönetim "
                 "bilgisayarı açılınca kopya alınır.")
    else:
        neden = "Diğer bilgisayarlar görünüyor ama hiçbiri hizmet vermiyor; birkaç saniye içinde biri devralacak."
    ek = ('<details open><summary>Ayrıntılar</summary><ul>{}</ul><p>Bu bilgisayarın kopyası: {}</p>{}<p>{}</p></details>'
          .format(satirlar or "<li>Eş bulunamadı</li>",
                  e(time.strftime("%d.%m.%Y %H:%M", time.localtime(kopya))) if kopya else "yok",
                  ("<p>Son kopya hatası: {}</p>".format(e(tani["hata"])) if tani.get("hata") else ""), neden))
    return _sayfa('<meta http-equiv="refresh" content="5">', giris + "<p>Bu sayfa birkaç saniyede bir kendini yeniler.</p>" + ek)


def _sayfa(baslik_ek, govde):
    return ('<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Tahta Yönetim</title>{}'
            '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
            '<body style="font-family:Segoe UI,Arial,sans-serif;max-width:620px;margin:10vh auto;padding:0 20px;'
            'color:#222;line-height:1.5"><h2>Tahta Yönetim</h2>{}</body></html>').format(baslik_ek, govde)
