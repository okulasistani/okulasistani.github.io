# -*- coding: utf-8 -*-
"""
Tahta Yönetim Sistemi — Windows başlatıcısı
  sunucu.pyw          → sunucu çalışmıyorsa arka planda başlatır
  sunucu.pyw --ac     → ayrıca paneli tarayıcıda açar (masaüstü kısayolu bunu kullanır)
Konsol penceresi açılmaz (pythonw ile çalışır).
"""
import os
import sys
import time
import socket
import threading
import webbrowser
import urllib.request

PROGRAM = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROGRAM)

# pythonw altında stdout/stderr yoktur; hataları dosyaya yönlendir
VERI = os.environ.get("TYS_VERI") or os.path.join(os.path.dirname(PROGRAM), "veri")
os.makedirs(VERI, exist_ok=True)
if sys.stdout is None or sys.stderr is None:
    _f = open(os.path.join(VERI, "hata.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _f
    sys.stderr = sys.stderr or _f

import tys  # noqa: E402

PANEL = "http://localhost:{}".format(tys.PORT)


def calisiyor_mu():
    try:
        with urllib.request.urlopen(PANEL + "/api/saglik", timeout=2) as r:
            return b"TahtaYonetim" in r.read()
    except Exception:
        return False


def port_dolu_mu():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", tys.PORT)) == 0
    finally:
        s.close()


def tarayici_ac():
    webbrowser.open(PANEL)


def main():
    ac = "--ac" in sys.argv
    if calisiyor_mu():
        if ac:
            tarayici_ac()
        return
    if port_dolu_mu():
        # Port başka bir program tarafından kullanılıyor
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, "{} numaralı bağlantı noktası başka bir program tarafından kullanılıyor.\n"
                   "Bilgisayarı yeniden başlatıp tekrar deneyin.".format(tys.PORT),
                "Tahta Yönetim", 0x30)
        except Exception:
            pass
        return

    def hazir():
        if ac:
            threading.Timer(0.8, tarayici_ac).start()

    try:
        tys.calistir(hazir)
    except OSError:
        # Aynı anda iki kez başlatıldıysa
        time.sleep(1)
        if ac and calisiyor_mu():
            tarayici_ac()


if __name__ == "__main__":
    main()
