# -*- coding: utf-8 -*-
"""
Tahta Yönetim Sistemi — Ortak Klasör (sunucu tarafı)
----------------------------------------------------
Yönetim bilgisayarındaki "Ortak Klasör" esas kaynaktır. Tahtalar ve öğretmen
bilgisayarları bu depoyla iki yönlü eşitlenir.

  * Her değişiklik artan bir numara (rev) alır; cihazlar "şu numaradan sonraki
    değişiklikleri ver" diye sorar.
  * Silinen dosyalar 30 gün çöp kutusunda, üzerine yazılan dosyaların eski
    sürümleri 30 gün saklanır.
  * Yönetim bilgisayarında Gezgin'den yapılan değişiklikler tarama ile bulunur.
"""
import os
import re
import stat
import time
import uuid
import errno
import shutil
import hashlib
import threading
from pathlib import Path

SAKLAMA_GUN = 30
SURUM_SAYISI = 5
YONETIM = "Yönetim bilgisayarı"

YOKSAY = re.compile(r"^(~\$.*|\.~lock\..*#|.*\.(tmp|temp|part|partial|crdownload|swp|indiriliyor)|"
                    r"thumbs\.db|desktop\.ini|\.ds_store|\..*)$", re.I)
GECERSIZ = re.compile(r'[<>:"\\|?*\x00-\x1f]')
AYRILMIS = {"con", "prn", "aux", "nul"} | {"com%d" % i for i in range(1, 10)} | {"lpt%d" % i for i in range(1, 10)}


class OrtakHata(Exception):
    def __init__(self, mesaj, kod=400):
        Exception.__init__(self, mesaj)
        self.kod = kod


def yoksay(ad):
    return bool(YOKSAY.match(ad))


def ad_hatasi(ad):
    if not ad or ad in (".", ".."):
        return "Geçersiz ad"
    if GECERSIZ.search(ad):
        return 'Ad şu karakterleri içeremez: < > : " \\ | ? *'
    if ad.endswith((" ", ".")):
        return "Ad boşluk veya nokta ile bitemez"
    if ad.split(".")[0].strip().lower() in AYRILMIS:
        return "Bu ad Windows'ta kullanılamaz"
    if yoksay(ad):
        return "Gizli veya geçici dosyalar eşitlenmez"
    return None


def yol_dogrula(yol):
    if not isinstance(yol, str):
        raise OrtakHata("Geçersiz dosya yolu")
    yol = yol.replace("\\", "/").strip().strip("/")
    parcalar = yol.split("/")
    if not yol or len(yol) > 240 or len(parcalar) > 24:
        raise OrtakHata("Dosya yolu boş veya çok uzun")
    for p in parcalar:
        h = ad_hatasi(p)
        if h:
            raise OrtakHata("{}: {}".format(h, p))
    return "/".join(parcalar)


def like_kacis(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def ozet(yol):
    h = hashlib.sha1()
    with open(yol, "rb") as f:
        for parca in iter(lambda: f.read(1 << 20), b""):
            h.update(parca)
    return h.hexdigest()


def kullanimda(yol):
    """Windows: dosya başka bir programda yazma amaçlı açıksa (kopyalanıyor, Word'de açık…) True."""
    if os.name != "nt":
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateFileW.restype = wintypes.HANDLE
        k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
                                    wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        h = k32.CreateFileW(str(yol), 0x80000000, 0x00000001, None, 3, 0x80, None)
        if h == wintypes.HANDLE(-1).value:
            return ctypes.get_last_error() == 32
        k32.CloseHandle(h)
    except Exception:
        pass
    return False


def gizle(yol):
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(yol), 0x02)
        except Exception:
            pass


def acik_hatasi(e):
    """Windows'ta dosya başka programda açıkken alınan hata mı?"""
    return isinstance(e, PermissionError) or getattr(e, "winerror", None) in (5, 32, 33)


def tasi(kaynak, hedef):
    """Aynı diskteyse yeniden adlandırır, değilse kopyalayıp siler."""
    try:
        os.replace(kaynak, hedef)
    except OSError as e:
        if e.errno != errno.EXDEV and getattr(e, "winerror", None) != 17:
            raise
        shutil.copy2(kaynak, hedef)
        try:
            os.remove(kaynak)
        except OSError:
            os.remove(hedef)
            raise


class OrtakDepo:
    def __init__(self, db, kok, veri, olay):
        self.db = db
        self.kok = Path(kok)
        self.cop = Path(veri) / "ortak_cop"
        self.surum = Path(veri) / "ortak_surum"
        self.olay = olay
        self.kilit = threading.RLock()
        self.kosul = threading.Condition()
        self.onceki = {}
        self.son_temizlik = 0.0
        self.hata = None
        if not db.ayar("ortak_kimlik"):
            db.ayar_yaz("ortak_kimlik", uuid.uuid4().hex[:16])
        self.kimlik = db.ayar("ortak_kimlik")
        self.rev = int(db.ayar("ortak_rev") or 0)
        try:
            self.kok.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            self.hata = str(e)

    # ── ayarlar ──────────────────────────────────────────────────────────────
    def ayar(self):
        a = self.db.ayar("ortak") or {}
        return {"etkin": a.get("etkin", True), "kota_gb": a.get("kota_gb", 20), "tahta_izin": a.get("tahta_izin", "tam")}

    def etkin(self):
        return bool(self.ayar()["etkin"])

    def kota(self):
        return int(float(self.ayar()["kota_gb"]) * 1024 ** 3)

    def kullanilan(self):
        r = self.db.bir("SELECT COALESCE(SUM(boyut), 0) AS t, COUNT(*) AS n FROM ortak WHERE sil=0 AND tur='f'")
        return int(r["t"]), int(r["n"])

    # ── iç yardımcılar ───────────────────────────────────────────────────────
    def satir(self, yol):
        return self.db.bir("SELECT * FROM ortak WHERE anahtar=?", (yol.lower(),))

    def tam(self, yol):
        p = self.kok
        for parca in yol.split("/"):
            p = p / parca
        return p

    def guvenli(self, yol):
        """Kök altındaki ara klasörlerin kısayol/bağlantı olmadığını doğrular."""
        p = self.kok
        for parca in yol.split("/")[:-1]:
            p = p / parca
            if p.is_symlink():
                raise OrtakHata("Geçersiz klasör yolu")
        return self.tam(yol)

    def _rev(self):
        self.rev += 1
        self.db.ayar_yaz("ortak_rev", self.rev)
        return self.rev

    def kaydet(self, yol, tur, boyut=0, mtime=0.0, oz="", kim="", ymt=0):
        with self.kilit:
            rev = self._rev()
            self.db.x("INSERT OR REPLACE INTO ortak(anahtar, yol, tur, boyut, mtime, ozet, rev, sil, kim, zaman, ymt) "
                      "VALUES(?,?,?,?,?,?,?,0,?,?,?)",
                      (yol.lower(), yol, tur, boyut, mtime, oz, rev, kim, time.time(), ymt))
        self.bildir()
        return rev

    def sil_kaydet(self, yol, kim):
        with self.kilit:
            rev = self._rev()
            self.db.x("UPDATE ortak SET sil=1, rev=?, kim=?, zaman=? WHERE anahtar=?", (rev, kim, time.time(), yol.lower()))
        self.bildir()
        return rev

    def bildir(self):
        with self.kosul:
            self.kosul.notify_all()

    def bekle(self, rev, sure=25):
        bitis = time.time() + sure
        with self.kosul:
            while self.rev == rev:
                kalan = bitis - time.time()
                if kalan <= 0:
                    break
                self.kosul.wait(kalan)
        return self.rev

    def ust_klasorler(self, yol, kim, kendisi=False):
        parcalar = yol.split("/")
        son = len(parcalar) if kendisi else len(parcalar) - 1
        for i in range(1, son + 1):
            y = "/".join(parcalar[:i])
            with self.kilit:
                r = self.satir(y)
                if r and not r["sil"]:
                    if r["tur"] == "d":
                        p = self.guvenli(r["yol"])
                        if not p.is_dir():
                            p.mkdir(exist_ok=True)
                        continue
                    raise OrtakHata("Aynı adda bir dosya var: " + r["yol"], 409)
                p = self.guvenli(y)
                if p.exists() and not p.is_dir():
                    raise OrtakHata("Aynı adda bir dosya var: " + y, 409)
                p.mkdir(exist_ok=True)
                self.kaydet(y, "d", kim=kim)

    # ── yönetim bilgisayarındaki değişiklikleri bul ──────────────────────────
    def tara(self):
        if not self.etkin():
            return
        try:
            self.kok.mkdir(parents=True, exist_ok=True)
            self.hata = None
        except OSError as e:
            self.hata = str(e)
            return
        gorulen = {}
        for kok, dizinler, dosyalar in os.walk(str(self.kok)):
            rel = os.path.relpath(kok, str(self.kok))
            rel = "" if rel == "." else rel.replace(os.sep, "/")
            tut = []
            for d in dizinler:
                y = rel + "/" + d if rel else d
                if ad_hatasi(d) or len(y) > 240 or os.path.islink(os.path.join(kok, d)):
                    continue
                tut.append(d)
                gorulen[y.lower()] = (y, "d", 0, 0.0, 0)
            dizinler[:] = tut
            for f in dosyalar:
                y = rel + "/" + f if rel else f
                if ad_hatasi(f) or len(y) > 240:
                    continue
                try:
                    st = os.lstat(os.path.join(kok, f))
                except OSError:
                    continue
                if stat.S_ISREG(st.st_mode):
                    gorulen[y.lower()] = (y, "f", st.st_size, st.st_mtime, st.st_mtime_ns)
        mevcut = {r["anahtar"]: r for r in self.db.q("SELECT anahtar, yol, tur, boyut, ozet, ymt FROM ortak WHERE sil=0")}
        n = time.time()
        for k, (y, t, b, mt, mtn) in gorulen.items():
            r = mevcut.get(k)
            if t == "d":
                if r and r["tur"] == "d":
                    continue
                with self.kilit:
                    r = self.satir(y)
                    if r and not r["sil"] and r["tur"] == "d":
                        continue
                    if r and not r["sil"]:
                        self.sil_kaydet(r["yol"], YONETIM)
                    self.kaydet(y, "d", kim=YONETIM)
                continue
            if r and r["tur"] == "f" and r["boyut"] == b and r["ymt"] == mtn:
                self.onceki.pop(k, None)
                continue
            o = self.onceki.get(k)
            if not o or o[:2] != (b, mtn):
                self.onceki[k] = (b, mtn, n)
                continue
            if n - mt < 2:
                continue
            p = self.tam(y)
            if kullanimda(p) and n - o[2] < 60:
                continue
            try:
                h = ozet(p)
            except OSError:
                continue
            with self.kilit:
                try:
                    st = os.lstat(str(p))
                except OSError:
                    continue
                if (st.st_size, st.st_mtime_ns) != (b, mtn):
                    continue
                r = self.satir(y)
                if r and not r["sil"] and r["tur"] == "f" and r["ozet"] == h:
                    self.db.x("UPDATE ortak SET boyut=?, ymt=? WHERE anahtar=?", (b, mtn, k))
                else:
                    if r and not r["sil"] and r["tur"] == "d":
                        self.sil_kaydet(r["yol"], YONETIM)
                    yeni = not (r and not r["sil"])
                    self.kaydet(y, "f", b, mt, h, YONETIM, mtn)
                    self.olay("", "ortak", "{}: {} ({})".format("Eklendi" if yeni else "Değiştirildi", y, YONETIM))
            self.onceki.pop(k, None)
        for k, r in mevcut.items():
            if k in gorulen:
                continue
            with self.kilit:
                r2 = self.satir(r["yol"])
                if not r2 or r2["sil"] or os.path.lexists(str(self.tam(r2["yol"]))):
                    continue
                self.sil_kaydet(r2["yol"], YONETIM)
            if r["tur"] == "f":
                self.olay("", "ortak", "Silindi: {} ({})".format(r["yol"], YONETIM))
        for k in [k for k in self.onceki if k not in gorulen]:
            self.onceki.pop(k, None)
        if n - self.son_temizlik > 3600:
            self.son_temizlik = n
            self.temizle()

    # ── cihazlara liste ──────────────────────────────────────────────────────
    def liste(self, rev):
        with self.kilit:
            simdi = self.rev
            kirpma = int(self.db.ayar("ortak_kirpma") or 0)
            tam = rev <= 0 or rev < kirpma or rev > simdi
            if tam:
                satirlar = self.db.q("SELECT * FROM ortak WHERE sil=0")
            else:
                satirlar = self.db.q("SELECT * FROM ortak WHERE rev>?", (rev,))
        return {"rev": simdi, "tam": tam, "kimlik": self.kimlik,
                "girdiler": [{"yol": r["yol"], "t": r["tur"], "b": r["boyut"], "m": r["mtime"], "h": r["ozet"],
                              "r": r["rev"], "sil": r["sil"]} for r in satirlar]}

    def indir_yolu(self, yol):
        yol = yol_dogrula(yol)
        r = self.satir(yol)
        if not r or r["sil"] or r["tur"] != "f":
            raise OrtakHata("Dosya bulunamadı", 404)
        p = self.tam(r["yol"])
        if not p.is_file():
            raise OrtakHata("Dosya bulunamadı", 404)
        return p, r

    # ── yükleme ──────────────────────────────────────────────────────────────
    def yukle(self, yol, akis, uzunluk, kim, temel=0, mtime=None, ustune=False, izin=None):
        def bosalt():
            kalan = uzunluk
            while kalan > 0:
                p = akis.read(min(kalan, 1 << 20))
                if not p:
                    break
                kalan -= len(p)
        try:
            yol = yol_dogrula(yol)
            if not self.etkin():
                raise OrtakHata("Ortak klasör yönetim panelinden kapatılmış", 403)
            r = self.satir(yol)
            canli = bool(r and not r["sil"])
            if canli and r["tur"] == "d":
                raise OrtakHata("Aynı adda bir klasör var", 409)
            eski = r["boyut"] if canli else 0
            kullanilan, _ = self.kullanilan()
            if kullanilan - eski + uzunluk > self.kota():
                raise OrtakHata("Ortak klasör dolu. Panelden yer açın veya sınırı artırın.", 507)
            self.ust_klasorler(yol, kim)
            dizin = self.guvenli(yol).parent
        except OrtakHata:
            bosalt()
            raise
        gecici = dizin / (".tys-yukle-" + uuid.uuid4().hex[:10])
        h = hashlib.sha1()
        kalan = uzunluk
        try:
            with open(str(gecici), "wb") as f:
                gizle(gecici)
                while kalan > 0:
                    p = akis.read(min(kalan, 1 << 18))
                    if not p:
                        break
                    f.write(p)
                    h.update(p)
                    kalan -= len(p)
            if kalan:
                raise OrtakHata("Dosya eksik yüklendi", 400)
            oz = h.hexdigest()
            with self.kilit:
                r = self.satir(yol)
                canli = bool(r and not r["sil"])
                if canli and r["tur"] == "d":
                    raise OrtakHata("Aynı adda bir klasör var", 409)
                if canli and r["ozet"] == oz:
                    return {"r": r["rev"], "h": oz, "yol": r["yol"], "degismedi": True}
                if canli and izin == "ekleme":
                    raise OrtakHata("Bu tahtada var olan dosyalar değiştirilemez", 403)
                if canli and not ustune and temel != r["rev"]:
                    raise OrtakHata("Dosya başka bir yerde değiştirildi", 409)
                hedef_yol = r["yol"] if canli else yol
                hedef = self.guvenli(hedef_yol)
                if canli and hedef.is_file():
                    self.surum_sakla(r, hedef)
                try:
                    os.replace(str(gecici), str(hedef))
                except OSError as e:
                    if acik_hatasi(e):
                        raise OrtakHata("Dosya yönetim bilgisayarında açık; kapatılınca eşitlenecek", 423)
                    raise
                if mtime:
                    try:
                        os.utime(str(hedef), (mtime, mtime))
                    except OSError:
                        pass
                st = os.stat(str(hedef))
                rev = self.kaydet(hedef_yol, "f", st.st_size, st.st_mtime, oz, kim, st.st_mtime_ns)
            self.olay("", "ortak", "{}: {} ({})".format("Değiştirildi" if canli else "Eklendi", hedef_yol, kim))
            return {"r": rev, "h": oz, "yol": hedef_yol}
        finally:
            if gecici.exists():
                try:
                    gecici.unlink()
                except OSError:
                    pass

    def surum_sakla(self, r, hedef):
        sid = uuid.uuid4().hex[:12]
        d = self.surum / sid
        try:
            d.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(hedef), str(d / hedef.name))
            self.db.x("INSERT INTO ortak_surum(id, anahtar, yol, boyut, zaman, kim) VALUES(?,?,?,?,?,?)",
                      (sid, r["anahtar"], r["yol"], r["boyut"], time.time(), r["kim"]))
            for e in self.db.q("SELECT id FROM ortak_surum WHERE anahtar=? ORDER BY zaman DESC", (r["anahtar"],))[SURUM_SAYISI:]:
                self.surum_sil(e["id"])
        except OSError:
            shutil.rmtree(str(d), ignore_errors=True)

    def surum_sil(self, sid):
        self.db.x("DELETE FROM ortak_surum WHERE id=?", (sid,))
        shutil.rmtree(str(self.surum / re.sub(r"[^a-f0-9]", "", sid)), ignore_errors=True)

    # ── silme ve klasör ──────────────────────────────────────────────────────
    def sil(self, yol, kim, temel=0, izin=None):
        yol = yol_dogrula(yol)
        with self.kilit:
            r = self.satir(yol)
            if not r or r["sil"]:
                raise OrtakHata("Bulunamadı", 404)
            if izin == "ekleme":
                raise OrtakHata("Bu tahtada ortak klasörden silme izni yok", 403)
            if temel and temel != r["rev"]:
                raise OrtakHata("Dosya başka bir yerde değiştirildi", 409)
            p = self.guvenli(r["yol"])
            if r["tur"] == "d":
                if self.db.bir("SELECT 1 AS x FROM ortak WHERE sil=0 AND anahtar LIKE ? ESCAPE '\\' LIMIT 1",
                               (like_kacis(r["anahtar"]) + "/%",)):
                    raise OrtakHata("Klasör boş değil", 409)
                if p.is_dir():
                    for c in os.listdir(str(p)):
                        if yoksay(c) and os.path.isfile(str(p / c)):
                            try:
                                os.remove(str(p / c))
                            except OSError:
                                pass
                    try:
                        p.rmdir()
                    except OSError:
                        raise OrtakHata("Klasör boş değil", 409)
                rev = self.sil_kaydet(r["yol"], kim)
            else:
                if p.exists():
                    cid = uuid.uuid4().hex[:12]
                    d = self.cop / cid
                    d.mkdir(parents=True, exist_ok=True)
                    try:
                        tasi(str(p), str(d / p.name))
                    except OSError as e:
                        shutil.rmtree(str(d), ignore_errors=True)
                        if acik_hatasi(e):
                            raise OrtakHata("Dosya yönetim bilgisayarında açık; kapatılınca silinecek", 423)
                        raise
                    self.db.x("INSERT INTO ortak_cop(id, yol, boyut, zaman, kim, sahip) VALUES(?,?,?,?,?,?)",
                              (cid, r["yol"], r["boyut"], time.time(), kim, r["kim"]))
                rev = self.sil_kaydet(r["yol"], kim)
        if r["tur"] == "f":
            self.olay("", "ortak", "Silindi: {} ({})".format(r["yol"], kim))
        return {"r": rev}

    def sil_agac(self, yol, kim):
        yol = yol_dogrula(yol)
        r = self.satir(yol)
        if not r or r["sil"]:
            raise OrtakHata("Bulunamadı", 404)
        if r["tur"] == "d":
            cocuklar = self.db.q("SELECT yol FROM ortak WHERE sil=0 AND anahtar LIKE ? ESCAPE '\\'",
                                 (like_kacis(r["anahtar"]) + "/%",))
            for c in sorted(cocuklar, key=lambda x: -x["yol"].count("/")):
                self.sil(c["yol"], kim)
        return self.sil(yol, kim)

    def klasor(self, yol, kim):
        yol = yol_dogrula(yol)
        if not self.etkin():
            raise OrtakHata("Ortak klasör yönetim panelinden kapatılmış", 403)
        self.ust_klasorler(yol, kim, kendisi=True)
        return {"r": self.satir(yol)["rev"]}

    def icerik(self, klasor=""):
        klasor = yol_dogrula(klasor) if klasor else ""
        if klasor:
            r = self.satir(klasor)
            if not r or r["sil"] or r["tur"] != "d":
                raise OrtakHata("Klasör bulunamadı", 404)
            klasor = r["yol"]
            satirlar = self.db.q("SELECT yol, tur, boyut, mtime, kim, zaman FROM ortak WHERE sil=0 AND anahtar LIKE ? ESCAPE '\\'",
                                 (like_kacis(klasor.lower()) + "/%",))
        else:
            satirlar = self.db.q("SELECT yol, tur, boyut, mtime, kim, zaman FROM ortak WHERE sil=0")
        derinlik = klasor.count("/") + 1 if klasor else 0
        sayac = {}
        for s in satirlar:
            if s["yol"].count("/") > derinlik:
                ust = "/".join(s["yol"].split("/")[:derinlik + 1]).lower()
                sayac[ust] = sayac.get(ust, 0) + (1 if s["tur"] == "f" else 0)
        ogeler = []
        for s in satirlar:
            if s["yol"].count("/") == derinlik:
                o = dict(s, ad=s["yol"].split("/")[-1])
                if s["tur"] == "d":
                    o["sayi"] = sayac.get(s["yol"].lower(), 0)
                ogeler.append(o)
        return klasor, ogeler

    # ── çöp kutusu ve sürümler ───────────────────────────────────────────────
    def cop_listesi(self):
        return self.db.q("SELECT * FROM ortak_cop ORDER BY zaman DESC LIMIT 300")

    def bos_ad(self, yol, ek):
        kok, uz = os.path.splitext(yol)
        aday, i = yol, 1
        while True:
            s = self.satir(aday)
            if not (s and not s["sil"]) and not self.tam(aday).exists():
                return aday
            aday = "{} ({}{}){}".format(kok, ek, "" if i == 1 else " " + str(i), uz)
            i += 1

    def geri_yukle(self, cid, kim):
        cid = re.sub(r"[^a-f0-9]", "", cid or "")
        r = self.db.bir("SELECT * FROM ortak_cop WHERE id=?", (cid,))
        if not r:
            raise OrtakHata("Çöp kutusunda bulunamadı", 404)
        d = self.cop / cid
        dosyalar = list(d.iterdir()) if d.is_dir() else []
        if not dosyalar:
            self.db.x("DELETE FROM ortak_cop WHERE id=?", (cid,))
            raise OrtakHata("Dosya çöp kutusunda bulunamadı", 404)
        with self.kilit:
            hedef_yol = self.bos_ad(r["yol"], "geri yüklendi")
            self.ust_klasorler(hedef_yol, kim)
            hedef = self.guvenli(hedef_yol)
            tasi(str(dosyalar[0]), str(hedef))
            st = os.stat(str(hedef))
            self.kaydet(hedef_yol, "f", st.st_size, st.st_mtime, ozet(hedef), kim, st.st_mtime_ns)
        self.db.x("DELETE FROM ortak_cop WHERE id=?", (cid,))
        shutil.rmtree(str(d), ignore_errors=True)
        self.olay("", "ortak", "Çöp kutusundan geri yüklendi: {}".format(hedef_yol))
        return {"yol": hedef_yol}

    def cop_sil(self, cid):
        cid = re.sub(r"[^a-f0-9]", "", cid or "")
        self.db.x("DELETE FROM ortak_cop WHERE id=?", (cid,))
        if cid:
            shutil.rmtree(str(self.cop / cid), ignore_errors=True)

    def surumler(self, yol):
        return self.db.q("SELECT * FROM ortak_surum WHERE anahtar=? ORDER BY zaman DESC", (yol_dogrula(yol).lower(),))

    def surum_geri(self, sid, kim):
        sid = re.sub(r"[^a-f0-9]", "", sid or "")
        r = self.db.bir("SELECT * FROM ortak_surum WHERE id=?", (sid,))
        d = self.surum / sid
        dosyalar = list(d.iterdir()) if r and d.is_dir() else []
        if not dosyalar:
            raise OrtakHata("Sürüm bulunamadı", 404)
        with open(str(dosyalar[0]), "rb") as f:
            sonuc = self.yukle(r["yol"], f, dosyalar[0].stat().st_size, kim, ustune=True)
        self.olay("", "ortak", "Eski sürüm geri yüklendi: {}".format(r["yol"]))
        return sonuc

    def temizle(self):
        sinir = time.time() - SAKLAMA_GUN * 86400
        for r in self.db.q("SELECT id FROM ortak_cop WHERE zaman<?", (sinir,)):
            self.cop_sil(r["id"])
        for r in self.db.q("SELECT id FROM ortak_surum WHERE zaman<?", (sinir,)):
            self.surum_sil(r["id"])
        with self.kilit:
            m = self.db.bir("SELECT MAX(rev) AS m FROM ortak WHERE sil=1 AND zaman<?", (sinir,))
            if m and m["m"]:
                self.db.x("DELETE FROM ortak WHERE sil=1 AND zaman<?", (sinir,))
                self.db.ayar_yaz("ortak_kirpma", max(int(self.db.ayar("ortak_kirpma") or 0), int(m["m"])))
        try:
            for kok, _, dosyalar in os.walk(str(self.kok)):
                for f in dosyalar:
                    if f.startswith(".tys-yukle-"):
                        p = os.path.join(kok, f)
                        if time.time() - os.path.getmtime(p) > 86400:
                            os.remove(p)
        except OSError:
            pass

    def ozet_bilgi(self):
        kullanilan, sayi = self.kullanilan()
        cop = self.db.bir("SELECT COUNT(*) AS n, COALESCE(SUM(boyut), 0) AS t FROM ortak_cop")
        klasor = self.db.bir("SELECT COUNT(*) AS n FROM ortak WHERE sil=0 AND tur='d'")
        a = self.ayar()
        return {"etkin": a["etkin"], "kota_gb": a["kota_gb"], "tahta_izin": a["tahta_izin"], "kota": self.kota(),
                "kullanilan": kullanilan, "dosya": sayi, "klasor": klasor["n"], "cop_sayi": cop["n"], "cop_boyut": cop["t"],
                "yol": str(self.kok), "hata": self.hata}
