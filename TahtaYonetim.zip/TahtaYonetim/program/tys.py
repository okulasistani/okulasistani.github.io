# -*- coding: utf-8 -*-
"""
Tahta Yönetim Sistemi — Sunucu
------------------------------
İdareci (Windows) bilgisayarında çalışır. Yalnızca Python'un standart
kütüphanesini kullanır; ek paket kurmaya gerek yoktur.

Görevleri:
  * Tahtalardaki ajanlarla haberleşmek (uzun bağlantı ile anında komut)
  * Web yönetim panelini sunmak (bilgisayar ve telefon)
  * Zamanlayıcı, Wake-on-LAN, dosya paylaşımı, kullanım kayıtları
"""
import os
import re
import sys
import csv
import io
import json
import time
import uuid
import socket
import sqlite3
import hashlib
import hmac
import secrets
import logging
import mimetypes
import shutil
import platform
import subprocess
import threading
from datetime import datetime
from pathlib import Path
from logging.handlers import RotatingFileHandler
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from socketserver import TCPServer
from urllib.parse import urlparse, parse_qs, unquote, quote

SURUM = "3.2.0"
PORT = int(os.environ.get("TYS_PORT", "8765"))
KESIF_PORT = 8766
PROGRAM = Path(__file__).resolve().parent
VERI = Path(os.environ.get("TYS_VERI") or (PROGRAM.parent / "veri"))
WEB = PROGRAM / "web"
AJAN_DOSYA = PROGRAM / "ajan" / "tahta-ajan.py"
KUR_SABLON = PROGRAM / "ajan" / "kur.sh"
KALDIR_SABLON = PROGRAM / "ajan" / "kaldir.sh"
TANI_SABLON = PROGRAM / "ajan" / "tani.sh"
KUR_PS1 = PROGRAM / "kur.ps1"
ORTAK_YOL = Path(os.environ.get("TYS_ORTAK") or (Path.home() / "Ortak Klasör"))
if str(PROGRAM) not in sys.path:
    sys.path.insert(0, str(PROGRAM))
import ortak as ortak_mod  # noqa: E402

CEVRIMICI_SN = 50          # bu kadar süre haber gelmezse tahta "kapalı" sayılır
SENK_BEKLEME = 20          # ajan isteği komut yoksa en fazla bu kadar bekletilir
BASLAMA = time.time()

log = logging.getLogger("tys")

KOMUT_ADI = {
    "kilitle": "Kilitle", "kilit_ac": "Kilidi aç", "kapat": "Kapat",
    "kapat_iptal": "Kapatmayı iptal et", "yeniden_baslat": "Yeniden başlat",
    "uyku": "Uyku modu", "duyuru": "Duyuru", "zil": "Zil", "dosya": "Dosya",
    "ac": "Uzaktan başlat", "kaldir": "Programı kaldır",
    "icerik_ac": "Site / dosya aç", "guncelle": "Sistem güncellemesi", "paket_kur": "Uygulama kur",
    "paket_kaldir": "Uygulama kaldır", "engel_ara": "Site engeline ara ver", "tani": "Tanı raporu",
}
PANEL_KOMUTLARI = set(KOMUT_ADI) - {"dosya"}
KURAL_KOMUTLARI = {"kilitle", "kilit_ac", "kapat", "yeniden_baslat", "uyku", "zil", "duyuru", "ac", "guncelle", "kilit_araligi"}
KOMUT_OMRU = {"dosya": 7 * 86400, "kaldir": 30 * 86400, "guncelle": 3600, "paket_kur": 3600, "paket_kaldir": 3600}
ARIZA_TURLERI = ["Ses yok", "Dokunmatik / kalem çalışmıyor", "Görüntü sorunu", "İnternet yok",
                 "Yavaş / donuyor", "Diğer"]
# Pardus paket adı (ör. vlc) veya Windows winget kimliği (ör. VideoLAN.VLC)
PAKET_DESEN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9+._\-]{0,80}$")

VARSAYILAN_AYAR = {
    "okul_adi": "",
    "kurulum_tamam": False,
    "sifre": "",
    "anahtar": "",
    "kimlik": "",
    "pinler": [],
    "kilit": {
        "acilista": True,
        "bosta_kilit_dk": 0,
        "bosta_kapat_dk": 0,
        "mesaj": "Bu tahta kilitlidir. Kullanmak için öğretmen şifrenizi girin.",
        "duyuru_goster": True,
    },
    "zamanlayici_etkin": True,
    "onizleme": True,
    "zil_sesi_ac": True,
    "zil_ozel": {},
    "panolar": [],
    "istemci_anahtar": "",
    "ortak": {"etkin": True, "kota_gb": 20, "tahta_izin": "tam"},
    "site_engel": {"etkin": False, "siteler": [], "hedef": {"hepsi": True}, "zaman": "her_zaman", "araliklar": []},
    "sinavlar": [],
    "saatler": [],
    "saat_koruyucu_dk": 0,
    "ariza_simge": True,
}

SEMA = """
CREATE TABLE IF NOT EXISTS ayar(anahtar TEXT PRIMARY KEY, deger TEXT);
CREATE TABLE IF NOT EXISTS tahta(id TEXT PRIMARY KEY, ad TEXT, grup TEXT DEFAULT '',
    bilgi TEXT DEFAULT '{}', eklenme REAL, son REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS olay(id INTEGER PRIMARY KEY AUTOINCREMENT, zaman REAL,
    tahta TEXT, tur TEXT, mesaj TEXT);
CREATE INDEX IF NOT EXISTS olay_zaman ON olay(zaman);
CREATE TABLE IF NOT EXISTS kural(id TEXT PRIMARY KEY, veri TEXT);
CREATE TABLE IF NOT EXISTS dosya(id TEXT PRIMARY KEY, ad TEXT, boyut INTEGER, zaman REAL,
    hedefler TEXT, teslim TEXT DEFAULT '[]', ac INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS kullanim(gun TEXT, tahta TEXT, acik REAL DEFAULT 0,
    aktif REAL DEFAULT 0, PRIMARY KEY(gun, tahta));
CREATE TABLE IF NOT EXISTS oturum(belirtec TEXT PRIMARY KEY, bitis REAL);
CREATE TABLE IF NOT EXISTS bekleyen(id TEXT PRIMARY KEY, tahta TEXT, tur TEXT, veri TEXT,
    olusma REAL, gecerlilik REAL);
CREATE INDEX IF NOT EXISTS bekleyen_tahta ON bekleyen(tahta);
CREATE TABLE IF NOT EXISTS ortak(anahtar TEXT PRIMARY KEY, yol TEXT, tur TEXT, boyut INTEGER DEFAULT 0,
    mtime REAL DEFAULT 0, ozet TEXT DEFAULT '', rev INTEGER, sil INTEGER DEFAULT 0, kim TEXT DEFAULT '',
    zaman REAL, ymt INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ortak_rev ON ortak(rev);
CREATE TABLE IF NOT EXISTS ortak_cop(id TEXT PRIMARY KEY, yol TEXT, boyut INTEGER, zaman REAL, kim TEXT, sahip TEXT);
CREATE TABLE IF NOT EXISTS ortak_surum(id TEXT PRIMARY KEY, anahtar TEXT, yol TEXT, boyut INTEGER, zaman REAL, kim TEXT);
CREATE TABLE IF NOT EXISTS istemci(id TEXT PRIMARY KEY, ad TEXT, bilgi TEXT DEFAULT '{}', son REAL, eklenme REAL);
CREATE TABLE IF NOT EXISTS ariza(id INTEGER PRIMARY KEY AUTOINCREMENT, tahta TEXT, kategori TEXT, aciklama TEXT,
    bildiren TEXT, zaman REAL, durum TEXT DEFAULT 'yeni', notlar TEXT DEFAULT '', guncelleme REAL);
CREATE TABLE IF NOT EXISTS aralik(id INTEGER PRIMARY KEY AUTOINCREMENT, tahta TEXT, tur TEXT, ad TEXT DEFAULT '',
    bas REAL, bit REAL);
CREATE INDEX IF NOT EXISTS aralik_bas ON aralik(bas);
"""


# ─────────────────────────────────────────────────────────────────────────────
# Veritabanı
# ─────────────────────────────────────────────────────────────────────────────

class Veritabani:
    def __init__(self, yol):
        self.c = sqlite3.connect(str(yol), check_same_thread=False, isolation_level=None)
        self.c.row_factory = sqlite3.Row
        self.k = threading.RLock()
        with self.k:
            self.c.execute("PRAGMA journal_mode=WAL")
            self.c.execute("PRAGMA synchronous=NORMAL")
            self.c.executescript(SEMA)
            # 3.0 sürümünden yükseltme
            for tablo, kolon, tanim in (("oturum", "tur", "TEXT DEFAULT 'yonetici'"), ("oturum", "ad", "TEXT DEFAULT ''")):
                try:
                    self.c.execute("ALTER TABLE {} ADD COLUMN {} {}".format(tablo, kolon, tanim))
                except sqlite3.OperationalError:
                    pass

    def q(self, sql, args=()):
        with self.k:
            return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def bir(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.k:
            return self.c.execute(sql, args).rowcount

    def ayar(self, anahtar):
        r = self.bir("SELECT deger FROM ayar WHERE anahtar=?", (anahtar,))
        if r is None:
            v = VARSAYILAN_AYAR.get(anahtar)
            return json.loads(json.dumps(v))
        return json.loads(r["deger"])

    def ayar_yaz(self, anahtar, deger):
        self.x("INSERT OR REPLACE INTO ayar(anahtar, deger) VALUES(?,?)",
               (anahtar, json.dumps(deger, ensure_ascii=False)))


db = None    # calistir() içinde kurulur
depo = None  # Ortak Klasör deposu


# ─────────────────────────────────────────────────────────────────────────────
# Canlı durum (bellekte)
# ─────────────────────────────────────────────────────────────────────────────

class CanliTahta:
    def __init__(self, tid):
        self.id = tid
        self.kosul = threading.Condition()
        self.nesil = 0
        self.bekliyor = False
        self.son = 0.0
        self.durum = {}
        self.cevrimici = False
        self.son_sayim = 0.0
        self.ekran = {}          # boyut -> (zaman, mime, bayt)
        self.ekran_istek = {}    # boyut -> istek zamanı


canli = {}
canli_kilit = threading.Lock()
silinenler = {}  # tahta id -> silinme zamanı (yeniden kaydı kısa süre engeller)


def canli_al(tid):
    with canli_kilit:
        c = canli.get(tid)
        if c is None:
            c = canli[tid] = CanliTahta(tid)
        return c


def cevrimici_mi(c):
    return bool(c) and (c.bekliyor or time.time() - c.son < CEVRIMICI_SN)


def uyandir(tid):
    c = canli.get(tid)
    if c:
        with c.kosul:
            c.kosul.notify_all()


def hepsini_uyandir():
    for tid in list(canli):
        uyandir(tid)


# ─────────────────────────────────────────────────────────────────────────────
# Yardımcılar
# ─────────────────────────────────────────────────────────────────────────────

def simdi():
    return time.time()


def utc_ofset():
    return int(datetime.now().astimezone().utcoffset().total_seconds())


def olay(tahta, tur, mesaj):
    try:
        db.x("INSERT INTO olay(zaman, tahta, tur, mesaj) VALUES(?,?,?,?)",
             (simdi(), tahta or "", tur, mesaj[:500]))
    except Exception:
        log.exception("olay yazılamadı")


def tahta_adi(tid):
    r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
    return r["ad"] if r else tid[:8]


def sifre_ozet(sifre, tuz=None, tekrar=200000):
    tuz = tuz or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz.encode(), tekrar).hex()
    return "pbkdf2${}${}${}".format(tekrar, tuz, h)


def sifre_dogru(sifre, kayit):
    try:
        _, tekrar, tuz, h = kayit.split("$")
        h2 = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz.encode(), int(tekrar)).hex()
        return hmac.compare_digest(h, h2)
    except Exception:
        return False


def guvenli_ad(ad):
    ad = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", ad or "").strip(" .")
    return (ad or "dosya")[:150]


def pin_bul(pin):
    """Tahta açma şifresine (PIN) karşılık gelen kaydı döner."""
    pin = re.sub(r"\D", "", str(pin or ""))[:12]
    if not pin:
        return None
    for p in db.ayar("pinler") or []:
        if hmac.compare_digest(hashlib.sha256((p["tuz"] + pin).encode()).hexdigest(), p["ozet"]):
            return p
    return None


def alan_temizle(s):
    """'https://www.youtube.com/watch' → 'youtube.com'"""
    s = str(s or "").strip().lower()
    s = re.sub(r"^[a-z]+://", "", s)
    s = s.split("/")[0].split("?")[0].split(":")[0].strip(".")
    if s.startswith("*."):
        s = s[2:]
    if s.startswith("www."):
        s = s[4:]
    try:
        s = s.encode("idna").decode("ascii")
    except Exception:
        return None
    return s if (len(s) <= 120 and re.match(r"^[a-z0-9-]+(\.[a-z0-9-]+)+$", s)) else None


ISTEMCI_BAT = r"""@echo off
setlocal
title Ortak Klasor - Kurulum
set "TYS_SUNUCU=__SUNUCU__"
set "TYS_ANAHTAR=__ANAHTAR__"
set "TYS_KIMLIK=__KIMLIK__"
set "TYS_PS=%TEMP%\tys-ortak-kur-%RANDOM%.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$s.IndexOf('#'+'TYS-PS1#'); [IO.File]::WriteAllText($env:TYS_PS,$s.Substring($i),(New-Object Text.UTF8Encoding $true))"
if errorlevel 1 goto hata
powershell -NoProfile -ExecutionPolicy Bypass -File "%TYS_PS%" -Istemci -Sunucu "%TYS_SUNUCU%" -Anahtar "%TYS_ANAHTAR%" -Kimlik "%TYS_KIMLIK%"
del "%TYS_PS%" >nul 2>&1
echo.
pause
exit /b 0
:hata
echo.
echo  Kurulum dosyasi okunamadi. Dosyayi Masaustune kaydedip yeniden calistirin.
pause
exit /b 1
"""


TAHTA_BAT = r"""@echo off
setlocal
title Tahta Yonetim - Windows tahta kurulumu
set "TYS_SUNUCU=__SUNUCU__"
set "TYS_ANAHTAR=__ANAHTAR__"
set "TYS_KIMLIK=__KIMLIK__"
set "TYS_AD=__AD__"
set "TYS_PS=%TEMP%\tys-tahta-kur-%RANDOM%.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$s.IndexOf('#'+'TYS-PS1#'); [IO.File]::WriteAllText($env:TYS_PS,$s.Substring($i),(New-Object Text.UTF8Encoding $true))"
if errorlevel 1 goto hata
powershell -NoProfile -ExecutionPolicy Bypass -File "%TYS_PS%" -Tahta -Sunucu "%TYS_SUNUCU%" -Anahtar "%TYS_ANAHTAR%" -Kimlik "%TYS_KIMLIK%" -Ad "%TYS_AD%"
del "%TYS_PS%" >nul 2>&1
echo.
pause
exit /b 0
:hata
echo.
echo  Kurulum dosyasi okunamadi. Dosyayi Masaustune kaydedip yeniden calistirin.
pause
exit /b 1
"""


SANAL_AGLAR = ("192.168.56.", "192.168.99.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.",
               "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.")


def ekran_boyutu(b):
    return b if b in ("kucuk", "buyuk", "tam") else "kucuk"


def tahta_adi_temizle(ad):
    """Kurulum komutuyla gelen tahta adı: kabuk ve JSON için güvenli karakterler, en fazla 40."""
    ad = str(ad or "")
    try:                                   # kodlanmadan gönderilmiş UTF-8 (ör. elle yazılan komut)
        ad = ad.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    ad = re.sub(r"[^\w .()\-/+#,]", "", str(ad or ""))
    return re.sub(r"\s+", " ", ad).strip()[:40]


def yerel_adresler():
    """Bilgisayarın ağdaki IPv4 adresleri; tahtaların kullanacağı adres başta.
    Sıra: tahtaların bulunduğu ağ > internete çıkılan (varsayılan) bağlantı > diğerleri > sanal ağlar."""
    adresler = []

    def ekle(ip):
        if ip and ip not in adresler and not ip.startswith(("127.", "169.254.", "0.")):
            adresler.append(ip)
    for hedef in ("8.8.8.8", "10.255.255.255", "192.168.255.255", "172.31.255.255"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((hedef, 9))          # paket gönderilmez; yalnızca hangi bağlantının kullanılacağı seçilir
            ekle(s.getsockname()[0])
            s.close()
        except Exception:
            pass
    try:
        for bilgi in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ekle(bilgi[4][0])
    except Exception:
        pass
    tahta_aglari = {}
    try:
        for r in db.q("SELECT bilgi FROM tahta"):
            ip = (json.loads(r["bilgi"] or "{}").get("ip") or "")
            if ip.count(".") == 3:
                ag = ip.rsplit(".", 1)[0]
                tahta_aglari[ag] = tahta_aglari.get(ag, 0) + 1
    except Exception:
        pass

    def sira(i_a):
        i, a = i_a
        return (-tahta_aglari.get(a.rsplit(".", 1)[0], 0), 1 if a.startswith(SANAL_AGLAR) and i else 0, i)
    return [a for _, a in sorted(enumerate(adresler), key=sira)]


def sistem_komutu(komut, zaman=8):
    """Windows komutunu pencere açmadan çalıştırır, çıktısını metin olarak döndürür."""
    try:
        r = subprocess.run(komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=zaman,
                           creationflags=0x08000000 if os.name == "nt" else 0)
        return r.stdout.decode("oem" if os.name == "nt" else "utf-8", "replace")
    except Exception as e:
        return "(çalıştırılamadı: {})".format(e)


def uyku_bilgisi():
    if os.name != "nt":
        return "Windows değil"

    def oku(ayar):
        m = re.search(r"\bAC\b[^:\n]*:\s*(0x[0-9a-fA-F]+)", sistem_komutu(["powercfg", "/query", "SCHEME_CURRENT", "SUB_SLEEP", ayar]))
        return int(m.group(1), 16) if m else None

    def yaz(v):
        return "bilinmiyor" if v is None else ("kapalı" if v == 0 else "{} dk".format(v // 60))
    return "uyku {}, hazırda bekletme {} (prize takılıyken)".format(yaz(oku("STANDBYIDLE")), yaz(oku("HIBERNATEIDLE")))


def guvenlik_duvari_bilgisi():
    if os.name != "nt":
        return "Windows değil"
    cikti = sistem_komutu('netsh advfirewall firewall show rule name="Tahta Yonetim Sistemi"')
    return "izin var (bağlantı noktası {})".format(PORT) if str(PORT) in cikti else "İZİN BULUNAMADI — KUR.bat yeniden çalıştırılmalı"


def dosya_sonu(yol, satir):
    try:
        with open(yol, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 200 * 1024))
            return "\n".join(f.read().decode("utf-8", "replace").splitlines()[-satir:])
    except OSError:
        return "(yok)"


def tani_raporu():
    """Destek için tek dosyalık rapor. Şifre, PIN ve anahtar içermez."""
    n = simdi()
    sat = []
    yaz = sat.append

    def zaman(t):
        return datetime.fromtimestamp(t).strftime("%d.%m.%Y %H:%M") if t else "—"
    yaz("TAHTA YÖNETİM SİSTEMİ — TANI RAPORU")
    yaz("Oluşturma: {}".format(zaman(n)))
    yaz("Okul: {}".format(db.ayar("okul_adi") or "—"))
    yaz("Bu rapor şifre, öğretmen şifresi ve bağlantı anahtarı içermez.")
    yaz("")
    yaz("── Yönetim bilgisayarı")
    yaz("Program sürümü: {} · Tahta programı: {}".format(SURUM, AJAN_SURUM))
    yaz("Çalışma süresi: {} dk (başlangıç {})".format(int((n - BASLAMA) / 60), zaman(BASLAMA)))
    yaz("Sistem: {}".format(platform.platform()))
    yaz("Python: {} ({})".format(platform.python_version(), sys.executable))
    yaz("Bilgisayar adı: {}".format(socket.gethostname()))
    yaz("Ağ adresleri (tahtaların kullanacağı başta): {}".format(", ".join(yerel_adresler()) or "—"))
    yaz("Bağlantı noktası: {}".format(PORT))
    yaz("Güvenlik duvarı: {}".format(guvenlik_duvari_bilgisi()))
    yaz("Güç: {}".format(uyku_bilgisi()))
    try:
        bos = shutil.disk_usage(str(VERI)).free
        yaz("Veri klasörü: {} (boş alan {:.1f} GB)".format(VERI, bos / 1e9))
    except Exception:
        yaz("Veri klasörü: {}".format(VERI))
    try:
        o = depo.ozet_bilgi()
        yaz("Ortak Klasör: {} · {} dosya · {:.1f} / {:.0f} GB · tahta izni {}{}".format(
            "açık" if o.get("etkin") else "kapalı", o.get("dosya"), (o.get("kullanilan") or 0) / 1e9,
            (o.get("kota") or 0) / 1e9, o.get("tahta_izin"), " · HATA: " + o["hata"] if o.get("hata") else ""))
    except Exception as e:
        yaz("Ortak Klasör: okunamadı ({})".format(e))
    if os.name == "nt":
        yaz("")
        yaz("── ipconfig")
        yaz(sistem_komutu(["ipconfig"]).strip())
    yaz("")
    tahtalar = db.q("SELECT * FROM tahta ORDER BY ad")
    yaz("── Tahtalar ({})".format(len(tahtalar)))
    for t in tahtalar:
        b = json.loads(t["bilgi"] or "{}")
        c = canli.get(t["id"])
        d = getattr(c, "durum", None) or {}
        cevrimici = cevrimici_mi(c)
        satir = "{} | {} | {} | sürüm {} | {}".format(
            t["ad"] or t["id"], b.get("ip") or "?", "çevrimiçi" if cevrimici else "kapalı (son " + zaman(t["son"]) + ")",
            b.get("surum") or "?", b.get("os") or "?")
        ek = []
        if d.get("ortak"):
            ek.append("ortak: {}{}".format(d["ortak"].get("durum"), " — " + d["ortak"]["mesaj"] if d["ortak"].get("mesaj") else ""))
        if d.get("engel") and d["engel"].get("hata"):
            ek.append("site engeli hatası: " + str(d["engel"]["hata"]))
        g = (d.get("guncelleme") or {}).get("son")
        if g and not g.get("ok"):
            ek.append("güncelleme hatası: " + str(g.get("mesaj")))
        if ek:
            satir += " | " + " | ".join(ek)
        yaz(satir)
    istemciler = db.q("SELECT * FROM istemci ORDER BY ad")
    if istemciler:
        yaz("")
        yaz("── Öğretmen bilgisayarları ({})".format(len(istemciler)))
        for i in istemciler:
            b = json.loads(i["bilgi"] or "{}")
            o = b.get("ortak") or {}
            yaz("{} | {} | son {} | sürüm {} | ortak: {}{}".format(
                i["ad"], b.get("ip") or "?", zaman(i["son"]), b.get("surum") or "?", o.get("durum") or "?",
                " — " + o["mesaj"] if o.get("mesaj") else ""))
    yaz("")
    yaz("── Son olaylar (hata ve sistem)")
    for r in reversed(db.q("SELECT o.zaman, o.tur, o.mesaj, t.ad FROM olay o LEFT JOIN tahta t ON t.id=o.tahta "
                           "WHERE o.tur IN ('hata','sistem','baglanti','guncelleme') ORDER BY o.zaman DESC LIMIT 80")):
        yaz("{} [{}] {}{}".format(zaman(r["zaman"]), r["tur"], (r["ad"] + ": ") if r["ad"] else "", r["mesaj"]))
    klasor = VERI / "tani"
    if klasor.is_dir():
        raporlar = sorted(klasor.glob("*.txt"))[-5:]
        if raporlar:
            yaz("")
            yaz("── Tahtalardan gelen tanı raporları (son {})".format(len(raporlar)))
            for r in raporlar:
                yaz("")
                yaz("### " + r.name)
                yaz(r.read_text(encoding="utf-8", errors="replace")[:12000])
    yaz("")
    yaz("── sunucu.log (son 200 satır)")
    yaz(dosya_sonu(VERI / "sunucu.log", 200))
    yaz("")
    yaz("── hata.log (son 60 satır)")
    yaz(dosya_sonu(VERI / "hata.log", 60))
    return "\n".join(sat) + "\n"



def ajan_surumu():
    try:
        m = re.search(r'^SURUM\s*=\s*"([^"]+)"', AJAN_DOSYA.read_text(encoding="utf-8"), re.M)
        return m.group(1) if m else "?"
    except Exception:
        return "?"


AJAN_SURUM = "?"


# ─────────────────────────────────────────────────────────────────────────────
# Hedef çözümleme, komut kuyruğu
# ─────────────────────────────────────────────────────────────────────────────

def hedef_cozumle(hedef):
    """hedef: {"hepsi":true} | {"grup":"ad"} | {"idler":[...]}  →  tahta id listesi"""
    hedef = hedef or {}
    satirlar = db.q("SELECT id, grup FROM tahta")
    if hedef.get("hepsi"):
        return [r["id"] for r in satirlar]
    if "grup" in hedef:
        return [r["id"] for r in satirlar if (r["grup"] or "") == hedef["grup"]]
    idler = set(hedef.get("idler") or [])
    return [r["id"] for r in satirlar if r["id"] in idler]


def hedef_kapsar(hedef, tid, grup):
    hedef = hedef or {"hepsi": True}
    if hedef.get("hepsi"):
        return True
    if "grup" in hedef:
        return (grup or "") == hedef["grup"]
    return tid in (hedef.get("idler") or [])


def hedef_yazi(hedef, sayi):
    if not hedef or hedef.get("hepsi"):
        return "tüm tahtalar ({})".format(sayi)
    if "grup" in hedef:
        return "{} grubu ({})".format(hedef["grup"] or "Grupsuz", sayi)
    if sayi == 1:
        return tahta_adi(hedef["idler"][0]) if hedef.get("idler") else "1 tahta"
    return "{} tahta".format(sayi)


def komut_ekle(tid, tur, veri=None, omur=None):
    kid = uuid.uuid4().hex[:12]
    n = simdi()
    omur = omur or KOMUT_OMRU.get(tur, 120)
    db.x("INSERT INTO bekleyen(id, tahta, tur, veri, olusma, gecerlilik) VALUES(?,?,?,?,?,?)",
         (kid, tid, tur, json.dumps(veri or {}, ensure_ascii=False), n, n + omur))
    uyandir(tid)
    return kid


def komutlari_al(c):
    n = simdi()
    satirlar = db.q("SELECT * FROM bekleyen WHERE tahta=? ORDER BY olusma", (c.id,))
    komutlar = []
    for r in satirlar:
        db.x("DELETE FROM bekleyen WHERE id=?", (r["id"],))
        if r["gecerlilik"] < n:
            continue
        komutlar.append({"id": r["id"], "tur": r["tur"], "veri": json.loads(r["veri"] or "{}")})
    for boyut, t in list(c.ekran_istek.items()):
        if t and n - t < 20:
            komutlar.append({"id": "ekran-" + boyut, "tur": "ekran", "veri": {"boyut": boyut}})
        c.ekran_istek.pop(boyut, None)
    return komutlar


# ─────────────────────────────────────────────────────────────────────────────
# Ajana gönderilen ayarlar
# ─────────────────────────────────────────────────────────────────────────────

def aralik_atla_bugun():
    """Panelden "bugün için bitir" denen kilitli saat aralıkları."""
    a = db.ayar("aralik_atla") or {}
    return sorted(a.get("idler") or []) if a.get("tarih") == time.strftime("%Y-%m-%d") else []


def ajan_ayari(tid):
    t = db.bir("SELECT ad, grup FROM tahta WHERE id=?", (tid,)) or {"ad": tid[:8], "grup": ""}
    n = simdi()
    kurallar = []
    for r in db.q("SELECT veri FROM kural"):
        k = json.loads(r["veri"])
        if k.get("tur") == "ac" or not k.get("aktif", True):
            continue
        if hedef_kapsar(k.get("hedef"), tid, t["grup"]):
            kurallar.append({x: k.get(x) for x in ("id", "saat", "gunler", "tur", "veri", "aciklama")})
    panolar = []
    for p in db.ayar("panolar"):
        if p.get("bitis", 0) > n and hedef_kapsar(p.get("hedef"), tid, t["grup"]):
            panolar.append({"baslik": p.get("baslik", ""), "metin": p.get("metin", ""), "bitis": p["bitis"]})
    zil = {}
    for tur, bilgi in (db.ayar("zil_ozel") or {}).items():
        zil[tur] = {"ozet": bilgi.get("ozet"), "uzanti": bilgi.get("uzanti")}
    ayar = {
        "ad": t["ad"],
        "okul_adi": db.ayar("okul_adi"),
        "pinler": [{"ad": p["ad"], "tuz": p["tuz"], "ozet": p["ozet"]} for p in db.ayar("pinler")],
        "kilit": db.ayar("kilit"),
        "zamanlayici_etkin": db.ayar("zamanlayici_etkin"),
        "kurallar": kurallar,
        "panolar": panolar,
        "zil_ozel": zil,
        "zil_sesi_ac": db.ayar("zil_sesi_ac"),
        "sinav": None, "saat_ekran": None,
        "saat_koruyucu_dk": int(db.ayar("saat_koruyucu_dk") or 0),
        "site_engel": None,
        "ortak_etkin": bool((db.ayar("ortak") or {}).get("etkin", True)),
        "ariza_simge": bool(db.ayar("ariza_simge")),
        "aralik_atla": aralik_atla_bugun(),
    }
    for s in sorted(db.ayar("sinavlar") or [], key=lambda x: x.get("olusma", 0)):
        if s.get("bitis", 0) + 180 > n and hedef_kapsar(s.get("hedef"), tid, t["grup"]):
            ayar["sinav"] = {x: s.get(x) for x in ("id", "baslik", "bas", "bitis", "uyari_dk", "ses")}
    for s in sorted(db.ayar("saatler") or [], key=lambda x: x.get("olusma", 0)):
        if hedef_kapsar(s.get("hedef"), tid, t["grup"]):
            ayar["saat_ekran"] = {x: s.get(x) for x in ("id", "mesaj", "kapatilabilir")}
    engel = db.ayar("site_engel") or {}
    if engel.get("etkin") and engel.get("siteler") and hedef_kapsar(engel.get("hedef"), tid, t["grup"]):
        ayar["site_engel"] = {x: engel.get(x) for x in ("siteler", "zaman", "araliklar")}
    metin = json.dumps(ayar, sort_keys=True, ensure_ascii=False)
    return ayar, hashlib.sha1(metin.encode("utf-8")).hexdigest()[:16]


# ─────────────────────────────────────────────────────────────────────────────
# Wake-on-LAN
# ─────────────────────────────────────────────────────────────────────────────

def wol_gonder(mac, ip=None):
    mac = re.sub(r"[^0-9a-fA-F]", "", mac or "")
    if len(mac) != 12:
        return False
    paket = b"\xff" * 6 + bytes.fromhex(mac) * 16
    hedefler = {"255.255.255.255"}
    for a in ([ip] if ip else []) + yerel_adresler():
        p = a.split(".")
        if len(p) == 4:
            hedefler.add(".".join(p[:3] + ["255"]))
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    try:
        for h in hedefler:
            for port in (9, 7):
                try:
                    s.sendto(paket, (h, port))
                except OSError:
                    pass
    finally:
        s.close()
    return True


def tahtalari_uyandir(idler, liste=False):
    gonderilen, adressiz = [], []
    for tid in idler:
        t = db.bir("SELECT bilgi FROM tahta WHERE id=?", (tid,))
        if not t:
            continue
        bilgi = json.loads(t["bilgi"] or "{}")
        if cevrimici_mi(canli.get(tid)):
            continue
        if bilgi.get("mac"):
            for _ in range(3):
                wol_gonder(bilgi["mac"], bilgi.get("ip"))
            gonderilen.append(tid)
        else:
            adressiz.append(tid)
    return (gonderilen, adressiz) if liste else len(gonderilen)


# ─────────────────────────────────────────────────────────────────────────────
# Arka plan işleri
# ─────────────────────────────────────────────────────────────────────────────

kullanim_tampon = {}
kullanim_kilit = threading.Lock()


def arka_plan_sayac():
    """Çevrimiçi/çevrimdışı geçişlerini kaydeder, kullanım süresini biriktirir."""
    son_yazma = simdi()
    while True:
        time.sleep(15)
        try:
            n = simdi()
            gun = time.strftime("%Y-%m-%d")
            for tid, c in list(canli.items()):
                acik = cevrimici_mi(c)
                if c.cevrimici and not acik:
                    c.cevrimici = False
                    olay(tid, "baglanti", "Kapandı veya bağlantısı kesildi")
                d = c.durum or {}
                aktif = bool(acik and d.get("oturum") and not d.get("kilitli")
                             and d.get("bosta_sn") is not None and d.get("bosta_sn") < 120)
                if acik:
                    dt = min(n - (c.son_sayim or n), 30)
                    with kullanim_kilit:
                        k = kullanim_tampon.setdefault((gun, tid), [0.0, 0.0])
                        k[0] += dt
                        if aktif:
                            k[1] += dt
                c.son_sayim = n if acik else 0
                ogretmen = (d.get("acan") or "") if (acik and d.get("oturum") and not d.get("kilitli")) else ""
                aralik_isle(tid, "acik", acik, "", n)
                aralik_isle(tid, "aktif", aktif, "", n)
                aralik_isle(tid, "ogretmen", bool(ogretmen), ogretmen, n)
            if n - son_yazma > 60:
                kullanim_yaz()
                son_yazma = n
            db.x("DELETE FROM bekleyen WHERE gecerlilik < ?", (n,))
            if int(n) % 3600 < 15:
                db.x("DELETE FROM aralik WHERE bit < ?", (n - 400 * 86400,))
            db.x("DELETE FROM oturum WHERE bitis < ?", (n,))
            for tid, t in list(silinenler.items()):
                if n - t > 600:
                    silinenler.pop(tid, None)
        except Exception:
            log.exception("sayaç hatası")


acik_araliklar = {}  # (tahta, tür) -> {"id", "ad", "bas", "bit", "yazildi"}


def aralik_isle(tid, tur, durum, ad, n):
    """Tahtanın açık / aktif / öğretmen kullanım aralıklarını kaydeder (günlük çizelge için)."""
    k = (tid, tur)
    a = acik_araliklar.get(k)
    if durum:
        if a and a["ad"] == ad and n - a["bit"] <= 45:
            a["bit"] = n
            if n - a["yazildi"] > 60:
                db.x("UPDATE aralik SET bit=? WHERE id=?", (n, a["id"]))
                a["yazildi"] = n
            return
        if a:
            db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))
        with db.k:
            cur = db.c.execute("INSERT INTO aralik(tahta, tur, ad, bas, bit) VALUES(?,?,?,?,?)", (tid, tur, ad, n, n))
            acik_araliklar[k] = {"id": cur.lastrowid, "ad": ad, "bas": n, "bit": n, "yazildi": n}
    elif a:
        db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))
        acik_araliklar.pop(k, None)


def araliklari_yaz():
    for a in list(acik_araliklar.values()):
        db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))


def kullanim_yaz():
    with kullanim_kilit:
        tampon = dict(kullanim_tampon)
        kullanim_tampon.clear()
    for (gun, tid), (acik, aktif) in tampon.items():
        db.x("""INSERT INTO kullanim(gun, tahta, acik, aktif) VALUES(?,?,?,?)
                ON CONFLICT(gun, tahta) DO UPDATE SET acik=acik+excluded.acik, aktif=aktif+excluded.aktif""",
             (gun, tid, acik, aktif))


def arka_plan_zamanlayici():
    """Uzaktan açma (Wake-on-LAN) kurallarını çalıştırır. Diğer kurallar tahtada çalışır."""
    calisanlar = set()
    while True:
        time.sleep(10)
        try:
            sinavlar = db.ayar("sinavlar") or []
            kalan = [s for s in sinavlar if s.get("bitis", 0) + 180 > simdi()]
            if len(kalan) != len(sinavlar):
                db.ayar_yaz("sinavlar", kalan)
            if not db.ayar("zamanlayici_etkin"):
                continue
            t = time.localtime()
            gun = t.tm_wday + 1
            simdi_sn = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec
            tarih = time.strftime("%Y-%m-%d")
            for r in db.q("SELECT veri FROM kural"):
                k = json.loads(r["veri"])
                if k.get("tur") != "ac" or not k.get("aktif", True) or gun not in (k.get("gunler") or []):
                    continue
                sa, dk = map(int, k["saat"].split(":"))
                fark = simdi_sn - (sa * 3600 + dk * 60)
                anahtar = k["id"] + tarih
                if 0 <= fark < 120 and anahtar not in calisanlar:
                    calisanlar.add(anahtar)
                    idler = hedef_cozumle(k.get("hedef"))
                    n = tahtalari_uyandir(idler)
                    olay("", "kural", "Zamanlayıcı {} → uzaktan açma sinyali {} tahtaya gönderildi".format(k["saat"], n))
            if len(calisanlar) > 500:
                calisanlar = {a for a in calisanlar if a.endswith(tarih)}
        except Exception:
            log.exception("zamanlayıcı hatası")


def arka_plan_ortak():
    """Yönetim bilgisayarında Ortak Klasör'e Gezgin'den eklenen / değiştirilen dosyaları bulur."""
    while True:
        try:
            depo.tara()
        except Exception:
            log.exception("ortak klasör taraması")
        time.sleep(3)


def arka_plan_isaret():
    """Ağdaki tahtaların sunucuyu bulabilmesi için 10 sn'de bir yayın yapar.
    (Bilgisayarın IP adresi değişse bile tahtalar kendiliğinden yeniden bağlanır.)"""
    while True:
        try:
            mesaj = "TYS1 {} {}".format(db.ayar("kimlik"), PORT).encode()
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            hedefler = {"255.255.255.255"}
            for a in yerel_adresler():
                p = a.split(".")
                hedefler.add(".".join(p[:3] + ["255"]))
            for h in hedefler:
                try:
                    s.sendto(mesaj, (h, KESIF_PORT))
                except OSError:
                    pass
            s.close()
        except Exception:
            pass
        time.sleep(10)


# ─────────────────────────────────────────────────────────────────────────────
# Panel için özet
# ─────────────────────────────────────────────────────────────────────────────

def tahta_ozeti(r):
    c = canli.get(r["id"])
    d = (c.durum if c else {}) or {}
    bilgi = json.loads(r["bilgi"] or "{}")
    acik = cevrimici_mi(c)
    ekran_k = c.ekran.get("kucuk") if c else None
    ekran_b = c.ekran.get("buyuk") if c else None
    ekran_t = c.ekran.get("tam") if c else None
    return {
        "id": r["id"], "ad": r["ad"], "grup": r["grup"] or "",
        "ip": bilgi.get("ip"), "mac": bilgi.get("mac"), "hostname": bilgi.get("hostname"),
        "os": bilgi.get("os"), "surum": bilgi.get("surum"),
        "platform": d.get("platform") or ("windows" if "windows" in str(bilgi.get("os") or "").lower() else "linux"),
        "guncel": bilgi.get("surum") == AJAN_SURUM,
        "cevrimici": acik,
        "kilitli": bool(d.get("kilitli")) if acik else False,
        "oturum": bool(d.get("oturum")) if acik else False,
        "kullanici": d.get("kullanici") if acik else None,
        "bosta_sn": d.get("bosta_sn") if acik else None,
        "calisma_sn": d.get("calisma_sn") if acik else None,
        "ram": d.get("ram"), "disk": d.get("disk"), "sicaklik": d.get("sicaklik"),
        "kapanis": d.get("kapanis") if acik else None,
        "ozellikler": d.get("ozellikler") or {},
        "saat_farki": round(d["zaman_farki"]) if acik and d.get("zaman_farki") is not None else None,
        "son": r["son"] or 0,
        "eklenme": r["eklenme"],
        "ekran_kucuk": ekran_k[0] if ekran_k else 0,
        "ekran_buyuk": ekran_b[0] if ekran_b else 0,
        "ekran_tam": ekran_t[0] if ekran_t else 0,
        "acan": d.get("acan") if acik else None,
        "ortak": d.get("ortak"),
        "engel": d.get("engel") if acik else None,
        "guncelleme": d.get("guncelleme"),
        "tam_ekran": d.get("tam_ekran") if acik else None,
        "aralik": d.get("aralik") if acik else None,
    }


def onizleme_iste():
    """Panel açıkken, açık tahtaların küçük ekran görüntülerini tazeler."""
    if not db.ayar("onizleme"):
        return
    n = simdi()
    for tid, c in list(canli.items()):
        if not cevrimici_mi(c) or not (c.durum or {}).get("oturum"):
            continue
        son = c.ekran.get("kucuk", (0,))[0]
        if n - son > 30 and n - c.ekran_istek.get("kucuk", 0) > 15:
            c.ekran_istek["kucuk"] = n
            uyandir(tid)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP sunucu
# ─────────────────────────────────────────────────────────────────────────────

giris_denemeleri = {}


class Hata(Exception):
    def __init__(self, mesaj, kod=400):
        Exception.__init__(self, mesaj)
        self.kod = kod


class Isleyici(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "TahtaYonetim/" + SURUM
    sys_version = ""

    # ── altyapı ──────────────────────────────────────────────────────────────
    def log_message(self, fmt, *args):
        log.debug("%s %s", self.client_address[0], fmt % args)

    def yanit(self, govde, kod=200, mime="application/json; charset=utf-8", basliklar=None):
        if isinstance(govde, (dict, list)):
            govde = json.dumps(govde, ensure_ascii=False).encode("utf-8")
        elif isinstance(govde, str):
            govde = govde.encode("utf-8")
        self.send_response(kod)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(govde)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (basliklar or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(govde)

    def json_oku(self, sinir=2 * 1024 * 1024):
        n = int(self.headers.get("Content-Length") or 0)
        if n > sinir:
            raise Hata("İstek çok büyük", 413)
        ham = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(ham.decode("utf-8") or "{}")
        except Exception:
            raise Hata("Geçersiz veri")

    def ham_oku(self, sinir):
        n = int(self.headers.get("Content-Length") or 0)
        if n > sinir:
            raise Hata("Dosya çok büyük", 413)
        return self.rfile.read(n)

    def cerez(self, ad="tys"):
        ham = self.headers.get("Cookie") or ""
        for parca in ham.split(";"):
            if "=" in parca:
                k, v = parca.strip().split("=", 1)
                if k == ad:
                    return v
        return None

    def oturum_bul(self, cerez, tur):
        b = self.cerez(cerez)
        if not b:
            return None
        h = hashlib.sha256(b.encode()).hexdigest()
        r = db.bir("SELECT bitis, ad FROM oturum WHERE belirtec=? AND COALESCE(tur, 'yonetici')=?", (h, tur))
        return r if (r and r["bitis"] > simdi()) else None

    def oturum_var(self):
        return bool(self.oturum_bul("tys", "yonetici"))

    def ogretmen(self):
        """Ortak Klasör sayfası için (ad, yönetici mi) döner; giriş yoksa None."""
        r = self.oturum_bul("tyso", "ogretmen")
        if r:
            return {"ad": r["ad"] or "Öğretmen", "yonetici": False}
        if self.oturum_var():
            return {"ad": "Yönetici", "yonetici": True}
        return None

    def ajan_dogrula(self):
        anahtar = self.headers.get("X-Anahtar") or ""
        if anahtar and hmac.compare_digest(anahtar, db.ayar("anahtar")):
            return "tahta"
        ia = db.ayar("istemci_anahtar") or ""
        if anahtar and ia and hmac.compare_digest(anahtar, ia):
            return "istemci"
        raise Hata("Yetkisiz", 401)

    def dosya_gonder(self, p, ad=None, satir_ici=False, ek=None, mime="application/octet-stream"):
        boyut = p.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(boyut))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if ad:
            self.send_header("Content-Disposition", "{}; filename*=UTF-8''{}".format(
                "inline" if satir_ici else "attachment", quote(ad)))
        for k, v in (ek or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(str(p), "rb") as f:
            while True:
                parca = f.read(256 * 1024)
                if not parca:
                    break
                self.wfile.write(parca)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.yonlendir("GET")

    def do_POST(self):
        self.yonlendir("POST")

    def yonlendir(self, yontem):
        try:
            u = urlparse(self.path)
            self.sorgu = {k: v[0] for k, v in parse_qs(u.query).items()}
            yol = u.path.rstrip("/") or "/"
            # Statik ve kurulum
            if yontem == "GET":
                if yol in ("/", "/index.html"):
                    return self.statik("index.html")
                if yol in ("/manifest.webmanifest", "/ikon-192.png", "/ikon-512.png"):
                    return self.statik(yol[1:])
                if yol == "/ortak":
                    return self.statik("ortak.html")
                if yol == "/kilavuz":
                    k = WEB / "kilavuz.html"
                    if not k.is_file():
                        k = PROGRAM.parent / "KURULUM_KILAVUZU.html"
                    if not k.is_file():
                        raise Hata("Kılavuz bulunamadı", 404)
                    return self.yanit(k.read_bytes(), mime="text/html; charset=utf-8",
                                      basliklar={"X-Frame-Options": "SAMEORIGIN", "Referrer-Policy": "no-referrer",
                                                 "Cache-Control": "private, max-age=3600"})
                if yol in ("/k", "/kur"):
                    return self.kurulum_betigi(self.headers.get("Host"), ad=self.sorgu.get("ad", ""))
                if yol in ("/w", "/kw"):
                    return self.windows_kurulum(self.headers.get("Host"), ad=self.sorgu.get("ad", ""))
                if yol == "/kaldir":
                    return self.yanit(KALDIR_SABLON.read_bytes(), mime="text/plain; charset=utf-8")
                if yol == "/tani":
                    return self.tani_betigi(self.headers.get("Host"))
                if yol == "/api/saglik":
                    return self.yanit({"ok": True, "surum": SURUM, "uygulama": "TahtaYonetim", "ad": socket.gethostname()})
            # Ajan API
            if yol.startswith("/api/a/"):
                rol = self.ajan_dogrula()
                ad = yol[len("/api/a/"):]
                if rol == "istemci" and ad not in ("kod", "istemci") and not ad.startswith("ortak/"):
                    raise Hata("Yetkisiz", 403)
                if ad.startswith("ortak/"):
                    return self.a_ortak(ad[6:], yontem, rol)
                if yontem == "POST" and ad == "istemci":
                    return self.yanit(self.a_istemci(self.json_oku()))
                if yontem == "POST" and ad == "ariza":
                    return self.yanit(self.a_ariza(self.json_oku()))
                if yontem == "POST" and ad == "tani":
                    if rol != "tahta":
                        raise Hata("Yetkisiz", 403)
                    return self.a_tani()
                if yontem == "POST" and ad == "senk":
                    return self.yanit(self.a_senk(self.json_oku()))
                if yontem == "POST" and ad == "olay":
                    return self.yanit(self.a_olay(self.json_oku()))
                if yontem == "POST" and ad == "ekran":
                    return self.yanit(self.a_ekran())
                if yontem == "GET" and ad == "kod":
                    return self.yanit(AJAN_DOSYA.read_bytes(), mime="text/x-python; charset=utf-8")
                if yontem == "GET" and ad.startswith("dosya/"):
                    return self.a_dosya(ad[6:])
                if yontem == "GET" and ad.startswith("ses/"):
                    return self.a_ses(ad[4:])
                raise Hata("Bulunamadı", 404)
            # Ortak Klasör web sayfası (öğretmen şifresi veya yönetici oturumu)
            if yol.startswith("/api/o/"):
                ad = yol[len("/api/o/"):]
                self.kullanici = self.ogretmen()
                if ad not in ("giris", "bilgi", "istemci-anahtar", "tahta-anahtar") and not self.kullanici:
                    raise Hata("Giriş yapmanız gerekiyor", 401)
                fonk = getattr(self, "o_" + ad.replace("-", "_").replace(".", "_"), None)
                if fonk is None:
                    raise Hata("Bulunamadı", 404)
                return fonk(yontem)
            # Panel API
            if yol.startswith("/api/p/"):
                ad = yol[len("/api/p/"):]
                acik = {"baslangic", "kurulum", "giris"}
                if ad not in acik and not self.oturum_var():
                    raise Hata("Oturum açmanız gerekiyor", 401)
                fonk = getattr(self, "p_" + ad.replace("-", "_").replace("/", "__").replace(".", "_"), None)
                if fonk is None:
                    raise Hata("Bulunamadı", 404)
                return fonk(yontem)
            raise Hata("Bulunamadı", 404)
        except (Hata, ortak_mod.OrtakHata) as h:
            if yontem == "POST":
                self.close_connection = True
            try:
                self.yanit({"hata": str(h)}, kod=h.kod)
            except Exception:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as e:
            log.exception("istek hatası: %s", self.path)
            try:
                self.yanit({"hata": "Sunucu hatası: {}".format(e)}, kod=500)
            except Exception:
                pass

    def statik(self, ad):
        yol = WEB / ad
        if not yol.is_file():
            raise Hata("Bulunamadı", 404)
        mime = {"html": "text/html; charset=utf-8", "png": "image/png",
                "webmanifest": "application/manifest+json"}.get(ad.rsplit(".", 1)[-1], "application/octet-stream")
        ek = {"X-Frame-Options": "SAMEORIGIN" if ad == "ortak.html" else "DENY", "Referrer-Policy": "no-referrer"}
        self.yanit(yol.read_bytes(), mime=mime, basliklar=ek)

    def kurulum_betigi(self, host, ek=None, ad=""):
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        metin = KUR_SABLON.read_text(encoding="utf-8")
        metin = (metin.replace("__SUNUCU__", "http://" + host)
                 .replace("__ANAHTAR__", db.ayar("anahtar"))
                 .replace("__KIMLIK__", db.ayar("kimlik"))
                 .replace("__ADRESLER__", " ".join(yerel_adresler()))
                 .replace("__TAHTA_AD__", tahta_adi_temizle(ad)))
        self.yanit(metin.encode("utf-8"), mime="text/plain; charset=utf-8", basliklar=ek)

    def windows_kurulum(self, host, ad=""):
        """Windows tahta kurulum dosyası (.bat içine gömülü PowerShell betiği)."""
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if host.split(":")[0] in ("localhost", "127.0.0.1"):
            host = "{}:{}".format((yerel_adresler() or ["127.0.0.1"])[0], PORT)
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        ad = tahta_adi_temizle(ad)
        ps = KUR_PS1.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        bat = (TAHTA_BAT.replace("__SUNUCU__", "http://" + host).replace("__ANAHTAR__", db.ayar("anahtar"))
               .replace("__KIMLIK__", db.ayar("kimlik")).replace("__AD__", ad.replace('"', "").replace("%", ""))
               + "#TYS-PS1#\n" + ps).replace("\n", "\r\n")
        dosya = "TahtaKurulum{}.bat".format("-" + re.sub(r"[^A-Za-z0-9\-]+", "_", ad).strip("_") if ad else "")
        self.yanit(bat.encode("utf-8"), mime="application/octet-stream", basliklar={
            "Content-Disposition": "attachment; filename=" + dosya})

    def tani_betigi(self, host):
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        metin = (TANI_SABLON.read_text(encoding="utf-8").replace("__SUNUCU__", "http://" + host)
                 .replace("__ANAHTAR__", db.ayar("anahtar")))
        self.yanit(metin.encode("utf-8"), mime="text/plain; charset=utf-8")

    def a_tani(self):
        """Tahtadan gelen tanı raporunu saklar (son 30 rapor)."""
        veri = self.ham_oku(300 * 1024)
        ip = self.client_address[0]
        ad = None
        for r in db.q("SELECT ad, bilgi FROM tahta"):
            if (json.loads(r["bilgi"] or "{}").get("ip") or "") == ip:
                ad = r["ad"]
                break
        if not ad:
            from urllib.parse import unquote
            ad = unquote(self.headers.get("X-Cihaz-Ad") or "") or ip
        klasor = VERI / "tani"
        klasor.mkdir(exist_ok=True)
        guvenli = re.sub(r"[^\w.\-]+", "_", ad)[:40] or "tahta"
        (klasor / "{}-{}.txt".format(datetime.now().strftime("%Y%m%d-%H%M%S"), guvenli)).write_bytes(
            "Tahta: {} ({})\n".format(ad, ip).encode("utf-8") + veri)
        for eski in sorted(klasor.glob("*.txt"))[:-30]:
            try:
                eski.unlink()
            except OSError:
                pass
        olay(None, "sistem", "{} tahtasından tanı raporu geldi".format(ad))
        self.yanit({"ok": True})

    # ── ajan uçları ──────────────────────────────────────────────────────────
    def a_senk(self, g):
        tid = str(g.get("id") or "")
        if not re.match(r"^[A-Za-z0-9\-]{6,64}$", tid):
            raise Hata("Geçersiz kimlik")
        d = g.get("durum") or {}
        n = simdi()
        if tid in silinenler:
            bek = db.q("SELECT * FROM bekleyen WHERE tahta=? AND tur='kaldir'", (tid,))
            db.x("DELETE FROM bekleyen WHERE tahta=?", (tid,))
            return {"komutlar": [{"id": r["id"], "tur": "kaldir", "veri": {}} for r in bek],
                    "sunucu_zaman": n, "utc_ofset": utc_ofset()}
        if d.get("zaman"):
            d["zaman_farki"] = float(d["zaman"]) - n
        c = canli_al(tid)
        with c.kosul:
            c.nesil += 1
            nesil = c.nesil
            ilk = not c.cevrimici
            c.durum = d
            c.son = n
            c.bekliyor = True
            c.cevrimici = True
        r = db.bir("SELECT id, bilgi FROM tahta WHERE id=?", (tid,))
        bilgi = {k: d.get(k) for k in ("ip", "mac", "hostname", "os", "surum")}
        kurulum_ad = tahta_adi_temizle(d.get("kurulum_ad") or "")
        if kurulum_ad:
            bilgi["kurulum_ad"] = kurulum_ad
        if bilgi.get("ip") is None:
            bilgi["ip"] = self.client_address[0]
        if r is None:
            ad = (kurulum_ad or d.get("hostname") or "Tahta")[:60]
            db.x("INSERT INTO tahta(id, ad, grup, bilgi, eklenme, son) VALUES(?,?,?,?,?,?)",
                 (tid, ad, "", json.dumps(bilgi), n, n))
            olay(tid, "sistem", "Yeni tahta bağlandı ({})".format(bilgi.get("ip")))
        else:
            eski = json.loads(r["bilgi"] or "{}")
            if eski.get("mac") and not bilgi.get("mac"):
                bilgi["mac"] = eski["mac"]
            if kurulum_ad and kurulum_ad != eski.get("kurulum_ad"):
                # Kurulum komutunda yeni bir ad verildi (yeniden kurulum); paneldeki adı günceller.
                db.x("UPDATE tahta SET ad=? WHERE id=?", (kurulum_ad, tid))
                olay(tid, "sistem", "Tahta adı kurulumda verildi: {}".format(kurulum_ad))
            if eski != bilgi:
                db.x("UPDATE tahta SET bilgi=?, son=? WHERE id=?", (json.dumps(bilgi), n, tid))
            else:
                db.x("UPDATE tahta SET son=? WHERE id=?", (n, tid))
            if ilk and n - BASLAMA > 60:
                olay(tid, "baglanti", "Açıldı")
        for s in g.get("sonuclar") or []:
            if not s.get("ok"):
                olay(tid, "hata", "{}: {}".format(KOMUT_ADI.get(s.get("tur"), s.get("tur")), s.get("mesaj", "")))
        bitis = n + (0 if g.get("hemen") else SENK_BEKLEME)
        komutlar = []
        ayar = surum = None
        with c.kosul:
            while True:
                if c.nesil != nesil:
                    break
                komutlar = komutlari_al(c)
                ayar, surum = ajan_ayari(tid)
                kalan = bitis - simdi()
                if komutlar or surum != g.get("ayar_surum") or kalan <= 0:
                    break
                c.kosul.wait(timeout=kalan)
            if c.nesil == nesil:
                c.bekliyor = False
                c.son = simdi()
        cevap = {"komutlar": komutlar, "sunucu_zaman": simdi(), "utc_ofset": utc_ofset(),
                 "ajan_surum": AJAN_SURUM, "ayar_surum": surum}
        if surum != g.get("ayar_surum"):
            cevap["ayar"] = ayar
        return cevap

    def a_olay(self, g):
        tid = str(g.get("id") or "")
        c = canli.get(tid)
        if c and isinstance(g.get("durum"), dict):
            d = g["durum"]
            if d.get("zaman"):
                d["zaman_farki"] = float(d["zaman"]) - simdi()
            c.durum = d
            c.son = max(c.son, simdi()) if not c.bekliyor else c.son
        tur = g.get("tur")
        if tur == "dosya_teslim":
            fid = (g.get("veri") or {}).get("fid")
            r = db.bir("SELECT teslim, ad FROM dosya WHERE id=?", (fid,))
            if r:
                teslim = json.loads(r["teslim"] or "[]")
                if tid not in teslim:
                    teslim.append(tid)
                    db.x("UPDATE dosya SET teslim=? WHERE id=?", (json.dumps(teslim), fid))
                olay(tid, "dosya", "Dosya teslim alındı: {}".format(r["ad"]))
        elif tur:
            olay(tid, tur, str(g.get("mesaj") or ""))
        return {"ok": True}

    def a_ekran(self):
        tid = self.sorgu.get("id", "")
        boyut = ekran_boyutu(self.sorgu.get("boyut"))
        veri = self.ham_oku(8 * 1024 * 1024)
        c = canli.get(tid)
        if c and len(veri) > 100:
            mime = "image/png" if veri[:4] == b"\x89PNG" else "image/jpeg"
            c.ekran[boyut] = (simdi(), mime, veri)
            if boyut != "kucuk" and "kucuk" not in c.ekran:
                c.ekran["kucuk"] = c.ekran[boyut]
        return {"ok": True}

    def a_dosya(self, fid):
        fid = re.sub(r"[^a-f0-9]", "", fid)
        r = db.bir("SELECT ad FROM dosya WHERE id=?", (fid,))
        if not r:
            raise Hata("Dosya bulunamadı", 404)
        yol = VERI / "dosyalar" / fid / guvenli_ad(r["ad"])
        if not yol.is_file():
            raise Hata("Dosya bulunamadı", 404)
        boyut = yol.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(boyut))
        self.end_headers()
        with open(yol, "rb") as f:
            while True:
                parca = f.read(256 * 1024)
                if not parca:
                    break
                self.wfile.write(parca)

    def a_ses(self, tur):
        bilgi = (db.ayar("zil_ozel") or {}).get(tur)
        if not bilgi:
            raise Hata("Ses yok", 404)
        yol = VERI / "sesler" / "{}.{}".format(tur, bilgi["uzanti"])
        if not yol.is_file():
            raise Hata("Ses yok", 404)
        self.yanit(yol.read_bytes(), mime="application/octet-stream")

    def a_ortak(self, ad, yontem, rol):
        cid = self.headers.get("X-Cihaz") or ""
        if rol == "tahta":
            r = db.bir("SELECT ad FROM tahta WHERE id=?", (cid,))
            isim, izin = (r["ad"] if r else "Tahta"), depo.ayar()["tahta_izin"]
        else:
            r = db.bir("SELECT ad FROM istemci WHERE id=?", (cid,))
            isim, izin = (r["ad"] if r else unquote(self.headers.get("X-Cihaz-Ad") or "Bilgisayar")), "tam"
        if ad == "liste":
            v = depo.liste(int(self.sorgu.get("rev") or 0))
            kullanilan, _ = depo.kullanilan()
            v.update(etkin=depo.etkin(), izin=izin, kota=depo.kota(), kullanilan=kullanilan)
            return self.yanit(v)
        if ad == "bekle":
            return self.yanit({"rev": depo.bekle(int(self.sorgu.get("rev") or 0), 25)})
        if ad == "indir":
            p, r = depo.indir_yolu(self.sorgu.get("yol") or "")
            return self.dosya_gonder(p, ek={"X-Rev": str(r["rev"]), "X-Ozet": r["ozet"], "X-Mtime": repr(r["mtime"])})
        if yontem != "POST":
            raise Hata("Geçersiz istek")
        if ad == "yukle":
            n = int(self.headers.get("Content-Length") or 0)
            return self.yanit(depo.yukle(unquote(self.headers.get("X-Yol") or ""), self.rfile, n, isim,
                                         temel=int(self.headers.get("X-Temel") or 0),
                                         mtime=float(self.headers.get("X-Mtime") or 0) or None, izin=izin))
        g = self.json_oku()
        if ad == "sil":
            return self.yanit(depo.sil(g.get("yol") or "", isim, int(g.get("temel") or 0), izin))
        if ad == "klasor":
            return self.yanit(depo.klasor(g.get("yol") or "", isim))
        raise Hata("Bulunamadı", 404)

    def a_istemci(self, g):
        iid = str(g.get("id") or "")
        if not re.match(r"^[A-Za-z0-9\-]{6,64}$", iid):
            raise Hata("Geçersiz kimlik")
        bilgi = {k: g.get(k) for k in ("kullanici", "surum", "os", "ortak", "klasor")}
        bilgi["ip"] = self.client_address[0]
        ad = (g.get("ad") or "Bilgisayar")[:60]
        if db.bir("SELECT id FROM istemci WHERE id=?", (iid,)):
            db.x("UPDATE istemci SET bilgi=?, son=? WHERE id=?", (json.dumps(bilgi), simdi(), iid))
        else:
            db.x("INSERT INTO istemci(id, ad, bilgi, son, eklenme) VALUES(?,?,?,?,?)", (iid, ad, json.dumps(bilgi), simdi(), simdi()))
            olay("", "ortak", "Yeni öğretmen bilgisayarı bağlandı: {}".format(ad))
        return {"ok": True, "ajan_surum": AJAN_SURUM, "sunucu_zaman": simdi()}

    def a_ariza(self, g):
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Tahta bulunamadı", 404)
        kategori = g.get("kategori") if g.get("kategori") in ARIZA_TURLERI else "Diğer"
        aciklama = str(g.get("aciklama") or "").strip()[:500]
        bildiren = str(g.get("bildiren") or "").strip()[:60]
        zaman = float(g.get("zaman") or simdi())
        db.x("INSERT INTO ariza(tahta, kategori, aciklama, bildiren, zaman, durum, guncelleme) VALUES(?,?,?,?,?,?,?)",
             (tid, kategori, aciklama, bildiren, min(zaman, simdi()), "yeni", simdi()))
        olay(tid, "ariza", "Arıza bildirildi: {}{}".format(kategori, " — " + bildiren if bildiren else ""))
        return {"ok": True}

    # ── panel: oturum ────────────────────────────────────────────────────────
    def p_baslangic(self, y):
        self.yanit({"kurulum_tamam": db.ayar("kurulum_tamam"), "oturum": self.oturum_var(),
                    "okul_adi": db.ayar("okul_adi"), "surum": SURUM})

    def oturum_ac(self, ek=None):
        b = secrets.token_urlsafe(32)
        db.x("INSERT INTO oturum(belirtec, bitis) VALUES(?,?)",
             (hashlib.sha256(b.encode()).hexdigest(), simdi() + 30 * 86400))
        cerez = "tys={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(b, 30 * 86400)
        self.yanit(ek or {"ok": True}, basliklar={"Set-Cookie": cerez})

    def p_kurulum(self, y):
        if db.ayar("kurulum_tamam"):
            raise Hata("Kurulum zaten yapılmış", 403)
        g = self.json_oku()
        okul = (g.get("okul_adi") or "").strip()[:120]
        sifre = g.get("sifre") or ""
        pin = re.sub(r"\D", "", g.get("pin") or "")
        if not okul:
            raise Hata("Okul adını yazın")
        if len(sifre) < 6:
            raise Hata("Yönetici şifresi en az 6 karakter olmalı")
        if not 4 <= len(pin) <= 8:
            raise Hata("Tahta açma şifresi 4-8 rakam olmalı")
        db.ayar_yaz("okul_adi", okul)
        db.ayar_yaz("sifre", sifre_ozet(sifre))
        tuz = secrets.token_hex(8)
        db.ayar_yaz("pinler", [{"id": uuid.uuid4().hex[:8], "ad": (g.get("pin_ad") or "Ortak şifre").strip()[:40],
                                "tuz": tuz, "ozet": hashlib.sha256((tuz + pin).encode()).hexdigest()}])
        db.ayar_yaz("kurulum_tamam", True)
        olay("", "sistem", "İlk kurulum tamamlandı")
        hepsini_uyandir()
        self.oturum_ac()

    def p_giris(self, y):
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        g = self.json_oku()
        if not sifre_dogru(g.get("sifre") or "", db.ayar("sifre")):
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(ip, None)
        olay("", "giris", "Panele giriş yapıldı ({})".format(ip))
        self.oturum_ac()

    def p_cikis(self, y):
        b = self.cerez()
        if b:
            db.x("DELETE FROM oturum WHERE belirtec=?", (hashlib.sha256(b.encode()).hexdigest(),))
        self.yanit({"ok": True}, basliklar={"Set-Cookie": "tys=; Path=/; Max-Age=0"})

    # ── panel: durum ve komutlar ─────────────────────────────────────────────
    def p_durum(self, y):
        onizleme_iste()
        tahtalar = [tahta_ozeti(r) for r in db.q("SELECT * FROM tahta ORDER BY ad COLLATE NOCASE")]
        arizalar = {r["tahta"]: r["n"] for r in db.q("SELECT tahta, COUNT(*) AS n FROM ariza WHERE durum!='cozuldu' GROUP BY tahta")}
        for t in tahtalar:
            t["ariza"] = arizalar.get(t["id"], 0)
        gruplar = sorted({t["grup"] for t in tahtalar if t["grup"]}, key=lambda s: s.lower())
        n = simdi()
        engel = db.ayar("site_engel") or {}
        self.yanit({
            "tahtalar": tahtalar, "gruplar": gruplar,
            "sunucu": {"surum": SURUM, "ajan_surum": AJAN_SURUM, "zaman": n,
                       "okul_adi": db.ayar("okul_adi"), "port": PORT,
                       "pin_var": bool(db.ayar("pinler")),
                       "zamanlayici_etkin": db.ayar("zamanlayici_etkin"),
                       "ariza_acik": sum(arizalar.values()),
                       "sinavlar": [s for s in db.ayar("sinavlar") or [] if s.get("bitis", 0) + 180 > n],
                       "saatler": db.ayar("saatler") or [],
                       "engel": {"etkin": bool(engel.get("etkin")), "sayi": len(engel.get("siteler") or [])},
                       "ortak_etkin": depo.etkin()},
        })

    def p_komut(self, y):
        g = self.json_oku()
        tur = g.get("tur")
        if tur not in PANEL_KOMUTLARI:
            raise Hata("Geçersiz komut")
        veri = g.get("veri") or {}
        idler = hedef_cozumle(g.get("hedef"))
        if not idler:
            raise Hata("Seçili tahta yok")
        acik = [t for t in idler if cevrimici_mi(canli.get(t))]
        if tur == "ac":
            gonderilen, adressiz = tahtalari_uyandir(idler, liste=True)
            olay("", "komut", "{} → {}".format(KOMUT_ADI[tur], hedef_yazi(g.get("hedef"), len(gonderilen))))
            return self.yanit({"ok": True, "hedef": len(idler), "gonderilen": len(gonderilen),
                               "idler": gonderilen, "adressiz": adressiz, "acik": len(acik)})
        omur = None
        if tur == "duyuru":
            veri = {
                "baslik": (veri.get("baslik") or "").strip()[:120],
                "metin": (veri.get("metin") or "").strip()[:1500],
                "stil": "kucuk" if veri.get("stil") == "kucuk" else "buyuk",
                "sure": max(5, min(int(veri.get("sure") or 20), 3600)),
                "ses": bool(veri.get("ses", True)),
            }
            if not veri["metin"]:
                raise Hata("Duyuru metni boş olamaz")
            omur = veri["sure"] + 30
        elif tur == "kapat":
            veri = {"gecikme": max(0, min(int(veri.get("gecikme") or 0), 3600))}
        elif tur == "zil":
            veri = {"tur": "teneffus" if veri.get("tur") == "teneffus" else "ders"}
        elif tur == "icerik_ac":
            if veri.get("tur") == "ortak":
                try:
                    veri = {"tur": "ortak", "yol": ortak_mod.yol_dogrula(veri.get("yol") or "")}
                except ortak_mod.OrtakHata as h:
                    raise Hata(str(h))
            else:
                adres = (veri.get("adres") or "").strip()
                if adres and not re.match(r"^https?://", adres, re.I):
                    adres = "https://" + adres
                if not re.match(r"^https?://[^\s/$.?#][^\s]*$", adres, re.I) or len(adres) > 1000:
                    raise Hata("Geçerli bir internet adresi yazın")
                veri = {"tur": "url", "adres": adres}
            omur = 600
        elif tur in ("paket_kur", "paket_kaldir"):
            paketler = [p.strip() for p in (veri.get("paketler") or []) if p and p.strip()]
            if not paketler or len(paketler) > 15:
                raise Hata("1-15 arası uygulama (paket) adı yazın")
            for p in paketler:
                if not PAKET_DESEN.match(p):
                    raise Hata("Geçersiz paket adı: " + p)
            veri = {"paketler": paketler}
        elif tur == "engel_ara":
            veri = {"dk": max(5, min(int(veri.get("dk") or 45), 480))}
        else:
            veri = {} if tur not in ("duyuru", "kapat", "zil") else veri
        hedeflenecek = idler if tur in ("kaldir",) else acik
        for tid in hedeflenecek:
            komut_ekle(tid, tur, veri, omur)
        ek = ""
        if tur == "duyuru":
            ek = ": " + (veri["baslik"] or veri["metin"])[:80]
        elif tur == "icerik_ac":
            ek = ": " + (veri.get("adres") or veri.get("yol"))[:100]
        elif tur in ("paket_kur", "paket_kaldir"):
            ek = ": " + ", ".join(veri["paketler"])
        elif tur == "engel_ara":
            ek = " ({} dk)".format(veri["dk"])
        olay("", "duyuru" if tur == "duyuru" else "komut",
             "{} → {}{}".format(KOMUT_ADI[tur], hedef_yazi(g.get("hedef"), len(idler)), ek))
        self.yanit({"ok": True, "hedef": len(idler), "gonderilen": len(hedeflenecek)})

    def p_tahta(self, y):
        g = self.json_oku()
        tid = g.get("id")
        r = db.bir("SELECT * FROM tahta WHERE id=?", (tid,))
        if not r:
            raise Hata("Tahta bulunamadı", 404)
        ad = (g.get("ad") if g.get("ad") is not None else r["ad"]).strip()[:60]
        grup = (g.get("grup") if g.get("grup") is not None else r["grup"] or "").strip()[:40]
        if not ad:
            raise Hata("Tahta adı boş olamaz")
        db.x("UPDATE tahta SET ad=?, grup=? WHERE id=?", (ad, grup, tid))
        if ad != r["ad"]:
            olay(tid, "sistem", "Adı değiştirildi: {} → {}".format(r["ad"], ad))
        uyandir(tid)
        self.yanit({"ok": True})

    def p_tahta_sil(self, y):
        g = self.json_oku()
        tid = g.get("id")
        r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
        if not r:
            raise Hata("Tahta bulunamadı", 404)
        if g.get("kaldir"):
            komut_ekle(tid, "kaldir", {})
            silinenler[tid] = simdi()
        db.x("DELETE FROM tahta WHERE id=?", (tid,))
        with canli_kilit:
            canli.pop(tid, None) if not g.get("kaldir") else None
        olay("", "sistem", "Tahta listeden silindi: {}".format(r["ad"]))
        self.yanit({"ok": True})

    def p_ekran(self, y):
        tid = self.sorgu.get("id", "")
        boyut = ekran_boyutu(self.sorgu.get("boyut"))
        c = canli.get(tid)
        e = c and (c.ekran.get(boyut) or c.ekran.get("buyuk") or c.ekran.get("kucuk"))
        if not e:
            raise Hata("Görüntü yok", 404)
        bas = {"Cache-Control": "private, max-age=600"}
        if self.sorgu.get("indir"):
            r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
            ad = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", (r["ad"] if r else "tahta"))[:60]
            ad = "{} {}.jpg".format(ad, datetime.fromtimestamp(e[0]).strftime("%Y-%m-%d %H.%M.%S"))
            bas["Content-Disposition"] = "attachment; filename*=UTF-8''" + quote(ad)
        self.yanit(e[2], mime=e[1], basliklar=bas)

    def p_ekran_iste(self, y):
        g = self.json_oku()
        c = canli.get(g.get("id"))
        if not cevrimici_mi(c):
            raise Hata("Tahta kapalı")
        c.ekran_istek[ekran_boyutu(g.get("boyut"))] = simdi()
        uyandir(c.id)
        self.yanit({"ok": True})

    # ── panel: lehçe/pano duyuruları ─────────────────────────────────────────
    def p_panolar(self, y):
        n = simdi()
        liste = [p for p in db.ayar("panolar") if p.get("bitis", 0) > n]
        self.yanit({"panolar": liste})

    def p_pano(self, y):
        g = self.json_oku()
        metin = (g.get("metin") or "").strip()[:600]
        if not metin:
            raise Hata("Metin boş olamaz")
        gun = max(1, min(int(g.get("gun") or 1), 90))
        n = simdi()
        liste = [p for p in db.ayar("panolar") if p.get("bitis", 0) > n]
        liste.append({"id": uuid.uuid4().hex[:8], "baslik": (g.get("baslik") or "").strip()[:120],
                      "metin": metin, "hedef": g.get("hedef") or {"hepsi": True},
                      "olusma": n, "bitis": n + gun * 86400})
        db.ayar_yaz("panolar", liste)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_pano_sil(self, y):
        g = self.json_oku()
        db.ayar_yaz("panolar", [p for p in db.ayar("panolar") if p.get("id") != g.get("id")])
        hepsini_uyandir()
        self.yanit({"ok": True})

    # ── panel: dosyalar ──────────────────────────────────────────────────────
    def p_dosya(self, y):
        if y != "POST":
            raise Hata("Geçersiz istek")
        ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "dosya"))
        try:
            hedef = json.loads(unquote(self.headers.get("X-Hedef") or "{}"))
        except Exception:
            raise Hata("Geçersiz hedef")
        idler = hedef_cozumle(hedef)
        if not idler:
            raise Hata("Seçili tahta yok")
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            raise Hata("Dosya boş")
        if n > 2 * 1024 ** 3:
            raise Hata("Dosya 2 GB'dan büyük olamaz", 413)
        fid = uuid.uuid4().hex[:16]
        klasor = VERI / "dosyalar" / fid
        klasor.mkdir(parents=True, exist_ok=True)
        kalan = n
        with open(klasor / ad, "wb") as f:
            while kalan > 0:
                parca = self.rfile.read(min(kalan, 256 * 1024))
                if not parca:
                    break
                f.write(parca)
                kalan -= len(parca)
        if kalan:
            raise Hata("Dosya eksik yüklendi")
        ac = self.headers.get("X-Ac") == "1"
        db.x("INSERT INTO dosya(id, ad, boyut, zaman, hedefler, teslim, ac) VALUES(?,?,?,?,?,?,?)",
             (fid, ad, n, simdi(), json.dumps(idler), "[]", 1 if ac else 0))
        for tid in idler:
            komut_ekle(tid, "dosya", {"fid": fid, "ad": ad, "boyut": n, "ac": ac})
        olay("", "dosya", "Dosya gönderildi: {} → {}".format(ad, hedef_yazi(hedef, len(idler))))
        self.yanit({"ok": True, "id": fid, "hedef": len(idler)})

    def p_dosyalar(self, y):
        liste = []
        for r in db.q("SELECT * FROM dosya ORDER BY zaman DESC LIMIT 100"):
            hedefler = json.loads(r["hedefler"] or "[]")
            teslim = json.loads(r["teslim"] or "[]")
            liste.append({"id": r["id"], "ad": r["ad"], "boyut": r["boyut"], "zaman": r["zaman"],
                          "hedef": len(hedefler), "teslim": len(teslim),
                          "bekleyen": [tahta_adi(t) for t in hedefler if t not in teslim][:30]})
        self.yanit({"dosyalar": liste})

    def p_dosya_sil(self, y):
        g = self.json_oku()
        fid = re.sub(r"[^a-f0-9]", "", g.get("id") or "")
        db.x("DELETE FROM dosya WHERE id=?", (fid,))
        db.x("DELETE FROM bekleyen WHERE tur='dosya' AND veri LIKE ?", ('%"' + fid + '"%',))
        klasor = VERI / "dosyalar" / fid
        if fid and klasor.is_dir():
            for f in klasor.iterdir():
                f.unlink()
            klasor.rmdir()
        self.yanit({"ok": True})

    # ── panel: zamanlayıcı ───────────────────────────────────────────────────
    def kural_dogrula(self, k):
        if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", k.get("saat") or ""):
            raise Hata("Saat geçersiz")
        if k.get("tur") not in KURAL_KOMUTLARI:
            raise Hata("İşlem geçersiz")
        gunler = sorted({int(x) for x in (k.get("gunler") or []) if 1 <= int(x) <= 7})
        if not gunler:
            raise Hata("En az bir gün seçin")
        veri = k.get("veri") or {}
        if k["tur"] == "duyuru":
            veri = {"baslik": (veri.get("baslik") or "").strip()[:120],
                    "metin": (veri.get("metin") or "").strip()[:1500],
                    "stil": "kucuk" if veri.get("stil") == "kucuk" else "buyuk",
                    "sure": max(5, min(int(veri.get("sure") or 20), 3600)), "ses": True}
            if not veri["metin"]:
                raise Hata("Duyuru metni boş olamaz")
        elif k["tur"] == "zil":
            veri = {"tur": "teneffus" if veri.get("tur") == "teneffus" else "ders"}
        elif k["tur"] == "kapat":
            veri = {"gecikme": max(0, min(int(veri.get("gecikme") or 0), 3600))}
        elif k["tur"] == "kilit_araligi":
            bitis = veri.get("bitis") or ""
            if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bitis):
                raise Hata("Bitiş saati geçersiz")
            if bitis <= k["saat"]:
                raise Hata("Bitiş saati başlangıçtan sonra olmalı")
            veri = {"bitis": bitis, "ogretmen": bool(veri.get("ogretmen", True)),
                    "bitince_ac": bool(veri.get("bitince_ac", True))}
        else:
            veri = {}
        return {"id": k.get("id") or uuid.uuid4().hex[:10], "saat": k["saat"], "gunler": gunler,
                "tur": k["tur"], "veri": veri, "hedef": k.get("hedef") or {"hepsi": True},
                "aktif": bool(k.get("aktif", True)), "etiket": (k.get("etiket") or "")[:40],
                "aciklama": (k.get("aciklama") or "").strip()[:80]}

    def p_kurallar(self, y):
        liste = [json.loads(r["veri"]) for r in db.q("SELECT veri FROM kural")]
        liste.sort(key=lambda k: (k["saat"], k["tur"]))
        self.yanit({"kurallar": liste, "etkin": db.ayar("zamanlayici_etkin")})

    def p_kural(self, y):
        k = self.kural_dogrula(self.json_oku())
        db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        hepsini_uyandir()
        self.yanit({"ok": True, "kural": k})

    def p_aralik_bitir(self, y):
        """Kilitli saat aralığını bugün için erken bitirir (yarın yine çalışır)."""
        g = self.json_oku()
        kid = str(g.get("id") or "")
        r = db.bir("SELECT veri FROM kural WHERE id=?", (kid,))
        if not r:
            raise Hata("Kural bulunamadı")
        bugun = time.strftime("%Y-%m-%d")
        a = db.ayar("aralik_atla") or {}
        idler = set(a.get("idler") or []) if a.get("tarih") == bugun else set()
        idler.add(kid)
        db.ayar_yaz("aralik_atla", {"tarih": bugun, "idler": sorted(idler)})
        k = json.loads(r["veri"])
        olay("", "kural", "Kilitli saat aralığı bugün için bitirildi: {}".format(k.get("aciklama") or k.get("saat")))
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_kurallar_toplu(self, y):
        g = self.json_oku()
        yeni = [self.kural_dogrula(k) for k in (g.get("kurallar") or [])]
        if g.get("sil_etiket"):
            for r in db.q("SELECT id, veri FROM kural"):
                if json.loads(r["veri"]).get("etiket") == g["sil_etiket"]:
                    db.x("DELETE FROM kural WHERE id=?", (r["id"],))
        for k in yeni:
            db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        hepsini_uyandir()
        olay("", "sistem", "Zamanlayıcıya {} kural eklendi".format(len(yeni)))
        self.yanit({"ok": True, "sayi": len(yeni)})

    def p_kural_sil(self, y):
        g = self.json_oku()
        if g.get("etiket"):
            for r in db.q("SELECT id, veri FROM kural"):
                if json.loads(r["veri"]).get("etiket") == g["etiket"]:
                    db.x("DELETE FROM kural WHERE id=?", (r["id"],))
        else:
            db.x("DELETE FROM kural WHERE id=?", (g.get("id"),))
        hepsini_uyandir()
        self.yanit({"ok": True})

    # ── panel: kayıtlar ve rapor ─────────────────────────────────────────────
    def p_olaylar(self, y):
        sinir = max(10, min(int(self.sorgu.get("sinir") or 200), 1000))
        kosul, args = [], []
        if self.sorgu.get("tahta"):
            kosul.append("tahta=?")
            args.append(self.sorgu["tahta"])
        if self.sorgu.get("tur"):
            kosul.append("tur=?")
            args.append(self.sorgu["tur"])
        if self.sorgu.get("once"):
            kosul.append("zaman<?")
            args.append(float(self.sorgu["once"]))
        sql = "SELECT * FROM olay" + (" WHERE " + " AND ".join(kosul) if kosul else "") + " ORDER BY zaman DESC LIMIT ?"
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        liste = db.q(sql, args + [sinir])
        for o in liste:
            o["tahta_ad"] = adlar.get(o["tahta"], "") if o["tahta"] else ""
        self.yanit({"olaylar": liste})

    def kullanim_verisi(self, gun_sayisi):
        kullanim_yaz()
        bas = time.strftime("%Y-%m-%d", time.localtime(simdi() - (gun_sayisi - 1) * 86400))
        satirlar = db.q("SELECT * FROM kullanim WHERE gun>=? ORDER BY gun", (bas,))
        return satirlar

    def p_kullanim(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 7), 90))
        tahtalar = {r["id"]: {"ad": r["ad"], "grup": r["grup"]} for r in db.q("SELECT id, ad, grup FROM tahta")}
        self.yanit({"satirlar": self.kullanim_verisi(gun), "tahtalar": tahtalar, "gun": gun})

    def p_kullanim_csv(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        tampon = io.StringIO()
        w = csv.writer(tampon, delimiter=";")
        w.writerow(["Tarih", "Tahta", "Açık kalma (saat)", "Aktif kullanım (saat)"])
        for r in self.kullanim_verisi(gun):
            w.writerow([r["gun"], adlar.get(r["tahta"], r["tahta"]),
                        str(round(r["acik"] / 3600, 2)).replace(".", ","),
                        str(round(r["aktif"] / 3600, 2)).replace(".", ",")])
        veri = ("﻿" + tampon.getvalue()).encode("utf-8")
        self.yanit(veri, mime="text/csv; charset=utf-8", basliklar={
            "Content-Disposition": "attachment; filename=tahta-kullanim-raporu.csv"})

    # ── panel: kurulum yardımı ───────────────────────────────────────────────
    def p_kurulum_bilgi(self, y):
        self.yanit({"adresler": yerel_adresler(), "port": PORT, "ajan_surum": AJAN_SURUM})

    def p_kurulum_dosyasi_win(self, y):
        ip = self.sorgu.get("ip") or (yerel_adresler() or ["127.0.0.1"])[0]
        self.windows_kurulum(ip, self.sorgu.get("ad", ""))

    def p_kurulum_dosyasi(self, y):
        ip = self.sorgu.get("ip") or (yerel_adresler() or ["127.0.0.1"])[0]
        ad = tahta_adi_temizle(self.sorgu.get("ad", ""))
        dosya = "tahta-kur-{}.sh".format(re.sub(r"[^A-Za-z0-9\-]+", "_", ad).strip("_")) if ad else "tahta-kur.sh"
        self.kurulum_betigi(ip, {"Content-Disposition": "attachment; filename=" + dosya}, ad=ad)

    # ── panel: ayarlar ───────────────────────────────────────────────────────
    def p_ayarlar(self, y):
        if y == "POST":
            g = self.json_oku()
            if "okul_adi" in g:
                db.ayar_yaz("okul_adi", str(g["okul_adi"]).strip()[:120])
            if "kilit" in g:
                k = db.ayar("kilit")
                gk = g["kilit"] or {}
                if "acilista" in gk:
                    k["acilista"] = bool(gk["acilista"])
                if "duyuru_goster" in gk:
                    k["duyuru_goster"] = bool(gk["duyuru_goster"])
                if "mesaj" in gk:
                    k["mesaj"] = str(gk["mesaj"]).strip()[:200]
                for alan in ("bosta_kilit_dk", "bosta_kapat_dk"):
                    if alan in gk:
                        k[alan] = max(0, min(int(gk[alan] or 0), 600))
                db.ayar_yaz("kilit", k)
            for alan in ("zamanlayici_etkin", "onizleme", "zil_sesi_ac", "ariza_simge"):
                if alan in g:
                    db.ayar_yaz(alan, bool(g[alan]))
            if "saat_koruyucu_dk" in g:
                db.ayar_yaz("saat_koruyucu_dk", max(0, min(int(g["saat_koruyucu_dk"] or 0), 120)))
            hepsini_uyandir()
        zil = {t: b.get("ad") for t, b in (db.ayar("zil_ozel") or {}).items()}
        self.yanit({
            "ariza_simge": db.ayar("ariza_simge"), "saat_koruyucu_dk": db.ayar("saat_koruyucu_dk"),
            "okul_adi": db.ayar("okul_adi"), "kilit": db.ayar("kilit"),
            "zamanlayici_etkin": db.ayar("zamanlayici_etkin"), "onizleme": db.ayar("onizleme"),
            "zil_sesi_ac": db.ayar("zil_sesi_ac"), "zil_ozel": zil,
            "pinler": [{"id": p["id"], "ad": p["ad"]} for p in db.ayar("pinler")],
            "sistem": {"surum": SURUM, "ajan_surum": AJAN_SURUM, "veri": str(VERI),
                       "adresler": yerel_adresler(), "port": PORT,
                       "calisma_sn": int(simdi() - BASLAMA)},
        })

    def p_pin(self, y):
        g = self.json_oku()
        pinler = db.ayar("pinler")
        if g.get("sil"):
            if len(pinler) <= 1:
                raise Hata("En az bir şifre kalmalı")
            pinler = [p for p in pinler if p["id"] != g["sil"]]
        else:
            ad = (g.get("ad") or "").strip()[:40]
            pin = re.sub(r"\D", "", g.get("pin") or "")
            if not ad:
                raise Hata("Ad yazın (ör. Ayşe Öğretmen veya 9. sınıflar)")
            if not 4 <= len(pin) <= 8:
                raise Hata("Şifre 4-8 rakam olmalı")
            for p in pinler:
                if hashlib.sha256((p["tuz"] + pin).encode()).hexdigest() == p["ozet"]:
                    raise Hata("Bu şifre zaten kullanılıyor")
            tuz = secrets.token_hex(8)
            pinler.append({"id": uuid.uuid4().hex[:8], "ad": ad, "tuz": tuz,
                           "ozet": hashlib.sha256((tuz + pin).encode()).hexdigest()})
        db.ayar_yaz("pinler", pinler)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_sifre(self, y):
        g = self.json_oku()
        if not sifre_dogru(g.get("eski") or "", db.ayar("sifre")):
            raise Hata("Mevcut şifre hatalı")
        if len(g.get("yeni") or "") < 6:
            raise Hata("Yeni şifre en az 6 karakter olmalı")
        db.ayar_yaz("sifre", sifre_ozet(g["yeni"]))
        olay("", "sistem", "Yönetici şifresi değiştirildi")
        self.yanit({"ok": True})

    def p_zil_sesi(self, y):
        tur = "teneffus" if self.sorgu.get("tur") == "teneffus" else "ders"
        ozel = db.ayar("zil_ozel") or {}
        if self.sorgu.get("sil"):
            ozel.pop(tur, None)
        else:
            ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "zil.wav"))
            uzanti = (ad.rsplit(".", 1)[-1].lower() if "." in ad else "wav")
            if uzanti not in ("wav", "mp3", "ogg", "oga", "flac"):
                raise Hata("Desteklenen biçimler: WAV, MP3, OGG, FLAC")
            veri = self.ham_oku(20 * 1024 * 1024)
            (VERI / "sesler").mkdir(parents=True, exist_ok=True)
            (VERI / "sesler" / "{}.{}".format(tur, uzanti)).write_bytes(veri)
            ozel[tur] = {"ad": ad, "uzanti": uzanti, "ozet": hashlib.sha1(veri).hexdigest()[:12]}
        db.ayar_yaz("zil_ozel", ozel)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_yedek(self, y):
        veri = {
            "uygulama": "TahtaYonetim", "surum": SURUM, "tarih": time.strftime("%Y-%m-%d %H:%M"),
            "ayarlar": {r["anahtar"]: json.loads(r["deger"]) for r in db.q("SELECT * FROM ayar")},
            "tahtalar": db.q("SELECT id, ad, grup, bilgi, eklenme FROM tahta"),
            "kurallar": [json.loads(r["veri"]) for r in db.q("SELECT veri FROM kural")],
        }
        ad = "tahta-yonetim-yedek-{}.json".format(time.strftime("%Y%m%d"))
        self.yanit(json.dumps(veri, ensure_ascii=False, indent=1),
                   basliklar={"Content-Disposition": "attachment; filename=" + ad})

    def p_geri_yukle(self, y):
        g = self.json_oku(sinir=20 * 1024 * 1024)
        if g.get("uygulama") != "TahtaYonetim":
            raise Hata("Bu dosya Tahta Yönetim yedeği değil")
        for k, v in (g.get("ayarlar") or {}).items():
            if k in VARSAYILAN_AYAR:
                db.ayar_yaz(k, v)
        for t in g.get("tahtalar") or []:
            db.x("INSERT OR REPLACE INTO tahta(id, ad, grup, bilgi, eklenme, son) VALUES(?,?,?,?,?,0)",
                 (t["id"], t["ad"], t.get("grup") or "", t.get("bilgi") or "{}", t.get("eklenme") or simdi()))
        db.x("DELETE FROM kural")
        for k in g.get("kurallar") or []:
            db.x("INSERT INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        olay("", "sistem", "Yedekten geri yüklendi ({})".format(g.get("tarih", "")))
        hepsini_uyandir()
        self.yanit({"ok": True})

    # ── panel: sınav ve tam ekran saat ───────────────────────────────────────
    @staticmethod
    def bugun_saat(hhmm):
        m = re.match(r"^([01]\d|2[0-3]):([0-5]\d)$", hhmm or "")
        if not m:
            raise Hata("Saat geçersiz")
        t = time.localtime()
        return time.mktime((t.tm_year, t.tm_mon, t.tm_mday, int(m.group(1)), int(m.group(2)), 0, 0, 0, -1))

    def p_sinav(self, y):
        n = simdi()
        liste = [s for s in db.ayar("sinavlar") or [] if s.get("bitis", 0) + 180 > n]
        if y == "POST":
            g = self.json_oku()
            islem = g.get("islem")
            if islem == "baslat":
                baslik = (g.get("baslik") or "").strip()[:80]
                if not baslik:
                    raise Hata("Sınavın adını yazın")
                bas = n
                if g.get("bas_saat"):
                    bas = self.bugun_saat(g["bas_saat"])
                    if bas < n - 60:
                        raise Hata("Başlangıç saati geçmiş")
                if g.get("bitis_saat"):
                    bitis = self.bugun_saat(g["bitis_saat"])
                else:
                    sure = int(g.get("sure_dk") or 0)
                    if not 1 <= sure <= 600:
                        raise Hata("Süre 1-600 dakika arasında olmalı")
                    bitis = bas + sure * 60
                if bitis <= max(bas, n):
                    raise Hata("Bitiş saati başlangıçtan sonra olmalı")
                hedef = g.get("hedef") or {"hepsi": True}
                sayi = len(hedef_cozumle(hedef))
                if not sayi:
                    raise Hata("Seçili tahta yok")
                liste.append({"id": uuid.uuid4().hex[:8], "baslik": baslik, "bas": bas, "bitis": bitis,
                              "uyari_dk": max(0, min(int(g.get("uyari_dk") or 0), 60)), "ses": bool(g.get("ses", True)),
                              "hedef": hedef, "olusma": n})
                olay("", "sinav", "Sınav: {} ({}–{}) → {}".format(baslik, time.strftime("%H:%M", time.localtime(bas)),
                                                                  time.strftime("%H:%M", time.localtime(bitis)), hedef_yazi(hedef, sayi)))
            else:
                s = next((x for x in liste if x["id"] == g.get("id")), None)
                if not s:
                    raise Hata("Sınav bulunamadı", 404)
                if islem == "uzat":
                    dk = max(1, min(int(g.get("dk") or 5), 120))
                    s["bitis"] = max(s["bitis"], n) + dk * 60
                    olay("", "sinav", "Sınav süresi uzatıldı: {} (+{} dk)".format(s["baslik"], dk))
                elif islem == "bitir":
                    s["bitis"] = min(s["bitis"], n)
                    s["bas"] = min(s["bas"], n)
                    olay("", "sinav", "Sınav bitirildi: {}".format(s["baslik"]))
                elif islem == "kapat":
                    liste = [x for x in liste if x["id"] != s["id"]]
                    olay("", "sinav", "Sınav ekranı kapatıldı: {}".format(s["baslik"]))
                else:
                    raise Hata("Geçersiz işlem")
            db.ayar_yaz("sinavlar", liste)
            hepsini_uyandir()
        for s in liste:
            s["hedef_yazi"] = hedef_yazi(s["hedef"], len(hedef_cozumle(s["hedef"])))
        self.yanit({"sinavlar": liste, "zaman": simdi()})

    def p_saat(self, y):
        liste = db.ayar("saatler") or []
        if y == "POST":
            g = self.json_oku()
            islem = g.get("islem")
            if islem == "baslat":
                hedef = g.get("hedef") or {"hepsi": True}
                sayi = len(hedef_cozumle(hedef))
                if not sayi:
                    raise Hata("Seçili tahta yok")
                liste.append({"id": uuid.uuid4().hex[:8], "mesaj": (g.get("mesaj") or "").strip()[:120],
                              "kapatilabilir": bool(g.get("kapatilabilir")), "hedef": hedef, "olusma": simdi()})
                olay("", "komut", "Tam ekran saat → {}".format(hedef_yazi(hedef, sayi)))
            elif islem == "durdur":
                liste = [s for s in liste if s["id"] != g.get("id")]
            elif islem == "durdur_tahta":
                tid = g.get("tahta")
                t = db.bir("SELECT grup FROM tahta WHERE id=?", (tid,))
                yeni = []
                for s in liste:
                    if t and hedef_kapsar(s["hedef"], tid, t["grup"]):
                        kalan = [x for x in hedef_cozumle(s["hedef"]) if x != tid]
                        if not kalan:
                            continue
                        s["hedef"] = {"idler": kalan}
                    yeni.append(s)
                liste = yeni
            elif islem == "hepsini_durdur":
                liste = []
            else:
                raise Hata("Geçersiz işlem")
            db.ayar_yaz("saatler", liste)
            hepsini_uyandir()
        for s in liste:
            s["hedef_yazi"] = hedef_yazi(s["hedef"], len(hedef_cozumle(s["hedef"])))
        self.yanit({"saatler": liste, "koruyucu_dk": db.ayar("saat_koruyucu_dk")})

    # ── panel: site engeli ───────────────────────────────────────────────────
    def p_site_engel(self, y):
        e = db.ayar("site_engel") or {}
        if y == "POST":
            g = self.json_oku()
            siteler = []
            for s in g.get("siteler") or []:
                a = alan_temizle(s)
                if a and a not in siteler:
                    siteler.append(a)
            if len(siteler) > 300:
                raise Hata("En fazla 300 site eklenebilir")
            araliklar = []
            for a in g.get("araliklar") or []:
                bas, bit = a.get("bas") or "", a.get("bit") or ""
                if not (re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bas) and re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bit)) or bas >= bit:
                    raise Hata("Saat aralığı geçersiz: {} – {}".format(bas, bit))
                gunler = sorted({int(x) for x in (a.get("gunler") or []) if 1 <= int(x) <= 7})
                if not gunler:
                    raise Hata("Her saat aralığı için en az bir gün seçin")
                araliklar.append({"gunler": gunler, "bas": bas, "bit": bit})
            zaman = "saatlerde" if g.get("zaman") == "saatlerde" else "her_zaman"
            if zaman == "saatlerde" and not araliklar:
                raise Hata("En az bir saat aralığı ekleyin")
            e = {"etkin": bool(g.get("etkin")), "siteler": siteler, "hedef": g.get("hedef") or {"hepsi": True},
                 "zaman": zaman, "araliklar": araliklar}
            if e["etkin"] and not siteler:
                raise Hata("Engellenecek en az bir site ekleyin")
            db.ayar_yaz("site_engel", e)
            olay("", "sistem", "Site engeli {} ({} site)".format("açık" if e["etkin"] else "kapalı", len(siteler)))
            hepsini_uyandir()
        self.yanit(e)

    # ── panel: arızalar ──────────────────────────────────────────────────────
    def p_arizalar(self, y):
        durum = self.sorgu.get("durum") or "acik"
        kosul, args = [], []
        if durum == "acik":
            kosul.append("durum!='cozuldu'")
        elif durum == "cozuldu":
            kosul.append("durum='cozuldu'")
        if self.sorgu.get("tahta"):
            kosul.append("tahta=?")
            args.append(self.sorgu["tahta"])
        liste = db.q("SELECT * FROM ariza" + (" WHERE " + " AND ".join(kosul) if kosul else "") +
                     " ORDER BY zaman DESC LIMIT 300", args)
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        for a in liste:
            a["tahta_ad"] = adlar.get(a["tahta"], "Silinmiş tahta")
        self.yanit({"arizalar": liste, "turler": ARIZA_TURLERI, "simge": db.ayar("ariza_simge")})

    def p_ariza(self, y):
        g = self.json_oku()
        aid = int(g.get("id") or 0)
        r = db.bir("SELECT * FROM ariza WHERE id=?", (aid,))
        if not r:
            raise Hata("Kayıt bulunamadı", 404)
        if g.get("sil"):
            db.x("DELETE FROM ariza WHERE id=?", (aid,))
            return self.yanit({"ok": True})
        durum = g.get("durum") if g.get("durum") in ("yeni", "inceleniyor", "cozuldu") else r["durum"]
        notlar = str(g["notlar"] if g.get("notlar") is not None else (r["notlar"] or ""))[:500]
        db.x("UPDATE ariza SET durum=?, notlar=?, guncelleme=? WHERE id=?", (durum, notlar, simdi(), aid))
        if durum != r["durum"]:
            olay(r["tahta"], "ariza", "Arıza ({}) → {}".format(
                r["kategori"], {"yeni": "Yeni", "inceleniyor": "İnceleniyor", "cozuldu": "Çözüldü"}[durum]))
        self.yanit({"ok": True})

    # ── panel: kullanım süreleri ─────────────────────────────────────────────
    def p_cizelge(self, y):
        gun = self.sorgu.get("gun") or time.strftime("%Y-%m-%d")
        try:
            bas = time.mktime(time.strptime(gun, "%Y-%m-%d"))
        except ValueError:
            raise Hata("Tarih geçersiz")
        son = bas + 86400
        araliklari_yaz()
        satirlar = db.q("SELECT tahta, tur, ad, bas, bit FROM aralik WHERE bas<? AND bit>?", (son, bas))
        self.yanit({"gun": gun, "bas": bas, "son": son, "tahtalar": db.q("SELECT id, ad, grup FROM tahta"),
                    "araliklar": [[s["tahta"], s["tur"], s["ad"], max(s["bas"], bas), min(s["bit"], son)] for s in satirlar]})

    def ogretmen_verisi(self, gun_sayisi):
        araliklari_yaz()
        bas = time.mktime(time.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d")) - (gun_sayisi - 1) * 86400
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        ozet = {}
        for s in db.q("SELECT tahta, ad, bas, bit FROM aralik WHERE tur='ogretmen' AND bit>?", (bas,)):
            sure = s["bit"] - max(s["bas"], bas)
            if sure <= 0:
                continue
            o = ozet.setdefault(s["ad"], {"sure": 0.0, "gunler": set(), "tahtalar": {}, "son": 0.0})
            o["sure"] += sure
            o["gunler"].add(time.strftime("%Y-%m-%d", time.localtime(max(s["bas"], bas))))
            ta = adlar.get(s["tahta"], "Silinmiş tahta")
            o["tahtalar"][ta] = o["tahtalar"].get(ta, 0) + sure
            o["son"] = max(o["son"], s["bit"])
        liste = [{"ad": ad, "sure": o["sure"], "gun": len(o["gunler"]), "son": o["son"],
                  "tahtalar": sorted(o["tahtalar"].items(), key=lambda x: -x[1])[:5]} for ad, o in ozet.items()]
        return sorted(liste, key=lambda x: -x["sure"])

    def p_ogretmenler(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        self.yanit({"ogretmenler": self.ogretmen_verisi(gun), "gun": gun, "pin_sayisi": len(db.ayar("pinler"))})

    def p_ogretmenler_csv(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        tampon = io.StringIO()
        w = csv.writer(tampon, delimiter=";")
        w.writerow(["Öğretmen", "Toplam kullanım (saat)", "Gün sayısı", "En çok kullandığı tahtalar", "Son kullanım"])
        for o in self.ogretmen_verisi(gun):
            w.writerow([o["ad"], str(round(o["sure"] / 3600, 2)).replace(".", ","), o["gun"],
                        ", ".join(t for t, _ in o["tahtalar"][:3]), time.strftime("%d.%m.%Y %H:%M", time.localtime(o["son"]))])
        self.yanit(("﻿" + tampon.getvalue()).encode("utf-8"), mime="text/csv; charset=utf-8", basliklar={
            "Content-Disposition": "attachment; filename=ogretmen-kullanim-raporu.csv"})

    # ── panel: ortak klasör ──────────────────────────────────────────────────
    def p_ortak(self, y):
        o = depo.ozet_bilgi()
        cihazlar = []
        for r in db.q("SELECT * FROM tahta ORDER BY ad COLLATE NOCASE"):
            c = canli.get(r["id"])
            d = (c.durum if c else {}) or {}
            cihazlar.append({"id": r["id"], "ad": r["ad"], "tur": "tahta", "cevrimici": cevrimici_mi(c),
                             "ortak": d.get("ortak"), "son": r["son"]})
        for r in db.q("SELECT * FROM istemci ORDER BY ad COLLATE NOCASE"):
            b = json.loads(r["bilgi"] or "{}")
            cihazlar.append({"id": r["id"], "ad": r["ad"], "tur": "bilgisayar", "cevrimici": simdi() - (r["son"] or 0) < 150,
                             "ortak": b.get("ortak"), "son": r["son"], "kullanici": b.get("kullanici"), "ip": b.get("ip")})
        o.update(cihazlar=cihazlar, islemler=db.q("SELECT * FROM olay WHERE tur='ortak' ORDER BY zaman DESC LIMIT 25"),
                 adresler=yerel_adresler(), port=PORT, windows=os.name == "nt",
                 yerel=self.client_address[0] in ("127.0.0.1", "::1"))
        self.yanit(o)

    def p_ortak_ayar(self, y):
        g = self.json_oku()
        a = depo.ayar()
        if "etkin" in g:
            a["etkin"] = bool(g["etkin"])
        if "kota_gb" in g:
            a["kota_gb"] = max(1, min(int(g["kota_gb"] or 20), 4000))
        if g.get("tahta_izin") in ("tam", "ekleme"):
            a["tahta_izin"] = g["tahta_izin"]
        db.ayar_yaz("ortak", a)
        depo.bildir()
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_ortak_cop(self, y):
        self.yanit({"cop": depo.cop_listesi()})

    def p_ortak_geri(self, y):
        self.yanit(depo.geri_yukle(self.json_oku().get("id"), "Yönetici"))

    def p_ortak_cop_sil(self, y):
        g = self.json_oku()
        for r in (depo.cop_listesi() if g.get("hepsi") else [{"id": g.get("id")}]):
            depo.cop_sil(r["id"])
        self.yanit({"ok": True})

    def p_ortak_surumler(self, y):
        if self.sorgu.get("yol"):
            return self.yanit({"surumler": depo.surumler(self.sorgu["yol"])})
        self.yanit({"surumler": db.q("SELECT * FROM ortak_surum ORDER BY zaman DESC LIMIT 60")})

    def p_ortak_surum_geri(self, y):
        self.yanit(depo.surum_geri(self.json_oku().get("id"), "Yönetici"))

    def p_ortak_klasoru_ac(self, y):
        if os.name != "nt" or self.client_address[0] not in ("127.0.0.1", "::1"):
            raise Hata("Klasör yalnızca yönetim bilgisayarının kendisinden açılabilir")
        os.startfile(str(depo.kok))
        self.yanit({"ok": True})

    def p_tani(self, y):
        metin = tani_raporu()
        ad = "tani-raporu-{}.txt".format(datetime.now().strftime("%Y%m%d-%H%M"))
        self.yanit(("\ufeff" + metin).encode("utf-8"), mime="text/plain; charset=utf-8",
                   basliklar={"Content-Disposition": "attachment; filename=" + ad})

    def p_istemci_sil(self, y):
        db.x("DELETE FROM istemci WHERE id=?", (self.json_oku().get("id"),))
        self.yanit({"ok": True})

    # ── Ortak Klasör web sayfası (öğretmenler) ───────────────────────────────
    def o_giris(self, y):
        ip = self.client_address[0]
        anahtar = ("pin", ip)
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(anahtar, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        p = pin_bul(self.json_oku().get("pin"))
        if not p:
            denemeler.append(n)
            giris_denemeleri[anahtar] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(anahtar, None)
        b = secrets.token_urlsafe(32)
        db.x("INSERT INTO oturum(belirtec, bitis, tur, ad) VALUES(?,?,?,?)",
             (hashlib.sha256(b.encode()).hexdigest(), n + 12 * 3600, "ogretmen", p["ad"]))
        olay("", "giris", "Ortak Klasör sayfasına giriş: {} ({})".format(p["ad"], ip))
        self.yanit({"ok": True, "ad": p["ad"]}, basliklar={
            "Set-Cookie": "tyso={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(b, 12 * 3600)})

    def o_cikis(self, y):
        b = self.cerez("tyso")
        if b:
            db.x("DELETE FROM oturum WHERE belirtec=?", (hashlib.sha256(b.encode()).hexdigest(),))
        self.yanit({"ok": True}, basliklar={"Set-Cookie": "tyso=; Path=/; Max-Age=0"})

    def o_bilgi(self, y):
        k = self.kullanici
        kullanilan, sayi = depo.kullanilan()
        self.yanit({"okul_adi": db.ayar("okul_adi"), "giris": bool(k), "ad": k["ad"] if k else None,
                    "yonetici": bool(k and k["yonetici"]), "etkin": depo.etkin(), "kota": depo.kota(),
                    "kullanilan": kullanilan, "dosya": sayi, "kurulum_tamam": db.ayar("kurulum_tamam")})

    def o_kim(self):
        return self.kullanici["ad"] + ("" if self.kullanici["yonetici"] else " (web)")

    def o_liste(self, y):
        klasor, ogeler = depo.icerik(self.sorgu.get("klasor") or "")
        self.yanit({"klasor": klasor, "ogeler": ogeler})

    def o_indir(self, y):
        p, r = depo.indir_yolu(self.sorgu.get("yol") or "")
        mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        guvenli = mime == "application/pdf" or mime == "text/plain" or \
            mime.split("/")[0] in ("video", "audio") or mime in ("image/png", "image/jpeg", "image/gif", "image/webp")
        ac = self.sorgu.get("ac") == "1" and guvenli
        self.dosya_gonder(p, ad=p.name, satir_ici=ac, mime=mime if ac else "application/octet-stream")

    def o_yukle(self, y):
        if y != "POST":
            raise Hata("Geçersiz istek")
        n = int(self.headers.get("Content-Length") or 0)
        self.yanit(depo.yukle(unquote(self.headers.get("X-Yol") or ""), self.rfile, n, self.o_kim(),
                              mtime=float(self.headers.get("X-Mtime") or 0) or None, ustune=True))

    def o_klasor(self, y):
        self.yanit(depo.klasor(self.json_oku().get("yol") or "", self.o_kim()))

    def o_sil(self, y):
        self.yanit(depo.sil_agac(self.json_oku().get("yol") or "", self.o_kim()))

    def o_istemci_kur(self, y):
        host = (self.headers.get("Host") or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if host.split(":")[0] in ("localhost", "127.0.0.1"):
            host = "{}:{}".format((yerel_adresler() or ["127.0.0.1"])[0], PORT)
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        ps = KUR_PS1.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        bat = (ISTEMCI_BAT.replace("__SUNUCU__", "http://" + host).replace("__ANAHTAR__", db.ayar("istemci_anahtar"))
               .replace("__KIMLIK__", db.ayar("kimlik")) + "#TYS-PS1#\n" + ps).replace("\n", "\r\n")
        self.yanit(bat.encode("utf-8"), mime="application/octet-stream", basliklar={
            "Content-Disposition": "attachment; filename=OrtakKlasor-Kurulum.bat"})

    def o_tahta_anahtar(self, y):
        """Windows tahta kurulumu (KUR.bat › 3): panel yönetici şifresiyle tahta anahtarını verir."""
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        if not sifre_dogru(self.json_oku().get("sifre") or "", db.ayar("sifre")):
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(ip, None)
        olay("", "sistem", "Windows tahta kurulumu için anahtar verildi ({})".format(ip))
        self.yanit({"anahtar": db.ayar("anahtar"), "kimlik": db.ayar("kimlik")})

    def o_istemci_anahtar(self, y):
        ip = self.client_address[0]
        anahtar = ("pin", ip)
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(anahtar, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        p = pin_bul(self.json_oku().get("pin"))
        if not p:
            denemeler.append(n)
            giris_denemeleri[anahtar] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        olay("", "ortak", "Öğretmen bilgisayarı kurulumu: {} ({})".format(p["ad"], ip))
        self.yanit({"anahtar": db.ayar("istemci_anahtar"), "kimlik": db.ayar("kimlik"), "ad": socket.gethostname()})


class Sunucu(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = os.name != "nt"
    request_queue_size = 64

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        TCPServer.server_bind(self)
        self.server_name = "tys"
        self.server_port = self.server_address[1]

    def handle_error(self, request, client_address):
        e = sys.exc_info()[1]
        if not isinstance(e, (ConnectionError, TimeoutError)):
            log.exception("bağlantı hatası %s", client_address)


# ─────────────────────────────────────────────────────────────────────────────
# Başlatma
# ─────────────────────────────────────────────────────────────────────────────

def log_kur():
    VERI.mkdir(parents=True, exist_ok=True)
    h = RotatingFileHandler(str(VERI / "sunucu.log"), maxBytes=1024 * 1024, backupCount=3, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(h)
    log.setLevel(logging.INFO)
    if sys.stderr is not None and os.environ.get("TYS_KONSOL"):
        log.addHandler(logging.StreamHandler(sys.stderr))


def hazirla():
    global db, depo, AJAN_SURUM
    log_kur()
    db = Veritabani(VERI / "tahta.db")
    if not db.ayar("anahtar"):
        db.ayar_yaz("anahtar", secrets.token_urlsafe(24))
    if not db.ayar("istemci_anahtar"):
        db.ayar_yaz("istemci_anahtar", secrets.token_urlsafe(24))
    if not db.ayar("kimlik"):
        db.ayar_yaz("kimlik", uuid.uuid4().hex[:12])
    depo = ortak_mod.OrtakDepo(db, ORTAK_YOL, VERI, olay)
    AJAN_SURUM = ajan_surumu()


def calistir(port_bilgisi=None):
    """Sunucuyu başlatır ve kapanana kadar çalıştırır. Port doluysa OSError fırlatır."""
    hazirla()
    sunucu = Sunucu(("0.0.0.0", PORT), Isleyici)
    log.info("Tahta Yönetim Sunucusu %s başladı — port %s — veri %s", SURUM, PORT, VERI)
    for hedef in (arka_plan_sayac, arka_plan_zamanlayici, arka_plan_isaret, arka_plan_ortak):
        threading.Thread(target=hedef, daemon=True).start()
    if port_bilgisi:
        port_bilgisi()
    try:
        sunucu.serve_forever(poll_interval=1)
    finally:
        kullanim_yaz()
        araliklari_yaz()


def sifre_sifirla():
    """Başlat menüsündeki 'Yönetici şifresini sıfırla' kısayolu bunu çalıştırır."""
    import getpass
    hazirla()
    print("\n  Tahta Yönetim — Yönetici şifresini sıfırlama\n")
    while True:
        s1 = getpass.getpass("  Yeni şifre (en az 6 karakter, yazarken görünmez): ")
        if len(s1) < 6:
            print("  Şifre en az 6 karakter olmalı.\n")
            continue
        if getpass.getpass("  Yeni şifre (tekrar): ") != s1:
            print("  Şifreler aynı değil.\n")
            continue
        break
    db.ayar_yaz("sifre", sifre_ozet(s1))
    db.x("DELETE FROM oturum")
    olay("", "sistem", "Yönetici şifresi bu bilgisayardan sıfırlandı")
    print("\n  Şifre değiştirildi. Panele yeni şifreyle giriş yapabilirsiniz.\n")
    input("  Kapatmak için Enter'a basın...")


if __name__ == "__main__":
    if "--sifre-sifirla" in sys.argv:
        sifre_sifirla()
        sys.exit(0)
    os.environ.setdefault("TYS_KONSOL", "1")
    calistir(lambda: print("Panel: http://localhost:{}".format(PORT), flush=True))
