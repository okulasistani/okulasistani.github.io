# -*- coding: utf-8 -*-
"""
Tahta Yönetim Asistanı — Sunucu
------------------------------
İdareci (Windows) bilgisayarında çalışır. Yalnızca Python'un standart
kütüphanesini kullanır; ek paket kurmaya gerek yoktur.

Görevleri:
  * Tahtalardaki ajanlarla haberleşmek (uzun bağlantı ile anında komut)
  * Web yönetim panelini sunmak (bilgisayar ve telefon)
  * Zamanlayıcı, Wake-on-LAN, dosya paylaşımı, kullanım kayıtları
"""
import os
import re
import sys
import csv
import io
import json
import array
import wave
import math
import time
import uuid
import socket
import sqlite3
import hashlib
import hmac
import secrets
import logging
import mimetypes
import shutil
import platform
import subprocess
import threading
import urllib.request
from datetime import datetime
from pathlib import Path
from logging.handlers import RotatingFileHandler
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from socketserver import TCPServer
from urllib.parse import urlparse, parse_qs, unquote, quote

SURUM = "4.2"
PORT = int(os.environ.get("TYS_PORT", "8765"))
KESIF_PORT = 8766
PROGRAM = Path(__file__).resolve().parent
VERI = Path(os.environ.get("TYS_VERI") or (PROGRAM.parent / "veri"))
WEB = PROGRAM / "web"
AJAN_DOSYA = PROGRAM / "ajan" / "tahta-ajan.py"
KUR_SABLON = PROGRAM / "ajan" / "kur.sh"
KALDIR_SABLON = PROGRAM / "ajan" / "kaldir.sh"
TANI_SABLON = PROGRAM / "ajan" / "tani.sh"
KUR_PS1 = PROGRAM / "kur.ps1"


def _yedek_dugumu_mu():
    """veri/dugum.json içinde sıra 0'dan büyükse bu bilgisayar yedek yönetim bilgisayarıdır."""
    try:
        return int(json.loads((VERI / "dugum.json").read_text(encoding="utf-8")).get("rank") or 0) > 0
    except Exception:
        return False


# Yedek bilgisayarda Ortak Klasör'ün kopyası veri klasöründe tutulur (kişisel klasörle karışmasın)
ORTAK_YOL = Path(os.environ.get("TYS_ORTAK") or
                 ((VERI / "Ortak Klasör") if _yedek_dugumu_mu() else (Path.home() / "Ortak Klasör")))
if str(PROGRAM) not in sys.path:
    sys.path.insert(0, str(PROGRAM))
import ortak as ortak_mod  # noqa: E402
import yedek as yedek_mod  # noqa: E402

CEVRIMICI_SN = 50          # bu kadar süre haber gelmezse tahta "kapalı" sayılır
SENK_BEKLEME = 20          # ajan isteği komut yoksa en fazla bu kadar bekletilir
BASLAMA = time.time()

log = logging.getLogger("tys")

KOMUT_ADI = {"oturum_kapat": "Oturumu kapat", "kullanici_gecis": "Kullanıcıya geç", "kiosk": "Kiosk modu",
    "envanter": "Uygulama listesini yenile", "usb_geri_al": "USB temizliğini geri al", "yazici_test": "Yazıcı test sayfası", "yazici_temizle": "Yazıcı kuyruğunu temizle", 
    "kilitle": "Kilitle", "kilit_ac": "Kilidi aç", "kapat": "Kapat",
    "kapat_iptal": "Kapatmayı iptal et", "yeniden_baslat": "Yeniden başlat",
    "uyku": "Uyku modu", "duyuru": "Duyuru", "zil": "Zil", "dosya": "Dosya",
    "ac": "Uzaktan başlat", "kaldir": "Programı kaldır",
    "icerik_ac": "Site / dosya aç", "guncelle": "Sistem güncellemesi", "paket_kur": "Uygulama kur",
    "paket_kaldir": "Uygulama kaldır", "engel_ara": "Site engeline ara ver", "tani": "Tanı raporu",
    "saglik": "Sağlık bilgisi", "sifre_degistir": "Yönetici şifresi değiştir", "donem_onizle": "Yeni dönem temizliği (ön izleme)",
    "donem_temizle": "Yeni dönem temizliği", "donem_geri_al": "Yeni dönem temizliğini geri al",
    "tanila": "Tanıla", "onar": "Onar", "onar_geri": "Onarımı geri al", "yazici_onar": "Yazıcı: basmıyor, onar",
}
PANEL_KOMUTLARI = set(KOMUT_ADI) - {"dosya", "saglik", "sifre_degistir", "donem_onizle", "donem_temizle", "donem_geri_al"}
KURAL_KOMUTLARI = {"kilitle", "kilit_ac", "kapat", "yeniden_baslat", "uyku", "zil", "duyuru", "ac", "guncelle", "kilit_araligi"}
KOMUT_OMRU = {"dosya": 7 * 86400, "kaldir": 30 * 86400, "guncelle": 3600, "paket_kur": 3600, "paket_kaldir": 3600, "onar": 1800, "tanila": 900}
ARIZA_TURLERI = ["Ses yok", "Dokunmatik / kalem çalışmıyor", "Görüntü sorunu", "İnternet yok",
                 "Yavaş / donuyor", "Diğer"]
# Pardus paket adı (ör. vlc) veya Windows winget kimliği (ör. VideoLAN.VLC)
PAKET_DESEN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9+._\-]{0,80}$")

VARSAYILAN_AYAR = {
    "okul_adi": "",
    "kurulum_tamam": False,
    "sifre": "",
    "yoneticiler": [],
    "anahtar": "",
    "kimlik": "",
    "pinler": [],
    "kilit": {
        "acilista": True,
        "bosta_kilit_dk": 0,
        "bosta_kapat_dk": 0,
        "mesaj": "Bu tahta kilitlidir. Kullanmak için öğretmen şifrenizi girin.",
        "duyuru_goster": True,
    },
    "zamanlayici_etkin": True,
    "onizleme": True,
    "zil_sesi_ac": True,
    "zil_ozel": {},
    "zil_etkin": True,
    "yazici_ayar": {"otomatik": False, "kilit": False, "kayit": False},
    "usb_ayar": {"varsayilan": "uyar", "ozel": [], "wsh_kapat": False},
    "zil_programlari": [],
    "zil_sesleri": [],
    "zil_tatil": [],
    "zil_goc": False,
    "acil": None,
    "acil_plan": [],
    "acil_ozel": {},
    "acil_gecmis": [],
    "panolar": [],
    "istemci_anahtar": "",
    "ortak": {"etkin": True, "kota_gb": 20, "tahta_izin": "tam"},
    "site_engel": {"etkin": False, "siteler": [], "hedef": {"hepsi": True}, "zaman": "her_zaman", "araliklar": []},
    "sinavlar": [],
    "saatler": [],
    "saat_koruyucu_dk": 0,
    "ariza_simge": True,
    # 4.0
    "kademe": [],
    "okul_logo": None,
    "nobet": {"baslik": "Bugünün Nöbetçileri", "tablolar": []},
    "bgh": {"liste": None},
    "okul_gorunum": {"mod": "arka_plan", "hedef": {"hepsi": True}, "bgh_goster": True,
                     "serit": {"taraf": "sag", "genislik": 340, "yazi": 100, "saydamlik": 88},
                     "giris_notu": {"etkin": False, "kaynak": "nobet", "metin": ""}},
    "acilis_gorseller": [],
    "yedek_ayar": {"gunluk": True},
}

SEMA = """
CREATE TABLE IF NOT EXISTS ayar(anahtar TEXT PRIMARY KEY, deger TEXT);
CREATE TABLE IF NOT EXISTS tahta(id TEXT PRIMARY KEY, ad TEXT, grup TEXT DEFAULT '',
    bilgi TEXT DEFAULT '{}', eklenme REAL, son REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS olay(id INTEGER PRIMARY KEY AUTOINCREMENT, zaman REAL,
    tahta TEXT, tur TEXT, mesaj TEXT);
CREATE INDEX IF NOT EXISTS olay_zaman ON olay(zaman);
CREATE TABLE IF NOT EXISTS kural(id TEXT PRIMARY KEY, veri TEXT);
CREATE TABLE IF NOT EXISTS dosya(id TEXT PRIMARY KEY, ad TEXT, boyut INTEGER, zaman REAL,
    hedefler TEXT, teslim TEXT DEFAULT '[]', ac INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS kullanim(gun TEXT, tahta TEXT, acik REAL DEFAULT 0,
    aktif REAL DEFAULT 0, PRIMARY KEY(gun, tahta));
CREATE TABLE IF NOT EXISTS oturum(belirtec TEXT PRIMARY KEY, bitis REAL);
CREATE TABLE IF NOT EXISTS bekleyen(id TEXT PRIMARY KEY, tahta TEXT, tur TEXT, veri TEXT,
    olusma REAL, gecerlilik REAL);
CREATE INDEX IF NOT EXISTS bekleyen_tahta ON bekleyen(tahta);
CREATE TABLE IF NOT EXISTS ortak(anahtar TEXT PRIMARY KEY, yol TEXT, tur TEXT, boyut INTEGER DEFAULT 0,
    mtime REAL DEFAULT 0, ozet TEXT DEFAULT '', rev INTEGER, sil INTEGER DEFAULT 0, kim TEXT DEFAULT '',
    zaman REAL, ymt INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ortak_rev ON ortak(rev);
CREATE TABLE IF NOT EXISTS politika(id TEXT PRIMARY KEY, modul TEXT, tur TEXT, ad TEXT, hedef TEXT, veri TEXT,
    aktif INTEGER DEFAULT 1, surum INTEGER DEFAULT 1, olusturma REAL, guncelleme REAL, kim TEXT);
CREATE TABLE IF NOT EXISTS politika_durum(politika TEXT, tahta TEXT, durum TEXT, ayrinti TEXT, sonuc TEXT, zaman REAL,
    PRIMARY KEY(politika, tahta));
CREATE TABLE IF NOT EXISTS depo(sha TEXT PRIMARY KEY, ad TEXT, boyut INTEGER, tur TEXT, aciklama TEXT, eklenme REAL, kim TEXT);
CREATE TABLE IF NOT EXISTS yazici(tahta TEXT, anahtar TEXT, veri TEXT, ilk REAL, son REAL, takili INTEGER DEFAULT 1,
    PRIMARY KEY(tahta, anahtar));
CREATE TABLE IF NOT EXISTS yazici_model(model TEXT, platform TEXT, sonuc TEXT, yontem TEXT, surucu TEXT, ayrinti TEXT,
    zaman REAL, tahta TEXT, PRIMARY KEY(model, platform));
CREATE TABLE IF NOT EXISTS yazici_is(id INTEGER PRIMARY KEY AUTOINCREMENT, zaman REAL, tahta TEXT, kuyruk TEXT,
    paylasim TEXT, ip TEXT, istemci TEXT, ad TEXT, kullanici TEXT, sayfa INTEGER, boyut INTEGER, yontem TEXT, sonuc TEXT, hata TEXT);
CREATE INDEX IF NOT EXISTS yazici_is_zaman ON yazici_is(zaman);
CREATE TABLE IF NOT EXISTS uygulama(id TEXT PRIMARY KEY, ad TEXT, kaynak TEXT, aciklama TEXT, wine_sonuc TEXT DEFAULT '',
    olusturma REAL, guncelleme REAL);
CREATE TABLE IF NOT EXISTS usb_olay(id TEXT PRIMARY KEY, zaman REAL, tahta TEXT, seri TEXT, sonuc TEXT, veri TEXT);
CREATE INDEX IF NOT EXISTS usb_olay_zaman ON usb_olay(zaman);
CREATE TABLE IF NOT EXISTS ortak_cop(id TEXT PRIMARY KEY, yol TEXT, boyut INTEGER, zaman REAL, kim TEXT, sahip TEXT);
CREATE TABLE IF NOT EXISTS ortak_surum(id TEXT PRIMARY KEY, anahtar TEXT, yol TEXT, boyut INTEGER, zaman REAL, kim TEXT);
CREATE TABLE IF NOT EXISTS istemci(id TEXT PRIMARY KEY, ad TEXT, bilgi TEXT DEFAULT '{}', son REAL, eklenme REAL);
CREATE TABLE IF NOT EXISTS ariza(id INTEGER PRIMARY KEY AUTOINCREMENT, tahta TEXT, kategori TEXT, aciklama TEXT,
    bildiren TEXT, zaman REAL, durum TEXT DEFAULT 'yeni', notlar TEXT DEFAULT '', guncelleme REAL);
CREATE TABLE IF NOT EXISTS aralik(id INTEGER PRIMARY KEY AUTOINCREMENT, tahta TEXT, tur TEXT, ad TEXT DEFAULT '',
    bas REAL, bit REAL);
CREATE INDEX IF NOT EXISTS aralik_bas ON aralik(bas);
CREATE TABLE IF NOT EXISTS islem(id TEXT PRIMARY KEY, zaman REAL, kim TEXT, tur TEXT, ad TEXT, veri TEXT, hedef TEXT);
CREATE INDEX IF NOT EXISTS islem_zaman ON islem(zaman);
CREATE TABLE IF NOT EXISTS islem_tahta(islem TEXT, tahta TEXT, kid TEXT, durum TEXT, mesaj TEXT DEFAULT '', veri TEXT DEFAULT '',
    zaman REAL, PRIMARY KEY(islem, tahta));
CREATE INDEX IF NOT EXISTS islem_tahta_kid ON islem_tahta(kid);
CREATE TABLE IF NOT EXISTS saglik(tahta TEXT PRIMARY KEY, veri TEXT, zaman REAL);
CREATE TABLE IF NOT EXISTS tani(id INTEGER PRIMARY KEY AUTOINCREMENT, tahta TEXT, zaman REAL, kaynak TEXT, ozet TEXT, veri TEXT);
CREATE INDEX IF NOT EXISTS tani_tahta ON tani(tahta, zaman);
"""


# ─────────────────────────────────────────────────────────────────────────────
# Veritabanı
# ─────────────────────────────────────────────────────────────────────────────

class Veritabani:
    def __init__(self, yol):
        self.yol = Path(yol)
        self.k = threading.RLock()
        with self.k:
            self._ac()

    def _ac(self):
        self.c = sqlite3.connect(str(self.yol), check_same_thread=False, isolation_level=None)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA journal_mode=WAL")
        self.c.execute("PRAGMA synchronous=NORMAL")
        self.c.executescript(SEMA)
        # 3.0 sürümünden yükseltme
        for tablo, kolon, tanim in (("oturum", "tur", "TEXT DEFAULT 'yonetici'"), ("oturum", "ad", "TEXT DEFAULT ''"),
                                    ("oturum", "kim", "TEXT DEFAULT ''")):
            try:
                self.c.execute("ALTER TABLE {} ADD COLUMN {} {}".format(tablo, kolon, tanim))
            except sqlite3.OperationalError:
                pass

    def degistir(self, yeni, yedekle=False):
        """Veritabanı dosyasını 'yeni' ile değiştirir (yedek bilgisayar kopyası / görevi geri alma)."""
        with self.k:
            if yedekle:
                try:
                    klasor = self.yol.parent / "yedek_once"
                    klasor.mkdir(exist_ok=True)
                    hedef = sqlite3.connect(str(klasor / "tahta-{}.db".format(time.strftime("%Y%m%d-%H%M%S"))))
                    try:
                        self.c.backup(hedef)
                    finally:
                        hedef.close()
                    for eski in sorted(klasor.glob("tahta-*.db"))[:-yedek_mod.KOPYA_SAYISI]:
                        eski.unlink()
                except Exception:
                    log.exception("veritabanı yedeği alınamadı")
            self.c.close()
            hata = None
            try:
                for _ in range(6):
                    try:
                        for ek in ("-wal", "-shm"):
                            try:
                                os.remove(str(self.yol) + ek)
                            except OSError:
                                pass
                        os.replace(str(yeni), str(self.yol))
                        hata = None
                        break
                    except OSError as e:
                        hata = e
                        time.sleep(0.5)
            finally:
                self._ac()
            if hata:
                raise hata

    def q(self, sql, args=()):
        with self.k:
            return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def bir(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.k:
            return self.c.execute(sql, args).rowcount

    def ayar(self, anahtar):
        r = self.bir("SELECT deger FROM ayar WHERE anahtar=?", (anahtar,))
        if r is None:
            v = VARSAYILAN_AYAR.get(anahtar)
            return json.loads(json.dumps(v))
        return json.loads(r["deger"])

    def ayar_yaz(self, anahtar, deger):
        self.x("INSERT OR REPLACE INTO ayar(anahtar, deger) VALUES(?,?)",
               (anahtar, json.dumps(deger, ensure_ascii=False)))


db = None    # calistir() içinde kurulur
dugum = None  # yedek yönetim düğümü (hazirla() içinde kurulur)
depo = None  # Ortak Klasör deposu


# ─────────────────────────────────────────────────────────────────────────────
# Canlı durum (bellekte)
# ─────────────────────────────────────────────────────────────────────────────

class CanliTahta:
    def __init__(self, tid):
        self.id = tid
        self.kosul = threading.Condition()
        self.nesil = 0
        self.bekliyor = False
        self.son = 0.0
        self.durum = {}
        self.cevrimici = False
        self.son_sayim = 0.0
        self.ekran = {}          # boyut -> (zaman, mime, bayt)
        self.ekran_istek = {}    # boyut -> istek zamanı


canli = {}
canli_kilit = threading.Lock()
silinenler = {}  # tahta id -> silinme zamanı (yeniden kaydı kısa süre engeller)


def canli_al(tid):
    with canli_kilit:
        c = canli.get(tid)
        if c is None:
            c = canli[tid] = CanliTahta(tid)
        return c


def cevrimici_mi(c):
    return bool(c) and (c.bekliyor or time.time() - c.son < CEVRIMICI_SN)


def uyandir(tid):
    c = canli.get(tid)
    if c:
        with c.kosul:
            c.kosul.notify_all()


def hepsini_uyandir():
    for tid in list(canli):
        uyandir(tid)


# ─────────────────────────────────────────────────────────────────────────────
# Yardımcılar
# ─────────────────────────────────────────────────────────────────────────────

def simdi():
    return time.time()


def utc_ofset():
    return int(datetime.now().astimezone().utcoffset().total_seconds())


def olay(tahta, tur, mesaj):
    try:
        db.x("INSERT INTO olay(zaman, tahta, tur, mesaj) VALUES(?,?,?,?)",
             (simdi(), tahta or "", tur, mesaj[:500]))
    except Exception:
        log.exception("olay yazılamadı")


def tahta_adi(tid):
    r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
    return r["ad"] if r else tid[:8]


def sifre_ozet(sifre, tuz=None, tekrar=200000):
    tuz = tuz or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz.encode(), tekrar).hex()
    return "pbkdf2${}${}${}".format(tekrar, tuz, h)


def sifre_dogru(sifre, kayit):
    try:
        _, tekrar, tuz, h = kayit.split("$")
        h2 = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz.encode(), int(tekrar)).hex()
        return hmac.compare_digest(h, h2)
    except Exception:
        return False


def guvenli_ad(ad):
    ad = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", ad or "").strip(" .")
    return (ad or "dosya")[:150]


ANA_YONETICI = "Ana yönetici"
YONETICI_SINIR = 20


def yonetici_bul(sifre):
    """Şifreye karşılık gelen yöneticiyi döner: {"id", "ad", "ana"} ya da None.
    Ana yönetici (ilk kurulumdaki şifre) 'ana' kimliğiyle; ek yöneticiler kendi kimliğiyle."""
    sifre = sifre or ""
    if not sifre:
        return None
    bulunan = None
    kayit = db.ayar("sifre")
    if kayit and sifre_dogru(sifre, kayit):
        bulunan = {"id": "ana", "ad": ANA_YONETICI, "ana": True}
    for y in db.ayar("yoneticiler") or []:
        if sifre_dogru(sifre, y.get("sifre", "")) and not bulunan:
            bulunan = {"id": y["id"], "ad": y["ad"], "ana": False}
    return bulunan


def yonetici_sifre_kullanimda(sifre, haric=None):
    """Bu şifre başka bir yöneticide var mı? (Giriş şifreyle yapıldığı için şifreler benzersiz olmalı.)"""
    y = yonetici_bul(sifre)
    return bool(y and y["id"] != haric)


def pin_bul(pin):
    """Tahta açma şifresine (PIN) karşılık gelen kaydı döner."""
    pin = re.sub(r"\D", "", str(pin or ""))[:12]
    if not pin:
        return None
    for p in db.ayar("pinler") or []:
        if hmac.compare_digest(hashlib.sha256((p["tuz"] + pin).encode()).hexdigest(), p["ozet"]):
            return p
    return None


def alan_temizle(s):
    """'https://www.youtube.com/watch' → 'youtube.com'"""
    s = str(s or "").strip().lower()
    s = re.sub(r"^[a-z]+://", "", s)
    s = s.split("/")[0].split("?")[0].split(":")[0].strip(".")
    if s.startswith("*."):
        s = s[2:]
    if s.startswith("www."):
        s = s[4:]
    try:
        s = s.encode("idna").decode("ascii")
    except Exception:
        return None
    return s if (len(s) <= 120 and re.match(r"^[a-z0-9-]+(\.[a-z0-9-]+)+$", s)) else None


ISTEMCI_BAT = r"""@echo off
setlocal
title Ortak Klasor - Kurulum
set "TYS_SUNUCU=__SUNUCU__"
set "TYS_ANAHTAR=__ANAHTAR__"
set "TYS_KIMLIK=__KIMLIK__"
set "TYS_PS=%TEMP%\tys-ortak-kur-%RANDOM%.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$s.IndexOf('#'+'TYS-PS1#'); [IO.File]::WriteAllText($env:TYS_PS,$s.Substring($i),(New-Object Text.UTF8Encoding $true))"
if errorlevel 1 goto hata
powershell -NoProfile -ExecutionPolicy Bypass -File "%TYS_PS%" -Istemci -Sunucu "%TYS_SUNUCU%" -Anahtar "%TYS_ANAHTAR%" -Kimlik "%TYS_KIMLIK%"
del "%TYS_PS%" >nul 2>&1
echo.
pause
exit /b 0
:hata
echo.
echo  Kurulum dosyasi okunamadi. Dosyayi Masaustune kaydedip yeniden calistirin.
pause
exit /b 1
"""


TAHTA_BAT = r"""@echo off
setlocal
title Tahta Yonetim - Windows tahta kurulumu
set "TYS_SUNUCU=__SUNUCU__"
set "TYS_ANAHTAR=__ANAHTAR__"
set "TYS_KIMLIK=__KIMLIK__"
set "TYS_AD=__AD__"
set "TYS_PS=%TEMP%\tys-tahta-kur-%RANDOM%.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$s.IndexOf('#'+'TYS-PS1#'); [IO.File]::WriteAllText($env:TYS_PS,$s.Substring($i),(New-Object Text.UTF8Encoding $true))"
if errorlevel 1 goto hata
powershell -NoProfile -ExecutionPolicy Bypass -File "%TYS_PS%" -Tahta -Sunucu "%TYS_SUNUCU%" -Anahtar "%TYS_ANAHTAR%" -Kimlik "%TYS_KIMLIK%" -Ad "%TYS_AD%"
del "%TYS_PS%" >nul 2>&1
echo.
pause
exit /b 0
:hata
echo.
echo  Kurulum dosyasi okunamadi. Dosyayi Masaustune kaydedip yeniden calistirin.
pause
exit /b 1
"""


SANAL_AGLAR = ("192.168.56.", "192.168.99.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.",
               "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.")


def ekran_boyutu(b):
    return b if b in ("kucuk", "buyuk", "tam") else "kucuk"


def tahta_adi_temizle(ad):
    """Kurulum komutuyla gelen tahta adı: kabuk ve JSON için güvenli karakterler, en fazla 40."""
    ad = str(ad or "")
    try:                                   # kodlanmadan gönderilmiş UTF-8 (ör. elle yazılan komut)
        ad = ad.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    ad = re.sub(r"[^\w .()\-/+#,]", "", str(ad or ""))
    return re.sub(r"\s+", " ", ad).strip()[:40]


def yerel_adresler():
    """Bilgisayarın ağdaki IPv4 adresleri; tahtaların kullanacağı adres başta.
    Sıra: tahtaların bulunduğu ağ > internete çıkılan (varsayılan) bağlantı > diğerleri > sanal ağlar."""
    adresler = []

    def ekle(ip):
        if ip and ip not in adresler and not ip.startswith(("127.", "169.254.", "0.")):
            adresler.append(ip)
    for hedef in ("8.8.8.8", "10.255.255.255", "192.168.255.255", "172.31.255.255"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((hedef, 9))          # paket gönderilmez; yalnızca hangi bağlantının kullanılacağı seçilir
            ekle(s.getsockname()[0])
            s.close()
        except Exception:
            pass
    try:
        for bilgi in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ekle(bilgi[4][0])
    except Exception:
        pass
    tahta_aglari = {}
    try:
        for r in db.q("SELECT bilgi FROM tahta"):
            ip = (json.loads(r["bilgi"] or "{}").get("ip") or "")
            if ip.count(".") == 3:
                ag = ip.rsplit(".", 1)[0]
                tahta_aglari[ag] = tahta_aglari.get(ag, 0) + 1
    except Exception:
        pass

    def sira(i_a):
        i, a = i_a
        return (-tahta_aglari.get(a.rsplit(".", 1)[0], 0), 1 if a.startswith(SANAL_AGLAR) and i else 0, i)
    return [a for _, a in sorted(enumerate(adresler), key=sira)]


def sistem_komutu(komut, zaman=8):
    """Windows komutunu pencere açmadan çalıştırır, çıktısını metin olarak döndürür."""
    try:
        r = subprocess.run(komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=zaman,
                           creationflags=0x08000000 if os.name == "nt" else 0)
        return r.stdout.decode("oem" if os.name == "nt" else "utf-8", "replace")
    except Exception as e:
        return "(çalıştırılamadı: {})".format(e)


def uyku_bilgisi():
    if os.name != "nt":
        return "Windows değil"

    def oku(ayar):
        m = re.search(r"\bAC\b[^:\n]*:\s*(0x[0-9a-fA-F]+)", sistem_komutu(["powercfg", "/query", "SCHEME_CURRENT", "SUB_SLEEP", ayar]))
        return int(m.group(1), 16) if m else None

    def yaz(v):
        return "bilinmiyor" if v is None else ("kapalı" if v == 0 else "{} dk".format(v // 60))
    return "uyku {}, hazırda bekletme {} (prize takılıyken)".format(yaz(oku("STANDBYIDLE")), yaz(oku("HIBERNATEIDLE")))


def guvenlik_duvari_bilgisi():
    if os.name != "nt":
        return "Windows değil"
    cikti = sistem_komutu('netsh advfirewall firewall show rule name="Tahta Yonetim Sistemi"')
    return "izin var (bağlantı noktası {})".format(PORT) if str(PORT) in cikti else "İZİN BULUNAMADI — KUR.bat yeniden çalıştırılmalı"


def dosya_sonu(yol, satir):
    try:
        with open(yol, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 200 * 1024))
            return "\n".join(f.read().decode("utf-8", "replace").splitlines()[-satir:])
    except OSError:
        return "(yok)"


def tani_raporu():
    """Destek için tek dosyalık rapor. Şifre, PIN ve anahtar içermez."""
    n = simdi()
    sat = []
    yaz = sat.append

    def zaman(t):
        return datetime.fromtimestamp(t).strftime("%d.%m.%Y %H:%M") if t else "—"
    yaz("TAHTA YÖNETİM SİSTEMİ — TANI RAPORU")
    yaz("Oluşturma: {}".format(zaman(n)))
    yaz("Okul: {}".format(db.ayar("okul_adi") or "—"))
    yaz("Bu rapor şifre, öğretmen şifresi ve bağlantı anahtarı içermez.")
    yaz("")
    yaz("── Yönetim bilgisayarı")
    yaz("Program sürümü: {} · Tahta programı: {}".format(SURUM, AJAN_SURUM))
    yaz("Çalışma süresi: {} dk (başlangıç {})".format(int((n - BASLAMA) / 60), zaman(BASLAMA)))
    yaz("Sistem: {}".format(platform.platform()))
    yaz("Python: {} ({})".format(platform.python_version(), sys.executable))
    yaz("Bilgisayar adı: {}".format(socket.gethostname()))
    yaz("Ağ adresleri (tahtaların kullanacağı başta): {}".format(", ".join(yerel_adresler()) or "—"))
    yaz("Bağlantı noktası: {}".format(PORT))
    yaz("Güvenlik duvarı: {}".format(guvenlik_duvari_bilgisi()))
    yaz("Güç: {}".format(uyku_bilgisi()))
    try:
        bos = shutil.disk_usage(str(VERI)).free
        yaz("Veri klasörü: {} (boş alan {:.1f} GB)".format(VERI, bos / 1e9))
    except Exception:
        yaz("Veri klasörü: {}".format(VERI))
    try:
        o = depo.ozet_bilgi()
        yaz("Ortak Klasör: {} · {} dosya · {:.1f} / {:.0f} GB · tahta izni {}{}".format(
            "açık" if o.get("etkin") else "kapalı", o.get("dosya"), (o.get("kullanilan") or 0) / 1e9,
            (o.get("kota") or 0) / 1e9, o.get("tahta_izin"), " · HATA: " + o["hata"] if o.get("hata") else ""))
    except Exception as e:
        yaz("Ortak Klasör: okunamadı ({})".format(e))
    if os.name == "nt":
        yaz("")
        yaz("── ipconfig")
        yaz(sistem_komutu(["ipconfig"]).strip())
    yaz("")
    tahtalar = db.q("SELECT * FROM tahta ORDER BY ad")
    yaz("── Tahtalar ({})".format(len(tahtalar)))
    for t in tahtalar:
        b = json.loads(t["bilgi"] or "{}")
        c = canli.get(t["id"])
        d = getattr(c, "durum", None) or {}
        cevrimici = cevrimici_mi(c)
        satir = "{} | {} | {} | sürüm {} | {}".format(
            t["ad"] or t["id"], b.get("ip") or "?", "çevrimiçi" if cevrimici else "kapalı (son " + zaman(t["son"]) + ")",
            b.get("surum") or "?", b.get("os") or "?")
        ek = []
        if d.get("ortak"):
            ek.append("ortak: {}{}".format(d["ortak"].get("durum"), " — " + d["ortak"]["mesaj"] if d["ortak"].get("mesaj") else ""))
        if d.get("engel") and d["engel"].get("hata"):
            ek.append("site engeli hatası: " + str(d["engel"]["hata"]))
        g = (d.get("guncelleme") or {}).get("son")
        if g and not g.get("ok"):
            ek.append("güncelleme hatası: " + str(g.get("mesaj")))
        if ek:
            satir += " | " + " | ".join(ek)
        yaz(satir)
    istemciler = db.q("SELECT * FROM istemci ORDER BY ad")
    if istemciler:
        yaz("")
        yaz("── Öğretmen bilgisayarları ({})".format(len(istemciler)))
        for i in istemciler:
            b = json.loads(i["bilgi"] or "{}")
            o = b.get("ortak") or {}
            yaz("{} | {} | son {} | sürüm {} | ortak: {}{}".format(
                i["ad"], b.get("ip") or "?", zaman(i["son"]), b.get("surum") or "?", o.get("durum") or "?",
                " — " + o["mesaj"] if o.get("mesaj") else ""))
    yaz("")
    yaz("── Son olaylar (hata ve sistem)")
    for r in reversed(db.q("SELECT o.zaman, o.tur, o.mesaj, t.ad FROM olay o LEFT JOIN tahta t ON t.id=o.tahta "
                           "WHERE o.tur IN ('hata','sistem','baglanti','guncelleme') ORDER BY o.zaman DESC LIMIT 80")):
        yaz("{} [{}] {}{}".format(zaman(r["zaman"]), r["tur"], (r["ad"] + ": ") if r["ad"] else "", r["mesaj"]))
    klasor = VERI / "tani"
    if klasor.is_dir():
        raporlar = sorted(klasor.glob("*.txt"))[-5:]
        if raporlar:
            yaz("")
            yaz("── Tahtalardan gelen tanı raporları (son {})".format(len(raporlar)))
            for r in raporlar:
                yaz("")
                yaz("### " + r.name)
                yaz(r.read_text(encoding="utf-8", errors="replace")[:12000])
    yaz("")
    yaz("── sunucu.log (son 200 satır)")
    yaz(dosya_sonu(VERI / "sunucu.log", 200))
    yaz("")
    yaz("── hata.log (son 60 satır)")
    yaz(dosya_sonu(VERI / "hata.log", 60))
    return "\n".join(sat) + "\n"



def ajan_surumu():
    try:
        m = re.search(r'^SURUM\s*=\s*"([^"]+)"', AJAN_DOSYA.read_text(encoding="utf-8"), re.M)
        return m.group(1) if m else "?"
    except Exception:
        return "?"


AJAN_SURUM = "?"


# ─────────────────────────────────────────────────────────────────────────────
# Hedef çözümleme, komut kuyruğu
# ─────────────────────────────────────────────────────────────────────────────

def hedef_cozumle(hedef):
    """hedef: {"hepsi":true} | {"grup":"ad"} | {"idler":[...]}  →  tahta id listesi"""
    hedef = hedef or {}
    satirlar = db.q("SELECT id, grup FROM tahta")
    if hedef.get("hepsi"):
        return [r["id"] for r in satirlar]
    if "grup" in hedef:
        return [r["id"] for r in satirlar if (r["grup"] or "") == hedef["grup"]]
    idler = set(hedef.get("idler") or [])
    return [r["id"] for r in satirlar if r["id"] in idler]


def hedef_kapsar(hedef, tid, grup):
    hedef = hedef or {"hepsi": True}
    if hedef.get("hepsi"):
        return True
    if "grup" in hedef:
        return (grup or "") == hedef["grup"]
    return tid in (hedef.get("idler") or [])


def hedef_yazi(hedef, sayi):
    if not hedef or hedef.get("hepsi"):
        return "tüm tahtalar ({})".format(sayi)
    if "grup" in hedef:
        return "{} grubu ({})".format(hedef["grup"] or "Grupsuz", sayi)
    if sayi == 1:
        return tahta_adi(hedef["idler"][0]) if hedef.get("idler") else "1 tahta"
    return "{} tahta".format(sayi)


def komut_ekle(tid, tur, veri=None, omur=None):
    kid = uuid.uuid4().hex[:12]
    n = simdi()
    omur = omur or KOMUT_OMRU.get(tur, 120)
    db.x("INSERT INTO bekleyen(id, tahta, tur, veri, olusma, gecerlilik) VALUES(?,?,?,?,?,?)",
         (kid, tid, tur, json.dumps(veri or {}, ensure_ascii=False), n, n + omur))
    uyandir(tid)
    return kid


def komutlari_al(c):
    n = simdi()
    satirlar = db.q("SELECT * FROM bekleyen WHERE tahta=? ORDER BY olusma", (c.id,))
    komutlar = []
    for r in satirlar:
        db.x("DELETE FROM bekleyen WHERE id=?", (r["id"],))
        if r["gecerlilik"] < n:
            db.x("UPDATE islem_tahta SET durum='hata', mesaj=?, zaman=? WHERE kid=? AND durum='bekliyor'",
                 ("Tahta komutu zamanında almadı (süresi doldu)", n, r["id"]))
            continue
        komutlar.append({"id": r["id"], "tur": r["tur"], "veri": json.loads(r["veri"] or "{}")})
        db.x("UPDATE islem_tahta SET durum='iletildi', zaman=? WHERE kid=? AND durum='bekliyor'", (n, r["id"]))
    for boyut, t in list(c.ekran_istek.items()):
        if t and n - t < 20:
            komutlar.append({"id": "ekran-" + boyut, "tur": "ekran", "veri": {"boyut": boyut}})
        c.ekran_istek.pop(boyut, None)
    return komutlar


# ─────────────────────────────────────────────────────────────────────────────
# Ajana gönderilen ayarlar
# ─────────────────────────────────────────────────────────────────────────────

def aralik_atla_bugun():
    """Panelden "bugün için bitir" denen kilitli saat aralıkları."""
    a = db.ayar("aralik_atla") or {}
    return sorted(a.get("idler") or []) if a.get("tarih") == time.strftime("%Y-%m-%d") else []


def ajan_ayari(tid):
    t = db.bir("SELECT ad, grup FROM tahta WHERE id=?", (tid,)) or {"ad": tid[:8], "grup": ""}
    n = simdi()
    kurallar = []
    for r in db.q("SELECT veri FROM kural"):
        k = json.loads(r["veri"])
        if k.get("tur") == "ac" or not k.get("aktif", True):
            continue
        if hedef_kapsar(k.get("hedef"), tid, t["grup"]):
            kurallar.append({x: k.get(x) for x in ("id", "saat", "gunler", "tur", "veri", "aciklama")})
    panolar = []
    for p in db.ayar("panolar"):
        if p.get("bitis", 0) > n and hedef_kapsar(p.get("hedef"), tid, t["grup"]):
            panolar.append({"baslik": p.get("baslik", ""), "metin": p.get("metin", ""), "bitis": p["bitis"]})
    zil = {}
    for tur, bilgi in (db.ayar("zil_ozel") or {}).items():
        zil[tur] = {"ozet": bilgi.get("ozet"), "uzanti": bilgi.get("uzanti")}
    ayar = {
        "ad": t["ad"],
        "okul_adi": db.ayar("okul_adi"),
        "pinler": [{"ad": p["ad"], "tuz": p["tuz"], "ozet": p["ozet"]} for p in db.ayar("pinler")],
        "kilit": db.ayar("kilit"),
        "zamanlayici_etkin": db.ayar("zamanlayici_etkin"),
        "kurallar": kurallar,
        "panolar": panolar,
        "zil_ozel": zil,
        "zil_sesi_ac": db.ayar("zil_sesi_ac"),
        "sinav": None, "saat_ekran": None,
        "saat_koruyucu_dk": int(db.ayar("saat_koruyucu_dk") or 0),
        "site_engel": None,
        "ortak_etkin": bool((db.ayar("ortak") or {}).get("etkin", True)),
        "ariza_simge": bool(db.ayar("ariza_simge")),
        "aralik_atla": aralik_atla_bugun(),
    }
    ayar.update(zil_ayari(tid, t["grup"]))
    ayar["okul"] = okul_ayari(tid, t["grup"])
    ayar["politikalar"] = politikalar_tahta(tid, t["grup"])
    ayar["koruma"] = koruma_listesi()
    ayar["yazici_firmware"] = [{"ad": d["ad"], "sha": d["sha"]} for d in db.q("SELECT sha, ad FROM depo ORDER BY eklenme")
                               if re.match(r"^sihpP?\d{4}\.(dl|img|tar\.gz|tgz)$", d["ad"] or "", re.I)]
    ua = db.ayar("usb_ayar") or {}
    ayar["usb"] = {"mod": usb_modu(tid, t["grup"]), "wsh_kapat": bool(ua.get("wsh_kapat")), "kurallar": usb_kurallari()}
    acil = db.ayar("acil")
    if acil and hedef_kapsar(acil.get("hedef"), tid, t["grup"]):
        ayar["acil"] = {x: acil.get(x) for x in ("id", "senaryo", "baslik", "metin", "ses", "tekrar", "tatbikat", "bitis")}
    for s in sorted(db.ayar("sinavlar") or [], key=lambda x: x.get("olusma", 0)):
        if s.get("bitis", 0) + 180 > n and hedef_kapsar(s.get("hedef"), tid, t["grup"]):
            ayar["sinav"] = {x: s.get(x) for x in ("id", "baslik", "bas", "bitis", "uyari_dk", "ses")}
    for s in sorted(db.ayar("saatler") or [], key=lambda x: x.get("olusma", 0)):
        if hedef_kapsar(s.get("hedef"), tid, t["grup"]):
            ayar["saat_ekran"] = {x: s.get(x) for x in ("id", "mesaj", "kapatilabilir")}
    engel = db.ayar("site_engel") or {}
    if engel.get("etkin") and engel.get("siteler") and hedef_kapsar(engel.get("hedef"), tid, t["grup"]):
        ayar["site_engel"] = {x: engel.get(x) for x in ("siteler", "zaman", "araliklar")}
    metin = json.dumps(ayar, sort_keys=True, ensure_ascii=False)
    return ayar, hashlib.sha1(metin.encode("utf-8")).hexdigest()[:16]



# ─────────────────────────────────────────────────────────────────────────────
# Zil programı
# ─────────────────────────────────────────────────────────────────────────────

SAAT_DESEN = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
TARIH_DESEN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ZIL_SES_SINIR = 10 * 1024 * 1024
ZIL_SES_ADET = 40


def zil_ses_gecerli(ref):
    if ref in ("ders", "teneffus", "siren"):
        return True
    return ref.startswith("k:") and any(x.get("id") == ref[2:] for x in (db.ayar("zil_sesleri") or []))


def zil_ses_adi(ref):
    if ref == "siren":
        return "Siren"
    if ref == "ders":
        return "Ders zili"
    if ref == "teneffus":
        return "Teneffüs zili"
    for x in db.ayar("zil_sesleri") or []:
        if "k:" + x.get("id", "") == ref:
            return x.get("ad") or "Ses"
    return "?"


def zil_tatil_guncel():
    bugun = time.strftime("%Y-%m-%d")
    return [t for t in (db.ayar("zil_tatil") or []) if (t.get("bit") or "") >= bugun]


def zil_ayari(tid, grup):
    """Tahtaya gönderilen zil saatleri, tatiller ve ses kitaplığı."""
    ziller = []
    if db.ayar("zil_etkin"):
        for pr in db.ayar("zil_programlari") or []:
            if not pr.get("aktif", True) or not hedef_kapsar(pr.get("hedef"), tid, grup):
                continue
            for z in pr.get("satirlar") or []:
                ziller.append({"saat": z["saat"], "ad": z.get("ad") or "", "ses": z.get("ses") or "ders",
                               "sure": int(pr.get("sure") or 0), "gunler": pr.get("gunler") or []})
    ziller.sort(key=lambda z: z["saat"])
    return {
        "ziller": ziller,
        "zil_tatil": [[t["bas"], t["bit"]] for t in zil_tatil_guncel()],
        "zil_kitaplik": {x["id"]: {"uzanti": x["uzanti"], "ozet": x["ozet"]} for x in db.ayar("zil_sesleri") or []},
    }


def zil_goc():
    """Eski sürümün zamanlayıcıdaki zil kurallarını Zil Programı'na taşır (bir kez)."""
    if db.ayar("zil_goc"):
        return
    gruplar = {}
    for r in db.q("SELECT id, veri FROM kural"):
        k = json.loads(r["veri"])
        if k.get("tur") != "zil":
            continue
        anahtar = (k.get("etiket") == "zil-programi", json.dumps(k.get("hedef") or {"hepsi": True}, sort_keys=True),
                   tuple(k.get("gunler") or []))
        gruplar.setdefault(anahtar, []).append(k)
        db.x("DELETE FROM kural WHERE id=?", (r["id"],))
    programlar = db.ayar("zil_programlari") or []
    ek_etiket = None
    for (prog, hedef, gunler), kurallar in gruplar.items():
        pid = uuid.uuid4().hex[:10]
        if prog:
            ek_etiket = "zilp-" + pid
        satirlar = sorted(({"saat": k["saat"], "ad": (k.get("aciklama") or "")[:60],
                            "ses": "teneffus" if (k.get("veri") or {}).get("tur") == "teneffus" else "ders"}
                           for k in kurallar if k.get("aktif", True)), key=lambda z: z["saat"])
        programlar.append({"id": pid, "ad": "Zil programı" if prog else "Zamanlayıcıdan aktarılan ziller",
                           "aktif": bool(satirlar), "hedef": json.loads(hedef), "gunler": list(gunler) or [1, 2, 3, 4, 5],
                           "sure": 0, "satirlar": satirlar or [{"saat": k["saat"], "ad": "", "ses": "ders"} for k in kurallar]})
    for r in db.q("SELECT id, veri FROM kural"):
        k = json.loads(r["veri"])
        if k.get("etiket") == "zil-programi":
            if ek_etiket:
                k["etiket"] = ek_etiket
            else:
                k.pop("etiket", None)
            db.x("UPDATE kural SET veri=? WHERE id=?", (json.dumps(k, ensure_ascii=False), r["id"]))
    db.ayar_yaz("zil_programlari", programlar)
    db.ayar_yaz("zil_goc", True)
    if gruplar:
        olay("", "sistem", "Zamanlayıcıdaki {} zil kuralı Zil Programı'na taşındı".format(sum(len(v) for v in gruplar.values())))


_HAZIR_SES = {}


def hazir_ses(tur):
    """Panelde dinlemek için hazır zil sesini (tahtadakiyle aynı) üretir."""
    if tur not in _HAZIR_SES:
        import tempfile
        yol = os.path.join(tempfile.gettempdir(), "tys-hazir-{}.wav".format(tur))
        ses_uret(tur, yol)
        with open(yol, "rb") as f:
            _HAZIR_SES[tur] = f.read()
        try:
            os.remove(yol)
        except OSError:
            pass
    return _HAZIR_SES[tur]


def _can_sesi(f, t, sonum):
    return (math.sin(2 * math.pi * f * t)
            + 0.5 * math.sin(2 * math.pi * f * 2.0 * t) * math.exp(-t * 2.5)
            + 0.25 * math.sin(2 * math.pi * f * 3.01 * t) * math.exp(-t * 4)) * math.exp(-t * sonum)


def ses_uret(tur, yol):
    sr = 22050
    ornek = array.array("h")
    if tur == "siren":
        sure, faz = 6.0, 0.0
        for n in range(int(sr * sure)):
            t = n / float(sr)
            f = 650 + 550 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 3.0))
            faz += 2 * math.pi * f / sr
            x = 0.42 * (math.sin(faz) + 0.3 * math.sin(2 * faz) + 0.12 * math.sin(3 * faz))
            x *= min(1.0, t / 0.05) * min(1.0, (sure - t) / 0.1)
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    elif tur == "ders":
        # Klasik elektrikli okul zili
        sure = 3.6
        for n in range(int(sr * sure)):
            t = n / float(sr)
            faz = (t * 24.0) % 1.0
            vurus = math.exp(-faz * 7.0)
            ton = (math.sin(2 * math.pi * 1150 * t) + 0.6 * math.sin(2 * math.pi * 2390 * t)
                   + 0.35 * math.sin(2 * math.pi * 3520 * t) + 0.2 * math.sin(2 * math.pi * 4950 * t))
            zarf = min(1.0, t / 0.02) * min(1.0, (sure - t) / 0.3)
            x = 0.30 * ton * (0.25 + 0.75 * vurus) * zarf
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    else:
        if tur == "teneffus":      # Dört notalı melodik zil
            notalar, sure, sonum, kazanc = [(0.0, 659.25), (0.5, 523.25), (1.0, 587.33), (1.5, 392.0)], 3.8, 1.5, 0.26
        elif tur == "duyuru":      # Yükselen dört nota (anons sesi)
            notalar, sure, sonum, kazanc = [(0.0, 523.25), (0.3, 659.25), (0.6, 783.99), (0.9, 1046.5)], 2.8, 2.0, 0.24
        else:                      # Kısa bildirim
            notalar, sure, sonum, kazanc = [(0.0, 880.0), (0.14, 1318.5)], 1.0, 6.0, 0.30
        for n in range(int(sr * sure)):
            t = n / float(sr)
            x = 0.0
            for bas, f in notalar:
                if t >= bas:
                    x += _can_sesi(f, t - bas, sonum)
            x *= kazanc * min(1.0, (sure - t) / 0.2)
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    gecici = yol + ".tmp"
    w = wave.open(gecici, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes(ornek.tobytes())
    w.close()
    os.replace(gecici, yol)



# ─────────────────────────────────────────────────────────────────────────────
# Acil durum / tatbikat
# ─────────────────────────────────────────────────────────────────────────────

ACIL_SENARYO = ("deprem", "yangin", "kilit", "genel")
ACIL_ULASAN = {}          # acil id → o ana kadar uyarıyı gösteren tahta sayısının en yükseği


def acil_ulasan(aid):
    n = 0
    for tid, c in list(canli.items()):
        if cevrimici_mi(c) and ((c.durum or {}).get("acil") == aid):
            n += 1
    ACIL_ULASAN[aid] = max(ACIL_ULASAN.get(aid, 0), n)
    return n


def acil_dogrula(g):
    senaryo = g.get("senaryo") if g.get("senaryo") in ACIL_SENARYO else "genel"
    baslik = (g.get("baslik") or "").strip()[:80]
    if not baslik:
        raise Hata("Başlık boş olamaz")
    ses = g.get("ses") or "siren"
    if not zil_ses_gecerli(ses):
        ses = "siren"
    return {"senaryo": senaryo, "baslik": baslik, "metin": (g.get("metin") or "").strip()[:400], "ses": ses,
            "tekrar": max(0, min(int(g.get("tekrar") if g.get("tekrar") is not None else 3), 20)),
            "tatbikat": bool(g.get("tatbikat", True)), "hedef": g.get("hedef") or {"hepsi": True},
            "sure_dk": max(0, min(int(g.get("sure_dk") or 0), 240))}


def acil_baslat(g, kim):
    a = acil_dogrula(g)
    eski = db.ayar("acil")
    if eski:
        acil_bitir("yeni uyarı başlatıldı", kayit=True)
    n = simdi()
    a.update(id=uuid.uuid4().hex[:10], baslangic=n, kim=kim, bitis=n + a["sure_dk"] * 60 if a["sure_dk"] else 0,
             hedef_sayi=len(hedef_cozumle(a["hedef"])))
    db.ayar_yaz("acil", a)
    ACIL_ULASAN[a["id"]] = 0
    olay("", "acil", "{} başlatıldı: {} — {} ({} tahta hedef)".format(
        "TATBİKAT" if a["tatbikat"] else "ACİL DURUM", a["baslik"], kim, a["hedef_sayi"]))
    hepsini_uyandir()
    return a


def acil_bitir(kim, kayit=True):
    a = db.ayar("acil")
    if not a:
        return None
    acil_ulasan(a["id"])
    db.ayar_yaz("acil", None)
    sure = max(0, simdi() - a["baslangic"])
    if kayit:
        gecmis = db.ayar("acil_gecmis") or []
        k = {x: a.get(x) for x in ("id", "senaryo", "baslik", "tatbikat", "baslangic", "kim", "hedef_sayi")}
        k.update(bitis=simdi(), bitiren=kim, ulasan=ACIL_ULASAN.get(a["id"], 0))
        gecmis.insert(0, k)
        db.ayar_yaz("acil_gecmis", gecmis[:50])
    olay("", "acil", "{} bitti: {} — {} · {} dk {} sn · {} / {} tahtada gösterildi".format(
        "Tatbikat" if a.get("tatbikat") else "Acil durum", a["baslik"], kim, sure // 60, sure % 60,
        ACIL_ULASAN.get(a["id"], 0), a.get("hedef_sayi", 0)))
    ACIL_ULASAN.pop(a["id"], None)
    hepsini_uyandir()
    return a


def acil_zamanla():
    """Süresi dolan uyarıyı bitirir, planlanan tatbikatı başlatır (arka plan, 10 sn'de bir)."""
    a = db.ayar("acil")
    if a:
        acil_ulasan(a["id"])
        if a.get("bitis") and simdi() >= a["bitis"]:
            acil_bitir("süre doldu (otomatik)")
    plan = db.ayar("acil_plan") or []
    if not plan:
        return
    simdi_s = time.strftime("%Y-%m-%d %H:%M")
    kalan, degisti = [], False
    for x in plan:
        an = "{} {}".format(x.get("tarih"), x.get("saat"))
        if an <= simdi_s:
            degisti = True
            gecikme = time.mktime(time.localtime()) - time.mktime(time.strptime(an, "%Y-%m-%d %H:%M"))
            if gecikme <= 180:
                try:
                    acil_baslat(x, "Planlı tatbikat" + (" ({})".format(x.get("kim")) if x.get("kim") else ""))
                except Exception:
                    log.exception("planlı tatbikat başlatılamadı")
            else:
                olay("", "acil", "Planlı tatbikat kaçırıldı (yönetim bilgisayarı kapalıydı): {} {}".format(an, x.get("baslik")))
        else:
            kalan.append(x)
    if degisti:
        db.ayar_yaz("acil_plan", kalan)



# ─────────────────────────────────────────────────────────────────────────────
# Politikalar (istenen durum) — kapalı cihaz açılınca kendisi tamamlar, geri alınabilir
# ─────────────────────────────────────────────────────────────────────────────

POLITIKA_DURUMLARI = ("bekliyor", "uygulaniyor", "tamam", "hata", "kaldirildi", "desteklenmiyor")
DEPO_DIZIN = VERI / "depo"
DEPO_SINIR = 4 * 1024 ** 3                          # tek dosya en çok 4 GB
DEPO_INDIRME = threading.BoundedSemaphore(4)        # aynı anda en çok 4 cihaz indirir
_KORUMA = {"mt": None, "veri": {}}


def koruma_listesi():
    """Hiçbir modülün kapatamayacağı / kaldıramayacağı sistem bileşenleri (program/koruma.json)."""
    yol = PROGRAM / "koruma.json"
    try:
        mt = yol.stat().st_mtime
        if _KORUMA["mt"] != mt:
            _KORUMA.update(mt=mt, veri=json.loads(yol.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return _KORUMA["veri"]


def politika_kaydet(modul, tur, ad, hedef, veri, kim, pid=None):
    n = simdi()
    eski = db.bir("SELECT * FROM politika WHERE id=?", (pid,)) if pid else None
    if eski:
        db.x("UPDATE politika SET ad=?, hedef=?, veri=?, aktif=1, surum=surum+1, guncelleme=?, kim=? WHERE id=?",
             (ad, json.dumps(hedef, ensure_ascii=False), json.dumps(veri, ensure_ascii=False), n, kim, pid))
    else:
        pid = pid or uuid.uuid4().hex[:12]
        db.x("INSERT INTO politika(id, modul, tur, ad, hedef, veri, aktif, surum, olusturma, guncelleme, kim) "
             "VALUES(?,?,?,?,?,?,1,1,?,?,?)", (pid, modul, tur, ad, json.dumps(hedef, ensure_ascii=False),
                                                json.dumps(veri, ensure_ascii=False), n, n, kim))
    db.x("DELETE FROM politika_durum WHERE politika=? AND durum IN ('kaldirildi')", (pid,))
    olay("", "politika", "{}: {} — {}".format("Güncellendi" if eski else "Uygulandı", ad, hedef_yazi(hedef, "")))
    hepsini_uyandir()
    return pid


def politika_kaldir(pid, kim):
    p = db.bir("SELECT * FROM politika WHERE id=?", (pid,))
    if not p:
        raise Hata("Kayıt bulunamadı")
    db.x("UPDATE politika SET aktif=0, guncelleme=?, kim=? WHERE id=?", (simdi(), kim, pid))
    olay("", "politika", "Geri alındı: {} ({})".format(p["ad"], kim))
    hepsini_uyandir()


def tahta_ip(tid):
    r = db.bir("SELECT bilgi FROM tahta WHERE id=?", (tid,))
    return (json.loads(r["bilgi"] or "{}").get("ip") or None) if r else None


def politika_dinamik(p, veri, tid):
    """Bazı politikaların verisi o anki duruma göre tamamlanır (izinli adresler, sunucu tahtanın adresi...).
    Değişince sürüm de değişir; tahta yeniden uygular."""
    if p["modul"] == "yazici" and p["tur"] in ("isle", "uzak"):
        if p["tur"] == "isle":
            ek = {"hedef_ip": tahta_ip(veri.get("tahta"))}
        else:
            w = db.bir("SELECT ad FROM tahta WHERE id=?", (veri.get("isleyici") or "",))
            ek = {"isleyici_ip": tahta_ip(veri.get("isleyici")), "isleyici_ad": w["ad"] if w else "?"}
        imza = hashlib.sha1(json.dumps(ek, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:8]
        return dict(veri, **ek), imza
    if p["modul"] != "yazici" or p["tur"] not in ("paylas", "baglan"):
        return veri, ""
    if p["tur"] == "paylas":
        b = db.bir("SELECT hedef FROM politika WHERE id=? AND aktif=1", (veri.get("baglan_id") or "",))
        izinli = set()
        if b:
            h = json.loads(b["hedef"] or "{}")
            for t in db.q("SELECT id, grup, bilgi FROM tahta"):
                if t["id"] != tid and hedef_kapsar(h, t["id"], t["grup"]):
                    ip = json.loads(t["bilgi"] or "{}").get("ip")
                    if ip:
                        izinli.add(ip)
        ek = {"izinli": sorted(izinli), "kayit": bool((db.ayar("yazici_ayar") or {}).get("kayit"))}
    else:
        h = db.bir("SELECT ad FROM tahta WHERE id=?", (veri.get("host") or "",))
        rapor = db.ayar("yazici_kuyruk_" + (veri.get("host") or "")) or {}
        surucu = next((k.get("surucu") for k in rapor.get("liste") or [] if k.get("ad") == veri.get("kuyruk")), None)
        ek = {"host_ip": tahta_ip(veri.get("host")), "host_ad": h["ad"] if h else "?", "surucu_adi": surucu}
    imza = hashlib.sha1(json.dumps(ek, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:8]
    return dict(veri, **ek), imza


def politikalar_tahta(tid, grup):
    sonuc = []
    for p in db.q("SELECT id, modul, tur, hedef, veri, surum FROM politika WHERE aktif=1 ORDER BY olusturma"):
        if hedef_kapsar(json.loads(p["hedef"] or "{}"), tid, grup):
            veri = json.loads(p["veri"] or "{}")
            if p["modul"] == "yazici" and p["tur"] == "baglan" and veri.get("host") == tid:
                continue                                  # yazıcının bağlı olduğu cihaz kendine bağlanmaz
            veri, imza = politika_dinamik(p, veri, tid)
            sonuc.append({"id": p["id"], "modul": p["modul"], "tur": p["tur"],
                          "surum": "{}.{}".format(p["surum"], imza) if imza else p["surum"], "veri": veri})
    return sonuc


def politika_ozeti(p, adlar=None):
    """Politika + hedefteki her cihazın durumu (panel için)."""
    adlar = adlar if adlar is not None else {r["id"]: (r["ad"], r["grup"]) for r in db.q("SELECT id, ad, grup FROM tahta")}
    hedef = json.loads(p["hedef"] or "{}")
    durumlar = {r["tahta"]: r for r in db.q("SELECT * FROM politika_durum WHERE politika=?", (p["id"],))}
    cihazlar = []
    haric = json.loads(p["veri"] or "{}").get("host") if p["modul"] == "yazici" and p["tur"] == "baglan" else None
    for tid, (ad, grup) in adlar.items():
        if tid == haric:
            continue
        kapsar = p["aktif"] and hedef_kapsar(hedef, tid, grup)
        d = durumlar.get(tid)
        if not kapsar and not (d and d["durum"] not in ("kaldirildi",)):
            continue
        c = canli.get(tid)
        cihazlar.append({"tahta": tid, "ad": ad, "cevrimici": bool(c and cevrimici_mi(c)),
                         "durum": (d["durum"] if d else "bekliyor") if kapsar else ("kaldiriliyor" if d else "kaldirildi"),
                         "ayrinti": d["ayrinti"] if d else "", "zaman": d["zaman"] if d else None})
    say = {}
    for c in cihazlar:
        say[c["durum"]] = say.get(c["durum"], 0) + 1
    return {"id": p["id"], "modul": p["modul"], "tur": p["tur"], "ad": p["ad"], "hedef": hedef,
            "veri": json.loads(p["veri"] or "{}"), "aktif": bool(p["aktif"]), "surum": p["surum"],
            "olusturma": p["olusturma"], "guncelleme": p["guncelleme"], "kim": p["kim"],
            "cihazlar": sorted(cihazlar, key=lambda c: c["ad"]), "sayilar": say}


def depo_yolu(sha):
    sha = re.sub(r"[^0-9a-f]", "", (sha or "").lower())
    if len(sha) != 64:
        raise Hata("Geçersiz dosya", 404)
    return DEPO_DIZIN / sha


def depo_kullanan(sha):
    return [p["ad"] for p in db.q("SELECT ad, veri FROM politika WHERE aktif=1") if sha in (p["veri"] or "")]


# ─────────────────────────────────────────────────────────────────────────────
# Yazıcı Merkezi
# ─────────────────────────────────────────────────────────────────────────────

def yazici_model_anahtar(v):
    m = (v.get("marka") or "") + " " + (v.get("model") or "")
    return re.sub(r"\s+", " ", m).strip()[:120] or (v.get("vidpid") or "?")


def yazici_otomatik(tid, y, platform_):
    """Daha önce başarıyla kurulmuş bir model takılırsa (otomatik mod açıksa) kurulumu kendiliğinden başlatır."""
    if not (db.ayar("yazici_ayar") or {}).get("otomatik") or y.get("kurulu"):
        return False
    model = yazici_model_anahtar(y)
    m = db.bir("SELECT * FROM yazici_model WHERE model=? AND platform=? AND sonuc='calisiyor'", (model, platform_))
    if not m:
        return False
    for p in db.q("SELECT id, hedef, veri FROM politika WHERE aktif=1 AND modul='yazici' AND tur='kur'"):
        if json.loads(p["veri"]).get("anahtar") == y["anahtar"] and tid in (json.loads(p["hedef"]).get("idler") or []):
            return True                                   # zaten kuruluyor
    t = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
    veri = {"anahtar": y["anahtar"], "model": model, "marka": y.get("marka"), "aygit_id": y.get("aygit_id"),
            "surucu": json.loads(m["surucu"] or "{}"), "varsayilan": True, "test": True}
    politika_kaydet("yazici", "kur", "{}: {} (otomatik)".format(t["ad"] if t else tid, model), {"idler": [tid]}, veri,
                    "Otomatik kurulum")
    return True

# ─────────────────────────────────────────────────────────────────────────────
# USB Koruma
# ─────────────────────────────────────────────────────────────────────────────

USB_MODLAR = ("kapali", "uyar", "temizle")
_USB_KURAL = {"mt": None, "veri": {}}


def usb_kurallari():
    """Tespit kuralları: program klasöründeki usb-kurallar.json (program güncellemesiyle yenilenir)."""
    yol = PROGRAM / "usb-kurallar.json"
    try:
        mt = yol.stat().st_mtime
        if _USB_KURAL["mt"] != mt:
            _USB_KURAL.update(mt=mt, veri=json.loads(yol.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return _USB_KURAL["veri"]


def usb_modu(tid, grup):
    ua = db.ayar("usb_ayar") or {}
    for x in ua.get("ozel") or []:
        if x.get("mod") in USB_MODLAR and hedef_kapsar(x.get("hedef"), tid, grup):
            return x["mod"]
    return ua.get("varsayilan") if ua.get("varsayilan") in USB_MODLAR else "uyar"

# ─────────────────────────────────────────────────────────────────────────────
# Wake-on-LAN
# ─────────────────────────────────────────────────────────────────────────────

def wol_gonder(mac, ip=None):
    mac = re.sub(r"[^0-9a-fA-F]", "", mac or "")
    if len(mac) != 12:
        return False
    paket = b"\xff" * 6 + bytes.fromhex(mac) * 16
    hedefler = {"255.255.255.255"}
    for a in ([ip] if ip else []) + yerel_adresler():
        p = a.split(".")
        if len(p) == 4:
            hedefler.add(".".join(p[:3] + ["255"]))
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    try:
        for h in hedefler:
            for port in (9, 7):
                try:
                    s.sendto(paket, (h, port))
                except OSError:
                    pass
    finally:
        s.close()
    return True


def tahtalari_uyandir(idler, liste=False):
    gonderilen, adressiz = [], []
    for tid in idler:
        t = db.bir("SELECT bilgi FROM tahta WHERE id=?", (tid,))
        if not t:
            continue
        bilgi = json.loads(t["bilgi"] or "{}")
        if cevrimici_mi(canli.get(tid)):
            continue
        if bilgi.get("mac"):
            for _ in range(3):
                wol_gonder(bilgi["mac"], bilgi.get("ip"))
            gonderilen.append(tid)
        else:
            adressiz.append(tid)
    return (gonderilen, adressiz) if liste else len(gonderilen)


# ─────────────────────────────────────────────────────────────────────────────
# Arka plan işleri
# ─────────────────────────────────────────────────────────────────────────────

kullanim_tampon = {}
kullanim_kilit = threading.Lock()


def arka_plan_sayac():
    """Çevrimiçi/çevrimdışı geçişlerini kaydeder, kullanım süresini biriktirir."""
    son_yazma = simdi()
    while True:
        time.sleep(15)
        try:
            if not dugum.aktif():
                continue
            n = simdi()
            gun = time.strftime("%Y-%m-%d")
            for tid, c in list(canli.items()):
                acik = cevrimici_mi(c)
                if c.cevrimici and not acik:
                    c.cevrimici = False
                    olay(tid, "baglanti", "Kapandı veya bağlantısı kesildi")
                d = c.durum or {}
                aktif = bool(acik and d.get("oturum") and not d.get("kilitli")
                             and d.get("bosta_sn") is not None and d.get("bosta_sn") < 120)
                if acik:
                    dt = min(n - (c.son_sayim or n), 30)
                    with kullanim_kilit:
                        k = kullanim_tampon.setdefault((gun, tid), [0.0, 0.0])
                        k[0] += dt
                        if aktif:
                            k[1] += dt
                c.son_sayim = n if acik else 0
                ogretmen = (d.get("acan") or "") if (acik and d.get("oturum") and not d.get("kilitli")) else ""
                aralik_isle(tid, "acik", acik, "", n)
                aralik_isle(tid, "aktif", aktif, "", n)
                aralik_isle(tid, "ogretmen", bool(ogretmen), ogretmen, n)
            if n - son_yazma > 60:
                kullanim_yaz()
                son_yazma = n
            db.x("DELETE FROM bekleyen WHERE gecerlilik < ?", (n,))
            if int(n) % 3600 < 15:
                db.x("DELETE FROM aralik WHERE bit < ?", (n - 400 * 86400,))
            db.x("DELETE FROM oturum WHERE bitis < ?", (n,))
            for tid, t in list(silinenler.items()):
                if n - t > 600:
                    silinenler.pop(tid, None)
        except Exception:
            log.exception("sayaç hatası")


acik_araliklar = {}  # (tahta, tür) -> {"id", "ad", "bas", "bit", "yazildi"}


def aralik_isle(tid, tur, durum, ad, n):
    """Tahtanın açık / aktif / öğretmen kullanım aralıklarını kaydeder (günlük çizelge için)."""
    k = (tid, tur)
    a = acik_araliklar.get(k)
    if durum:
        if a and a["ad"] == ad and n - a["bit"] <= 45:
            a["bit"] = n
            if n - a["yazildi"] > 60:
                db.x("UPDATE aralik SET bit=? WHERE id=?", (n, a["id"]))
                a["yazildi"] = n
            return
        if a:
            db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))
        with db.k:
            cur = db.c.execute("INSERT INTO aralik(tahta, tur, ad, bas, bit) VALUES(?,?,?,?,?)", (tid, tur, ad, n, n))
            acik_araliklar[k] = {"id": cur.lastrowid, "ad": ad, "bas": n, "bit": n, "yazildi": n}
    elif a:
        db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))
        acik_araliklar.pop(k, None)


def araliklari_yaz():
    for a in list(acik_araliklar.values()):
        db.x("UPDATE aralik SET bit=? WHERE id=?", (a["bit"], a["id"]))


def kullanim_yaz():
    with kullanim_kilit:
        tampon = dict(kullanim_tampon)
        kullanim_tampon.clear()
    for (gun, tid), (acik, aktif) in tampon.items():
        db.x("""INSERT INTO kullanim(gun, tahta, acik, aktif) VALUES(?,?,?,?)
                ON CONFLICT(gun, tahta) DO UPDATE SET acik=acik+excluded.acik, aktif=aktif+excluded.aktif""",
             (gun, tid, acik, aktif))


def arka_plan_zamanlayici():
    """Uzaktan açma (Wake-on-LAN) kurallarını çalıştırır. Diğer kurallar tahtada çalışır."""
    calisanlar = set()
    while True:
        time.sleep(10)
        try:
            if not dugum.aktif():
                continue
            try:
                acil_zamanla()
            except Exception:
                log.exception("acil durum zamanlayıcısı")
            sinavlar = db.ayar("sinavlar") or []
            kalan = [s for s in sinavlar if s.get("bitis", 0) + 180 > simdi()]
            if len(kalan) != len(sinavlar):
                db.ayar_yaz("sinavlar", kalan)
            if not db.ayar("zamanlayici_etkin"):
                continue
            t = time.localtime()
            gun = t.tm_wday + 1
            simdi_sn = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec
            tarih = time.strftime("%Y-%m-%d")
            for r in db.q("SELECT veri FROM kural"):
                k = json.loads(r["veri"])
                if k.get("tur") != "ac" or not k.get("aktif", True) or gun not in (k.get("gunler") or []):
                    continue
                sa, dk = map(int, k["saat"].split(":"))
                fark = simdi_sn - (sa * 3600 + dk * 60)
                anahtar = k["id"] + tarih
                if 0 <= fark < 120 and anahtar not in calisanlar:
                    calisanlar.add(anahtar)
                    idler = hedef_cozumle(k.get("hedef"))
                    n = tahtalari_uyandir(idler)
                    olay("", "kural", "Zamanlayıcı {} → uzaktan açma sinyali {} tahtaya gönderildi".format(k["saat"], n))
            if len(calisanlar) > 500:
                calisanlar = {a for a in calisanlar if a.endswith(tarih)}
        except Exception:
            log.exception("zamanlayıcı hatası")


def arka_plan_ortak():
    """Yönetim bilgisayarında Ortak Klasör'e Gezgin'den eklenen / değiştirilen dosyaları bulur."""
    while True:
        try:
            if dugum.aktif():
                depo.tara()
        except Exception:
            log.exception("ortak klasör taraması")
        time.sleep(3)


def isaret_yayinla():
    """Ağdaki tahtalara 'sunucu burada' yayını yapar (yalnızca aktif yönetim bilgisayarı)."""
    try:
        mesaj = "TYS1 {} {}".format(db.ayar("kimlik"), PORT).encode()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        hedefler = {"255.255.255.255"}
        for a in yerel_adresler():
            p = a.split(".")
            hedefler.add(".".join(p[:3] + ["255"]))
        for h in hedefler:
            try:
                s.sendto(mesaj, (h, KESIF_PORT))
            except OSError:
                pass
        s.close()
    except Exception:
        pass


def arka_plan_isaret():
    """Ağdaki tahtaların sunucuyu bulabilmesi için 10 sn'de bir yayın yapar.
    (Bilgisayarın IP adresi değişse bile tahtalar kendiliğinden yeniden bağlanır.)
    Yalnızca aktif yönetim bilgisayarı yayın yapar; bekleyen yedek susar."""
    while True:
        if dugum.aktif():
            isaret_yayinla()
        time.sleep(10)


# ─────────────────────────────────────────────────────────────────────────────
# Panel için özet
# ─────────────────────────────────────────────────────────────────────────────

def tahta_ozeti(r):
    c = canli.get(r["id"])
    d = (c.durum if c else {}) or {}
    bilgi = json.loads(r["bilgi"] or "{}")
    acik = cevrimici_mi(c)
    ekran_k = c.ekran.get("kucuk") if c else None
    ekran_b = c.ekran.get("buyuk") if c else None
    ekran_t = c.ekran.get("tam") if c else None
    return {
        "id": r["id"], "ad": r["ad"], "grup": r["grup"] or "",
        "ip": bilgi.get("ip"), "mac": bilgi.get("mac"), "hostname": bilgi.get("hostname"),
        "os": bilgi.get("os"), "surum": bilgi.get("surum"),
        "platform": d.get("platform") or ("windows" if "windows" in str(bilgi.get("os") or "").lower() else "linux"),
        "guncel": bilgi.get("surum") == AJAN_SURUM,
        "cevrimici": acik,
        "kilitli": bool(d.get("kilitli")) if acik else False,
        "oturum": bool(d.get("oturum")) if acik else False,
        "kullanici": d.get("kullanici") if acik else None,
        "bosta_sn": d.get("bosta_sn") if acik else None,
        "calisma_sn": d.get("calisma_sn") if acik else None,
        "ram": d.get("ram"), "disk": d.get("disk"), "sicaklik": d.get("sicaklik"),
        "kapanis": d.get("kapanis") if acik else None,
        "ozellikler": d.get("ozellikler") or {},
        "saat_farki": round(d["zaman_farki"]) if acik and d.get("zaman_farki") is not None else None,
        "son": r["son"] or 0,
        "eklenme": r["eklenme"],
        "ekran_kucuk": ekran_k[0] if ekran_k else 0,
        "ekran_buyuk": ekran_b[0] if ekran_b else 0,
        "ekran_tam": ekran_t[0] if ekran_t else 0,
        "acan": d.get("acan") if acik else None,
        "ortak": d.get("ortak"),
        "engel": d.get("engel") if acik else None,
        "guncelleme": d.get("guncelleme"),
        "tam_ekran": d.get("tam_ekran") if acik else None,
        "aralik": d.get("aralik") if acik else None,
        "acil": d.get("acil") if acik else None,
    }


def onizleme_iste():
    """Panel açıkken, açık tahtaların küçük ekran görüntülerini tazeler."""
    if not db.ayar("onizleme") or not goruntu_acik_var():
        return
    n = simdi()
    for tid, c in list(canli.items()):
        if not cevrimici_mi(c) or not (c.durum or {}).get("oturum"):
            continue
        son = c.ekran.get("kucuk", (0,))[0]
        if n - son > 30 and n - c.ekran_istek.get("kucuk", 0) > 15:
            c.ekran_istek["kucuk"] = n
            uyandir(tid)


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Nöbet çizelgesi, Belirli Gün ve Haftalar, okul kademesi
# ─────────────────────────────────────────────────────────────────────────────

KADEMELER = (("okuloncesi", "Okul öncesi"), ("ilkokul", "İlkokul"), ("ortaokul", "Ortaokul"),
             ("lise", "Lise (meslek ve imam hatip dahil)"))
KADEME_KODLARI = {k for k, _ in KADEMELER}
HEPSI = ["okuloncesi", "ilkokul", "ortaokul", "lise"]
OKUL_YAS = ["ilkokul", "ortaokul", "lise"]

# MEB "Belirli Gün ve Haftalar" listesinden hazırlanmış başlangıç listesi. Yönetici panelden
# düzenler; MEB listeyi zaman zaman günceller, okul yılı başında kontrol edilmesi önerilir.
#   tarih: "AA-GG" (her yıl) · bas/bit: "AA-GG" aralığı · kural: {"ay", "sira"} ayın N. haftası
#   (sira -1 = son hafta; hafta, o ayın N. pazartesisiyle başlar) · iceren: "AA-GG" o günü içine alan hafta
BGH_HAZIR = [
    ("hafta", "İlköğretim Haftası", {"kural": {"ay": 9, "sira": 3}}, ["ilkokul", "ortaokul"]),
    ("gun", "Gaziler Günü", {"tarih": "09-19"}, HEPSI),
    ("gun", "Hayvanları Koruma Günü", {"tarih": "10-04"}, HEPSI),
    ("gun", "Dünya Gıda Günü", {"tarih": "10-16"}, HEPSI),
    ("gun", "Birleşmiş Milletler Günü", {"tarih": "10-24"}, OKUL_YAS),
    ("gun", "Cumhuriyet Bayramı", {"tarih": "10-29"}, HEPSI),
    ("hafta", "Kızılay Haftası", {"bas": "10-29", "bit": "11-04"}, HEPSI),
    ("hafta", "Lösemili Çocuklar Haftası", {"bas": "11-02", "bit": "11-08"}, HEPSI),
    ("hafta", "Organ Bağışı ve Nakli Haftası", {"bas": "11-03", "bit": "11-09"}, OKUL_YAS),
    ("gun", "Atatürk'ü Anma Günü", {"tarih": "11-10"}, HEPSI),
    ("hafta", "Atatürk Haftası", {"bas": "11-10", "bit": "11-16"}, HEPSI),
    ("gun", "Dünya Çocuk Hakları Günü", {"tarih": "11-20"}, HEPSI),
    ("hafta", "Ağız ve Diş Sağlığı Haftası", {"bas": "11-21", "bit": "11-27"}, HEPSI),
    ("gun", "Öğretmenler Günü", {"tarih": "11-24"}, HEPSI),
    ("gun", "Dünya Engelliler Günü", {"tarih": "12-03"}, HEPSI),
    ("hafta", "İnsan Hakları ve Demokrasi Haftası", {"iceren": "12-10"}, OKUL_YAS),
    ("hafta", "Tutum, Yatırım ve Türk Malları Haftası", {"bas": "12-12", "bit": "12-18"}, HEPSI),
    ("hafta", "Enerji Tasarrufu Haftası", {"kural": {"ay": 1, "sira": 2}}, HEPSI),
    ("gun", "Dünya Anadil Günü", {"tarih": "02-21"}, HEPSI),
    ("hafta", "Vergi Haftası", {"kural": {"ay": 2, "sira": -1}}, OKUL_YAS),
    ("gun", "Sivil Savunma Günü", {"tarih": "02-28"}, HEPSI),
    ("hafta", "Yeşilay Haftası", {"iceren": "03-01"}, OKUL_YAS),
    ("hafta", "Deprem Haftası", {"bas": "03-01", "bit": "03-07"}, HEPSI),
    ("gun", "Dünya Kadınlar Günü", {"tarih": "03-08"}, HEPSI),
    ("hafta", "Bilim ve Teknoloji Haftası", {"bas": "03-08", "bit": "03-14"}, HEPSI),
    ("gun", "İstiklal Marşı'nın Kabulü ve Mehmet Akif Ersoy'u Anma Günü", {"tarih": "03-12"}, HEPSI),
    ("gun", "Tıp Bayramı", {"tarih": "03-14"}, OKUL_YAS),
    ("hafta", "Tüketiciyi Koruma Haftası", {"bas": "03-15", "bit": "03-21"}, OKUL_YAS),
    ("gun", "Şehitler Günü", {"tarih": "03-18"}, HEPSI),
    ("hafta", "Orman Haftası", {"bas": "03-21", "bit": "03-26"}, HEPSI),
    ("gun", "Dünya Su Günü", {"tarih": "03-22"}, HEPSI),
    ("gun", "Dünya Tiyatrolar Günü", {"tarih": "03-27"}, HEPSI),
    ("hafta", "Kütüphaneler Haftası", {"kural": {"ay": 3, "sira": -1}}, HEPSI),
    ("hafta", "Kanser Haftası", {"bas": "04-01", "bit": "04-07"}, OKUL_YAS),
    ("gun", "Dünya Otizm Farkındalık Günü", {"tarih": "04-02"}, HEPSI),
    ("gun", "Dünya Sağlık Günü", {"tarih": "04-07"}, HEPSI),
    ("hafta", "Turizm Haftası", {"bas": "04-15", "bit": "04-22"}, OKUL_YAS),
    ("gun", "Ulusal Egemenlik ve Çocuk Bayramı", {"tarih": "04-23"}, HEPSI),
    ("hafta", "Trafik ve İlk Yardım Haftası", {"kural": {"ay": 5, "sira": 1}}, HEPSI),
    ("hafta", "Engelliler Haftası", {"bas": "05-10", "bit": "05-16"}, HEPSI),
    ("hafta", "Müzeler Haftası", {"bas": "05-18", "bit": "05-24"}, HEPSI),
    ("gun", "Atatürk'ü Anma, Gençlik ve Spor Bayramı", {"tarih": "05-19"}, HEPSI),
    ("gun", "Etik Günü", {"tarih": "05-25"}, OKUL_YAS),
    ("gun", "İstanbul'un Fethi", {"tarih": "05-29"}, HEPSI),
    ("gun", "Dünya Çevre Günü", {"tarih": "06-05"}, HEPSI),
    ("hafta", "Çevre Koruma Haftası", {"kural": {"ay": 6, "sira": 2}}, HEPSI),
    ("gun", "Demokrasi ve Millî Birlik Günü", {"tarih": "07-15"}, HEPSI),
]
AA_GG = re.compile(r"^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$")


def bgh_hazir_liste():
    liste = []
    for i, (tur, ad, kural, kademe) in enumerate(BGH_HAZIR):
        d = {"id": "h{:02d}".format(i + 1), "tur": tur, "ad": ad, "kademe": list(kademe), "hazir": True, "aktif": True}
        d.update(kural)
        liste.append(d)
    return liste


def bgh_liste():
    v = db.ayar("bgh") or {}
    return v.get("liste") if isinstance(v.get("liste"), list) else bgh_hazir_liste()


def _tarih(y, aa_gg):
    from datetime import date
    a, g = int(aa_gg[:2]), int(aa_gg[3:5])
    try:
        return date(y, a, g)
    except ValueError:                          # 29 Şubat
        return date(y, a, 28)


def _ayin_haftasi(y, ay, sira):
    """O ayın 'sira'. pazartesisiyle başlayan hafta (pazartesi–pazar); sira -1 = son pazartesi."""
    from datetime import date, timedelta
    ilk = date(y, ay, 1)
    pzt = ilk + timedelta(days=(7 - ilk.weekday()) % 7)
    pazartesiler = []
    while pzt.month == ay:
        pazartesiler.append(pzt)
        pzt += timedelta(days=7)
    if not pazartesiler:
        return None
    try:
        bas = pazartesiler[sira - 1] if sira > 0 else pazartesiler[sira]
    except IndexError:
        return None
    return bas, bas + timedelta(days=6)


def bgh_aralik(e, yil):
    """Bir kaydın verilen yıldaki (başlangıç, bitiş) tarihleri; tarih yoksa None."""
    from datetime import date, timedelta
    try:
        if e.get("yil_tarih"):                  # tek seferlik: YYYY-AA-GG
            b = date.fromisoformat(e["yil_tarih"])
            s = date.fromisoformat(e.get("yil_bitis") or e["yil_tarih"])
            return (b, s) if b.year == yil or s.year == yil else None
        if e.get("tarih") and AA_GG.match(e["tarih"]):
            d = _tarih(yil, e["tarih"])
            return d, d
        if e.get("bas") and AA_GG.match(e["bas"]):
            b = _tarih(yil, e["bas"])
            s = _tarih(yil, e.get("bit") if AA_GG.match(e.get("bit") or "") else e["bas"])
            if s < b:
                s = _tarih(yil + 1, e["bit"])
            return b, s
        if e.get("iceren") and AA_GG.match(e["iceren"]):
            d = _tarih(yil, e["iceren"])
            b = d - timedelta(days=d.weekday())
            return b, b + timedelta(days=6)
        k = e.get("kural") or {}
        if k.get("ay"):
            return _ayin_haftasi(yil, int(k["ay"]), int(k.get("sira") or 1))
    except (ValueError, TypeError):
        return None
    return None


def bgh_gun(gun, liste=None, kademe=None):
    """Verilen tarihte (date) geçerli belirli günler ve haftalar → ({"gunler": [...], "haftalar": [...]})."""
    liste = bgh_liste() if liste is None else liste
    kademe = set(db.ayar("kademe") or []) if kademe is None else set(kademe)
    gunler, haftalar = [], []
    for e in liste:
        if not e.get("aktif", True) or not e.get("ad"):
            continue
        if kademe and e.get("kademe") and not (kademe & set(e["kademe"])):
            continue
        for yil in (gun.year - 1, gun.year):
            a = bgh_aralik(e, yil)
            if a and a[0] <= gun <= a[1]:
                (haftalar if e.get("tur") == "hafta" else gunler).append(e["ad"])
                break
    return {"gunler": gunler, "haftalar": haftalar}


def bgh_dogrula(liste):
    temiz = []
    for e in (liste or [])[:400]:
        ad = re.sub(r"\s+", " ", str(e.get("ad") or "")).strip()[:120]
        if not ad:
            continue
        d = {"id": str(e.get("id") or uuid.uuid4().hex[:8])[:12], "ad": ad,
             "tur": "hafta" if e.get("tur") == "hafta" else "gun",
             "kademe": [k for k in (e.get("kademe") or []) if k in KADEME_KODLARI],
             "aktif": bool(e.get("aktif", True)), "hazir": bool(e.get("hazir"))}
        for alan in ("tarih", "bas", "bit", "iceren"):
            v = str(e.get(alan) or "").strip()
            if v:
                if not AA_GG.match(v):
                    raise Hata("{}: tarih AA-GG biçiminde olmalı (ör. 10-29)".format(ad))
                d[alan] = v
        for alan in ("yil_tarih", "yil_bitis"):
            v = str(e.get(alan) or "").strip()
            if v:
                if not TARIH_DESEN.match(v):
                    raise Hata("{}: tarih geçersiz".format(ad))
                d[alan] = v
        k = e.get("kural") or {}
        if k.get("ay"):
            d["kural"] = {"ay": max(1, min(int(k["ay"]), 12)), "sira": max(-1, min(int(k.get("sira") or 1), 5)) or 1}
        if not any(x in d for x in ("tarih", "bas", "iceren", "kural", "yil_tarih")):
            raise Hata("{}: tarih girin".format(ad))
        temiz.append(d)
    return temiz


def tatil_mi(tarih_str):
    for t in db.ayar("zil_tatil") or []:
        if (t.get("bas") or "") <= tarih_str <= (t.get("bit") or t.get("bas") or ""):
            return t.get("ad") or "Tatil"
    return None


def _hafta_pazartesi(gun):
    from datetime import timedelta
    return (gun - timedelta(days=gun.weekday())).isoformat()


def nobet_dogrula(t):
    """Panelden gelen bir nöbet tablosunu doğrular."""
    tur = t.get("tur")
    if tur not in ("haftalik", "aylik", "gunluk"):
        raise Hata("Tablo türü geçersiz")
    satirlar = [re.sub(r"\s+", " ", str(s or "")).strip()[:60] for s in (t.get("satirlar") or [])][:40]
    sutunlar = []
    for s in (t.get("sutunlar") or [])[:40]:
        c = {"ad": re.sub(r"\s+", " ", str(s.get("ad") or "")).strip()[:40]}
        if tur == "haftalik":
            c["gun"] = max(0, min(int(s.get("gun") or 0), 6))
        elif tur == "aylik":
            if not TARIH_DESEN.match(str(s.get("tarih") or "")):
                raise Hata("Aylık tabloda sütun tarihi geçersiz")
            c["tarih"] = s["tarih"]
        sutunlar.append(c)
    if tur == "gunluk":
        sutunlar = [{"ad": (sutunlar[0]["ad"] if sutunlar else "") or "Nöbetçi"}]
    hucre = {}
    for k, v in (t.get("hucre") or {}).items():
        m = re.match(r"^(\d{1,2}),(\d{1,2})$", str(k))
        v = re.sub(r"\s+", " ", str(v or "")).strip()[:80]
        if m and v and int(m.group(1)) < len(satirlar) and int(m.group(2)) < len(sutunlar):
            hucre[k] = v
    d = {"id": str(t.get("id") or uuid.uuid4().hex[:8])[:12], "tur": tur, "satirlar": satirlar,
         "sutunlar": sutunlar, "hucre": hucre, "ad": str(t.get("ad") or "").strip()[:60]}
    if tur == "haftalik":
        h = str(t.get("hafta") or "sablon")
        if h != "sablon" and not TARIH_DESEN.match(h):
            raise Hata("Hafta geçersiz")
        d["hafta"] = h
    elif tur == "aylik":
        if not re.match(r"^\d{4}-\d{2}$", str(t.get("ay") or "")):
            raise Hata("Ay geçersiz")
        d["ay"] = t["ay"]
    else:
        if not TARIH_DESEN.match(str(t.get("tarih") or "")):
            raise Hata("Günlük tablonun tarihi geçersiz")
        d["tarih"] = t["tarih"]
    return d


def nobet_gun(gun, nobet=None):
    """Verilen günün nöbetçileri → {"satirlar": [[yer, kişi], ...], "kaynak": ...}.
    Öncelik: o güne ait günlük tablo > o haftanın tablosu > o ayın tablosu > tüm haftalar (sabit) tablosu."""
    nobet = nobet or db.ayar("nobet") or {}
    tablolar = nobet.get("tablolar") or []
    ts = gun.isoformat()
    tatil = tatil_mi(ts)
    if tatil:
        return {"satirlar": [], "kaynak": "tatil", "tatil": tatil}

    def topla(t, sutun_bul):
        sat = []
        for c, s in enumerate(t["sutunlar"]):
            if not sutun_bul(s):
                continue
            for r, yer in enumerate(t["satirlar"]):
                kisi = t["hucre"].get("{},{}".format(r, c))
                if kisi:
                    sat.append([yer, kisi])
        return sat

    adaylar = [
        ("gunluk", [t for t in tablolar if t.get("tur") == "gunluk" and t.get("tarih") == ts], lambda s: True),
        ("hafta", [t for t in tablolar if t.get("tur") == "haftalik" and t.get("hafta") == _hafta_pazartesi(gun)],
         lambda s: s.get("gun") == gun.weekday()),
        ("aylik", [t for t in tablolar if t.get("tur") == "aylik" and t.get("ay") == ts[:7]], lambda s: s.get("tarih") == ts),
        ("sablon", [t for t in tablolar if t.get("tur") == "haftalik" and t.get("hafta") == "sablon"],
         lambda s: s.get("gun") == gun.weekday()),
    ]
    for kaynak, liste, bul in adaylar:
        for t in liste:
            sat = topla(t, bul)
            if sat:
                return {"satirlar": sat, "kaynak": kaynak}
    return {"satirlar": [], "kaynak": ""}


def okul_ayari(tid, grup):
    """Tahtaya gönderilen nöbet / belirli gün / açılış görseli bilgileri (önümüzdeki 10 gün)."""
    from datetime import date, timedelta
    g = db.ayar("okul_gorunum") or {}
    nobet = db.ayar("nobet") or {}
    liste, kademe = bgh_liste(), db.ayar("kademe") or []
    bugun = date.fromtimestamp(simdi())
    gunluk = {}
    for i in range(10):
        d = bugun + timedelta(days=i)
        n = nobet_gun(d, nobet)
        b = bgh_gun(d, liste, kademe)
        gunluk[d.isoformat()] = {"nobet": n["satirlar"], "tatil": n.get("tatil"),
                                 "gunler": b["gunler"], "haftalar": b["haftalar"]}
    # Yönetici çizelge girmedikçe ya da görünüm ayarını kaydetmedikçe tahtada hiçbir şey değişmez
    # (4.0'a yükseltince masaüstü resimleri kendiliğinden değişmesin).
    hedefte = hedef_kapsar(g.get("hedef") or {"hepsi": True}, tid, grup) and bool(nobet.get("tablolar") or g.get("kaydedildi"))
    acilis = []
    son = (bugun + timedelta(days=10)).isoformat()
    for a in db.ayar("acilis_gorseller") or []:
        if a.get("aktif", True) and a.get("bit", "") >= bugun.isoformat() and a.get("bas", "") <= son \
                and hedef_kapsar(a.get("hedef"), tid, grup):
            acilis.append({x: a.get(x) for x in ("id", "sha", "dosya", "bas", "bit", "saat", "sure", "kapatilabilir", "ad")})
    logo = db.ayar("okul_logo")
    return {
        "mod": (g.get("mod") or "arka_plan") if hedefte else "kapali",
        "baslik": nobet.get("baslik") or "Bugünün Nöbetçileri",
        "bgh_goster": bool(g.get("bgh_goster", True)),
        "serit": g.get("serit") or {},
        "giris_notu": (g.get("giris_notu") or {}) if hedefte else {"etkin": False},
        "logo": {"sha": logo["sha"], "dosya": logo.get("ad")} if logo else None,
        "gunluk": gunluk,
        "acilis": acilis,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — İşlem sonucu (toplu işlemlerin tahta tahta sonucu)
# ─────────────────────────────────────────────────────────────────────────────

ISLEM_SURE = 120          # bu süre içinde sonuç gelmezse "yanıt yok" sayılır (sn)
ISLEM_SURE_TUR = {"tanila": 300, "onar": 1800, "yazici_onar": 300}


def islem_baslat(tur, ad, veri, idler, gonderilecek, kim, hedef_yazi_="", omur=None, kayit_veri=None):
    """Toplu işlemi kaydeder; açık tahtalara komutu gönderir, kapalıları 'kapalı' olarak işaretler."""
    iid = uuid.uuid4().hex[:12]
    n = simdi()
    db.x("INSERT INTO islem(id, zaman, kim, tur, ad, veri, hedef) VALUES(?,?,?,?,?,?,?)",
         (iid, n, kim or "", tur, ad, json.dumps(kayit_veri if kayit_veri is not None else veri, ensure_ascii=False),
          hedef_yazi_))
    gonder = set(gonderilecek)
    for tid in idler:
        if tid in gonder:
            kid = komut_ekle(tid, tur, veri, omur)
            db.x("INSERT OR REPLACE INTO islem_tahta(islem, tahta, kid, durum, zaman) VALUES(?,?,?,?,?)",
                 (iid, tid, kid, "bekliyor", n))
        else:
            db.x("INSERT OR REPLACE INTO islem_tahta(islem, tahta, kid, durum, mesaj, zaman) VALUES(?,?,?,?,?,?)",
                 (iid, tid, "", "kapali", "Tahta kapalıydı; işlem gönderilmedi", n))
    db.x("DELETE FROM islem WHERE zaman < ?", (n - 90 * 86400,))
    db.x("DELETE FROM islem_tahta WHERE zaman < ?", (n - 90 * 86400,))
    return iid


def islem_sonuc(kid, ok, mesaj="", veri=None):
    if not kid:
        return
    db.x("UPDATE islem_tahta SET durum=?, mesaj=?, veri=?, zaman=? WHERE kid=?",
         ("tamam" if ok else "hata", str(mesaj or "")[:500],
          json.dumps(veri, ensure_ascii=False)[:200000] if veri is not None else "", simdi(), kid))


def islem_ozet(r, ayrinti=False):
    satirlar = db.q("SELECT * FROM islem_tahta WHERE islem=?", (r["id"],))
    n = simdi()
    sayi = {}
    tahtalar = []
    for s in satirlar:
        d = s["durum"]
        sure = ISLEM_SURE_TUR.get(r["tur"], ISLEM_SURE)
        if d in ("bekliyor", "iletildi") and n - s["zaman"] > sure and n - r["zaman"] > sure:
            d = "yanitsiz"
        sayi[d] = sayi.get(d, 0) + 1
        if ayrinti:
            x = {"tahta": s["tahta"], "ad": tahta_adi(s["tahta"]), "durum": d, "mesaj": s["mesaj"] or "", "zaman": s["zaman"]}
            if s.get("veri"):
                try:
                    x["veri"] = json.loads(s["veri"])
                except ValueError:
                    pass
            tahtalar.append(x)
    sira = {"hata": 0, "yanitsiz": 1, "kapali": 2, "bekliyor": 3, "iletildi": 4, "tamam": 5}
    tahtalar.sort(key=lambda x: (sira.get(x["durum"], 9), x["ad"].lower()))
    o = {"id": r["id"], "zaman": r["zaman"], "kim": r["kim"], "tur": r["tur"], "ad": r["ad"], "hedef": r["hedef"],
         "toplam": len(satirlar), "sayi": sayi,
         "bitti": not any(k in sayi for k in ("bekliyor", "iletildi"))}
    if ayrinti:
        o["tahtalar"] = tahtalar
    return o


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Ekran görüntüleri: varsayılan gizli, yönetici şifresiyle açılır
# ─────────────────────────────────────────────────────────────────────────────

GORUNTU_SURE = 15 * 60          # bu kadar süre işlem yapılmazsa görüntüler yeniden gizlenir
GORUNTU = {}                    # oturum özeti → {"bitis", "kim"}
GORUNTU_KILIT = threading.Lock()


def goruntu_acik_var():
    n = simdi()
    with GORUNTU_KILIT:
        for k in [k for k, v in GORUNTU.items() if v["bitis"] <= n]:
            GORUNTU.pop(k, None)
        return bool(GORUNTU)


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Şifreleme yardımcıları (yalnızca standart kütüphane)
#   * Yedek dosyası: PBKDF2-SHA256 ile anahtar, HMAC-SHA256 sayaç kipi akış şifresi + HMAC bütünlük
#   * Windows tahtalara giden yeni şifre: ajan anahtarından türetilen akışla şifrelenir
#   * Pardus tahtalara giden yeni şifre: SHA-512 crypt özeti (şifrenin kendisi gönderilmez)
# ─────────────────────────────────────────────────────────────────────────────

YEDEK_IMZA = b"TYA4YDK1"


def _akis(anahtar, nonce, n):
    out = bytearray()
    i = 0
    while len(out) < n:
        out += hmac.new(anahtar, nonce + i.to_bytes(8, "big"), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def _xor(veri, akis):
    return (int.from_bytes(veri, "big") ^ int.from_bytes(akis, "big")).to_bytes(len(veri), "big") if veri else b""


def yedek_anahtar(sifre, tuz):
    k = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz, 200000, 64)
    return k[:32], k[32:]


def yedek_sifrele(duz_yol, hedef_yol, sifre):
    """duz_yol dosyasını şifreleyip hedef_yol'a yazar."""
    tuz, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    ka, km = yedek_anahtar(sifre, tuz)
    mac = hmac.new(km, YEDEK_IMZA + tuz + nonce, hashlib.sha256)
    with open(str(duz_yol), "rb") as g, open(str(hedef_yol), "wb") as c:
        c.write(YEDEK_IMZA + tuz + nonce)
        i = 0
        while True:
            parca = g.read(1024 * 1024)
            if not parca:
                break
            sifreli = _xor(parca, _akis_blok(ka, nonce, i, len(parca)))
            i += (len(parca) + 31) // 32
            mac.update(sifreli)
            c.write(sifreli)
        c.write(mac.digest())


def _akis_blok(ka, nonce, bas_blok, n):
    out = bytearray()
    i = bas_blok
    while len(out) < n:
        out += hmac.new(ka, nonce + i.to_bytes(8, "big"), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def yedek_coz(sifreli_yol, hedef_yol, sifre):
    boyut = os.path.getsize(str(sifreli_yol))
    with open(str(sifreli_yol), "rb") as g:
        bas = g.read(40)
        if bas[:8] != YEDEK_IMZA or boyut < 72:
            raise Hata("Bu dosya Tahta Yönetim Asistanı yedeği değil")
        tuz, nonce = bas[8:24], bas[24:40]
        ka, km = yedek_anahtar(sifre, tuz)
        mac = hmac.new(km, bas, hashlib.sha256)
        kalan = boyut - 40 - 32
        while kalan > 0:
            parca = g.read(min(kalan, 1024 * 1024))
            mac.update(parca)
            kalan -= len(parca)
        if not hmac.compare_digest(mac.digest(), g.read(32)):
            raise Hata("Yedek şifresi yanlış ya da dosya bozuk")
        g.seek(40)
        kalan = boyut - 72
        i = 0
        with open(str(hedef_yol), "wb") as c:
            while kalan > 0:
                parca = g.read(min(kalan, 1024 * 1024))
                c.write(_xor(parca, _akis_blok(ka, nonce, i, len(parca))))
                i += (len(parca) + 31) // 32
                kalan -= len(parca)


def sifre_paketle(sifre, anahtar):
    """Windows tahtalar için: yeni şifre ajan anahtarıyla şifrelenip gönderilir."""
    import base64
    nonce = secrets.token_bytes(16)
    veri = sifre.encode("utf-8")
    k = hmac.new(anahtar.encode(), b"tys-sifre" + nonce, hashlib.sha256).digest()
    return {"n": base64.b64encode(nonce).decode(), "s": base64.b64encode(_xor(veri, _akis(k, nonce, len(veri)))).decode(),
            "m": hmac.new(k, veri, hashlib.sha256).hexdigest()[:16]}


_CRYPT_ALFABE = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


def sha512_crypt(sifre, tuz=None, tur=5000):
    """glibc SHA-512 crypt ($6$) — Pardus'ta 'usermod -p' ile kullanılır; şifrenin kendisi tahtaya gitmez."""
    tuz = (tuz or "".join(secrets.choice(_CRYPT_ALFABE) for _ in range(16)))[:16]
    p, s = sifre.encode("utf-8"), tuz.encode("ascii")
    b = hashlib.sha512(p + s + p).digest()
    a = hashlib.sha512(p + s)
    n = len(p)
    while n > 64:
        a.update(b)
        n -= 64
    a.update(b[:n])
    n = len(p)
    while n:
        a.update(b if n & 1 else p)
        n >>= 1
    a = a.digest()
    dp = hashlib.sha512(p * len(p)).digest()
    P = (dp * (len(p) // 64 + 1))[:len(p)]
    ds = hashlib.sha512(s * (16 + a[0])).digest()
    S = (ds * (len(s) // 64 + 1))[:len(s)]
    c = a
    for i in range(tur):
        h = hashlib.sha512()
        h.update(P if i & 1 else c)
        if i % 3:
            h.update(S)
        if i % 7:
            h.update(P)
        h.update(c if i & 1 else P)
        c = h.digest()
    sira = [(0, 21, 42), (22, 43, 1), (44, 2, 23), (3, 24, 45), (25, 46, 4), (47, 5, 26), (6, 27, 48), (28, 49, 7),
            (50, 8, 29), (9, 30, 51), (31, 52, 10), (53, 11, 32), (12, 33, 54), (34, 55, 13), (56, 14, 35),
            (15, 36, 57), (37, 58, 16), (59, 17, 38), (18, 39, 60), (40, 61, 19), (62, 20, 41)]
    out = []

    def b64(v, n):
        for _ in range(n):
            out.append(_CRYPT_ALFABE[v & 63])
            v >>= 6
    for x, y, z in sira:
        b64((c[x] << 16) | (c[y] << 8) | c[z], 4)
    b64(c[63], 2)
    return "$6$" + tuz + "$" + "".join(out)


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Ayar yedeği (her gün otomatik, elle indirme, geri yükleme öncesi otomatik)
# ─────────────────────────────────────────────────────────────────────────────

YEDEK_GUN_SAYISI = 14
YEDEK_HARIC_AYAR = {"acil", "acil_gecmis", "yedekler"}


def yedek_klasoru():
    k = VERI / "yedekler"
    k.mkdir(exist_ok=True)
    return k


def yerel_yedek_sifresi():
    """Bu bilgisayardaki otomatik yedeklerin şifresi (kurulumdaki gizli anahtardan türetilir)."""
    return hashlib.sha256(("tys-yerel-yedek:" + (db.ayar("kimlik") or "") + ":" + (db.ayar("anahtar") or "")).encode()).hexdigest()


def yedek_icerik():
    tablolar = {}
    for tablo, sql in (("tahta", "SELECT id, ad, grup, bilgi, eklenme FROM tahta"),
                       ("kural", "SELECT id, veri FROM kural"),
                       ("politika", "SELECT * FROM politika"),
                       ("depo", "SELECT * FROM depo"),
                       ("uygulama", "SELECT * FROM uygulama"),
                       ("yazici_model", "SELECT * FROM yazici_model")):
        tablolar[tablo] = db.q(sql)
    return {"uygulama": "TahtaYonetim", "surum": SURUM, "tarih": time.strftime("%Y-%m-%d %H:%M"),
            "okul_adi": db.ayar("okul_adi"),
            "ayarlar": {r["anahtar"]: json.loads(r["deger"]) for r in db.q("SELECT * FROM ayar")
                        if r["anahtar"] not in YEDEK_HARIC_AYAR},
            "tablolar": tablolar}


def yedek_olustur(hedef, sifre, depo_dahil=False):
    """Şifreli yedek dosyası üretir: ZIP (yedek.json [+ depo dosyaları]) → şifreli."""
    import zipfile
    import tempfile
    icerik = yedek_icerik()
    fd, gecici = tempfile.mkstemp(prefix="tys-yedek-", suffix=".zip", dir=str(VERI))
    os.close(fd)
    try:
        with zipfile.ZipFile(gecici, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("yedek.json", json.dumps(icerik, ensure_ascii=False))
            if depo_dahil:
                for r in icerik["tablolar"]["depo"]:
                    p = DEPO_DIZIN / r["sha"]
                    if p.is_file():
                        z.write(str(p), "depo/" + r["sha"], compress_type=zipfile.ZIP_STORED)
                logo = db.ayar("okul_logo")
                if logo and (DEPO_DIZIN / logo["sha"]).is_file() and not any(r["sha"] == logo["sha"] for r in icerik["tablolar"]["depo"]):
                    z.write(str(DEPO_DIZIN / logo["sha"]), "depo/" + logo["sha"], compress_type=zipfile.ZIP_STORED)
        yedek_sifrele(gecici, hedef, sifre)
    finally:
        try:
            os.remove(gecici)
        except OSError:
            pass
    return icerik


def gunluk_yedek_al(neden="gunluk", zorla=False):
    k = yedek_klasoru()
    bugun = time.strftime("%Y%m%d")
    if neden == "gunluk" and not zorla and any(k.glob("yedek-{}-gunluk*.tya".format(bugun))):
        return None
    ad = "yedek-{}-{}-{}.tya".format(bugun, time.strftime("%H%M%S"), neden)
    yedek_olustur(k / ad, yerel_yedek_sifresi())
    eski = sorted(k.glob("yedek-*.tya"))
    if len(eski) > YEDEK_GUN_SAYISI * 2:
        for p in eski[:len(eski) - YEDEK_GUN_SAYISI * 2]:
            try:
                p.unlink()
            except OSError:
                pass
    sinir = time.time() - YEDEK_GUN_SAYISI * 86400
    for p in k.glob("yedek-*.tya"):
        try:
            if p.stat().st_mtime < sinir and p.name != ad:
                p.unlink()
        except OSError:
            pass
    return ad


def yedek_uygula(icerik, depo_klasoru=None):
    """Yedekteki ayarları ve tabloları geri yükler (önce o anki durumun yedeği alınır)."""
    if icerik.get("uygulama") != "TahtaYonetim":
        raise Hata("Bu dosya Tahta Yönetim Asistanı yedeği değil")
    try:
        gunluk_yedek_al("geri-yukleme-oncesi", zorla=True)
    except Exception:
        log.exception("geri yükleme öncesi yedek alınamadı")
    for k, v in (icerik.get("ayarlar") or {}).items():
        if k in VARSAYILAN_AYAR and k not in YEDEK_HARIC_AYAR:
            db.ayar_yaz(k, v)
    t = icerik.get("tablolar")
    if t is None:                                   # eski (3.x) JSON yedeği
        t = {"tahta": icerik.get("tahtalar") or [],
             "kural": [{"id": k["id"], "veri": json.dumps(k, ensure_ascii=False)} for k in icerik.get("kurallar") or []]}
    for r in t.get("tahta") or []:
        db.x("INSERT OR REPLACE INTO tahta(id, ad, grup, bilgi, eklenme, son) VALUES(?,?,?,?,?,COALESCE((SELECT son FROM tahta WHERE id=?),0))",
             (r["id"], r["ad"], r.get("grup") or "", r.get("bilgi") or "{}", r.get("eklenme") or simdi(), r["id"]))
    if "kural" in t:
        db.x("DELETE FROM kural")
        for r in t["kural"]:
            db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (r["id"], r["veri"]))
    for tablo, alanlar in (("politika", ("id", "modul", "tur", "ad", "hedef", "veri", "aktif", "surum", "olusturma", "guncelleme", "kim")),
                           ("depo", ("sha", "ad", "boyut", "tur", "aciklama", "eklenme", "kim")),
                           ("uygulama", ("id", "ad", "kaynak", "aciklama", "wine_sonuc", "olusturma", "guncelleme")),
                           ("yazici_model", ("model", "platform", "sonuc", "yontem", "surucu", "ayrinti", "zaman", "tahta"))):
        if tablo not in t:
            continue
        for r in t[tablo]:
            db.x("INSERT OR REPLACE INTO {}({}) VALUES({})".format(tablo, ", ".join(alanlar), ",".join("?" * len(alanlar))),
                 tuple(r.get(a) for a in alanlar))
    if depo_klasoru:
        DEPO_DIZIN.mkdir(parents=True, exist_ok=True)
        for p in Path(depo_klasoru).iterdir():
            if re.match(r"^[a-f0-9]{64}$", p.name) and not (DEPO_DIZIN / p.name).exists():
                shutil.move(str(p), str(DEPO_DIZIN / p.name))
    if any((json.loads(r["veri"]) if isinstance(r.get("veri"), str) else {}).get("tur") == "zil" for r in t.get("kural") or []):
        db.ayar_yaz("zil_goc", False)
    zil_goc()
    hepsini_uyandir()


def arka_plan_yedek():
    """Her gün bir kez ayar yedeği alır (bilgisayar açıldıktan 2 dk sonra ve saatte bir kontrol)."""
    time.sleep(120)
    while True:
        try:
            if (db.ayar("yedek_ayar") or {}).get("gunluk", True) and dugum.aktif():
                ad = gunluk_yedek_al()
                if ad:
                    log.info("Günlük ayar yedeği alındı: %s", ad)
        except Exception:
            log.exception("günlük yedek alınamadı")
        time.sleep(3600)


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Tahta sağlığı
# ─────────────────────────────────────────────────────────────────────────────

def saglik_degerlendir(v, cevrimici, son):
    """→ (seviye, [uyarılar]) seviye: 2 kritik, 1 uyarı, 0 iyi"""
    uyarilar, seviye = [], 0
    disk, bos = v.get("disk"), v.get("disk_bos_gb")
    if disk is not None and disk >= 90:
        uyarilar.append("Disk %{} dolu".format(round(disk)))
        seviye = 2
    elif (disk is not None and disk >= 80) or (bos is not None and bos < 5):
        uyarilar.append("Disk %{} dolu".format(round(disk)) if disk is not None and disk >= 80 else
                        "Diskte {:.1f} GB boş yer kaldı".format(bos))
        seviye = max(seviye, 1)
    s = v.get("sicaklik")
    if s is not None and s >= 85:
        uyarilar.append("Sıcaklık {} °C".format(round(s)))
        seviye = 2
    ram = v.get("ram")
    if ram is not None and ram >= 90:
        uyarilar.append("Bellekte %{} boş yer kaldı".format(max(0, 100 - round(ram))))
        seviye = max(seviye, 1)
    calisma = v.get("calisma_sn")
    if cevrimici and calisma and calisma > 3 * 86400:
        uyarilar.append("{} gündür kapatılmadı".format(int(calisma // 86400)))
        seviye = max(seviye, 1)
    pl = v.get("paket_listesi")
    if pl and simdi() - pl > 30 * 86400:
        uyarilar.append("Paket listesi {} gündür yenilenmedi".format(int((simdi() - pl) // 86400)))
        seviye = max(seviye, 1)
    return seviye, uyarilar


# ─────────────────────────────────────────────────────────────────────────────
# 4.0 — Ağdan toplu kurulum: ağdaki Pardus tahtaları bulur, SSH ile tahta programını kurar
# ─────────────────────────────────────────────────────────────────────────────

AG_IS = {"tarama": {}, "kurulum": {}}
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def ag_tara_is(ipler):
    import ssh_mini
    from concurrent.futures import ThreadPoolExecutor
    t = AG_IS["tarama"]
    bilinen = {}
    for r in db.q("SELECT id, ad, bilgi FROM tahta"):
        ip = json.loads(r["bilgi"] or "{}").get("ip")
        if ip:
            bilinen[ip] = r["ad"]
    kendi = set(yerel_adresler())

    def yokla(ip):
        try:
            if not ssh_mini.port_acik(ip, 22, 0.8):
                return None
            s = {"ip": ip, "bilinen": bilinen.get(ip), "kendi": ip in kendi}
            try:
                k = ssh_mini.kimlik_al(ip, 22, 5)
                s.update(surum=k["surum"], tur=k["tur"], parmak_izi=k["parmak_izi"])
            except Exception as e:
                s.update(hata=str(e)[:160], surum=getattr(e, "surum", None) or None)
            return s
        finally:
            t["biten"] += 1
    try:
        with ThreadPoolExecutor(max_workers=64) as hav:
            for s in hav.map(yokla, ipler):
                if s:
                    t["sonuclar"].append(s)
        surumler = {}
        for s in t["sonuclar"]:
            if s.get("surum"):
                surumler[s["surum"]] = surumler.get(s["surum"], 0) + 1
        cogu = max(surumler, key=surumler.get) if surumler else None
        for s in t["sonuclar"]:
            s["pardus"] = "debian" in (s.get("surum") or "").lower() or "pardus" in (s.get("surum") or "").lower()
            s["farkli"] = bool(s.get("surum")) and s["surum"] != cogu and len(surumler) > 1
            # Sürümünü bildiren ama Pardus/Debian olmayan (ya da yazılım adını gizleyen) cihazlar tahta değildir
            if s.get("surum") is not None and not s["pardus"] and not s.get("bilinen") and not s.get("kendi"):
                s["tahta_degil"] = True
                s["cihaz_turu"] = ssh_cihaz_turu(s["surum"])
        import ipaddress
        t["sonuclar"].sort(key=lambda s: ipaddress.ip_address(s["ip"]))
        t["durum"] = "bitti"
        olay("", "sistem", "Ağ taraması bitti: {} SSH cihazı bulundu".format(len(t["sonuclar"])))
    except Exception as e:
        log.exception("ağ taraması")
        t["durum"], t["hata"] = "hata", str(e)


# ─────────────────────────────────────────────────────────────────────────────
# 4.2 — Tanıla ve onar · okul ağı sertifikası · Tahta Onarım Belleği
# ─────────────────────────────────────────────────────────────────────────────
ONARIM_KIMLIKLERI = {"ag_yenile", "dhcp", "proxy", "wifi_tasarruf", "sertifika", "saat", "paket", "disk", "hizmet", "ses",
                     "kalibrasyon", "ekran", "yazici", "r8168", "kimlik", "ajan_baslat"}
ONARIM_MODUL = PROGRAM / "ajan" / "moduller" / "onarim.py"
HP_FIRMWARE = {"1000": ["sihp1000"], "1005": ["sihp1005"], "1018": ["sihp1018"], "1020": ["sihp1020", "sihp1018"],
               "P1005": ["sihpP1005"], "P1006": ["sihpP1006", "sihpP1005"], "P1007": ["sihpP1005"], "P1008": ["sihpP1006"],
               "P1505": ["sihpP1505"]}
BELLEK_SURE_GUN = 7
KIMLIK_MAC = {}                   # tahta kimliği → son (zaman, mac) kayıtları (aynı imajdan kurulmuş tahtaları yakalamak için)
KIMLIK_MAC_KILIT = threading.Lock()


def onarim_modulu():
    """Tanılama motoru (ajan modülü) — Windows betiklerini ve Linux betiğini bellek için verir."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("tys_onarim_sunucu", str(ONARIM_MODUL))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def kimlik_mac_kaydet(tid, mac):
    if not mac:
        return
    with KIMLIK_MAC_KILIT:
        l = KIMLIK_MAC.setdefault(tid, [])
        if not l or l[-1][1] != mac.lower():
            l.append((simdi(), mac.lower()))
            del l[:-30]


def kimlik_cakisma(tid):
    """Aynı kimlikle iki farklı ağ kartı son 30 dakikada sık sık yer değiştiriyorsa: aynı imajdan kurulmuş iki tahta."""
    with KIMLIK_MAC_KILIT:
        l = [x for x in KIMLIK_MAC.get(tid, []) if simdi() - x[0] < 1800]
    return len({m for _, m in l}) > 1 and len(l) >= 4


def tani_ozet(veri):
    b = (veri or {}).get("bulgular") or []
    return {"hata": sum(1 for x in b if x.get("durum") == "hata"), "uyari": sum(1 for x in b if x.get("durum") == "uyari"),
            "onarilabilir": sum(1 for x in b if x.get("onar") and x.get("durum") in ("hata", "uyari")),
            "platform": (veri or {}).get("platform") or "", "tur": (veri or {}).get("tur") or ""}


def tani_kaydet(tid, kaynak, veri):
    if kaynak == "panel" and tid and kimlik_cakisma(tid) and not any(b.get("id") == "kimlik" for b in veri.get("bulgular") or []):
        veri.setdefault("bulgular", []).append({
            "id": "kimlik", "grup": "Tahta programı", "baslik": "Tahta kimliği", "durum": "hata", "onar": "kimlik",
            "onar_yazi": "Tahtaya yeni kimlik ver (aynı imajdan kurulmuş tahtalar)",
            "mesaj": "Bu kimlikle iki farklı tahta bağlanıyor (aynı imajdan kurulmuşlar); panelde tek tahta gibi görünüyorlar. "
                     "Yeni kimlik verilen tahta panele ayrı tahta olarak gelir."})
    n = simdi()
    db.x("INSERT INTO tani(tahta, zaman, kaynak, ozet, veri) VALUES(?,?,?,?,?)",
         (tid, n, kaynak, json.dumps(tani_ozet(veri)), json.dumps(veri, ensure_ascii=False)[:400000]))
    eski = [r["id"] for r in db.q("SELECT id FROM tani WHERE tahta=? ORDER BY zaman DESC", (tid,))][10:]
    for i in eski:
        db.x("DELETE FROM tani WHERE id=?", (i,))
    db.x("DELETE FROM tani WHERE zaman < ?", (n - 180 * 86400,))


def pem_cikar(ham):
    """Yüklenen sertifika dosyasını (PEM ya da DER: .crt/.cer/.pem) tek bir PEM sertifikaya çevirir."""
    import ssl
    if b"-----BEGIN CERTIFICATE-----" in ham:
        m = re.search(rb"-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----", ham)
        if not m:
            raise Hata("Sertifika dosyası bozuk")
        pem = m.group(0).decode("ascii").replace("\r", "")
    else:
        try:
            import base64
            if re.fullmatch(rb"[A-Za-z0-9+/=\s]+", ham.strip() or b"x"):
                ham = base64.b64decode(ham)
            pem = ssl.DER_cert_to_PEM_cert(ham)
        except Exception:
            raise Hata("Sertifika dosyası tanınmadı (.crt, .cer ya da .pem olmalı)")
    try:
        bilgi = onarim_modulu().sertifika_bilgi(pem)
    except Exception:
        raise Hata("Sertifika okunamadı; dosyanın bir sertifika olduğundan emin olun")
    return pem.strip() + "\n", bilgi


def bellek_dogrula(belirtec):
    """Onarım Belleği belirtecini doğrular: var, iptal edilmemiş, süresi dolmamış."""
    if not belirtec or len(belirtec) < 20:
        raise Hata("Geçersiz bellek", 403)
    ozet = hashlib.sha256(belirtec.encode()).hexdigest()
    for b in db.ayar("onarim_bellekler") or []:
        if hmac.compare_digest(b.get("ozet", ""), ozet):
            if b.get("iptal"):
                raise Hata("Bu onarım belleği panelden iptal edilmiş", 403)
            if b.get("bitis", 0) < simdi():
                raise Hata("Bu onarım belleğinin süresi dolmuş; panelden yenisini hazırlayın", 403)
            return b
    raise Hata("Bu onarım belleği tanınmıyor", 403)


def cikarilabilir_suruculer():
    """Yönetim bilgisayarına takılı USB bellekler: [{yol, ad, bos_gb, toplam_gb}]"""
    sonuc = []
    test = os.environ.get("TYS_TEST_USB")
    if test:
        for d in test.split(os.pathsep):
            if os.path.isdir(d):
                u = shutil.disk_usage(d)
                sonuc.append({"yol": d, "ad": os.path.basename(d.rstrip("/")) or d, "bos_gb": round(u.free / 1024 ** 3, 1),
                              "toplam_gb": round(u.total / 1024 ** 3, 1)})
        return sonuc
    if os.name != "nt":
        return sonuc
    import ctypes
    k = ctypes.windll.kernel32
    maske = k.GetLogicalDrives()
    for i in range(26):
        if not maske & (1 << i):
            continue
        kok = "%s:\\" % chr(65 + i)
        if k.GetDriveTypeW(kok) != 2:              # DRIVE_REMOVABLE
            continue
        etiket = ctypes.create_unicode_buffer(261)
        dosya_sistemi = ctypes.create_unicode_buffer(261)
        if not k.GetVolumeInformationW(kok, etiket, 261, None, None, None, dosya_sistemi, 261):
            continue                                # kart okuyucuda kart yok vb.
        bos, toplam = ctypes.c_ulonglong(), ctypes.c_ulonglong()
        k.GetDiskFreeSpaceExW(kok, None, ctypes.byref(toplam), ctypes.byref(bos))
        sonuc.append({"yol": kok, "ad": "{} ({})".format(etiket.value or "USB bellek", kok.rstrip("\\")),
                      "bos_gb": round(bos.value / 1024 ** 3, 1), "toplam_gb": round(toplam.value / 1024 ** 3, 1)})
    return sonuc


LINUX_BASLAT = r"""#!/bin/bash
# Tahta Yönetim Asistanı — Tahta Onarım Belleği (Pardus / ETAP)
# Başlatma: bellekteki TahtaOnar simgesine çift tıklayın ya da bu klasörde Uçbirim açıp  bash tahta-onar.sh  yazın.
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$(id -u)" -eq 0 ]; then
  exec /usr/bin/python3 "$D/onarim.py" --bellek "$D"
fi
echo
echo "  Tahta yöneticisinin (etapadmin) şifresi istenecek."
if command -v pkexec >/dev/null 2>&1 && [ -n "$DISPLAY$WAYLAND_DISPLAY" ]; then
  pkexec /usr/bin/python3 "$D/onarim.py" --bellek "$D" --bekleme
  kod=$?
  if [ $kod -eq 126 ] || [ $kod -eq 127 ]; then
    echo
    echo "  Yönetici izni verilmedi. Şifre penceresinde etapadmin kullanıcısını seçip şifresini girin."
    echo "  Olmazsa bu klasörde Uçbirim açıp şunu yazın:  su etapadmin -c 'sudo bash tahta-onar.sh'"
  fi
  read -r -p "  Pencereyi kapatmak için Enter'a basın…" _
  exit $kod
fi
if id -nG | grep -qwE 'sudo|wheel'; then
  exec sudo -p "  $(whoami) şifresi: " /usr/bin/python3 "$D/onarim.py" --bellek "$D"
fi
echo "  Bu kullanıcının yönetici yetkisi yok. Şunu yazın:  su etapadmin -c 'sudo bash $D/tahta-onar.sh'"
"""
LINUX_DESKTOP = ("[Desktop Entry]\nType=Application\nName=TahtaOnar\nName[tr]=Tahta Onar\n"
                 "Comment=Tahta Yönetim Asistanı — tahtayı tanıla, onar, programı kur\nIcon=utilities-terminal\n"
                 'Exec=sh -c "cd \\\\"\\\\$(dirname \\\\"\\\\$1\\\\")/TahtaOnarim\\\\" && (x-terminal-emulator -e bash tahta-onar.sh || '
                 'gnome-terminal -- bash tahta-onar.sh || xterm -e bash tahta-onar.sh)" sh %k\nTerminal=false\n')
WIN_BASLAT = "\r\n".join([
    "@echo off", "chcp 65001 >nul", "title Tahta Yonetim - Tahta Onarim Bellegi",
    "net session >nul 2>&1",
    "if errorlevel 1 (",
    "  powershell -NoProfile -Command \"Start-Process -FilePath '%~f0' -Verb RunAs\"",
    "  exit /b",
    ")",
    "powershell -NoProfile -ExecutionPolicy Bypass -File \"%~dp0TahtaOnarim\\onarim.ps1\" -Bellek \"%~dp0TahtaOnarim\"",
    "echo.", "pause", ""])
BELLEK_OKUBENI = """TAHTA ONARIM BELLEĞİ — {okul}
Hazırlanma: {tarih} · Geçerlilik: {bitis} tarihine kadar

Programa bağlanmayan ya da sorunlu bir tahtayı yerinde tanılar, onarır ve gerekirse Tahta Yönetim
Asistanı'nı kurar. Bellekte hiçbir şifre yoktur. Bellek kaybolursa panelden iptal edin.

PARDUS / ETAP TAHTADA
  1. Belleği tahtaya takın.
  2. Bellekteki "TahtaOnar" simgesine çift tıklayın. "Güvenilmeyen başlatıcı" uyarısı çıkarsa
     "Yine de başlat"ı seçin. Tahta yöneticisinin (etapadmin) şifresi bir kez istenir.
     Simge açılmazsa: bellekteki TahtaOnarim klasörünü açın, boş bir yere sağ tıklayıp
     "Uçbirimde aç"ı seçin ve şunu yazın:   bash tahta-onar.sh
  3. Tahta incelenir, sorunlar listelenir; "onarılsın mı?" sorusuna Enter ile onay verin.
  4. Tahta programı kurulu değilse ya da bozuksa kurulması önerilir.

WINDOWS TAHTADA
  Bellekteki TahtaOnar.bat dosyasına çift tıklayın, yönetici iznini onaylayın.

RAPORLAR
  Her tahtanın raporu bellekteki TahtaOnarim\\raporlar klasörüne yazılır ve yönetim bilgisayarına
  ulaşılabiliyorsa panele de gönderilir. Ağa hiç bağlanamayan tahtaların raporu için belleği
  yönetim bilgisayarına takıp panelde Tahta Sağlığı › Onarım raporlarını içe al'a basın.

Onarımın değiştirdiği her ayarın yedeği alınır; kişisel dosyalara dokunulmaz.
Tahta açılmıyorsa ya da arıza donanımdaysa (ekran, dokunmatik çerçeve, anakart) bellek çözemez.
"""


def onarim_dosyalari(belirtec, bellek, adresler):
    """Belleğe yazılacak dosyalar: {göreli yol: bayt}"""
    m = onarim_modulu()
    sert = db.ayar("ag_sertifika") or {}
    ayar = {"surum": SURUM, "id": bellek["id"], "belirtec": belirtec, "okul_adi": db.ayar("okul_adi") or "",
            "sunucular": ["http://{}:{}".format(a, PORT) for a in adresler], "bitis": bellek["bitis"],
            "olusturma": bellek["olusturma"], "sertifika": sert.get("pem") or "", "ajan_surum": AJAN_SURUM}
    tarih = lambda t: datetime.fromtimestamp(t).strftime("%d.%m.%Y")
    okubeni = BELLEK_OKUBENI.format(okul=ayar["okul_adi"], tarih=tarih(bellek["olusturma"]), bitis=tarih(bellek["bitis"]))
    return {
        "TahtaOnarim/ayar.json": json.dumps(ayar, ensure_ascii=False, indent=1).encode("utf-8"),
        "TahtaOnarim/onarim.py": ONARIM_MODUL.read_bytes(),
        "TahtaOnarim/tahta-onar.sh": LINUX_BASLAT.encode("utf-8"),
        "TahtaOnarim/onarim.ps1": b"\xef\xbb\xbf" + m.win_bellek_betigi().replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8"),
        "TahtaOnarim/raporlar/.bos": b"",
        "TahtaOnar.desktop": LINUX_DESKTOP.encode("utf-8"),
        "TahtaOnar.bat": WIN_BASLAT.encode("utf-8"),
        "OKUBENI.txt": okubeni.replace("\n", "\r\n").encode("utf-8"),
    }


def onarim_rapor_al(rapor, kaynak="bellek"):
    """Bellekten gelen raporu kaydeder; tahtayı kimliğinden ya da ağ kartından bulur. Döner: tahta kimliği."""
    if not isinstance(rapor, dict) or not isinstance(rapor.get("bulgular"), list):
        raise Hata("Rapor dosyası tanınmadı")
    cihaz = rapor.get("cihaz") or {}
    macler = {str(x).lower() for x in cihaz.get("macler") or []}
    tid = None
    kimlik = str(cihaz.get("kimlik") or "")
    if kimlik and db.bir("SELECT id FROM tahta WHERE id=?", (kimlik,)):
        tid = kimlik
    if not tid and macler:
        for r in db.q("SELECT id, bilgi FROM tahta"):
            if (json.loads(r["bilgi"] or "{}").get("mac") or "").lower() in macler:
                tid = r["id"]
                break
    if not tid:
        tid = "bellek:" + re.sub(r"[^\w.\-]+", "_", str(cihaz.get("hostname") or "tahta"))[:40] + ":" + (sorted(macler)[0] if macler else "")
    veri = {"tur": "bellek", "bulgular": rapor.get("bulgular_sonra") or rapor["bulgular"], "ilk_bulgular": rapor["bulgular"],
            "sonuclar": rapor.get("onarimlar") or [], "kurulum": rapor.get("kurulum"), "cihaz": cihaz,
            "platform": rapor.get("platform") or "linux", "zaman": rapor.get("zaman"), "surum": rapor.get("surum")}
    zaman = float(rapor.get("zaman") or simdi())
    if db.bir("SELECT id FROM tani WHERE tahta=? AND kaynak=? AND ABS(zaman - ?) < 1", (tid, kaynak, zaman)):
        return tid, False                           # aynı rapor ikinci kez içe alınmaz
    tani_kaydet(tid, kaynak, veri)
    db.x("UPDATE tani SET zaman=? WHERE id=(SELECT MAX(id) FROM tani WHERE tahta=?)", (zaman, tid))
    return tid, True


def ssh_cihaz_turu(surum):
    """SSH sürüm satırından cihazın ne olabileceğini tahmin eder (yalnızca bilgi amaçlı)."""
    yazilim = re.sub(r"^SSH-[\d.]+-", "", surum or "").strip()
    k = yazilim.lower()
    if not yazilim.strip("-_ "):
        return "Yazılım adını gizliyor (modem, kamera, kayıt cihazı vb.)"
    for anahtar, ad in (("huawei", "Huawei ağ cihazı (switch / erişim noktası)"), ("cisco", "Cisco ağ cihazı"),
                        ("rosssh", "MikroTik ağ cihazı"), ("comware", "H3C / HPE ağ cihazı"), ("zte", "ZTE ağ cihazı"),
                        ("dropbear", "Gömülü cihaz (modem, kamera, NAS vb.)"), ("romsshell", "Gömülü cihaz (modem vb.)"),
                        ("lancom", "LANCOM ağ cihazı"), ("ubuntu", "Ubuntu bilgisayar"), ("raspbian", "Raspberry Pi"),
                        ("windows", "Windows bilgisayar"), ("freebsd", "FreeBSD cihaz"), ("mpssh", "Ağ cihazı"),
                        ("hikvision", "Hikvision kamera / kayıt cihazı"), ("dahua", "Dahua kamera / kayıt cihazı")):
        if anahtar in k:
            return ad
    return "Pardus olmayan cihaz"


def _kurulum_adresi(ip):
    """Tahtanın ulaşacağı yönetim bilgisayarı adresi: tahtayla aynı ağdaki yerel adres."""
    adresler = yerel_adresler()
    onek = ip.rsplit(".", 1)[0] + "."
    for a in adresler:
        if a.startswith(onek):
            return a
    return adresler[0] if adresler else ip


def ag_kur_is(kullanici, sifre):
    import ssh_mini
    from concurrent.futures import ThreadPoolExecutor
    k = AG_IS["kurulum"]

    def kur(t):
        t["durum"], t["mesaj"] = "baglaniyor", "Bağlanılıyor…"
        s = ssh_mini.SSH(t["ip"], 22, 15)
        try:
            kim = s.baglan()
            if kim["parmak_izi"] != t["parmak_izi"]:
                raise ssh_mini.SSHHata("Tahta kimliği taramadakinden farklı; şifre gönderilmedi")
            t["mesaj"] = "Giriş yapılıyor…"
            s.giris(kullanici, sifre)
            t["durum"], t["mesaj"] = "kuruluyor", "Kuruluyor…"
            adres = "http://{}:{}/k".format(_kurulum_adresi(t["ip"]), PORT) + ("?ad=" + quote(t["ad"]) if t.get("ad") else "")
            ic = ("( command -v wget >/dev/null && wget -T 20 -qO- '{0}' || curl -fsS --max-time 20 '{0}' ) | bash".format(adres))
            komut = "sudo -S -p '' bash -c \"{}\" 2>&1".format(ic.replace('"', '\\"'))
            kod, out, err = s.calistir(komut, girdi=(sifre + "\n").encode("utf-8"), zaman=900)
            metin = ANSI.sub("", (out + err).decode("utf-8", "replace"))
            if "KURULUM TAMAMLANDI" in metin:
                t["durum"], t["mesaj"] = "tamam", "Kuruldu; tahta birkaç saniye içinde listede görünür"
                return
            satirlar = [x.strip() for x in metin.splitlines() if x.strip()]
            hata = next((x.lstrip("✗ ").strip() for x in reversed(satirlar) if x.startswith("✗")), None)
            if "not in the sudoers" in metin or "sudoers dosyasında değil" in metin:
                hata = "{} kullanıcısının yönetici (sudo) yetkisi yok".format(kullanici)
            elif "incorrect password" in metin.lower() or "yanlış parola" in metin.lower():
                hata = "sudo şifresi kabul edilmedi"
            elif not hata and not metin.strip():
                hata = "Tahta yönetim bilgisayarından kurulum dosyasını indiremedi ({}). Güvenlik duvarını kontrol edin.".format(adres)
            t["durum"], t["mesaj"] = "hata", (hata or (satirlar[-1] if satirlar else "Kurulum tamamlanamadı"))[:300]
        except ssh_mini.GirisHatasi as e:
            t["durum"], t["mesaj"] = "hata", str(e)
        except Exception as e:
            t["durum"], t["mesaj"] = "hata", str(e)[:300]
        finally:
            s.kapat()
    try:
        with ThreadPoolExecutor(max_workers=6) as hav:
            list(hav.map(kur, k["tahtalar"]))
    finally:
        sifre = None
        k["durum"] = "bitti"
        n = sum(1 for t in k["tahtalar"] if t["durum"] == "tamam")
        olay("", "sistem", "Ağdan toplu kurulum bitti: {} kuruldu, {} hata".format(n, len(k["tahtalar"]) - n))


# ─────────────────────────────────────────────────────────────────────────────
# HTTP sunucu
# ─────────────────────────────────────────────────────────────────────────────

giris_denemeleri = {}


class Hata(Exception):
    def __init__(self, mesaj, kod=400):
        Exception.__init__(self, mesaj)
        self.kod = kod


class Isleyici(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "TahtaYonetim/" + SURUM
    sys_version = ""

    # ── altyapı ──────────────────────────────────────────────────────────────
    def log_message(self, fmt, *args):
        log.debug("%s %s", self.client_address[0], fmt % args)

    def yanit(self, govde, kod=200, mime="application/json; charset=utf-8", basliklar=None):
        if isinstance(govde, (dict, list)):
            govde = json.dumps(govde, ensure_ascii=False).encode("utf-8")
        elif isinstance(govde, str):
            govde = govde.encode("utf-8")
        self.send_response(kod)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(govde)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (basliklar or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(govde)

    def json_oku(self, sinir=2 * 1024 * 1024):
        n = int(self.headers.get("Content-Length") or 0)
        if n > sinir:
            raise Hata("İstek çok büyük", 413)
        ham = self.rfile.read(n) if n else b"{}"
        try:
            return json.loads(ham.decode("utf-8") or "{}")
        except Exception:
            raise Hata("Geçersiz veri")

    def ham_oku(self, sinir):
        n = int(self.headers.get("Content-Length") or 0)
        if n > sinir:
            raise Hata("Dosya çok büyük", 413)
        return self.rfile.read(n)

    def cerez(self, ad="tys"):
        ham = self.headers.get("Cookie") or ""
        for parca in ham.split(";"):
            if "=" in parca:
                k, v = parca.strip().split("=", 1)
                if k == ad:
                    return v
        return None

    def oturum_bul(self, cerez, tur):
        b = self.cerez(cerez)
        if not b:
            return None
        h = hashlib.sha256(b.encode()).hexdigest()
        r = db.bir("SELECT bitis, ad, kim FROM oturum WHERE belirtec=? AND COALESCE(tur, 'yonetici')=?", (h, tur))
        return r if (r and r["bitis"] > simdi()) else None

    def oturum_var(self):
        return bool(self.oturum_bul("tys", "yonetici"))

    def yonetici(self):
        """Oturumu açık yöneticinin {"id", "ad", "ana"} bilgisi. Eski (kimliksiz) oturumlar ana yöneticidir."""
        r = self.oturum_bul("tys", "yonetici")
        if not r:
            return None
        kim = r.get("kim") or "ana"
        if kim == "ana":
            return {"id": "ana", "ad": ANA_YONETICI, "ana": True}
        for y in db.ayar("yoneticiler") or []:
            if y["id"] == kim:
                return {"id": kim, "ad": y["ad"], "ana": False}
        return {"id": kim, "ad": r.get("ad") or "Yönetici", "ana": False}

    def ogretmen(self):
        """Ortak Klasör sayfası için (ad, yönetici mi) döner; giriş yoksa None."""
        r = self.oturum_bul("tyso", "ogretmen")
        if r:
            return {"ad": r["ad"] or "Öğretmen", "yonetici": False}
        y = self.yonetici()
        if y:
            return {"ad": y["ad"], "yonetici": True}
        return None

    def ajan_dogrula(self):
        anahtar = self.headers.get("X-Anahtar") or ""
        if anahtar and hmac.compare_digest(anahtar, db.ayar("anahtar")):
            return "tahta"
        ia = db.ayar("istemci_anahtar") or ""
        if anahtar and ia and hmac.compare_digest(anahtar, ia):
            return "istemci"
        raise Hata("Yetkisiz", 401)

    def dosya_gonder(self, p, ad=None, satir_ici=False, ek=None, mime="application/octet-stream"):
        boyut = p.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(boyut))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if ad:
            self.send_header("Content-Disposition", "{}; filename*=UTF-8''{}".format(
                "inline" if satir_ici else "attachment", quote(ad)))
        for k, v in (ek or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(str(p), "rb") as f:
            while True:
                parca = f.read(256 * 1024)
                if not parca:
                    break
                self.wfile.write(parca)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.yonlendir("GET")

    def do_POST(self):
        self.yonlendir("POST")

    def yonlendir(self, yontem):
        try:
            u = urlparse(self.path)
            self.sorgu = {k: v[0] for k, v in parse_qs(u.query).items()}
            yol = u.path.rstrip("/") or "/"
            # Yedek bilgisayar pasifken yalnızca sağlık ve yedekleme istekleri yanıtlanır
            if not dugum.aktif() and yol != "/api/saglik" and not yol.startswith("/api/y/"):
                return self.bekleme(yontem, yol)
            # Statik ve kurulum
            if yontem == "GET":
                if yol in ("/", "/index.html"):
                    return self.statik("index.html")
                if yol in ("/manifest.webmanifest", "/ikon-192.png", "/ikon-512.png"):
                    return self.statik(yol[1:])
                if yol == "/ortak":
                    return self.statik("ortak.html")
                if yol == "/kilavuz":
                    k = WEB / "kilavuz.html"
                    if not k.is_file():
                        k = PROGRAM.parent / "KURULUM_KILAVUZU.html"
                    if not k.is_file():
                        raise Hata("Kılavuz bulunamadı", 404)
                    return self.yanit(k.read_bytes(), mime="text/html; charset=utf-8",
                                      basliklar={"X-Frame-Options": "SAMEORIGIN", "Referrer-Policy": "no-referrer",
                                                 "Cache-Control": "private, max-age=3600"})
                if yol in ("/k", "/kur"):
                    return self.kurulum_betigi(self.headers.get("Host"), ad=self.sorgu.get("ad", ""))
                if yol in ("/w", "/kw"):
                    return self.windows_kurulum(self.headers.get("Host"), ad=self.sorgu.get("ad", ""))
                if yol == "/kaldir":
                    return self.yanit(KALDIR_SABLON.read_bytes(), mime="text/plain; charset=utf-8")
                if yol == "/tani":
                    return self.tani_betigi(self.headers.get("Host"))
                if yol == "/api/saglik":
                    return self.yanit(dugum.saglik(self.headers.get("Host")))
            # Yedek yönetim bilgisayarları arası haberleşme
            if yol.startswith("/onarim/"):
                return self.onarim_genel(yontem, yol[len("/onarim/"):])
            if yol.startswith("/api/y/"):
                fonk = getattr(self, "y_" + yol[len("/api/y/"):].replace("-", "_").replace("/", "__"), None)
                if fonk is None:
                    raise Hata("Bulunamadı", 404)
                return fonk(yontem)
            # Ajan API
            if yol.startswith("/api/a/"):
                rol = self.ajan_dogrula()
                ad = yol[len("/api/a/"):]
                if rol == "istemci" and ad not in ("kod", "istemci") and not ad.startswith("ortak/"):
                    raise Hata("Yetkisiz", 403)
                if ad.startswith("ortak/"):
                    return self.a_ortak(ad[6:], yontem, rol)
                if yontem == "POST" and ad == "istemci":
                    return self.yanit(self.a_istemci(self.json_oku()))
                if yontem == "POST" and ad == "ariza":
                    return self.yanit(self.a_ariza(self.json_oku()))
                if yontem == "POST" and ad == "tani":
                    if rol != "tahta":
                        raise Hata("Yetkisiz", 403)
                    return self.a_tani()
                if yontem == "GET" and ad == "moduller":
                    return self.yanit(self.a_moduller())
                if yontem == "GET" and ad.startswith("depo/"):
                    return self.a_depo(ad[5:])
                if yontem == "POST" and ad in ("politika", "yazici", "yazici-is", "envanter", "saglik"):
                    if rol != "tahta":
                        raise Hata("Yetkisiz", 403)
                    return self.yanit(getattr(self, "a_" + ad.replace("-", "_"))(self.json_oku()))
                if yontem == "POST" and ad == "usb":
                    if rol != "tahta":
                        raise Hata("Yetkisiz", 403)
                    return self.yanit(self.a_usb(self.json_oku()))
                if yontem == "POST" and ad == "senk":
                    return self.yanit(self.a_senk(self.json_oku()))
                if yontem == "POST" and ad == "olay":
                    return self.yanit(self.a_olay(self.json_oku()))
                if yontem == "POST" and ad == "ekran":
                    return self.yanit(self.a_ekran())
                if yontem == "GET" and ad == "kod":
                    return self.yanit(AJAN_DOSYA.read_bytes(), mime="text/x-python; charset=utf-8")
                if yontem == "GET" and ad.startswith("dosya/"):
                    return self.a_dosya(ad[6:])
                if yontem == "GET" and ad.startswith("ses/"):
                    return self.a_ses(ad[4:])
                raise Hata("Bulunamadı", 404)
            # Ortak Klasör web sayfası (öğretmen şifresi veya yönetici oturumu)
            if yol.startswith("/api/o/"):
                ad = yol[len("/api/o/"):]
                self.kullanici = self.ogretmen()
                if ad not in ("giris", "bilgi", "istemci-anahtar", "tahta-anahtar") and not self.kullanici:
                    raise Hata("Giriş yapmanız gerekiyor", 401)
                fonk = getattr(self, "o_" + ad.replace("-", "_").replace(".", "_"), None)
                if fonk is None:
                    raise Hata("Bulunamadı", 404)
                return fonk(yontem)
            # Panel API
            if yol.startswith("/api/p/"):
                ad = yol[len("/api/p/"):]
                acik = {"baslangic", "kurulum", "giris"}
                if ad not in acik and not self.oturum_var():
                    raise Hata("Oturum açmanız gerekiyor", 401)
                fonk = getattr(self, "p_" + ad.replace("-", "_").replace("/", "__").replace(".", "_"), None)
                if fonk is None:
                    raise Hata("Bulunamadı", 404)
                return fonk(yontem)
            raise Hata("Bulunamadı", 404)
        except (Hata, ortak_mod.OrtakHata) as h:
            if yontem == "POST":
                self.close_connection = True
            try:
                self.yanit({"hata": str(h)}, kod=h.kod)
            except Exception:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as e:
            log.exception("istek hatası: %s", self.path)
            try:
                self.yanit({"hata": "Sunucu hatası: {}".format(e)}, kod=500)
            except Exception:
                pass

    def statik(self, ad):
        yol = WEB / ad
        if not yol.is_file():
            raise Hata("Bulunamadı", 404)
        mime = {"html": "text/html; charset=utf-8", "png": "image/png",
                "webmanifest": "application/manifest+json"}.get(ad.rsplit(".", 1)[-1], "application/octet-stream")
        ek = {"X-Frame-Options": "SAMEORIGIN" if ad == "ortak.html" else "DENY", "Referrer-Policy": "no-referrer"}
        self.yanit(yol.read_bytes(), mime=mime, basliklar=ek)

    def kurulum_betigi(self, host, ek=None, ad=""):
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        metin = KUR_SABLON.read_text(encoding="utf-8")
        metin = (metin.replace("__SUNUCU__", "http://" + host)
                 .replace("__ANAHTAR__", db.ayar("anahtar"))
                 .replace("__KIMLIK__", db.ayar("kimlik"))
                 .replace("__ADRESLER__", " ".join(yerel_adresler()))
                 .replace("__TAHTA_AD__", tahta_adi_temizle(ad)))
        self.yanit(metin.encode("utf-8"), mime="text/plain; charset=utf-8", basliklar=ek)

    def windows_kurulum(self, host, ad=""):
        """Windows tahta kurulum dosyası (.bat içine gömülü PowerShell betiği)."""
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if host.split(":")[0] in ("localhost", "127.0.0.1"):
            host = "{}:{}".format((yerel_adresler() or ["127.0.0.1"])[0], PORT)
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        ad = tahta_adi_temizle(ad)
        ps = KUR_PS1.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        bat = (TAHTA_BAT.replace("__SUNUCU__", "http://" + host).replace("__ANAHTAR__", db.ayar("anahtar"))
               .replace("__KIMLIK__", db.ayar("kimlik")).replace("__AD__", ad.replace('"', "").replace("%", ""))
               + "#TYS-PS1#\n" + ps).replace("\n", "\r\n")
        dosya = "TahtaKurulum{}.bat".format("-" + re.sub(r"[^A-Za-z0-9\-]+", "_", ad).strip("_") if ad else "")
        self.yanit(bat.encode("utf-8"), mime="application/octet-stream", basliklar={
            "Content-Disposition": "attachment; filename=" + dosya})

    def tani_betigi(self, host):
        host = (host or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        metin = (TANI_SABLON.read_text(encoding="utf-8").replace("__SUNUCU__", "http://" + host)
                 .replace("__ANAHTAR__", db.ayar("anahtar")))
        self.yanit(metin.encode("utf-8"), mime="text/plain; charset=utf-8")

    def a_tani(self):
        """Tahtadan gelen tanı raporunu saklar (son 30 rapor)."""
        veri = self.ham_oku(300 * 1024)
        ip = self.client_address[0]
        ad = None
        for r in db.q("SELECT ad, bilgi FROM tahta"):
            if (json.loads(r["bilgi"] or "{}").get("ip") or "") == ip:
                ad = r["ad"]
                break
        if not ad:
            from urllib.parse import unquote
            ad = unquote(self.headers.get("X-Cihaz-Ad") or "") or ip
        klasor = VERI / "tani"
        klasor.mkdir(exist_ok=True)
        guvenli = re.sub(r"[^\w.\-]+", "_", ad)[:40] or "tahta"
        (klasor / "{}-{}.txt".format(datetime.now().strftime("%Y%m%d-%H%M%S"), guvenli)).write_bytes(
            "Tahta: {} ({})\n".format(ad, ip).encode("utf-8") + veri)
        for eski in sorted(klasor.glob("*.txt"))[:-30]:
            try:
                eski.unlink()
            except OSError:
                pass
        olay(None, "sistem", "{} tahtasından tanı raporu geldi".format(ad))
        self.yanit({"ok": True})

    # ── ajan uçları ──────────────────────────────────────────────────────────
    def a_senk(self, g):
        tid = str(g.get("id") or "")
        if not re.match(r"^[A-Za-z0-9\-]{6,64}$", tid):
            raise Hata("Geçersiz kimlik")
        d = g.get("durum") or {}
        n = simdi()
        if tid in silinenler:
            bek = db.q("SELECT * FROM bekleyen WHERE tahta=? AND tur='kaldir'", (tid,))
            db.x("DELETE FROM bekleyen WHERE tahta=?", (tid,))
            return {"komutlar": [{"id": r["id"], "tur": "kaldir", "veri": {}} for r in bek],
                    "sunucu_zaman": n, "utc_ofset": utc_ofset()}
        if d.get("zaman"):
            d["zaman_farki"] = float(d["zaman"]) - n
        c = canli_al(tid)
        with c.kosul:
            c.nesil += 1
            nesil = c.nesil
            ilk = not c.cevrimici
            c.durum = d
            c.son = n
            c.bekliyor = True
            c.cevrimici = True
        r = db.bir("SELECT id, bilgi FROM tahta WHERE id=?", (tid,))
        bilgi = {k: d.get(k) for k in ("ip", "mac", "hostname", "os", "surum")}
        kimlik_mac_kaydet(tid, d.get("mac"))
        kurulum_ad = tahta_adi_temizle(d.get("kurulum_ad") or "")
        if kurulum_ad:
            bilgi["kurulum_ad"] = kurulum_ad
        if bilgi.get("ip") is None:
            bilgi["ip"] = self.client_address[0]
        if r is None:
            ad = (kurulum_ad or d.get("hostname") or "Tahta")[:60]
            db.x("INSERT INTO tahta(id, ad, grup, bilgi, eklenme, son) VALUES(?,?,?,?,?,?)",
                 (tid, ad, "", json.dumps(bilgi), n, n))
            olay(tid, "sistem", "Yeni tahta bağlandı ({})".format(bilgi.get("ip")))
        else:
            eski = json.loads(r["bilgi"] or "{}")
            if eski.get("mac") and not bilgi.get("mac"):
                bilgi["mac"] = eski["mac"]
            if kurulum_ad and kurulum_ad != eski.get("kurulum_ad"):
                # Kurulum komutunda yeni bir ad verildi (yeniden kurulum); paneldeki adı günceller.
                db.x("UPDATE tahta SET ad=? WHERE id=?", (kurulum_ad, tid))
                olay(tid, "sistem", "Tahta adı kurulumda verildi: {}".format(kurulum_ad))
            if eski != bilgi:
                db.x("UPDATE tahta SET bilgi=?, son=? WHERE id=?", (json.dumps(bilgi), n, tid))
            else:
                db.x("UPDATE tahta SET son=? WHERE id=?", (n, tid))
            if ilk and n - BASLAMA > 60:
                olay(tid, "baglanti", "Açıldı")
        for s in g.get("sonuclar") or []:
            if not s.get("ok"):
                olay(tid, "hata", "{}: {}".format(KOMUT_ADI.get(s.get("tur"), s.get("tur")), s.get("mesaj", "")))
        bitis = n + (0 if g.get("hemen") else SENK_BEKLEME)
        komutlar = []
        ayar = surum = None
        with c.kosul:
            while True:
                if c.nesil != nesil:
                    break
                komutlar = komutlari_al(c)
                ayar, surum = ajan_ayari(tid)
                kalan = bitis - simdi()
                if komutlar or surum != g.get("ayar_surum") or kalan <= 0:
                    break
                c.kosul.wait(timeout=kalan)
            if c.nesil == nesil:
                c.bekliyor = False
                c.son = simdi()
        cevap = {"komutlar": komutlar, "sunucu_zaman": simdi(), "utc_ofset": utc_ofset(),
                 "ajan_surum": AJAN_SURUM, "ayar_surum": surum,
                 "sunucular": dugum.sunucular(self.headers.get("Host"))}
        if surum != g.get("ayar_surum"):
            cevap["ayar"] = ayar
        return cevap

    def a_moduller(self):
        """Ajan modülleri (eksik ya da eski sürümse tahta buradan tamamlar)."""
        dosyalar = {}
        for p in sorted((AJAN_DOSYA.parent / "moduller").glob("*.py")):
            dosyalar[p.name] = p.read_text(encoding="utf-8")
        return {"surum": SURUM, "dosyalar": dosyalar}

    def a_depo(self, sha):
        """Depodaki dosyayı verir; kaldığı yerden devam (Range) ve eşzamanlılık sınırı vardır."""
        yol = depo_yolu(sha)
        if not yol.is_file():
            raise Hata("Dosya depoda yok", 404)
        if not DEPO_INDIRME.acquire(timeout=2):
            return self.yanit({"hata": "Meşgul, birazdan tekrar deneyin"}, 503, basliklar={"Retry-After": "20"})
        try:
            boyut = yol.stat().st_size
            bas = 0
            m = re.match(r"bytes=(\d+)-", self.headers.get("Range") or "")
            if m and int(m.group(1)) < boyut:
                bas = int(m.group(1))
            self.send_response(206 if bas else 200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(boyut - bas))
            if bas:
                self.send_header("Content-Range", "bytes {}-{}/{}".format(bas, boyut - 1, boyut))
            self.end_headers()
            with open(yol, "rb") as f:
                f.seek(bas)
                while True:
                    parca = f.read(256 * 1024)
                    if not parca:
                        break
                    self.wfile.write(parca)
        finally:
            DEPO_INDIRME.release()

    def a_politika(self, g):
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Geçersiz")
        for d in (g.get("durumlar") or [])[:200]:
            pid = str(d.get("politika") or "")[:20]
            p = db.bir("SELECT * FROM politika WHERE id=?", (pid,))
            durum = d.get("durum") if d.get("durum") in POLITIKA_DURUMLARI else "hata"
            if not p:
                continue
            ayrinti = str(d.get("ayrinti") or "")[:2000]
            sonuc = d.get("sonuc") if isinstance(d.get("sonuc"), dict) else {}
            if durum == "kaldirildi":
                db.x("DELETE FROM politika_durum WHERE politika=? AND tahta=?", (pid, tid))
            else:
                db.x("INSERT OR REPLACE INTO politika_durum(politika, tahta, durum, ayrinti, sonuc, zaman) VALUES(?,?,?,?,?,?)",
                     (pid, tid, durum, ayrinti, json.dumps(sonuc, ensure_ascii=False), float(d.get("zaman") or simdi())))
            onceki = d.get("onceki")
            if durum in ("tamam", "hata") and onceki != durum:
                olay(tid, "hata" if durum == "hata" else "politika", "{} — {}{}".format(
                    p["ad"], "tamamlandı" if durum == "tamam" else "hata", (": " + ayrinti[:200]) if ayrinti else ""))
            if p["modul"] == "yazici" and p["tur"] in ("kur", "uzak") and durum in ("tamam", "hata") and sonuc.get("model"):
                calisti = durum == "tamam" and sonuc.get("test") != "hata"
                db.x("INSERT OR REPLACE INTO yazici_model(model, platform, sonuc, yontem, surucu, ayrinti, zaman, tahta) "
                     "VALUES(?,?,?,?,?,?,?,?)", (sonuc["model"][:120], str(sonuc.get("platform") or "")[:10],
                                                 "calisiyor" if calisti else "calismiyor", str(sonuc.get("yontem") or "")[:200],
                                                 json.dumps(json.loads(p["veri"]).get("surucu") or {}, ensure_ascii=False),
                                                 ayrinti[:500], simdi(), tid))
        return {"ok": True}

    def a_yazici(self, g):
        tid = str(g.get("id") or "")
        t = db.bir("SELECT id, ad FROM tahta WHERE id=?", (tid,))
        if not t:
            raise Hata("Geçersiz")
        n = simdi()
        platform_ = "windows" if g.get("platform") == "windows" else "linux"
        gorulen, yeni_bildirim = set(), []
        for y in (g.get("yazicilar") or [])[:20]:
            anahtar = re.sub(r"[^\w:.\-&]", "", str(y.get("anahtar") or ""))[:120]
            if not anahtar:
                continue
            y["anahtar"] = anahtar
            v = {k: (str(y.get(k))[:300] if y.get(k) is not None else None)
                 for k in ("marka", "model", "aygit_id", "vidpid", "seri", "kuyruk", "port", "uri")}
            v.update(kurulu=bool(y.get("kurulu")), platform=platform_, durum=str(y.get("durum") or "")[:200])
            eski = db.bir("SELECT * FROM yazici WHERE tahta=? AND anahtar=?", (tid, anahtar))
            db.x("INSERT OR REPLACE INTO yazici(tahta, anahtar, veri, ilk, son, takili) VALUES(?,?,?,?,?,1)",
                 (tid, anahtar, json.dumps(v, ensure_ascii=False), eski["ilk"] if eski else n, n))
            gorulen.add(anahtar)
            if not eski or not eski["takili"]:
                v["anahtar"] = anahtar
                oto = yazici_otomatik(tid, v, platform_)
                if not v["kurulu"]:
                    olay(tid, "yazici", "{}: {} takıldı{}".format(
                        t["ad"], yazici_model_anahtar(v), ", otomatik kuruluyor" if oto else ", sürücü yok — panelden kurulabilir"))
                    if not oto:
                        yeni_bildirim.append(anahtar)
        for r in db.q("SELECT anahtar FROM yazici WHERE tahta=? AND takili=1", (tid,)):
            if r["anahtar"] not in gorulen:
                db.x("UPDATE yazici SET takili=0 WHERE tahta=? AND anahtar=?", (tid, r["anahtar"]))
        if "kuyruklar" in g:
            db.ayar_yaz("yazici_kuyruk_" + tid, {"zaman": n, "platform": platform_, "liste": (g.get("kuyruklar") or [])[:30]})
        return {"ok": True, "bildir": yeni_bildirim}

    def a_yazici_is(self, g):
        """Paylaşılan yazıcılardan çıktı kaydı (yönetici açtıysa)."""
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Geçersiz")
        if not (db.ayar("yazici_ayar") or {}).get("kayit"):
            return {"ok": True}
        ipler = {}
        for t in db.q("SELECT id, ad, bilgi FROM tahta"):
            ip = json.loads(t["bilgi"] or "{}").get("ip")
            if ip:
                ipler[ip] = t["ad"]
        for j in (g.get("isler") or [])[:200]:
            ip = str(j.get("ip") or "")[:60]
            db.x("INSERT INTO yazici_is(zaman, tahta, kuyruk, paylasim, ip, istemci, ad, kullanici, sayfa, boyut, yontem, sonuc, hata) "
                 "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (float(j.get("zaman") or simdi()), tid, str(j.get("kuyruk") or "")[:120], str(j.get("paylasim") or "")[:20], ip,
                  ipler.get(ip) or "", str(j.get("ad") or "")[:200], str(j.get("kullanici") or "")[:100],
                  int(j.get("sayfa") or 0), int(j.get("boyut") or 0), str(j.get("yontem") or "")[:10],
                  str(j.get("sonuc") or "")[:10], str(j.get("hata") or "")[:300]))
        db.x("DELETE FROM yazici_is WHERE zaman < ?", (simdi() - 180 * 86400,))
        return {"ok": True}

    def a_envanter(self, g):
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Geçersiz")
        e = g.get("envanter") or {}
        if not isinstance(e, dict):
            raise Hata("Geçersiz")
        e["zaman"] = simdi()
        for k in ("uygulamalar", "baslangic"):
            e[k] = (e.get(k) or [])[:800]
        db.ayar_yaz("envanter_" + tid, e)
        return {"ok": True}

    def a_usb(self, g):
        """Tahtadan gelen USB Koruma raporu (ya da geri alma sonucu)."""
        tid = str(g.get("id") or "")
        t = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
        o = g.get("olay") or {}
        oid = re.sub(r"[^0-9a-f]", "", str(o.get("id") or ""))[:16]
        if not t or not oid:
            raise Hata("Geçersiz rapor")
        if o.get("geri"):
            r = db.bir("SELECT veri FROM usb_olay WHERE id=?", (oid,))
            if r:
                v = json.loads(r["veri"])
                v["geri"] = {"zaman": simdi(), "tahta": tid, "sayi": int(o.get("geri_sayi") or 0),
                             "sorun": [str(x)[:200] for x in (o.get("sorun") or [])][:10]}
                db.x("UPDATE usb_olay SET veri=? WHERE id=?", (json.dumps(v, ensure_ascii=False), oid))
                olay(tid, "usb", "USB temizliği geri alındı ({} işlem{})".format(
                    v["geri"]["sayi"], ", sorunlu" if v["geri"]["sorun"] else ""))
            return {"ok": True}
        v = {k: o.get(k) for k in ("etiket", "seri", "fs", "mod", "sonuc", "mesaj", "makineler", "lnk", "karantina",
                                   "gizli_klasor", "kurtarilacak", "gizli_isaretli", "kurtarilan", "karantinada", "hatalar",
                                   "damga", "windows", "oznitelik_destek", "kural_surum")}
        v["makineler"] = [re.sub(r"[^\w.\-]", "", str(m))[:30] for m in (v.get("makineler") or [])][:10]
        metin = json.dumps(v, ensure_ascii=False)
        if len(metin) > 60000:
            v["lnk"], v["karantina"] = (v.get("lnk") or [])[:5], (v.get("karantina") or [])[:10]
            metin = json.dumps(v, ensure_ascii=False)
        sonuc = str(v.get("sonuc") or "")[:20]
        db.x("INSERT OR REPLACE INTO usb_olay(id, zaman, tahta, seri, sonuc, veri) VALUES(?,?,?,?,?,?)",
             (oid, float(o.get("zaman") or simdi()), tid, str(v.get("seri") or "")[:40], sonuc, metin))
        etiket = v.get("etiket") or "etiketsiz flash"
        if sonuc == "temizlendi":
            m = "USB: {} temizlendi — {} dosya kurtarıldı, {} şüpheli dosya karantinada".format(
                etiket, v.get("kurtarilan") or 0, v.get("karantinada") or 0)
        else:
            m = "USB: {} — kısayol virüsü bulundu, temizlenmedi ({})".format(
                etiket, {"uyari": "yalnızca uyarı", "esik": "şüpheli sayısı çok yüksek",
                         "salt_okunur": "flash yazmaya kapalı"}.get(sonuc, sonuc))
        if v["makineler"]:
            m += " · kaynak bilgisayar: " + ", ".join(v["makineler"][:3])
        olay(tid, "usb", m)
        return {"ok": True}

    def a_olay(self, g):
        tid = str(g.get("id") or "")
        c = canli.get(tid)
        if c and isinstance(g.get("durum"), dict):
            d = g["durum"]
            if d.get("zaman"):
                d["zaman_farki"] = float(d["zaman"]) - simdi()
            c.durum = d
            c.son = max(c.son, simdi()) if not c.bekliyor else c.son
        tur = g.get("tur")
        if tur == "komut_sonuc":
            v = g.get("veri") or {}
            if v.get("tur") in ("tanila", "onar") and isinstance(v.get("veri"), dict) and isinstance(v["veri"].get("bulgular"), list):
                tani_kaydet(tid, "panel", v["veri"])
            islem_sonuc(str(v.get("kid") or ""), bool(v.get("ok")), v.get("mesaj") or "", v.get("veri"))
            if not v.get("ok") and v.get("mesaj"):
                olay(tid, "hata", "{}: {}".format(KOMUT_ADI.get(v.get("tur"), v.get("tur")), v.get("mesaj")))
            return {"ok": True}
        if tur == "dosya_teslim":
            fid = (g.get("veri") or {}).get("fid")
            r = db.bir("SELECT teslim, ad FROM dosya WHERE id=?", (fid,))
            if r:
                teslim = json.loads(r["teslim"] or "[]")
                if tid not in teslim:
                    teslim.append(tid)
                    db.x("UPDATE dosya SET teslim=? WHERE id=?", (json.dumps(teslim), fid))
                olay(tid, "dosya", "Dosya teslim alındı: {}".format(r["ad"]))
        elif tur:
            olay(tid, tur, str(g.get("mesaj") or ""))
        return {"ok": True}

    def a_ekran(self):
        tid = self.sorgu.get("id", "")
        boyut = ekran_boyutu(self.sorgu.get("boyut"))
        veri = self.ham_oku(8 * 1024 * 1024)
        c = canli.get(tid)
        if c and len(veri) > 100:
            mime = "image/png" if veri[:4] == b"\x89PNG" else "image/jpeg"
            c.ekran[boyut] = (simdi(), mime, veri)
            if boyut != "kucuk" and "kucuk" not in c.ekran:
                c.ekran["kucuk"] = c.ekran[boyut]
        return {"ok": True}

    def a_dosya(self, fid):
        fid = re.sub(r"[^a-f0-9]", "", fid)
        r = db.bir("SELECT ad FROM dosya WHERE id=?", (fid,))
        if not r:
            raise Hata("Dosya bulunamadı", 404)
        yol = VERI / "dosyalar" / fid / guvenli_ad(r["ad"])
        if not yol.is_file():
            raise Hata("Dosya bulunamadı", 404)
        boyut = yol.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(boyut))
        self.end_headers()
        with open(yol, "rb") as f:
            while True:
                parca = f.read(256 * 1024)
                if not parca:
                    break
                self.wfile.write(parca)

    def a_ses(self, tur):
        if tur.startswith("k-"):
            x = next((x for x in db.ayar("zil_sesleri") or [] if x.get("id") == tur[2:]), None)
            yol = VERI / "sesler" / "k-{}.{}".format(x["id"], x["uzanti"]) if x else None
            if not yol or not yol.is_file():
                raise Hata("Ses yok", 404)
            return self.yanit(yol.read_bytes(), mime="application/octet-stream")
        bilgi = (db.ayar("zil_ozel") or {}).get(tur)
        if not bilgi:
            raise Hata("Ses yok", 404)
        yol = VERI / "sesler" / "{}.{}".format(tur, bilgi["uzanti"])
        if not yol.is_file():
            raise Hata("Ses yok", 404)
        self.yanit(yol.read_bytes(), mime="application/octet-stream")

    def a_ortak(self, ad, yontem, rol):
        cid = self.headers.get("X-Cihaz") or ""
        if rol == "tahta":
            r = db.bir("SELECT ad FROM tahta WHERE id=?", (cid,))
            isim, izin = (r["ad"] if r else "Tahta"), depo.ayar()["tahta_izin"]
        else:
            r = db.bir("SELECT ad FROM istemci WHERE id=?", (cid,))
            isim, izin = (r["ad"] if r else unquote(self.headers.get("X-Cihaz-Ad") or "Bilgisayar")), "tam"
        if ad == "liste":
            v = depo.liste(int(self.sorgu.get("rev") or 0))
            kullanilan, _ = depo.kullanilan()
            v.update(etkin=depo.etkin(), izin=izin, kota=depo.kota(), kullanilan=kullanilan)
            return self.yanit(v)
        if ad == "bekle":
            return self.yanit({"rev": depo.bekle(int(self.sorgu.get("rev") or 0), 25)})
        if ad == "indir":
            p, r = depo.indir_yolu(self.sorgu.get("yol") or "")
            return self.dosya_gonder(p, ek={"X-Rev": str(r["rev"]), "X-Ozet": r["ozet"], "X-Mtime": repr(r["mtime"])})
        if yontem != "POST":
            raise Hata("Geçersiz istek")
        if ad == "yukle":
            n = int(self.headers.get("Content-Length") or 0)
            return self.yanit(depo.yukle(unquote(self.headers.get("X-Yol") or ""), self.rfile, n, isim,
                                         temel=int(self.headers.get("X-Temel") or 0),
                                         mtime=float(self.headers.get("X-Mtime") or 0) or None, izin=izin))
        g = self.json_oku()
        if ad == "sil":
            return self.yanit(depo.sil(g.get("yol") or "", isim, int(g.get("temel") or 0), izin))
        if ad == "klasor":
            return self.yanit(depo.klasor(g.get("yol") or "", isim))
        raise Hata("Bulunamadı", 404)

    def a_istemci(self, g):
        iid = str(g.get("id") or "")
        if not re.match(r"^[A-Za-z0-9\-]{6,64}$", iid):
            raise Hata("Geçersiz kimlik")
        bilgi = {k: g.get(k) for k in ("kullanici", "surum", "os", "ortak", "klasor")}
        bilgi["ip"] = self.client_address[0]
        ad = (g.get("ad") or "Bilgisayar")[:60]
        if db.bir("SELECT id FROM istemci WHERE id=?", (iid,)):
            db.x("UPDATE istemci SET bilgi=?, son=? WHERE id=?", (json.dumps(bilgi), simdi(), iid))
        else:
            db.x("INSERT INTO istemci(id, ad, bilgi, son, eklenme) VALUES(?,?,?,?,?)", (iid, ad, json.dumps(bilgi), simdi(), simdi()))
            olay("", "ortak", "Yeni öğretmen bilgisayarı bağlandı: {}".format(ad))
        return {"ok": True, "ajan_surum": AJAN_SURUM, "sunucu_zaman": simdi(),
                "sunucular": dugum.sunucular(self.headers.get("Host"))}

    def a_ariza(self, g):
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Tahta bulunamadı", 404)
        kategori = g.get("kategori") if g.get("kategori") in ARIZA_TURLERI else "Diğer"
        aciklama = str(g.get("aciklama") or "").strip()[:500]
        bildiren = str(g.get("bildiren") or "").strip()[:60]
        zaman = float(g.get("zaman") or simdi())
        db.x("INSERT INTO ariza(tahta, kategori, aciklama, bildiren, zaman, durum, guncelleme) VALUES(?,?,?,?,?,?,?)",
             (tid, kategori, aciklama, bildiren, min(zaman, simdi()), "yeni", simdi()))
        olay(tid, "ariza", "Arıza bildirildi: {}{}".format(kategori, " — " + bildiren if bildiren else ""))
        return {"ok": True}

    # ── panel: oturum ────────────────────────────────────────────────────────
    def p_baslangic(self, y):
        y = self.yonetici()
        self.yanit({"kurulum_tamam": db.ayar("kurulum_tamam"), "oturum": bool(y),
                    "yonetici": {"ad": y["ad"], "ana": y["ana"]} if y else None,
                    "okul_adi": db.ayar("okul_adi"), "surum": SURUM})

    def oturum_ac(self, ek=None, yonetici=None):
        yonetici = yonetici or {"id": "ana", "ad": ANA_YONETICI}
        b = secrets.token_urlsafe(32)
        db.x("INSERT INTO oturum(belirtec, bitis, tur, ad, kim) VALUES(?,?,?,?,?)",
             (hashlib.sha256(b.encode()).hexdigest(), simdi() + 30 * 86400, "yonetici", yonetici["ad"], yonetici["id"]))
        cerez = "tys={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(b, 30 * 86400)
        self.yanit(ek or {"ok": True}, basliklar={"Set-Cookie": cerez})

    def p_kurulum(self, y):
        if db.ayar("kurulum_tamam"):
            raise Hata("Kurulum zaten yapılmış", 403)
        g = self.json_oku()
        okul = (g.get("okul_adi") or "").strip()[:120]
        sifre = g.get("sifre") or ""
        pin = re.sub(r"\D", "", g.get("pin") or "")
        if not okul:
            raise Hata("Okul adını yazın")
        if len(sifre) < 6:
            raise Hata("Yönetici şifresi en az 6 karakter olmalı")
        if not 4 <= len(pin) <= 8:
            raise Hata("Tahta açma şifresi 4-8 rakam olmalı")
        db.ayar_yaz("okul_adi", okul)
        db.ayar_yaz("kademe", [k for k in (g.get("kademe") or []) if k in KADEME_KODLARI])
        db.ayar_yaz("sifre", sifre_ozet(sifre))
        tuz = secrets.token_hex(8)
        db.ayar_yaz("pinler", [{"id": uuid.uuid4().hex[:8], "ad": (g.get("pin_ad") or "Ortak şifre").strip()[:40],
                                "tuz": tuz, "ozet": hashlib.sha256((tuz + pin).encode()).hexdigest()}])
        db.ayar_yaz("kurulum_tamam", True)
        olay("", "sistem", "İlk kurulum tamamlandı")
        hepsini_uyandir()
        self.oturum_ac()

    def p_giris(self, y):
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        g = self.json_oku()
        y = yonetici_bul(g.get("sifre") or "")
        if not y:
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(ip, None)
        olay("", "giris", "Panele giriş yapıldı: {} ({})".format(y["ad"], ip))
        self.oturum_ac(ek={"ok": True, "yonetici": {"ad": y["ad"], "ana": y["ana"]}}, yonetici=y)

    def p_cikis(self, y):
        b = self.cerez()
        with GORUNTU_KILIT:
            GORUNTU.pop(self.oturum_ozeti(), None)
        if b:
            db.x("DELETE FROM oturum WHERE belirtec=?", (hashlib.sha256(b.encode()).hexdigest(),))
        self.yanit({"ok": True}, basliklar={"Set-Cookie": "tys=; Path=/; Max-Age=0"})

    # ── panel: durum ve komutlar ─────────────────────────────────────────────
    def p_durum(self, y):
        onizleme_iste()
        tahtalar = [tahta_ozeti(r) for r in db.q("SELECT * FROM tahta ORDER BY ad COLLATE NOCASE")]
        arizalar = {r["tahta"]: r["n"] for r in db.q("SELECT tahta, COUNT(*) AS n FROM ariza WHERE durum!='cozuldu' GROUP BY tahta")}
        for t in tahtalar:
            t["ariza"] = arizalar.get(t["id"], 0)
        gruplar = sorted({t["grup"] for t in tahtalar if t["grup"]}, key=lambda s: s.lower())
        n = simdi()
        engel = db.ayar("site_engel") or {}
        self.yanit({
            "tahtalar": tahtalar, "gruplar": gruplar,
            "sunucu": {"surum": SURUM, "ajan_surum": AJAN_SURUM, "zaman": n,
                       "okul_adi": db.ayar("okul_adi"), "port": PORT,
                       "pin_var": bool(db.ayar("pinler")),
                       "zamanlayici_etkin": db.ayar("zamanlayici_etkin"),
                       "ariza_acik": sum(arizalar.values()),
                       "sinavlar": [s for s in db.ayar("sinavlar") or [] if s.get("bitis", 0) + 180 > n],
                       "saatler": db.ayar("saatler") or [],
                       "engel": {"etkin": bool(engel.get("etkin")), "sayi": len(engel.get("siteler") or [])},
                       "ortak_etkin": depo.etkin(),
                       "yedek": {"rank": dugum.rank, "devrede": dugum.yedek_mi() and dugum.aktif(),
                                 "sayi": len(db.ayar("yedekler") or [])},
                       "acil": self.acil_ozet()},
        })

    def p_komut(self, y):
        g = self.json_oku()
        tur = g.get("tur")
        if tur not in PANEL_KOMUTLARI:
            raise Hata("Geçersiz komut")
        veri = g.get("veri") or {}
        idler = hedef_cozumle(g.get("hedef"))
        if not idler:
            raise Hata("Seçili tahta yok")
        acik = [t for t in idler if cevrimici_mi(canli.get(t))]
        if tur == "ac":
            gonderilen, adressiz = tahtalari_uyandir(idler, liste=True)
            olay("", "komut", "{} → {}".format(KOMUT_ADI[tur], hedef_yazi(g.get("hedef"), len(gonderilen))))
            return self.yanit({"ok": True, "hedef": len(idler), "gonderilen": len(gonderilen),
                               "idler": gonderilen, "adressiz": adressiz, "acik": len(acik)})
        omur = None
        if tur == "duyuru":
            veri = {
                "baslik": (veri.get("baslik") or "").strip()[:120],
                "metin": (veri.get("metin") or "").strip()[:1500],
                "stil": "kucuk" if veri.get("stil") == "kucuk" else "buyuk",
                "sure": max(5, min(int(veri.get("sure") or 20), 3600)),
                "ses": bool(veri.get("ses", True)),
            }
            if not veri["metin"]:
                raise Hata("Duyuru metni boş olamaz")
            omur = veri["sure"] + 30
        elif tur == "kapat":
            veri = {"gecikme": max(0, min(int(veri.get("gecikme") or 0), 3600))}
        elif tur == "zil":
            ses = str(veri.get("ses") or "")
            yeni = {"tur": "teneffus" if veri.get("tur") == "teneffus" or ses == "teneffus" else "ders"}
            if ses and zil_ses_gecerli(ses):
                yeni["ses"] = ses
            if veri.get("sure"):
                yeni["sure"] = max(0, min(int(veri.get("sure") or 0), 600))
            veri = yeni
        elif tur == "icerik_ac":
            if veri.get("tur") == "ortak":
                try:
                    veri = {"tur": "ortak", "yol": ortak_mod.yol_dogrula(veri.get("yol") or "")}
                except ortak_mod.OrtakHata as h:
                    raise Hata(str(h))
            else:
                adres = (veri.get("adres") or "").strip()
                if adres and not re.match(r"^https?://", adres, re.I):
                    adres = "https://" + adres
                if not re.match(r"^https?://[^\s/$.?#][^\s]*$", adres, re.I) or len(adres) > 1000:
                    raise Hata("Geçerli bir internet adresi yazın")
                veri = {"tur": "url", "adres": adres}
            omur = 600
        elif tur in ("paket_kur", "paket_kaldir"):
            paketler = [p.strip() for p in (veri.get("paketler") or []) if p and p.strip()]
            if not paketler or len(paketler) > 15:
                raise Hata("1-15 arası uygulama (paket) adı yazın")
            for p in paketler:
                if not PAKET_DESEN.match(p):
                    raise Hata("Geçersiz paket adı: " + p)
            veri = {"paketler": paketler}
        elif tur == "engel_ara":
            veri = {"dk": max(5, min(int(veri.get("dk") or 45), 480))}
        elif tur == "kiosk":
            adres = (veri.get("adres") or "").strip()
            if not veri.get("kapat"):
                if not re.match(r"^[a-z]+://", adres, re.I):
                    adres = "https://" + adres
                if not re.match(r"^https?://[^\s]+$", adres, re.I):
                    raise Hata("Geçerli bir adres girin")
            veri = {"adres": adres[:500], "kapat": bool(veri.get("kapat"))}
        elif tur == "kullanici_gecis":
            k = (veri.get("kullanici") or "").strip()
            if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_.\-]{0,31}\$?$", k):
                raise Hata("Geçerli bir kullanıcı adı girin")
            veri = {"kullanici": k}
        elif tur in ("tanila", "onar"):
            yeni = {}
            pem = (db.ayar("ag_sertifika") or {}).get("pem")
            if pem:
                yeni["sertifika"] = pem
            if tur == "onar":
                islemler = [str(x) for x in (veri.get("islemler") or []) if str(x) in ONARIM_KIMLIKLERI]
                if not islemler:
                    raise Hata("Onarılacak bir şey seçin")
                yeni["islemler"] = list(dict.fromkeys(islemler))[:20]
            veri = yeni
            omur = KOMUT_OMRU[tur]
        else:
            veri = {} if tur not in ("duyuru", "kapat", "zil") else veri
        hedeflenecek = idler if tur in ("kaldir",) else acik
        if tur == "ekran":
            for tid in hedeflenecek:
                komut_ekle(tid, tur, veri, omur)
            iid = None
        else:
            iid = islem_baslat(tur, KOMUT_ADI[tur], veri, idler, hedeflenecek, self.kim(),
                               hedef_yazi(g.get("hedef"), len(idler)), omur=omur)
        ek = ""
        if tur == "duyuru":
            ek = ": " + (veri["baslik"] or veri["metin"])[:80]
        elif tur == "icerik_ac":
            ek = ": " + (veri.get("adres") or veri.get("yol"))[:100]
        elif tur in ("paket_kur", "paket_kaldir"):
            ek = ": " + ", ".join(veri["paketler"])
        elif tur == "engel_ara":
            ek = " ({} dk)".format(veri["dk"])
        olay("", "duyuru" if tur == "duyuru" else "komut",
             "{} → {}{}".format(KOMUT_ADI[tur], hedef_yazi(g.get("hedef"), len(idler)), ek))
        self.yanit({"ok": True, "hedef": len(idler), "gonderilen": len(hedeflenecek), "islem": iid})

    def p_tahta(self, y):
        g = self.json_oku()
        tid = g.get("id")
        r = db.bir("SELECT * FROM tahta WHERE id=?", (tid,))
        if not r:
            raise Hata("Tahta bulunamadı", 404)
        ad = (g.get("ad") if g.get("ad") is not None else r["ad"]).strip()[:60]
        grup = (g.get("grup") if g.get("grup") is not None else r["grup"] or "").strip()[:40]
        if not ad:
            raise Hata("Tahta adı boş olamaz")
        db.x("UPDATE tahta SET ad=?, grup=? WHERE id=?", (ad, grup, tid))
        if ad != r["ad"]:
            olay(tid, "sistem", "Adı değiştirildi: {} → {}".format(r["ad"], ad))
        uyandir(tid)
        self.yanit({"ok": True})

    def p_tahta_sil(self, y):
        g = self.json_oku()
        tid = g.get("id")
        r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
        if not r:
            raise Hata("Tahta bulunamadı", 404)
        if g.get("kaldir"):
            komut_ekle(tid, "kaldir", {})
            silinenler[tid] = simdi()
        db.x("DELETE FROM tahta WHERE id=?", (tid,))
        with canli_kilit:
            canli.pop(tid, None) if not g.get("kaldir") else None
        olay("", "sistem", "Tahta listeden silindi: {}".format(r["ad"]))
        self.yanit({"ok": True})

    def p_ekran(self, y):
        if not self.goruntu_acik():
            raise Hata("Ekran görüntüleri gizli. Göstermek için yönetici şifrenizi girin.", 403)
        tid = self.sorgu.get("id", "")
        boyut = ekran_boyutu(self.sorgu.get("boyut"))
        c = canli.get(tid)
        e = c and (c.ekran.get(boyut) or c.ekran.get("buyuk") or c.ekran.get("kucuk"))
        if not e:
            raise Hata("Görüntü yok", 404)
        bas = {"Cache-Control": "private, max-age=600"}
        if self.sorgu.get("indir"):
            r = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
            ad = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", (r["ad"] if r else "tahta"))[:60]
            ad = "{} {}.jpg".format(ad, datetime.fromtimestamp(e[0]).strftime("%Y-%m-%d %H.%M.%S"))
            bas["Content-Disposition"] = "attachment; filename*=UTF-8''" + quote(ad)
        self.yanit(e[2], mime=e[1], basliklar=bas)

    def p_ekran_iste(self, y):
        if not self.goruntu_acik():
            raise Hata("Ekran görüntüleri gizli. Göstermek için yönetici şifrenizi girin.", 403)
        g = self.json_oku()
        c = canli.get(g.get("id"))
        if not cevrimici_mi(c):
            raise Hata("Tahta kapalı")
        c.ekran_istek[ekran_boyutu(g.get("boyut"))] = simdi()
        uyandir(c.id)
        self.yanit({"ok": True})

    # ── panel: lehçe/pano duyuruları ─────────────────────────────────────────
    def p_panolar(self, y):
        n = simdi()
        liste = [p for p in db.ayar("panolar") if p.get("bitis", 0) > n]
        self.yanit({"panolar": liste})

    def p_pano(self, y):
        g = self.json_oku()
        metin = (g.get("metin") or "").strip()[:600]
        if not metin:
            raise Hata("Metin boş olamaz")
        gun = max(1, min(int(g.get("gun") or 1), 90))
        n = simdi()
        liste = [p for p in db.ayar("panolar") if p.get("bitis", 0) > n]
        liste.append({"id": uuid.uuid4().hex[:8], "baslik": (g.get("baslik") or "").strip()[:120],
                      "metin": metin, "hedef": g.get("hedef") or {"hepsi": True},
                      "olusma": n, "bitis": n + gun * 86400})
        db.ayar_yaz("panolar", liste)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_pano_sil(self, y):
        g = self.json_oku()
        db.ayar_yaz("panolar", [p for p in db.ayar("panolar") if p.get("id") != g.get("id")])
        hepsini_uyandir()
        self.yanit({"ok": True})

    # ── panel: dosyalar ──────────────────────────────────────────────────────
    def p_dosya(self, y):
        if y != "POST":
            raise Hata("Geçersiz istek")
        ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "dosya"))
        try:
            hedef = json.loads(unquote(self.headers.get("X-Hedef") or "{}"))
        except Exception:
            raise Hata("Geçersiz hedef")
        idler = hedef_cozumle(hedef)
        if not idler:
            raise Hata("Seçili tahta yok")
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            raise Hata("Dosya boş")
        if n > 2 * 1024 ** 3:
            raise Hata("Dosya 2 GB'dan büyük olamaz", 413)
        fid = uuid.uuid4().hex[:16]
        klasor = VERI / "dosyalar" / fid
        klasor.mkdir(parents=True, exist_ok=True)
        kalan = n
        with open(klasor / ad, "wb") as f:
            while kalan > 0:
                parca = self.rfile.read(min(kalan, 256 * 1024))
                if not parca:
                    break
                f.write(parca)
                kalan -= len(parca)
        if kalan:
            raise Hata("Dosya eksik yüklendi")
        ac = self.headers.get("X-Ac") == "1"
        konum = "belgeler" if self.headers.get("X-Konum-Klasor") == "belgeler" else "masaustu"
        kullanici = unquote(self.headers.get("X-Kullanici") or "").strip()
        if kullanici and kullanici != "*" and not re.match(r"^[A-Za-z_][A-Za-z0-9_.\-]{0,31}\$?$", kullanici):
            raise Hata("Kullanıcı adı geçersiz")
        db.x("INSERT INTO dosya(id, ad, boyut, zaman, hedefler, teslim, ac) VALUES(?,?,?,?,?,?,?)",
             (fid, ad, n, simdi(), json.dumps(idler), "[]", 1 if ac else 0))
        veri = {"fid": fid, "ad": ad, "boyut": n, "ac": ac, "konum": konum, "kullanici": kullanici}
        kime = {"": "", "*": " (tüm kullanıcılar)"}.get(kullanici, " ({})".format(kullanici))
        iid = islem_baslat("dosya", "Dosya: {}{}".format(ad, kime), veri, idler, idler, self.kim(),
                           hedef_yazi(hedef, len(idler)), omur=KOMUT_OMRU["dosya"])
        olay("", "dosya", "Dosya gönderildi: {} → {}{} · {}".format(ad, hedef_yazi(hedef, len(idler)), kime,
                                                                 "Belgeler" if konum == "belgeler" else "Masaüstü"))
        self.yanit({"ok": True, "id": fid, "hedef": len(idler), "islem": iid})

    def p_dosyalar(self, y):
        liste = []
        for r in db.q("SELECT * FROM dosya ORDER BY zaman DESC LIMIT 100"):
            hedefler = json.loads(r["hedefler"] or "[]")
            teslim = json.loads(r["teslim"] or "[]")
            liste.append({"id": r["id"], "ad": r["ad"], "boyut": r["boyut"], "zaman": r["zaman"],
                          "hedef": len(hedefler), "teslim": len(teslim),
                          "bekleyen": [tahta_adi(t) for t in hedefler if t not in teslim][:30]})
        self.yanit({"dosyalar": liste})

    def p_dosya_sil(self, y):
        g = self.json_oku()
        fid = re.sub(r"[^a-f0-9]", "", g.get("id") or "")
        db.x("DELETE FROM dosya WHERE id=?", (fid,))
        db.x("DELETE FROM bekleyen WHERE tur='dosya' AND veri LIKE ?", ('%"' + fid + '"%',))
        klasor = VERI / "dosyalar" / fid
        if fid and klasor.is_dir():
            for f in klasor.iterdir():
                f.unlink()
            klasor.rmdir()
        self.yanit({"ok": True})

    # ── panel: zamanlayıcı ───────────────────────────────────────────────────
    def kural_dogrula(self, k):
        if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", k.get("saat") or ""):
            raise Hata("Saat geçersiz")
        if k.get("tur") not in KURAL_KOMUTLARI:
            raise Hata("İşlem geçersiz")
        gunler = sorted({int(x) for x in (k.get("gunler") or []) if 1 <= int(x) <= 7})
        if not gunler:
            raise Hata("En az bir gün seçin")
        veri = k.get("veri") or {}
        if k["tur"] == "duyuru":
            veri = {"baslik": (veri.get("baslik") or "").strip()[:120],
                    "metin": (veri.get("metin") or "").strip()[:1500],
                    "stil": "kucuk" if veri.get("stil") == "kucuk" else "buyuk",
                    "sure": max(5, min(int(veri.get("sure") or 20), 3600)), "ses": True}
            if not veri["metin"]:
                raise Hata("Duyuru metni boş olamaz")
        elif k["tur"] == "zil":
            raise Hata("Ziller artık Zil Programı sayfasından kurulur")
        elif k["tur"] == "kapat":
            veri = {"gecikme": max(0, min(int(veri.get("gecikme") or 0), 3600))}
        elif k["tur"] == "kilit_araligi":
            bitis = veri.get("bitis") or ""
            if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bitis):
                raise Hata("Bitiş saati geçersiz")
            if bitis <= k["saat"]:
                raise Hata("Bitiş saati başlangıçtan sonra olmalı")
            veri = {"bitis": bitis, "ogretmen": bool(veri.get("ogretmen", True)),
                    "bitince_ac": bool(veri.get("bitince_ac", True))}
        else:
            veri = {}
        return {"id": k.get("id") or uuid.uuid4().hex[:10], "saat": k["saat"], "gunler": gunler,
                "tur": k["tur"], "veri": veri, "hedef": k.get("hedef") or {"hepsi": True},
                "aktif": bool(k.get("aktif", True)), "etiket": (k.get("etiket") or "")[:40],
                "aciklama": (k.get("aciklama") or "").strip()[:80]}

    def p_kurallar(self, y):
        liste = [json.loads(r["veri"]) for r in db.q("SELECT veri FROM kural")]
        liste.sort(key=lambda k: (k["saat"], k["tur"]))
        self.yanit({"kurallar": liste, "etkin": db.ayar("zamanlayici_etkin")})

    def p_kural(self, y):
        k = self.kural_dogrula(self.json_oku())
        db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        hepsini_uyandir()
        self.yanit({"ok": True, "kural": k})

    def p_aralik_bitir(self, y):
        """Kilitli saat aralığını bugün için erken bitirir (yarın yine çalışır)."""
        g = self.json_oku()
        kid = str(g.get("id") or "")
        r = db.bir("SELECT veri FROM kural WHERE id=?", (kid,))
        if not r:
            raise Hata("Kural bulunamadı")
        bugun = time.strftime("%Y-%m-%d")
        a = db.ayar("aralik_atla") or {}
        idler = set(a.get("idler") or []) if a.get("tarih") == bugun else set()
        idler.add(kid)
        db.ayar_yaz("aralik_atla", {"tarih": bugun, "idler": sorted(idler)})
        k = json.loads(r["veri"])
        olay("", "kural", "Kilitli saat aralığı bugün için bitirildi: {}".format(k.get("aciklama") or k.get("saat")))
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_kurallar_toplu(self, y):
        g = self.json_oku()
        yeni = [self.kural_dogrula(k) for k in (g.get("kurallar") or [])]
        if g.get("sil_etiket"):
            for r in db.q("SELECT id, veri FROM kural"):
                if json.loads(r["veri"]).get("etiket") == g["sil_etiket"]:
                    db.x("DELETE FROM kural WHERE id=?", (r["id"],))
        for k in yeni:
            db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        hepsini_uyandir()
        olay("", "sistem", "Zamanlayıcıya {} kural eklendi".format(len(yeni)))
        self.yanit({"ok": True, "sayi": len(yeni)})

    def p_kural_sil(self, y):
        g = self.json_oku()
        if g.get("etiket"):
            for r in db.q("SELECT id, veri FROM kural"):
                if json.loads(r["veri"]).get("etiket") == g["etiket"]:
                    db.x("DELETE FROM kural WHERE id=?", (r["id"],))
        else:
            db.x("DELETE FROM kural WHERE id=?", (g.get("id"),))
        hepsini_uyandir()
        self.yanit({"ok": True})

    # ── panel: kayıtlar ve rapor ─────────────────────────────────────────────
    def p_olaylar(self, y):
        sinir = max(10, min(int(self.sorgu.get("sinir") or 200), 1000))
        kosul, args = [], []
        if self.sorgu.get("tahta"):
            kosul.append("tahta=?")
            args.append(self.sorgu["tahta"])
        if self.sorgu.get("tur"):
            kosul.append("tur=?")
            args.append(self.sorgu["tur"])
        if self.sorgu.get("once"):
            kosul.append("zaman<?")
            args.append(float(self.sorgu["once"]))
        sql = "SELECT * FROM olay" + (" WHERE " + " AND ".join(kosul) if kosul else "") + " ORDER BY zaman DESC LIMIT ?"
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        liste = db.q(sql, args + [sinir])
        for o in liste:
            o["tahta_ad"] = adlar.get(o["tahta"], "") if o["tahta"] else ""
        self.yanit({"olaylar": liste})

    def kullanim_verisi(self, gun_sayisi):
        kullanim_yaz()
        bas = time.strftime("%Y-%m-%d", time.localtime(simdi() - (gun_sayisi - 1) * 86400))
        satirlar = db.q("SELECT * FROM kullanim WHERE gun>=? ORDER BY gun", (bas,))
        return satirlar

    def p_kullanim(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 7), 90))
        tahtalar = {r["id"]: {"ad": r["ad"], "grup": r["grup"]} for r in db.q("SELECT id, ad, grup FROM tahta")}
        self.yanit({"satirlar": self.kullanim_verisi(gun), "tahtalar": tahtalar, "gun": gun})

    def p_kullanim_csv(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        tampon = io.StringIO()
        w = csv.writer(tampon, delimiter=";")
        w.writerow(["Tarih", "Tahta", "Açık kalma (saat)", "Aktif kullanım (saat)"])
        for r in self.kullanim_verisi(gun):
            w.writerow([r["gun"], adlar.get(r["tahta"], r["tahta"]),
                        str(round(r["acik"] / 3600, 2)).replace(".", ","),
                        str(round(r["aktif"] / 3600, 2)).replace(".", ",")])
        veri = ("﻿" + tampon.getvalue()).encode("utf-8")
        self.yanit(veri, mime="text/csv; charset=utf-8", basliklar={
            "Content-Disposition": "attachment; filename=tahta-kullanim-raporu.csv"})

    # ── yedek yönetim bilgisayarları ─────────────────────────────────────────
    def bekleme(self, yontem, yol):
        if yontem == "POST":
            self.close_connection = True
        hedef = dugum.aktif_adres()
        if yol.startswith("/api/"):
            return self.yanit({"hata": "Bu bilgisayar yedek yönetim sunucusu olarak bekliyor", "yedek": True,
                               "aktif": hedef}, kod=503, basliklar={"Retry-After": "10"})
        self.yanit(yedek_mod.bekleme_sayfasi(hedef, self.path, dugum.rank, dugum.tani()), mime="text/html; charset=utf-8",
                   basliklar={"X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"})

    def y_yetki(self):
        if not dugum.anahtar_dogru(self.headers.get("X-Yedek") or ""):
            raise Hata("Yetkisiz", 401)

    def y_anlik(self, yontem):
        """Veritabanının anlık kopyası (yedek bilgisayarlar ve görevi geri alan ana bilgisayar alır)."""
        self.y_yetki()
        yid = self.headers.get("X-Dugum") or ""
        if yid and (self.headers.get("X-Rank") or "0") != "0":
            port = self.headers.get("X-Port") or ""
            port = int(port) if port.isdigit() and 0 < int(port) < 65536 else PORT
            dugum.adres_guncelle(yid, "http://{}:{}".format(self.client_address[0], port))
        self.yanit(dugum.anlik_gz(), mime="application/gzip", basliklar={"X-Epoch": str(dugum.epoch)})

    def y_liste(self, yontem):
        self.y_yetki()
        self.yanit(dugum.liste_ver())

    def y_dosya(self, yontem):
        self.y_yetki()
        try:
            p = dugum.dosya_yolu(self.sorgu.get("k", ""), self.sorgu.get("y", ""))
        except yedek_mod.YedekHata as h:
            raise Hata(str(h), 404)
        self.dosya_gonder(p)

    def y_devret(self, yontem):
        """Sırası daha küçük bir yönetim bilgisayarı görevi geri alıyor: bu bilgisayar pasife geçer."""
        self.y_yetki()
        g = self.json_oku()
        try:
            rank = int(g.get("rank", 99))
        except (TypeError, ValueError):
            raise Hata("Geçersiz sıra")
        if rank >= dugum.rank:
            raise Hata("Yalnızca sırası daha küçük bir bilgisayar görevi geri alabilir", 403)
        dugum.pasiflestir("sırası {} olan yönetim bilgisayarı görevi geri aldı".format(rank))
        self.yanit({"ok": True})

    def y_kayit(self, yontem):
        """Yedek bilgisayar kurulumu: ana yönetici şifresiyle yedek olarak kaydolur, anahtarları alır."""
        if yontem != "POST":
            raise Hata("Geçersiz istek", 405)
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        g = self.json_oku()
        if not db.ayar("kurulum_tamam"):
            raise Hata("Önce ana yönetim bilgisayarında ilk kurulumu tamamlayın", 409)
        if not sifre_dogru(g.get("sifre") or "", db.ayar("sifre") or ""):
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı (ana yönetici şifresi gerekir)", 401)
        giris_denemeleri.pop(ip, None)
        adres = yedek_mod.adres_temiz(g.get("adres"))
        host = re.sub(r"[^A-Za-z0-9.\-]", "", str(g.get("host") or ""))[:40]
        if not adres:
            raise Hata("Geçersiz adres")
        ad = (str(g.get("ad") or host or "Yedek bilgisayar").strip())[:40]
        try:
            y = dugum.yedek_ekle(ad, adres, host)
        except yedek_mod.YedekHata as h:
            raise Hata(str(h))
        olay("", "sistem", "Yönetim bilgisayarı eklendi: {} (sıra {})".format(ad, y["rank"]))
        if dugum.rank == 0:
            h = (self.headers.get("Host") or "").strip()
            ana = "http://" + (h if ":" in h else "{}:{}".format(h, PORT))
        else:
            ana = dugum.ana
        self.yanit({"ok": True, "id": y["id"], "rank": y["rank"], "anahtar": dugum.anahtar_al(),
                    "kimlik": db.ayar("kimlik"), "ana": ana})

    def y_ayril(self, yontem):
        """Yedek bilgisayar kaldırılırken kendini kayıt defterinden siler."""
        self.y_yetki()
        g = self.json_oku()
        try:
            dugum.yedek_sil(str(g.get("id") or ""))
        except yedek_mod.YedekHata:
            pass
        self.yanit({"ok": True})

    def p_yedeksunucu(self, y):
        """Yedek yönetim bilgisayarlarının durumu; silme yalnızca ana yönetici."""
        if self.command == "POST":
            ben = self.yonetici()
            if not ben["ana"]:
                raise Hata("Bilgisayar silmek için ana yönetici olarak giriş yapmalısınız", 403)
            g = self.json_oku()
            if g.get("sil"):
                try:
                    dugum.yedek_sil(str(g["sil"]))
                except yedek_mod.YedekHata as h:
                    raise Hata(str(h), 404)
                olay("", "sistem", "Yönetim bilgisayarı listeden kaldırıldı")
            return self.yanit({"ok": True})
        h = (self.headers.get("Host") or "").strip()
        o = dugum.panel_ozeti()
        o["rol"] = "yedek" if dugum.yedek_mi() else "ana"
        o["aktif"] = dugum.aktif()
        o["adresler"] = yerel_adresler()
        o["port"] = PORT
        self.yanit(o)

    # ── panel: kurulum yardımı ───────────────────────────────────────────────
    def p_kurulum_bilgi(self, y):
        self.yanit({"adresler": yerel_adresler(), "port": PORT, "ajan_surum": AJAN_SURUM})

    def p_kurulum_dosyasi_win(self, y):
        ip = self.sorgu.get("ip") or (yerel_adresler() or ["127.0.0.1"])[0]
        self.windows_kurulum(ip, self.sorgu.get("ad", ""))

    def p_kurulum_dosyasi(self, y):
        ip = self.sorgu.get("ip") or (yerel_adresler() or ["127.0.0.1"])[0]
        ad = tahta_adi_temizle(self.sorgu.get("ad", ""))
        dosya = "tahta-kur-{}.sh".format(re.sub(r"[^A-Za-z0-9\-]+", "_", ad).strip("_")) if ad else "tahta-kur.sh"
        self.kurulum_betigi(ip, {"Content-Disposition": "attachment; filename=" + dosya}, ad=ad)

    # ── panel: ayarlar ───────────────────────────────────────────────────────
    def p_ayarlar(self, y):
        if y == "POST":
            g = self.json_oku()
            if "okul_adi" in g:
                db.ayar_yaz("okul_adi", str(g["okul_adi"]).strip()[:120])
            if "kilit" in g:
                k = db.ayar("kilit")
                gk = g["kilit"] or {}
                if "acilista" in gk:
                    k["acilista"] = bool(gk["acilista"])
                if "duyuru_goster" in gk:
                    k["duyuru_goster"] = bool(gk["duyuru_goster"])
                if "mesaj" in gk:
                    k["mesaj"] = str(gk["mesaj"]).strip()[:200]
                for alan in ("bosta_kilit_dk", "bosta_kapat_dk"):
                    if alan in gk:
                        k[alan] = max(0, min(int(gk[alan] or 0), 600))
                db.ayar_yaz("kilit", k)
            for alan in ("zamanlayici_etkin", "onizleme", "zil_sesi_ac", "ariza_simge"):
                if alan in g:
                    db.ayar_yaz(alan, bool(g[alan]))
            if "saat_koruyucu_dk" in g:
                db.ayar_yaz("saat_koruyucu_dk", max(0, min(int(g["saat_koruyucu_dk"] or 0), 120)))
            hepsini_uyandir()
        zil = {t: b.get("ad") for t, b in (db.ayar("zil_ozel") or {}).items()}
        self.yanit({
            "ariza_simge": db.ayar("ariza_simge"), "saat_koruyucu_dk": db.ayar("saat_koruyucu_dk"),
            "kademe": db.ayar("kademe") or [], "kademeler": KADEMELER,
            "okul_adi": db.ayar("okul_adi"), "kilit": db.ayar("kilit"),
            "zamanlayici_etkin": db.ayar("zamanlayici_etkin"), "onizleme": db.ayar("onizleme"),
            "zil_sesi_ac": db.ayar("zil_sesi_ac"), "zil_ozel": zil,
            "pinler": [{"id": p["id"], "ad": p["ad"]} for p in db.ayar("pinler")],
            "yoneticiler": [{"id": x["id"], "ad": x["ad"]} for x in db.ayar("yoneticiler") or []],
            "ben": self.yonetici(),
            "sistem": {"surum": SURUM, "ajan_surum": AJAN_SURUM, "veri": str(VERI),
                       "adresler": yerel_adresler(), "port": PORT,
                       "calisma_sn": int(simdi() - BASLAMA)},
        })

    def p_pin(self, y):
        g = self.json_oku()
        pinler = db.ayar("pinler")
        if g.get("sil"):
            if len(pinler) <= 1:
                raise Hata("En az bir şifre kalmalı")
            pinler = [p for p in pinler if p["id"] != g["sil"]]
        else:
            ad = (g.get("ad") or "").strip()[:40]
            pin = re.sub(r"\D", "", g.get("pin") or "")
            if not ad:
                raise Hata("Ad yazın (ör. Ayşe Öğretmen veya 9. sınıflar)")
            if not 4 <= len(pin) <= 8:
                raise Hata("Şifre 4-8 rakam olmalı")
            for p in pinler:
                if hashlib.sha256((p["tuz"] + pin).encode()).hexdigest() == p["ozet"]:
                    raise Hata("Bu şifre zaten kullanılıyor")
            tuz = secrets.token_hex(8)
            pinler.append({"id": uuid.uuid4().hex[:8], "ad": ad, "tuz": tuz,
                           "ozet": hashlib.sha256((tuz + pin).encode()).hexdigest()})
        db.ayar_yaz("pinler", pinler)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_sifre(self, y):
        """Oturumu açık yönetici kendi şifresini değiştirir."""
        g = self.json_oku()
        ben = self.yonetici()
        if ben["ana"]:
            kayit = db.ayar("sifre")
        else:
            kayit = next((x.get("sifre", "") for x in db.ayar("yoneticiler") or [] if x["id"] == ben["id"]), "")
        if not sifre_dogru(g.get("eski") or "", kayit):
            raise Hata("Mevcut şifre hatalı")
        yeni = g.get("yeni") or ""
        if len(yeni) < 6:
            raise Hata("Yeni şifre en az 6 karakter olmalı")
        if yonetici_sifre_kullanimda(yeni, haric=ben["id"]):
            raise Hata("Bu şifre başka bir yönetici tarafından kullanılıyor; farklı bir şifre seçin")
        if ben["ana"]:
            db.ayar_yaz("sifre", sifre_ozet(yeni))
        else:
            liste = db.ayar("yoneticiler")
            for x in liste:
                if x["id"] == ben["id"]:
                    x["sifre"] = sifre_ozet(yeni)
            db.ayar_yaz("yoneticiler", liste)
        olay("", "sistem", "Yönetici şifresi değiştirildi: {}".format(ben["ad"]))
        self.yanit({"ok": True})

    def p_yonetici(self, y):
        """Ek yöneticiler (ör. müdür yardımcıları): ekle / sil / şifresini yenile. Yalnızca ana yönetici."""
        ben = self.yonetici()
        if not ben["ana"]:
            raise Hata("Yönetici eklemek ve silmek için ana yönetici olarak giriş yapmalısınız", 403)
        g = self.json_oku()
        liste = db.ayar("yoneticiler") or []
        if g.get("sil"):
            hedef = next((x for x in liste if x["id"] == g["sil"]), None)
            if not hedef:
                raise Hata("Yönetici bulunamadı", 404)
            liste = [x for x in liste if x["id"] != g["sil"]]
            db.x("DELETE FROM oturum WHERE kim=?", (g["sil"],))     # açık oturumları da kapanır
            olay("", "sistem", "Yönetici silindi: {}".format(hedef["ad"]))
        elif g.get("sifirla"):
            hedef = next((x for x in liste if x["id"] == g["sifirla"]), None)
            if not hedef:
                raise Hata("Yönetici bulunamadı", 404)
            yeni = g.get("sifre") or ""
            if len(yeni) < 6:
                raise Hata("Şifre en az 6 karakter olmalı")
            if yonetici_sifre_kullanimda(yeni, haric=hedef["id"]):
                raise Hata("Bu şifre başka bir yönetici tarafından kullanılıyor; farklı bir şifre seçin")
            hedef["sifre"] = sifre_ozet(yeni)
            db.x("DELETE FROM oturum WHERE kim=?", (hedef["id"],))
            olay("", "sistem", "Yönetici şifresi yenilendi: {}".format(hedef["ad"]))
        else:
            ad = (g.get("ad") or "").strip()[:40]
            sifre = g.get("sifre") or ""
            if not ad:
                raise Hata("Ad yazın (ör. Ali Yılmaz - Müdür Yardımcısı)")
            if len(sifre) < 6:
                raise Hata("Şifre en az 6 karakter olmalı")
            if len(liste) >= YONETICI_SINIR:
                raise Hata("En fazla {} ek yönetici eklenebilir".format(YONETICI_SINIR))
            if ad.lower() == ANA_YONETICI.lower() or any(x["ad"].lower() == ad.lower() for x in liste):
                raise Hata("Bu adla bir yönetici zaten var")
            if yonetici_sifre_kullanimda(sifre):
                raise Hata("Bu şifre başka bir yönetici tarafından kullanılıyor; farklı bir şifre seçin")
            liste.append({"id": uuid.uuid4().hex[:8], "ad": ad, "sifre": sifre_ozet(sifre), "eklenme": simdi()})
            olay("", "sistem", "Yönetici eklendi: {}".format(ad))
        db.ayar_yaz("yoneticiler", liste)
        self.yanit({"ok": True})

    # ── panel: politikalar ve depo ───────────────────────────────────────────
    def p_politika(self, y):
        modul = self.sorgu.get("modul")
        satirlar = db.q("SELECT * FROM politika WHERE (aktif=1 OR guncelleme > ?) " + ("AND modul=? " if modul else "") +
                        "ORDER BY olusturma DESC LIMIT 300", (simdi() - 30 * 86400,) + ((modul,) if modul else ()))
        adlar = {r["id"]: (r["ad"], r["grup"]) for r in db.q("SELECT id, ad, grup FROM tahta")}
        self.yanit({"politikalar": [politika_ozeti(p, adlar) for p in satirlar]})

    def p_politika_kaldir(self, y):
        g = self.json_oku()
        politika_kaldir(str(g.get("id") or ""), self.kim_adi())
        self.yanit({"ok": True})

    def p_politika_yeniden(self, y):
        """Hata veren cihazlarda yeniden dener (politikanın sürümünü artırır)."""
        g = self.json_oku()
        p = db.bir("SELECT * FROM politika WHERE id=? AND aktif=1", (str(g.get("id") or ""),))
        if not p:
            raise Hata("Kayıt bulunamadı")
        db.x("UPDATE politika SET surum=surum+1, guncelleme=? WHERE id=?", (simdi(), p["id"]))
        db.x("UPDATE politika_durum SET durum='bekliyor', ayrinti='' WHERE politika=? AND durum='hata'", (p["id"],))
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_depo(self, y):
        tur = self.sorgu.get("tur")
        r = db.q("SELECT * FROM depo " + ("WHERE tur=? " if tur else "") + "ORDER BY eklenme DESC", ((tur,) if tur else ()))
        self.yanit({"dosyalar": [dict(x, kullanan=depo_kullanan(x["sha"])) for x in r]})

    def p_depo_yukle(self, y):
        """Parçalı yükleme: X-Yukleme (kimlik), X-Konum (bayt), X-Toplam, X-Dosya-Adi, X-Tur, X-Aciklama."""
        yid = re.sub(r"[^0-9a-f]", "", self.headers.get("X-Yukleme") or "")[:32]
        konum, toplam = int(self.headers.get("X-Konum") or 0), int(self.headers.get("X-Toplam") or 0)
        if len(yid) < 16 or toplam <= 0 or toplam > DEPO_SINIR:
            raise Hata("Geçersiz yükleme" if toplam <= DEPO_SINIR else "Dosya en çok 4 GB olabilir", 413 if toplam > DEPO_SINIR else 400)
        (VERI / "depo_yukleniyor").mkdir(parents=True, exist_ok=True)
        DEPO_DIZIN.mkdir(parents=True, exist_ok=True)
        gecici = VERI / "depo_yukleniyor" / yid
        mevcut = gecici.stat().st_size if gecici.exists() else 0
        if konum != mevcut:
            return self.yanit({"ok": False, "konum": mevcut})       # istemci kaldığı yerden devam eder
        parca = self.ham_oku(16 * 1024 * 1024)
        with open(gecici, "ab") as f:
            f.write(parca)
        mevcut += len(parca)
        if mevcut < toplam:
            return self.yanit({"ok": True, "konum": mevcut})
        h = hashlib.sha256()
        with open(gecici, "rb") as f:
            for b in iter(lambda: f.read(1024 * 1024), b""):
                h.update(b)
        sha = h.hexdigest()
        os.replace(gecici, DEPO_DIZIN / sha)
        ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "dosya"))[:150]
        tur = re.sub(r"[^a-z_]", "", (self.headers.get("X-Tur") or "diger").lower())[:20] or "diger"
        aciklama = unquote(self.headers.get("X-Aciklama") or "")[:300]
        db.x("INSERT OR REPLACE INTO depo(sha, ad, boyut, tur, aciklama, eklenme, kim) VALUES(?,?,?,?,?,?,?)",
             (sha, ad, toplam, tur, aciklama, simdi(), self.kim_adi()))
        olay("", "sistem", "Depoya eklendi: {} ({:.1f} MB)".format(ad, toplam / 1048576))
        self.yanit({"ok": True, "bitti": True, "sha": sha, "konum": mevcut})

    def p_depo_sil(self, y):
        g = self.json_oku()
        sha = depo_yolu(g.get("sha")).name
        kullanan = depo_kullanan(sha)
        if kullanan:
            raise Hata("Bu dosya kullanılıyor: " + ", ".join(kullanan[:3]))
        r = db.bir("SELECT ad FROM depo WHERE sha=?", (sha,))
        db.x("DELETE FROM depo WHERE sha=?", (sha,))
        try:
            (DEPO_DIZIN / sha).unlink()
        except OSError:
            pass
        olay("", "sistem", "Depodan silindi: " + (r["ad"] if r else sha[:12]))
        self.yanit({"ok": True})

    # ── panel: Yazıcı Merkezi ────────────────────────────────────────────────
    def p_yazici(self, y):
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        kur = {}
        for p in db.q("SELECT * FROM politika WHERE modul='yazici' AND tur IN ('kur','uzak') AND (aktif=1 OR guncelleme > ?) ORDER BY aktif, olusturma",
                      (simdi() - 7 * 86400,)):
            o = politika_ozeti(p)
            for c in o["cihazlar"]:
                kur[(c["tahta"], o["veri"].get("anahtar"))] = dict(o, cihaz=c)
        yazicilar = []
        for r in db.q("SELECT * FROM yazici ORDER BY son DESC"):
            v = json.loads(r["veri"])
            c = canli.get(r["tahta"])
            p = kur.get((r["tahta"], r["anahtar"]))
            yazicilar.append(dict(v, tahta=r["tahta"], tahta_ad=adlar.get(r["tahta"], "?"), anahtar=r["anahtar"],
                                  takili=bool(r["takili"]), ilk=r["ilk"], son=r["son"], ad=yazici_model_anahtar(v),
                                  cevrimici=bool(c and cevrimici_mi(c)),
                                  politika={"id": p["id"], "aktif": p["aktif"], "durum": p["cihaz"]["durum"],
                                            "ayrinti": p["cihaz"]["ayrinti"], "surucu": p["veri"].get("surucu")} if p else None))
        modeller = [dict(m, surucu=json.loads(m["surucu"] or "{}"), tahta_ad=adlar.get(m["tahta"], ""))
                    for m in db.q("SELECT * FROM yazici_model ORDER BY zaman DESC")]
        kuyruklar = {tid: (db.ayar("yazici_kuyruk_" + tid) or {}) for tid in adlar}
        paylasimlar = []
        for p in db.q("SELECT * FROM politika WHERE modul='yazici' AND tur='paylas' AND (aktif=1 OR guncelleme > ?) "
                      "ORDER BY olusturma", (simdi() - 86400,)):
            o = politika_ozeti(p)
            v = o["veri"]
            b = db.bir("SELECT * FROM politika WHERE id=?", (v.get("baglan_id") or "",))
            bo = politika_ozeti(b) if b else None
            if not p["aktif"] and not o["cihazlar"] and not (bo and bo["cihazlar"]):
                continue
            host = v.get("host")
            c = canli.get(host)
            k = next((x for x in (kuyruklar.get(host) or {}).get("liste") or [] if x.get("ad") == v.get("kuyruk")), None)
            paylasimlar.append({"id": p["id"], "aktif": bool(p["aktif"]), "ad": v.get("ad"), "kuyruk": v.get("kuyruk"),
                                "host": host, "host_ad": adlar.get(host, "?"), "host_platform": v.get("host_platform"),
                                "host_cevrimici": bool(c and cevrimici_mi(c)), "host_ip": tahta_ip(host),
                                "paylasim": o["cihazlar"][0] if o["cihazlar"] else None,
                                "hedef": bo["hedef"] if bo else {}, "cihazlar": bo["cihazlar"] if bo else [],
                                "sayilar": bo["sayilar"] if bo else {}, "kuyruk_durum": k,
                                "windows_surucu": (bo["veri"].get("windows_surucu") if bo else None),
                                "varsayilan": bool(bo and bo["veri"].get("varsayilan"))})
        ya = db.ayar("yazici_ayar") or {}
        isler = [dict(r, tahta_ad=adlar.get(r["tahta"], "?")) for r in
                 db.q("SELECT * FROM yazici_is ORDER BY zaman DESC LIMIT 200")] if ya.get("kayit") else []
        # HP host-based LaserJet'ler: her açılışta firmware ister (4.2)
        fw_depo = {re.sub(r"\.(dl|img|tar\.gz|tgz)$", "", d["ad"], flags=re.I) for d in db.q("SELECT ad FROM depo")
                   if re.match(r"^sihpP?\d{4}\.(dl|img|tar\.gz|tgz)$", d["ad"] or "", re.I)}
        fw_gerekli = {}
        for yz in yazicilar:
            m = re.search(r"(?<![\d])(P?1\d{3})(?![\d])", (yz.get("model") or "").upper())
            if yz.get("platform") != "windows" and m and m.group(1) in HP_FIRMWARE and re.search(r"hp|hewlett|laserjet", yz["ad"], re.I):
                g = fw_gerekli.setdefault(m.group(1), {"model": m.group(1), "dosyalar": HP_FIRMWARE[m.group(1)], "tahtalar": []})
                g["tahtalar"].append(yz["tahta_ad"])
        for g in fw_gerekli.values():
            g["var"] = any(d in fw_depo for d in g["dosyalar"])
        self.yanit({"yazicilar": yazicilar, "modeller": modeller, "ayar": ya, "paylasimlar": paylasimlar, "isler": isler,
                    "hp_firmware": {"gerekli": sorted(fw_gerekli.values(), key=lambda x: x["model"]), "depo": sorted(fw_depo)},
                    "platformlar": {tid: (kuyruklar.get(tid) or {}).get("platform") for tid in adlar},
                    "depo": [dict(x) for x in db.q("SELECT * FROM depo WHERE tur IN ('surucu','diger') ORDER BY eklenme DESC")],
                    "kuyruklar": {adlar[k]: dict(v, tahta=k) for k, v in kuyruklar.items() if v}})

    def p_yazici_kur(self, y):
        g = self.json_oku()
        tid, anahtar = str(g.get("tahta") or ""), str(g.get("anahtar") or "")
        r = db.bir("SELECT * FROM yazici WHERE tahta=? AND anahtar=?", (tid, anahtar))
        t = db.bir("SELECT ad FROM tahta WHERE id=?", (tid,))
        if not r or not t:
            raise Hata("Yazıcı bulunamadı")
        v = json.loads(r["veri"])
        s = g.get("surucu") or {"tur": "otomatik"}
        uzaklar = [p for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='yazici' AND tur='uzak'")
                   if json.loads(p["veri"]).get("anahtar") == anahtar and tid in (json.loads(p["hedef"]).get("idler") or [])]
        if s.get("tur") == "windows_isle":
            return self.yazici_windows_isle(g, tid, anahtar, t, v, s, uzaklar)
        for u in uzaklar:                       # başka yönteme geçiliyor: "Windows'ta işle" kurulumu geri alınır
            politika_kaldir(u["id"], self.kim_adi())
            politika_kaldir(json.loads(u["veri"]).get("isle_id") or "", self.kim_adi()) if db.bir(
                "SELECT id FROM politika WHERE id=?", (json.loads(u["veri"]).get("isle_id") or "",)) else None
        if s.get("tur") not in ("otomatik", "deb", "ppd", "inf", "exe"):
            raise Hata("Geçersiz sürücü türü")
        if s["tur"] != "otomatik":
            d = db.bir("SELECT * FROM depo WHERE sha=?", (str(s.get("sha") or ""),))
            if not d:
                raise Hata("Depodan bir sürücü dosyası seçin")
            s = {"tur": s["tur"], "sha": d["sha"], "ad": d["ad"], "boyut": d["boyut"], "parametre": str(s.get("parametre") or "")[:300]}
        veri = {"anahtar": anahtar, "model": yazici_model_anahtar(v), "marka": v.get("marka"), "aygit_id": v.get("aygit_id"),
                "surucu": s, "varsayilan": bool(g.get("varsayilan", True)), "test": bool(g.get("test", True))}
        eski = next((p["id"] for p in db.q("SELECT id, hedef, veri FROM politika WHERE aktif=1 AND modul='yazici' AND tur='kur'")
                     if json.loads(p["veri"]).get("anahtar") == anahtar and tid in (json.loads(p["hedef"]).get("idler") or [])), None)
        pid = politika_kaydet("yazici", "kur", "{}: {}".format(t["ad"], veri["model"]), {"idler": [tid]}, veri, self.kim_adi(), eski)
        self.yanit({"ok": True, "id": pid})

    def yazici_windows_isle(self, g, tid, anahtar, t, v, s, uzaklar):
        """Sürücüsü yalnızca Windows'ta olan, Pardus tahtaya takılı yazıcı: iş Windows'ta işlenir, tahtada basılır."""
        isleyici = str(s.get("isleyici") or "")
        w = db.bir("SELECT ad FROM tahta WHERE id=?", (isleyici,))
        if not w or (db.ayar("yazici_kuyruk_" + isleyici) or {}).get("platform") != "windows":
            raise Hata("İşi hazırlayacak bir Windows cihaz seçin")
        ws = s.get("windows_surucu") or {"tur": "otomatik"}
        if ws.get("tur") not in ("otomatik", "inf", "exe"):
            raise Hata("Geçersiz sürücü türü")
        if ws["tur"] != "otomatik":
            d = db.bir("SELECT * FROM depo WHERE sha=?", (str(ws.get("sha") or ""),))
            if not d:
                raise Hata("Depodan bir sürücü dosyası seçin")
            ws = {"tur": ws["tur"], "sha": d["sha"], "ad": d["ad"], "boyut": d["boyut"], "parametre": str(ws.get("parametre") or "")[:300]}
        eski_kur = [p for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='yazici' AND tur='kur'")
                    if json.loads(p["veri"]).get("anahtar") == anahtar and tid in (json.loads(p["hedef"]).get("idler") or [])]
        for p in eski_kur:
            politika_kaldir(p["id"], self.kim_adi())
        model = yazici_model_anahtar(v)
        if uzaklar:
            uid = uzaklar[0]["id"]
            iid = json.loads(uzaklar[0]["veri"]).get("isle_id")
            raw = json.loads(uzaklar[0]["veri"]).get("raw_port")
        else:
            uid, iid = uuid.uuid4().hex[:12], uuid.uuid4().hex[:12]
            kullanilan = {json.loads(p["veri"]).get("raw_port") for p in db.q(
                "SELECT veri FROM politika WHERE aktif=1 AND modul='yazici' AND tur IN ('paylas','uzak')")
                if tid in (json.loads(p["veri"]).get("host"), json.loads(p["veri"]).get("tahta"))}
            raw = next(n for n in range(9150, 9200) if n not in kullanilan)
        kim = self.kim_adi()
        politika_kaydet("yazici", "isle", "Windows'ta işleme: {} ({})".format(model, t["ad"]), {"idler": [isleyici]},
                        {"model": model, "windows_surucu": ws, "uzak_id": uid, "tahta": tid, "raw_port": raw,
                         "ad": model, "konum": t["ad"]}, kim, iid)
        pid = politika_kaydet("yazici", "uzak", "{}: {} (Windows'ta işle)".format(t["ad"], model), {"idler": [tid]},
                              {"anahtar": anahtar, "model": model, "marka": v.get("marka"), "isle_id": iid, "isleyici": isleyici,
                               "tahta": tid, "raw_port": raw, "surucu": {"tur": "windows_isle", "isleyici": isleyici, "windows_surucu": ws},
                               "varsayilan": bool(g.get("varsayilan", True)), "test": bool(g.get("test", True))}, kim, uid)
        self.yanit({"ok": True, "id": pid})

    def p_yazici_ayar(self, y):
        g = self.json_oku()
        a = db.ayar("yazici_ayar") or {}
        if "otomatik" in g:
            a["otomatik"] = bool(g["otomatik"])
        if "kayit" in g:
            a["kayit"] = bool(g["kayit"])
        if "kilit" in g:
            a["kilit"] = bool(g["kilit"])
            k = db.bir("SELECT id FROM politika WHERE modul='yazici' AND tur='kilit' ORDER BY olusturma DESC")
            if a["kilit"]:
                politika_kaydet("yazici", "kilit", "Yazıcı ayarları kilidi", {"hepsi": True}, {}, self.kim_adi(),
                                k["id"] if k else None)
            elif k:
                politika_kaldir(k["id"], self.kim_adi())
        db.ayar_yaz("yazici_ayar", a)
        hepsini_uyandir()
        self.yanit({"ok": True, "ayar": a})

    def p_yazici_paylas(self, y):
        """Bir cihazdaki yazıcıyı paylaşır ya da izinleri düzenler: sunucu tahtaya 'paylas', izinli cihazlara 'baglan'."""
        g = self.json_oku()
        tid, kuyruk = str(g.get("tahta") or ""), str(g.get("kuyruk") or "")[:120]
        t = db.bir("SELECT ad, bilgi FROM tahta WHERE id=?", (tid,))
        rapor = db.ayar("yazici_kuyruk_" + tid) or {}
        k = next((x for x in rapor.get("liste") or [] if x.get("ad") == kuyruk), None)
        if not t or not k:
            raise Hata("Yazıcı bulunamadı")
        hedef = g.get("hedef") or {}
        if not (hedef.get("hepsi") or "grup" in hedef or hedef.get("idler")):
            raise Hata("Yazıcıyı kullanacak cihazları seçin")
        if "idler" in hedef:
            hedef = {"idler": [str(x) for x in hedef["idler"]][:500]}
        ws = g.get("windows_surucu") or {"tur": "otomatik"}
        if ws.get("tur") not in ("otomatik", "inf", "exe"):
            raise Hata("Geçersiz sürücü türü")
        if ws["tur"] != "otomatik":
            d = db.bir("SELECT * FROM depo WHERE sha=?", (str(ws.get("sha") or ""),))
            if not d:
                raise Hata("Depodan bir sürücü dosyası seçin")
            ws = {"tur": ws["tur"], "sha": d["sha"], "ad": d["ad"], "boyut": d["boyut"], "parametre": str(ws.get("parametre") or "")[:300]}
        platform_ = rapor.get("platform") or ("windows" if "windows" in str(json.loads(t["bilgi"] or "{}").get("os") or "").lower() else "linux")
        eski = None
        for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='yazici' AND tur='paylas'"):
            v = json.loads(p["veri"])
            if (g.get("id") and p["id"] == g["id"]) or (v.get("host") == tid and v.get("kuyruk") == kuyruk):
                eski = (p, v)
        model = (k.get("surucu") or "") if platform_ == "windows" else ""
        ad = "{} ({})".format(kuyruk.replace("_", " "), t["ad"])
        if eski:
            pid, bid, raw = eski[0]["id"], eski[1]["baglan_id"], eski[1]["raw_port"]
        else:
            kullanilan = {json.loads(p["veri"]).get("raw_port") for p in db.q(
                "SELECT veri FROM politika WHERE aktif=1 AND modul='yazici' AND tur='paylas'") if json.loads(p["veri"]).get("host") == tid}
            raw = next(n for n in range(9101, 9200) if n not in kullanilan)
            pid, bid = uuid.uuid4().hex[:12], uuid.uuid4().hex[:12]
        kim = self.kim_adi()
        ortak = {"kuyruk": kuyruk, "ad": ad, "model": model or kuyruk.replace("_", " "), "raw_port": raw,
                 "host": tid, "host_platform": platform_}
        politika_kaydet("yazici", "baglan", "Paylaşılan yazıcı: " + ad, hedef,
                        dict(ortak, paylasim=pid, windows_surucu=ws, varsayilan=bool(g.get("varsayilan"))), kim, bid)
        if not eski:
            politika_kaydet("yazici", "paylas", "Yazıcı paylaşımı: " + ad, {"idler": [tid]},
                            dict(ortak, baglan_id=bid, konum=t["ad"]), kim, pid)
        self.yanit({"ok": True, "id": pid})

    def p_yazici_paylasim_kaldir(self, y):
        g = self.json_oku()
        p = db.bir("SELECT * FROM politika WHERE id=? AND modul='yazici' AND tur='paylas'", (str(g.get("id") or ""),))
        if not p:
            raise Hata("Paylaşım bulunamadı")
        v = json.loads(p["veri"])
        if db.bir("SELECT id FROM politika WHERE id=? AND aktif=1", (v.get("baglan_id") or "",)):
            politika_kaldir(v["baglan_id"], self.kim_adi())
        if p["aktif"]:
            politika_kaldir(p["id"], self.kim_adi())
        self.yanit({"ok": True})

    def p_yazici_temizle(self, y):
        g = self.json_oku()
        tid = str(g.get("tahta") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Cihaz bulunamadı")
        komut_ekle(tid, "yazici_temizle", {"kuyruk": str(g.get("kuyruk") or "")[:120]}, omur=1800)
        self.yanit({"ok": True})

    # ── Uygulama Merkezi ──────────────────────────────────────────────────────
    KAYNAK_TURLERI = {"apt": "linux", "deb": "linux", "flatpak": "linux", "wine": "linux", "winget": "windows", "msi": "windows", "exe": "windows"}

    def p_uygulama(self, y):
        adlar = {r["id"]: (r["ad"], r["grup"]) for r in db.q("SELECT id, ad, grup FROM tahta")}
        pol = {}
        for p in db.q("SELECT * FROM politika WHERE modul='uygulama' AND tur='kur' AND (aktif=1 OR guncelleme > ?) ORDER BY aktif, olusturma",
                      (simdi() - 86400,)):
            pol[json.loads(p["veri"]).get("kimlik")] = politika_ozeti(p, adlar)
        uygulamalar = []
        for u in db.q("SELECT * FROM uygulama ORDER BY ad"):
            d = dict(u, kaynak=json.loads(u["kaynak"] or "{}"))
            o = pol.get(u["id"])
            d["politika"] = ({k: o[k] for k in ("id", "aktif", "hedef", "cihazlar", "sayilar")} if o else None)
            uygulamalar.append(d)
        envanter = {}
        for tid, (ad, _) in adlar.items():
            e = db.ayar("envanter_" + tid)
            if e:
                envanter[tid] = {"ad": ad, "zaman": e.get("zaman"), "platform": e.get("platform"), "sayi": len(e.get("uygulamalar") or []),
                                 "acilis_sn": e.get("acilis_sn"), "masaustu": e.get("masaustu"), "kullanicilar": e.get("kullanicilar") or []}
        ozet = lambda modul, tur: [politika_ozeti(p, adlar) for p in db.q(
            "SELECT * FROM politika WHERE modul=? AND tur=? AND (aktif=1 OR guncelleme > ?) ORDER BY olusturma", (modul, tur, simdi() - 86400))]
        self.yanit({"uygulamalar": uygulamalar, "envanter": envanter, "ayar": db.ayar("uygulama_ayar") or {},
                    "depo": [dict(x) for x in db.q("SELECT * FROM depo WHERE tur='uygulama' ORDER BY eklenme DESC")],
                    "tarayici": ozet("tarayici", "ayar"), "baslangic": ozet("baslangic", "kapat") + ozet("baslangic", "ekle")})

    def p_uygulama_kaydet(self, y):
        g = self.json_oku()
        ad = (g.get("ad") or "").strip()[:120]
        k = g.get("kaynak") or {}
        tur = k.get("tur")
        if not ad or tur not in self.KAYNAK_TURLERI:
            raise Hata("Uygulama adı ve kaynağı gerekli")
        kaynak = {"tur": tur, "paket": str(k.get("paket") or "").strip()[:300], "parametre": str(k.get("parametre") or "")[:300],
                  "parametre_kaldir": str(k.get("parametre_kaldir") or "")[:200], "calistir": str(k.get("calistir") or "")[:300]}
        if tur in ("deb", "wine", "msi", "exe") or (tur == "flatpak" and k.get("sha")):
            d = db.bir("SELECT * FROM depo WHERE sha=?", (str(k.get("sha") or ""),))
            if not d:
                raise Hata("Depodan kurulum dosyasını seçin")
            kaynak.update(sha=d["sha"], dosya_ad=d["ad"], boyut=d["boyut"])
        elif not kaynak["paket"]:
            raise Hata("Paket adı / kimliği gerekli")
        uid = str(g.get("id") or "") or uuid.uuid4().hex[:10]
        eski = db.bir("SELECT * FROM uygulama WHERE id=?", (uid,))
        db.x("INSERT OR REPLACE INTO uygulama(id, ad, kaynak, aciklama, wine_sonuc, olusturma, guncelleme) VALUES(?,?,?,?,?,?,?)",
             (uid, ad, json.dumps(kaynak, ensure_ascii=False), str(g.get("aciklama") or "")[:300],
              eski["wine_sonuc"] if eski and json.loads(eski["kaynak"]).get("sha") == kaynak.get("sha") else "",
              eski["olusturma"] if eski else simdi(), simdi()))
        p = self.uygulama_politikasi(uid)
        if p:                                   # kaynak değiştiyse cihazlar yeni hâliyle günceller
            v = json.loads(p["veri"])
            politika_kaydet("uygulama", "kur", "Uygulama: " + ad, json.loads(p["hedef"]), dict(v, ad=ad, kaynak=kaynak), self.kim_adi(), p["id"])
        self.yanit({"ok": True, "id": uid})

    def uygulama_politikasi(self, uid):
        for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='uygulama' AND tur='kur'"):
            if json.loads(p["veri"]).get("kimlik") == uid:
                return p
        return None

    def p_uygulama_sil(self, y):
        g = self.json_oku()
        if self.uygulama_politikasi(str(g.get("id") or "")):
            raise Hata("Önce uygulamayı cihazlardan kaldırın")
        db.x("DELETE FROM uygulama WHERE id=?", (str(g.get("id") or ""),))
        self.yanit({"ok": True})

    def p_uygulama_kur(self, y):
        g = self.json_oku()
        u = db.bir("SELECT * FROM uygulama WHERE id=?", (str(g.get("id") or ""),))
        if not u:
            raise Hata("Uygulama bulunamadı")
        hedef = g.get("hedef") or {}
        if not (hedef.get("hepsi") or "grup" in hedef or hedef.get("idler")):
            raise Hata("Cihaz seçin")
        p = self.uygulama_politikasi(u["id"])
        veri = {"kimlik": u["id"], "ad": u["ad"], "kaynak": json.loads(u["kaynak"]),
                "guncelle": json.loads(p["veri"]).get("guncelle", 0) if p else 0}
        pid = politika_kaydet("uygulama", "kur", "Uygulama: " + u["ad"], hedef, veri, self.kim_adi(), p["id"] if p else None)
        self.yanit({"ok": True, "id": pid})

    def p_uygulama_kaldir(self, y):
        g = self.json_oku()
        p = self.uygulama_politikasi(str(g.get("id") or ""))
        if p:
            politika_kaldir(p["id"], self.kim_adi())
        self.yanit({"ok": True})

    def p_uygulama_guncelle(self, y):
        g = self.json_oku()
        p = self.uygulama_politikasi(str(g.get("id") or ""))
        if not p:
            raise Hata("Uygulama hiçbir cihaza kurulu değil")
        v = json.loads(p["veri"])
        v["guncelle"] = int(v.get("guncelle") or 0) + 1
        politika_kaydet("uygulama", "kur", p["ad"], json.loads(p["hedef"]), v, self.kim_adi(), p["id"])
        self.yanit({"ok": True})

    def p_uygulama_wine(self, y):
        g = self.json_oku()
        sonuc = g.get("sonuc") if g.get("sonuc") in ("calisiyor", "calismiyor", "") else ""
        db.x("UPDATE uygulama SET wine_sonuc=?, guncelleme=? WHERE id=?", (sonuc, simdi(), str(g.get("id") or "")))
        olay("", "uygulama", "Wine sonucu kaydedildi: {} → {}".format(g.get("id"), sonuc or "-"))
        self.yanit({"ok": True})

    def p_uygulama_ayar(self, y):
        g = self.json_oku()
        a = db.ayar("uygulama_ayar") or {}
        if "kilit" in g:
            a["kilit"] = bool(g["kilit"])
            k = db.bir("SELECT id FROM politika WHERE aktif=1 AND modul='uygulama' AND tur='kilit'")
            if a["kilit"] and not k:
                politika_kaydet("uygulama", "kilit", "Öğretmen uygulama kurup kaldıramaz", {"hepsi": True}, {}, self.kim_adi())
            elif not a["kilit"] and k:
                politika_kaldir(k["id"], self.kim_adi())
        db.ayar_yaz("uygulama_ayar", a)
        self.yanit({"ok": True})

    def p_envanter(self, y):
        tid = self.sorgu.get("tahta") or ""
        t = db.bir("SELECT ad, grup FROM tahta WHERE id=?", (tid,))
        if not t:
            raise Hata("Cihaz bulunamadı")
        e = db.ayar("envanter_" + tid) or {}
        kapali = {}
        for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='baslangic' AND tur='kapat'"):
            if hedef_kapsar(json.loads(p["hedef"]), tid, t["grup"]):
                d = db.bir("SELECT durum, ayrinti FROM politika_durum WHERE politika=? AND tahta=?", (p["id"], tid))
                kapali[json.loads(p["veri"])["oge"]["kimlik"]] = {"id": p["id"], "durum": d["durum"] if d else "bekliyor",
                                                                  "ayrinti": d["ayrinti"] if d else ""}
        self.yanit({"envanter": e, "kapali": kapali, "ad": t["ad"]})

    def p_tarayici_kaydet(self, y):
        g = self.json_oku()
        a = g.get("ayar") or {}
        hedef = g.get("hedef") or {}
        if not (hedef.get("hepsi") or "grup" in hedef or hedef.get("idler")):
            raise Hata("Cihaz seçin")
        liste = lambda x, n=200: [str(i).strip()[:500] for i in (x or []) if str(i).strip()][:n]
        url = lambda u: (u if re.match(r"^[a-z]+://", u, re.I) else "https://" + u) if u else ""
        veri = {"anasayfa": url(str(a.get("anasayfa") or "").strip()[:500]), "acilis": [url(x) for x in liste(a.get("acilis"), 20)],
                "klasor": str(a.get("klasor") or "Okul").strip()[:60] or "Okul",
                "yer_imleri": [{"ad": str(b.get("ad") or b.get("url"))[:100], "url": url(str(b.get("url") or "").strip())[:500]}
                               for b in (a.get("yer_imleri") or [])[:100] if (b.get("url") or "").strip()],
                "uzanti_zorla": [x for x in liste(a.get("uzanti_zorla"), 50) if re.match(r"^[a-p]{32}$", x)],
                "uzanti_kaldir": [x for x in liste(a.get("uzanti_kaldir"), 50) if re.match(r"^([a-p]{32}|\*)$", x)],
                "engelli": liste(a.get("engelli"), 500), "yeniden_baslat": bool(a.get("yeniden_baslat"))}
        ad = (g.get("ad") or "Tarayıcı ayarları").strip()[:100]
        pid = politika_kaydet("tarayici", "ayar", ad, hedef, veri, self.kim_adi(), str(g.get("id") or "") or None)
        self.yanit({"ok": True, "id": pid})

    def p_baslangic_kapat(self, y):
        g = self.json_oku()
        oge = g.get("oge") or {}
        if oge.get("tur") not in ("autostart", "servis", "run", "klasor", "gorev") or not oge.get("kimlik"):
            raise Hata("Geçersiz öğe")
        oge = {"tur": oge["tur"], "kimlik": str(oge["kimlik"])[:500], "ad": str(oge.get("ad") or "")[:200]}
        idler = hedef_cozumle(g.get("hedef")) if g.get("hedef") else [str(g.get("tahta") or "")]
        for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='baslangic' AND tur='kapat'"):
            v = json.loads(p["veri"])
            if v["oge"]["kimlik"] == oge["kimlik"] and v["oge"]["tur"] == oge["tur"]:
                h = json.loads(p["hedef"])
                eski = hedef_cozumle(h)
                politika_kaydet("baslangic", "kapat", p["ad"], {"idler": sorted(set(eski) | set(idler))}, v, self.kim_adi(), p["id"])
                return self.yanit({"ok": True, "id": p["id"]})
        pid = politika_kaydet("baslangic", "kapat", "Açılışta çalışmasın: " + (oge["ad"] or oge["kimlik"]), {"idler": idler},
                              {"oge": oge}, self.kim_adi())
        self.yanit({"ok": True, "id": pid})

    def p_baslangic_ac(self, y):
        g = self.json_oku()
        p = db.bir("SELECT * FROM politika WHERE id=? AND aktif=1 AND modul='baslangic'", (str(g.get("id") or ""),))
        if not p:
            raise Hata("Bulunamadı")
        tid = str(g.get("tahta") or "")
        kalan = [x for x in hedef_cozumle(json.loads(p["hedef"])) if x != tid] if tid else []
        if kalan:
            politika_kaydet(p["modul"], p["tur"], p["ad"], {"idler": kalan}, json.loads(p["veri"]), self.kim_adi(), p["id"])
        else:
            politika_kaldir(p["id"], self.kim_adi())
        self.yanit({"ok": True})

    def p_baslangic_ekle(self, y):
        g = self.json_oku()
        ad, komut = (g.get("ad") or "").strip()[:100], (g.get("komut") or "").strip()[:500]
        if not ad or not komut:
            raise Hata("Ad ve komut gerekli")
        hedef = g.get("hedef") or {}
        if not (hedef.get("hepsi") or "grup" in hedef or hedef.get("idler")):
            raise Hata("Cihaz seçin")
        pid = politika_kaydet("baslangic", "ekle", "Açılışta çalışsın: " + ad, hedef,
                              {"kimlik": uuid.uuid4().hex[:8], "ad": ad, "komut": komut, "platform": g.get("platform") or ""},
                              self.kim_adi())
        self.yanit({"ok": True, "id": pid})

    def p_baslangic_kopyala(self, y):
        """Bir tahtanın başlangıç ayarlarını (kapatılan / eklenen öğeler) seçili cihazlara da uygular."""
        g = self.json_oku()
        kaynak = db.bir("SELECT id, grup FROM tahta WHERE id=?", (str(g.get("kaynak") or ""),))
        idler = set(hedef_cozumle(g.get("hedef")))
        if not kaynak or not idler:
            raise Hata("Kaynak ve hedef cihazları seçin")
        n = 0
        for p in db.q("SELECT * FROM politika WHERE aktif=1 AND modul='baslangic'"):
            h = json.loads(p["hedef"])
            if hedef_kapsar(h, kaynak["id"], kaynak["grup"]):
                politika_kaydet(p["modul"], p["tur"], p["ad"], {"idler": sorted(set(hedef_cozumle(h)) | idler)},
                                json.loads(p["veri"]), self.kim_adi(), p["id"])
                n += 1
        self.yanit({"ok": True, "sayi": n})

    # ── Oturum / arka plan ────────────────────────────────────────────────────
    def p_oturum(self, y):
        adlar = {r["id"]: (r["ad"], r["grup"]) for r in db.q("SELECT id, ad, grup FROM tahta")}
        cihazlar = {}
        for tid, (ad, _) in adlar.items():
            e = db.ayar("envanter_" + tid) or {}
            cihazlar[tid] = {"ad": ad, "kullanicilar": e.get("kullanicilar") or [], "masaustu": e.get("masaustu") or "",
                             "platform": e.get("platform") or ""}
        pl = [politika_ozeti(p, adlar) for p in db.q(
            "SELECT * FROM politika WHERE modul='oturum' AND tur='arkaplan' AND (aktif=1 OR guncelleme > ?) ORDER BY olusturma",
            (simdi() - 86400,))]
        self.yanit({"arkaplanlar": pl, "cihazlar": cihazlar,
                    "resimler": [dict(x) for x in db.q("SELECT * FROM depo WHERE tur='resim' ORDER BY eklenme DESC")]})

    def p_arkaplan_kaydet(self, y):
        g = self.json_oku()
        v = g.get("veri") or {}
        hedef = g.get("hedef") or {}
        if not (hedef.get("hepsi") or "grup" in hedef or hedef.get("idler")):
            raise Hata("Cihaz seçin")

        def resim(r):
            if not r or not r.get("sha"):
                return None
            d = db.bir("SELECT sha, ad FROM depo WHERE sha=?", (str(r["sha"]),))
            if not d:
                raise Hata("Resim depoda yok")
            return {"sha": d["sha"], "ad": d["ad"], "dosya": d["ad"]}
        gunler = []
        for o in (v.get("ozel_gunler") or [])[:60]:
            t, b = str(o.get("tarih") or ""), str(o.get("bitis") or "")
            if not re.match(r"^(\d{4}-)?\d{2}-\d{2}$", t) or (b and not re.match(r"^(\d{4}-)?\d{2}-\d{2}$", b)):
                raise Hata("Özel gün tarihi geçersiz: " + t)
            gunler.append(dict(resim(o) or {}, tarih=t, bitis=b, ad=str(o.get("ad") or "")[:60]))
        veri = {"masaustu": resim(v.get("masaustu")), "giris": resim(v.get("giris")), "kilit_ekrani": resim(v.get("kilit_ekrani")),
                "tahtaya_ozel": {str(k): resim(x) for k, x in (v.get("tahtaya_ozel") or {}).items() if resim(x)},
                "ozel_gunler": gunler, "kilitle": bool(v.get("kilitle")),
                "giris_logo": bool(v.get("giris_logo")), "giris_bulanik": bool(v.get("giris_bulanik"))}
        if not (veri["masaustu"] or veri["tahtaya_ozel"] or veri["giris"] or veri["kilit_ekrani"] or gunler or veri["giris_logo"]):
            raise Hata("En az bir resim seçin")
        pid = politika_kaydet("oturum", "arkaplan", (g.get("ad") or "Arka plan").strip()[:100], hedef, veri, self.kim_adi(),
                              str(g.get("id") or "") or None)
        self.yanit({"ok": True, "id": pid})

    def p_yazici_test(self, y):
        g = self.json_oku()
        komut_ekle(str(g.get("tahta") or ""), "yazici_test", {"kuyruk": str(g.get("kuyruk") or "")[:120]}, omur=600)
        self.yanit({"ok": True})

    def p_yazici_unut(self, y):
        """Takılı olmayan bir yazıcıyı listeden kaldırır (kurulumu varsa önce geri alınmalı)."""
        g = self.json_oku()
        db.x("DELETE FROM yazici WHERE tahta=? AND anahtar=? AND takili=0", (str(g.get("tahta") or ""), str(g.get("anahtar") or "")))
        self.yanit({"ok": True})

    # ── panel: USB Koruma ────────────────────────────────────────────────────
    def p_usb(self, y):
        n = simdi()
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        satirlar = db.q("SELECT * FROM usb_olay WHERE zaman > ? ORDER BY zaman DESC LIMIT 400", (n - 180 * 86400,))
        olaylar, tahtalar, makineler, flashlar = [], {}, {}, {}
        for r in satirlar:
            v = json.loads(r["veri"] or "{}")
            v.update(id=r["id"], zaman=r["zaman"], tahta=r["tahta"], tahta_ad=adlar.get(r["tahta"], "(silinmiş tahta)"))
            olaylar.append(v)
            if r["zaman"] < n - 30 * 86400:
                continue
            t = tahtalar.setdefault(r["tahta"], {"tahta": r["tahta"], "ad": v["tahta_ad"], "sayi": 0, "son": 0, "seriler": set()})
            t["sayi"] += 1
            t["son"] = max(t["son"], r["zaman"])
            if r["seri"]:
                t["seriler"].add(r["seri"])
            for m in v.get("makineler") or []:
                x = makineler.setdefault(m, {"ad": m, "sayi": 0, "son": 0, "tahtalar": set(), "seriler": set()})
                x["sayi"] += 1
                x["son"] = max(x["son"], r["zaman"])
                x["tahtalar"].add(v["tahta_ad"])
                if r["seri"]:
                    x["seriler"].add(r["seri"])
            if r["seri"]:
                f = flashlar.setdefault(r["seri"], {"seri": r["seri"], "etiket": v.get("etiket") or "", "sayi": 0, "son": 0,
                                                    "tahtalar": set()})
                f["sayi"] += 1
                if r["zaman"] >= f["son"]:
                    f["son"], f["etiket"] = r["zaman"], v.get("etiket") or f["etiket"]
                f["tahtalar"].add(v["tahta_ad"])

        def duz(liste, anahtar):
            out = []
            for x in liste:
                x = dict(x)
                for k in ("tahtalar", "seriler"):
                    if k in x:
                        x[k] = sorted(x[k]) if k == "tahtalar" else len(x[k])
                out.append(x)
            return sorted(out, key=lambda x: (-x[anahtar], -x["son"]))
        k = usb_kurallari()
        self.yanit({"ayar": db.ayar("usb_ayar") or {}, "kural_surum": k.get("surum") or "yerleşik",
                    "olaylar": olaylar[:200], "tahtalar": duz(tahtalar.values(), "sayi")[:15],
                    "makineler": duz(makineler.values(), "sayi")[:15],
                    "flashlar": [f for f in duz(flashlar.values(), "sayi") if f["sayi"] > 1][:15]})

    def p_usb_ayar(self, y):
        g = self.json_oku()
        ua = db.ayar("usb_ayar") or {}
        if "varsayilan" in g:
            if g["varsayilan"] not in USB_MODLAR:
                raise Hata("Geçersiz mod")
            ua["varsayilan"] = g["varsayilan"]
        if "ozel" in g:
            ozel = []
            for x in g.get("ozel") or []:
                if x.get("mod") not in USB_MODLAR or not isinstance(x.get("hedef"), dict):
                    raise Hata("Geçersiz istisna")
                ozel.append({"id": x.get("id") or uuid.uuid4().hex[:8], "hedef": x["hedef"], "mod": x["mod"]})
            ua["ozel"] = ozel[:30]
        if "wsh_kapat" in g:
            ua["wsh_kapat"] = bool(g["wsh_kapat"])
        db.ayar_yaz("usb_ayar", ua)
        olay("", "sistem", "USB Koruma ayarı değişti: varsayılan {}{}".format(
            {"kapali": "kapalı", "uyar": "sadece uyar", "temizle": "otomatik temizle"}[ua.get("varsayilan", "uyar")],
            ", Windows Script Host kapalı" if ua.get("wsh_kapat") else ""))
        hepsini_uyandir()
        self.yanit({"ok": True, "ayar": ua})

    def p_usb_geri_al(self, y):
        g = self.json_oku()
        r = db.bir("SELECT * FROM usb_olay WHERE id=?", (str(g.get("id") or ""),))
        if not r:
            raise Hata("Kayıt bulunamadı")
        v = json.loads(r["veri"])
        if r["sonuc"] != "temizlendi" or not v.get("damga"):
            raise Hata("Bu kayıtta geri alınacak bir temizlik yok")
        if v.get("geri"):
            raise Hata("Bu temizlik zaten geri alınmış")
        for t in db.q("SELECT id FROM tahta"):
            komut_ekle(t["id"], "usb_geri_al", {"olay": r["id"], "damga": v["damga"], "seri": r["seri"]}, omur=1800)
        v["geri_istendi"] = simdi()
        db.x("UPDATE usb_olay SET veri=? WHERE id=?", (json.dumps(v, ensure_ascii=False), r["id"]))
        olay("", "usb", "USB temizliğini geri alma istendi: {} (flash hangi tahtaya takılırsa orada yapılır)".format(
            v.get("etiket") or r["seri"] or "flash"))
        self.yanit({"ok": True})

    # ── panel: acil durum ────────────────────────────────────────────────────
    def acil_ozet(self):
        a = db.ayar("acil")
        if not a:
            return None
        o = {x: a.get(x) for x in ("id", "senaryo", "baslik", "tatbikat", "baslangic", "bitis", "kim", "hedef_sayi", "hedef")}
        o.update(ulasan=acil_ulasan(a["id"]), simdi=simdi())
        return o

    def kim_adi(self):
        try:
            y = self.yonetici()
            return y["ad"] if y else "Yönetici"
        except Exception:
            return "Yönetici"

    def p_acil(self, y):
        self.yanit({"aktif": self.acil_ozet(), "ozel": db.ayar("acil_ozel") or {}, "plan": db.ayar("acil_plan") or [],
                    "gecmis": (db.ayar("acil_gecmis") or [])[:20], "simdi": time.strftime("%Y-%m-%d %H:%M")})

    def p_acil_baslat(self, y):
        g = self.json_oku()
        a = acil_baslat(g, self.kim_adi())
        if g.get("kaydet"):
            ozel = db.ayar("acil_ozel") or {}
            ozel[a["senaryo"]] = {x: a[x] for x in ("baslik", "metin", "ses", "tekrar")}
            db.ayar_yaz("acil_ozel", ozel)
        self.yanit({"ok": True, "acil": self.acil_ozet()})

    def p_acil_bitir(self, y):
        a = acil_bitir(self.kim_adi())
        self.yanit({"ok": True, "bitti": bool(a)})

    def p_acil_ozel(self, y):
        """Senaryo metinlerini kaydeder (başlatmadan)."""
        g = self.json_oku()
        ozel = db.ayar("acil_ozel") or {}
        if g.get("sifirla"):
            ozel.pop(g["sifirla"], None)
        else:
            a = acil_dogrula(g)
            ozel[a["senaryo"]] = {x: a[x] for x in ("baslik", "metin", "ses", "tekrar")}
        db.ayar_yaz("acil_ozel", ozel)
        self.yanit({"ok": True, "ozel": ozel})

    def p_acil_plan(self, y):
        g = self.json_oku()
        plan = db.ayar("acil_plan") or []
        if g.get("sil"):
            plan = [x for x in plan if x.get("id") != g["sil"]]
        else:
            x = acil_dogrula(g)
            tarih, saat = (g.get("tarih") or "").strip(), (g.get("saat") or "").strip()
            if not TARIH_DESEN.match(tarih) or not SAAT_DESEN.match(saat):
                raise Hata("Tarih ve saati seçin")
            if "{} {}".format(tarih, saat) <= time.strftime("%Y-%m-%d %H:%M"):
                raise Hata("Geçmiş bir zaman seçilemez")
            if not x["sure_dk"]:
                x["sure_dk"] = 10
            x.update(id=uuid.uuid4().hex[:8], tarih=tarih, saat=saat, kim=self.kim_adi())
            plan.append(x)
            olay("", "acil", "Tatbikat planlandı: {} {} — {}".format(tarih, saat, x["baslik"]))
        plan.sort(key=lambda x: (x["tarih"], x["saat"]))
        db.ayar_yaz("acil_plan", plan[:30])
        self.yanit({"ok": True, "plan": plan})

    # ── panel: zil programı ──────────────────────────────────────────────────
    def p_zil(self, y):
        ozel = {t: b.get("ad") for t, b in (db.ayar("zil_ozel") or {}).items()}
        self.yanit({"etkin": db.ayar("zil_etkin"), "programlar": db.ayar("zil_programlari") or [],
                    "sesler": db.ayar("zil_sesleri") or [], "tatiller": zil_tatil_guncel(),
                    "ozel": ozel, "sesi_ac": db.ayar("zil_sesi_ac"), "simdi": time.strftime("%Y-%m-%d %H:%M:%S")})

    def zil_program_dogrula(self, g):
        ad = (g.get("ad") or "").strip()[:60] or "Zil programı"
        gunler = sorted({int(x) for x in (g.get("gunler") or []) if 1 <= int(x) <= 7})
        if not gunler:
            raise Hata("En az bir gün seçin")
        satirlar, gorulen = [], set()
        for z in g.get("satirlar") or []:
            saat = (z.get("saat") or "").strip()
            if not SAAT_DESEN.match(saat):
                raise Hata("Geçersiz saat: " + (saat or "boş"))
            if saat in gorulen:
                raise Hata("Aynı saat iki kez yazılmış: " + saat)
            gorulen.add(saat)
            ses = z.get("ses") or "ders"
            if not zil_ses_gecerli(ses):
                raise Hata("{} satırındaki ses bulunamadı".format(saat))
            satirlar.append({"saat": saat, "ad": (z.get("ad") or "").strip()[:60], "ses": ses})
        if not satirlar:
            raise Hata("En az bir zil saati girin")
        if len(satirlar) > 80:
            raise Hata("Bir programda en fazla 80 zil olabilir")
        satirlar.sort(key=lambda z: z["saat"])
        return {"id": g.get("id") or uuid.uuid4().hex[:10], "ad": ad, "aktif": bool(g.get("aktif", True)),
                "hedef": g.get("hedef") or {"hepsi": True}, "gunler": gunler,
                "sure": max(0, min(int(g.get("sure") or 0), 600)), "satirlar": satirlar}

    def p_zil_kaydet(self, y):
        g = self.json_oku()
        pr = self.zil_program_dogrula(g.get("program") or {})
        liste = [x for x in db.ayar("zil_programlari") or [] if x.get("id") != pr["id"]]
        eski = next((x for x in db.ayar("zil_programlari") or [] if x.get("id") == pr["id"]), None)
        liste.append(pr)
        liste.sort(key=lambda x: (x["satirlar"][0]["saat"], x["ad"]))
        db.ayar_yaz("zil_programlari", liste)
        ek = g.get("ek_kurallar")
        if ek is not None:          # hızlı doldurdaki kilit / kapatma seçenekleri
            etiket = "zilp-" + pr["id"]
            for r in db.q("SELECT id, veri FROM kural"):
                if json.loads(r["veri"]).get("etiket") == etiket:
                    db.x("DELETE FROM kural WHERE id=?", (r["id"],))
            for k in ek:
                k.update(etiket=etiket, gunler=pr["gunler"], hedef=pr["hedef"])
                k = self.kural_dogrula(k)
                db.x("INSERT OR REPLACE INTO kural(id, veri) VALUES(?,?)", (k["id"], json.dumps(k, ensure_ascii=False)))
        elif eski:                  # hedef / günler değiştiyse bağlı kuralları da güncelle
            etiket = "zilp-" + pr["id"]
            for r in db.q("SELECT id, veri FROM kural"):
                k = json.loads(r["veri"])
                if k.get("etiket") == etiket:
                    k.update(gunler=pr["gunler"], hedef=pr["hedef"])
                    db.x("UPDATE kural SET veri=? WHERE id=?", (json.dumps(k, ensure_ascii=False), r["id"]))
        olay("", "sistem", "Zil programı kaydedildi: {} ({} zil)".format(pr["ad"], len(pr["satirlar"])))
        hepsini_uyandir()
        self.yanit({"ok": True, "program": pr})

    def p_zil_durum(self, y):
        """Programı açar/kapatır."""
        g = self.json_oku()
        liste = db.ayar("zil_programlari") or []
        for x in liste:
            if x.get("id") == g.get("id"):
                x["aktif"] = bool(g.get("aktif"))
        db.ayar_yaz("zil_programlari", liste)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_zil_sil(self, y):
        g = self.json_oku()
        liste = db.ayar("zil_programlari") or []
        pr = next((x for x in liste if x.get("id") == g.get("id")), None)
        if not pr:
            raise Hata("Program bulunamadı")
        db.ayar_yaz("zil_programlari", [x for x in liste if x is not pr])
        etiket = "zilp-" + pr["id"]
        for r in db.q("SELECT id, veri FROM kural"):
            if json.loads(r["veri"]).get("etiket") == etiket:
                db.x("DELETE FROM kural WHERE id=?", (r["id"],))
        olay("", "sistem", "Zil programı silindi: " + pr["ad"])
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_zil_etkin(self, y):
        g = self.json_oku()
        if "etkin" in g:
            db.ayar_yaz("zil_etkin", bool(g["etkin"]))
            olay("", "sistem", "Ziller " + ("açıldı" if g["etkin"] else "durduruldu"))
        if "sesi_ac" in g:
            db.ayar_yaz("zil_sesi_ac", bool(g["sesi_ac"]))
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_zil_tatil(self, y):
        g = self.json_oku()
        liste = []
        for t in g.get("tatiller") or []:
            bas, bit = (t.get("bas") or "").strip(), (t.get("bit") or t.get("bas") or "").strip()
            if not TARIH_DESEN.match(bas) or not TARIH_DESEN.match(bit):
                raise Hata("Tarih geçersiz")
            if bit < bas:
                raise Hata("Bitiş tarihi başlangıçtan önce olamaz")
            liste.append({"id": t.get("id") or uuid.uuid4().hex[:8], "bas": bas, "bit": bit,
                          "ad": (t.get("ad") or "").strip()[:60]})
        liste.sort(key=lambda t: t["bas"])
        db.ayar_yaz("zil_tatil", liste[:100])
        hepsini_uyandir()
        self.yanit({"ok": True, "tatiller": zil_tatil_guncel()})

    def p_zil_ses_yukle(self, y):
        sesler = db.ayar("zil_sesleri") or []
        if len(sesler) >= ZIL_SES_ADET:
            raise Hata("En fazla {} ses yüklenebilir; kullanmadıklarınızı silin".format(ZIL_SES_ADET))
        dosya = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "ses.mp3"))
        uzanti = dosya.rsplit(".", 1)[-1].lower() if "." in dosya else ""
        if uzanti not in ("wav", "mp3", "ogg", "oga", "flac"):
            raise Hata("Desteklenen biçimler: MP3, WAV, OGG, FLAC")
        if int(self.headers.get("Content-Length") or 0) > ZIL_SES_SINIR:
            raise Hata("Ses dosyası en fazla 10 MB olabilir", 413)
        veri = self.ham_oku(ZIL_SES_SINIR)
        if len(veri) < 100:
            raise Hata("Ses dosyası boş görünüyor")
        sid = uuid.uuid4().hex[:10]
        (VERI / "sesler").mkdir(parents=True, exist_ok=True)
        (VERI / "sesler" / "k-{}.{}".format(sid, uzanti)).write_bytes(veri)
        ad = (unquote(self.headers.get("X-Ad") or "").strip() or dosya.rsplit(".", 1)[0])[:40]
        x = {"id": sid, "ad": ad, "dosya": dosya, "uzanti": uzanti, "boyut": len(veri),
             "ozet": hashlib.sha1(veri).hexdigest()[:12]}
        sesler.append(x)
        db.ayar_yaz("zil_sesleri", sesler)
        hepsini_uyandir()
        self.yanit({"ok": True, "ses": x})

    def p_zil_ses_ad(self, y):
        g = self.json_oku()
        sesler = db.ayar("zil_sesleri") or []
        for x in sesler:
            if x["id"] == g.get("id"):
                x["ad"] = (g.get("ad") or "").strip()[:40] or x["ad"]
        db.ayar_yaz("zil_sesleri", sesler)
        self.yanit({"ok": True})

    def p_zil_ses_sil(self, y):
        g = self.json_oku()
        ref = "k:" + str(g.get("id") or "")
        kullanan = [p["ad"] for p in db.ayar("zil_programlari") or [] if any(z.get("ses") == ref for z in p.get("satirlar") or [])]
        if kullanan:
            raise Hata("Bu ses şu programlarda kullanılıyor: {}. Önce oradan değiştirin.".format(", ".join(kullanan)))
        sesler = db.ayar("zil_sesleri") or []
        x = next((x for x in sesler if x["id"] == g.get("id")), None)
        if x:
            try:
                (VERI / "sesler" / "k-{}.{}".format(x["id"], x["uzanti"])).unlink()
            except OSError:
                pass
            db.ayar_yaz("zil_sesleri", [s for s in sesler if s is not x])
            hepsini_uyandir()
        self.yanit({"ok": True})

    def p_zil_dinle(self, y):
        ref = self.sorgu.get("ses") or "ders"
        mime = {"wav": "audio/wav", "mp3": "audio/mpeg", "ogg": "audio/ogg", "oga": "audio/ogg", "flac": "audio/flac"}
        if ref.startswith("k:"):
            x = next((x for x in db.ayar("zil_sesleri") or [] if x["id"] == ref[2:]), None)
            yol = VERI / "sesler" / "k-{}.{}".format(x["id"], x["uzanti"]) if x else None
            if not yol or not yol.is_file():
                raise Hata("Ses yok", 404)
            return self.yanit(yol.read_bytes(), mime=mime.get(x["uzanti"], "application/octet-stream"))
        if ref == "siren":
            return self.yanit(hazir_ses("siren"), mime="audio/wav")
        tur = "teneffus" if ref == "teneffus" else "ders"
        b = (db.ayar("zil_ozel") or {}).get(tur)
        if b:
            yol = VERI / "sesler" / "{}.{}".format(tur, b["uzanti"])
            if yol.is_file():
                return self.yanit(yol.read_bytes(), mime=mime.get(b["uzanti"], "application/octet-stream"))
        self.yanit(hazir_ses(tur), mime="audio/wav")

    def p_zil_sesi(self, y):
        tur = "teneffus" if self.sorgu.get("tur") == "teneffus" else "ders"
        ozel = db.ayar("zil_ozel") or {}
        if self.sorgu.get("sil"):
            ozel.pop(tur, None)
        else:
            ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "zil.wav"))
            uzanti = (ad.rsplit(".", 1)[-1].lower() if "." in ad else "wav")
            if uzanti not in ("wav", "mp3", "ogg", "oga", "flac"):
                raise Hata("Desteklenen biçimler: WAV, MP3, OGG, FLAC")
            veri = self.ham_oku(20 * 1024 * 1024)
            (VERI / "sesler").mkdir(parents=True, exist_ok=True)
            (VERI / "sesler" / "{}.{}".format(tur, uzanti)).write_bytes(veri)
            ozel[tur] = {"ad": ad, "uzanti": uzanti, "ozet": hashlib.sha1(veri).hexdigest()[:12]}
        db.ayar_yaz("zil_ozel", ozel)
        _HAZIR_SES.pop(tur, None)
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_yedek(self, y):
        """Eski (3.x) düz JSON yedeği — geriye uyumluluk için."""
        veri = yedek_icerik()
        ad = "tahta-yonetim-yedek-{}.json".format(time.strftime("%Y%m%d"))
        self.yanit(json.dumps(veri, ensure_ascii=False, indent=1),
                   basliklar={"Content-Disposition": "attachment; filename=" + ad})

    def p_geri_yukle(self, y):
        """Şifreli (.tya) yedek: gövde dosyanın kendisi, X-Yedek-Sifre başlığında şifre.
        Eski düz JSON yedekleri de kabul edilir."""
        n = int(self.headers.get("Content-Length") or 0)
        if n > 8 * 1024 ** 3:
            raise Hata("Dosya çok büyük", 413)
        import tempfile
        fd, gecici = tempfile.mkstemp(prefix="tys-yukle-", dir=str(VERI))
        os.close(fd)
        try:
            kalan = n
            with open(gecici, "wb") as f:
                while kalan > 0:
                    parca = self.rfile.read(min(kalan, 1024 * 1024))
                    if not parca:
                        break
                    f.write(parca)
                    kalan -= len(parca)
            if kalan:
                raise Hata("Dosya eksik yüklendi")
            with open(gecici, "rb") as f:
                bas = f.read(8)
            if bas == YEDEK_IMZA:
                self.panel_sifresi_dogrula(unquote(self.headers.get("X-Panel-Sifre") or ""))
                icerik = self.yedekten_yukle(gecici, unquote(self.headers.get("X-Yedek-Sifre") or ""))
            else:
                if n > 50 * 1024 * 1024:
                    raise Hata("Bu dosya Tahta Yönetim Asistanı yedeği değil")
                try:
                    icerik = json.loads(Path(gecici).read_text(encoding="utf-8-sig"))
                except Exception:
                    raise Hata("Bu dosya Tahta Yönetim Asistanı yedeği değil")
                self.panel_sifresi_dogrula(unquote(self.headers.get("X-Panel-Sifre") or ""))
                yedek_uygula(icerik)
        finally:
            try:
                os.remove(gecici)
            except OSError:
                pass
        olay("", "sistem", "Yedekten geri yüklendi ({}, {})".format(icerik.get("tarih", ""), self.kim()))
        self.yanit({"ok": True, "tarih": icerik.get("tarih"), "surum": icerik.get("surum")})

    # ── panel: sınav ve tam ekran saat ───────────────────────────────────────
    @staticmethod
    def bugun_saat(hhmm):
        m = re.match(r"^([01]\d|2[0-3]):([0-5]\d)$", hhmm or "")
        if not m:
            raise Hata("Saat geçersiz")
        t = time.localtime()
        return time.mktime((t.tm_year, t.tm_mon, t.tm_mday, int(m.group(1)), int(m.group(2)), 0, 0, 0, -1))

    def p_sinav(self, y):
        n = simdi()
        liste = [s for s in db.ayar("sinavlar") or [] if s.get("bitis", 0) + 180 > n]
        if y == "POST":
            g = self.json_oku()
            islem = g.get("islem")
            if islem == "baslat":
                baslik = (g.get("baslik") or "").strip()[:80]
                if not baslik:
                    raise Hata("Sınavın adını yazın")
                bas = n
                if g.get("bas_saat"):
                    bas = self.bugun_saat(g["bas_saat"])
                    if bas < n - 60:
                        raise Hata("Başlangıç saati geçmiş")
                if g.get("bitis_saat"):
                    bitis = self.bugun_saat(g["bitis_saat"])
                else:
                    sure = int(g.get("sure_dk") or 0)
                    if not 1 <= sure <= 600:
                        raise Hata("Süre 1-600 dakika arasında olmalı")
                    bitis = bas + sure * 60
                if bitis <= max(bas, n):
                    raise Hata("Bitiş saati başlangıçtan sonra olmalı")
                hedef = g.get("hedef") or {"hepsi": True}
                sayi = len(hedef_cozumle(hedef))
                if not sayi:
                    raise Hata("Seçili tahta yok")
                liste.append({"id": uuid.uuid4().hex[:8], "baslik": baslik, "bas": bas, "bitis": bitis,
                              "uyari_dk": max(0, min(int(g.get("uyari_dk") or 0), 60)), "ses": bool(g.get("ses", True)),
                              "hedef": hedef, "olusma": n})
                olay("", "sinav", "Sınav: {} ({}–{}) → {}".format(baslik, time.strftime("%H:%M", time.localtime(bas)),
                                                                  time.strftime("%H:%M", time.localtime(bitis)), hedef_yazi(hedef, sayi)))
            else:
                s = next((x for x in liste if x["id"] == g.get("id")), None)
                if not s:
                    raise Hata("Sınav bulunamadı", 404)
                if islem == "uzat":
                    dk = max(1, min(int(g.get("dk") or 5), 120))
                    s["bitis"] = max(s["bitis"], n) + dk * 60
                    olay("", "sinav", "Sınav süresi uzatıldı: {} (+{} dk)".format(s["baslik"], dk))
                elif islem == "bitir":
                    s["bitis"] = min(s["bitis"], n)
                    s["bas"] = min(s["bas"], n)
                    olay("", "sinav", "Sınav bitirildi: {}".format(s["baslik"]))
                elif islem == "kapat":
                    liste = [x for x in liste if x["id"] != s["id"]]
                    olay("", "sinav", "Sınav ekranı kapatıldı: {}".format(s["baslik"]))
                else:
                    raise Hata("Geçersiz işlem")
            db.ayar_yaz("sinavlar", liste)
            hepsini_uyandir()
        for s in liste:
            s["hedef_yazi"] = hedef_yazi(s["hedef"], len(hedef_cozumle(s["hedef"])))
        self.yanit({"sinavlar": liste, "zaman": simdi()})

    def p_saat(self, y):
        liste = db.ayar("saatler") or []
        if y == "POST":
            g = self.json_oku()
            islem = g.get("islem")
            if islem == "baslat":
                hedef = g.get("hedef") or {"hepsi": True}
                sayi = len(hedef_cozumle(hedef))
                if not sayi:
                    raise Hata("Seçili tahta yok")
                liste.append({"id": uuid.uuid4().hex[:8], "mesaj": (g.get("mesaj") or "").strip()[:120],
                              "kapatilabilir": bool(g.get("kapatilabilir")), "hedef": hedef, "olusma": simdi()})
                olay("", "komut", "Tam ekran saat → {}".format(hedef_yazi(hedef, sayi)))
            elif islem == "durdur":
                liste = [s for s in liste if s["id"] != g.get("id")]
            elif islem == "durdur_tahta":
                tid = g.get("tahta")
                t = db.bir("SELECT grup FROM tahta WHERE id=?", (tid,))
                yeni = []
                for s in liste:
                    if t and hedef_kapsar(s["hedef"], tid, t["grup"]):
                        kalan = [x for x in hedef_cozumle(s["hedef"]) if x != tid]
                        if not kalan:
                            continue
                        s["hedef"] = {"idler": kalan}
                    yeni.append(s)
                liste = yeni
            elif islem == "hepsini_durdur":
                liste = []
            else:
                raise Hata("Geçersiz işlem")
            db.ayar_yaz("saatler", liste)
            hepsini_uyandir()
        for s in liste:
            s["hedef_yazi"] = hedef_yazi(s["hedef"], len(hedef_cozumle(s["hedef"])))
        self.yanit({"saatler": liste, "koruyucu_dk": db.ayar("saat_koruyucu_dk")})

    # ── panel: site engeli ───────────────────────────────────────────────────
    def p_site_engel(self, y):
        e = db.ayar("site_engel") or {}
        if y == "POST":
            g = self.json_oku()
            siteler = []
            for s in g.get("siteler") or []:
                a = alan_temizle(s)
                if a and a not in siteler:
                    siteler.append(a)
            if len(siteler) > 300:
                raise Hata("En fazla 300 site eklenebilir")
            araliklar = []
            for a in g.get("araliklar") or []:
                bas, bit = a.get("bas") or "", a.get("bit") or ""
                if not (re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bas) and re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bit)) or bas >= bit:
                    raise Hata("Saat aralığı geçersiz: {} – {}".format(bas, bit))
                gunler = sorted({int(x) for x in (a.get("gunler") or []) if 1 <= int(x) <= 7})
                if not gunler:
                    raise Hata("Her saat aralığı için en az bir gün seçin")
                araliklar.append({"gunler": gunler, "bas": bas, "bit": bit})
            zaman = "saatlerde" if g.get("zaman") == "saatlerde" else "her_zaman"
            if zaman == "saatlerde" and not araliklar:
                raise Hata("En az bir saat aralığı ekleyin")
            e = {"etkin": bool(g.get("etkin")), "siteler": siteler, "hedef": g.get("hedef") or {"hepsi": True},
                 "zaman": zaman, "araliklar": araliklar}
            if e["etkin"] and not siteler:
                raise Hata("Engellenecek en az bir site ekleyin")
            db.ayar_yaz("site_engel", e)
            olay("", "sistem", "Site engeli {} ({} site)".format("açık" if e["etkin"] else "kapalı", len(siteler)))
            hepsini_uyandir()
        self.yanit(e)

    # ── panel: arızalar ──────────────────────────────────────────────────────
    def p_arizalar(self, y):
        durum = self.sorgu.get("durum") or "acik"
        kosul, args = [], []
        if durum == "acik":
            kosul.append("durum!='cozuldu'")
        elif durum == "cozuldu":
            kosul.append("durum='cozuldu'")
        if self.sorgu.get("tahta"):
            kosul.append("tahta=?")
            args.append(self.sorgu["tahta"])
        liste = db.q("SELECT * FROM ariza" + (" WHERE " + " AND ".join(kosul) if kosul else "") +
                     " ORDER BY zaman DESC LIMIT 300", args)
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        for a in liste:
            a["tahta_ad"] = adlar.get(a["tahta"], "Silinmiş tahta")
        self.yanit({"arizalar": liste, "turler": ARIZA_TURLERI, "simge": db.ayar("ariza_simge")})

    def p_ariza(self, y):
        g = self.json_oku()
        aid = int(g.get("id") or 0)
        r = db.bir("SELECT * FROM ariza WHERE id=?", (aid,))
        if not r:
            raise Hata("Kayıt bulunamadı", 404)
        if g.get("sil"):
            db.x("DELETE FROM ariza WHERE id=?", (aid,))
            return self.yanit({"ok": True})
        durum = g.get("durum") if g.get("durum") in ("yeni", "inceleniyor", "cozuldu") else r["durum"]
        notlar = str(g["notlar"] if g.get("notlar") is not None else (r["notlar"] or ""))[:500]
        db.x("UPDATE ariza SET durum=?, notlar=?, guncelleme=? WHERE id=?", (durum, notlar, simdi(), aid))
        if durum != r["durum"]:
            olay(r["tahta"], "ariza", "Arıza ({}) → {}".format(
                r["kategori"], {"yeni": "Yeni", "inceleniyor": "İnceleniyor", "cozuldu": "Çözüldü"}[durum]))
        self.yanit({"ok": True})

    # ── panel: kullanım süreleri ─────────────────────────────────────────────
    def p_cizelge(self, y):
        gun = self.sorgu.get("gun") or time.strftime("%Y-%m-%d")
        try:
            bas = time.mktime(time.strptime(gun, "%Y-%m-%d"))
        except ValueError:
            raise Hata("Tarih geçersiz")
        son = bas + 86400
        araliklari_yaz()
        satirlar = db.q("SELECT tahta, tur, ad, bas, bit FROM aralik WHERE bas<? AND bit>?", (son, bas))
        self.yanit({"gun": gun, "bas": bas, "son": son, "tahtalar": db.q("SELECT id, ad, grup FROM tahta"),
                    "araliklar": [[s["tahta"], s["tur"], s["ad"], max(s["bas"], bas), min(s["bit"], son)] for s in satirlar]})

    def ogretmen_verisi(self, gun_sayisi):
        araliklari_yaz()
        bas = time.mktime(time.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d")) - (gun_sayisi - 1) * 86400
        adlar = {r["id"]: r["ad"] for r in db.q("SELECT id, ad FROM tahta")}
        ozet = {}
        for s in db.q("SELECT tahta, ad, bas, bit FROM aralik WHERE tur='ogretmen' AND bit>?", (bas,)):
            sure = s["bit"] - max(s["bas"], bas)
            if sure <= 0:
                continue
            o = ozet.setdefault(s["ad"], {"sure": 0.0, "gunler": set(), "tahtalar": {}, "son": 0.0})
            o["sure"] += sure
            o["gunler"].add(time.strftime("%Y-%m-%d", time.localtime(max(s["bas"], bas))))
            ta = adlar.get(s["tahta"], "Silinmiş tahta")
            o["tahtalar"][ta] = o["tahtalar"].get(ta, 0) + sure
            o["son"] = max(o["son"], s["bit"])
        liste = [{"ad": ad, "sure": o["sure"], "gun": len(o["gunler"]), "son": o["son"],
                  "tahtalar": sorted(o["tahtalar"].items(), key=lambda x: -x[1])[:5]} for ad, o in ozet.items()]
        return sorted(liste, key=lambda x: -x["sure"])

    def p_ogretmenler(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        self.yanit({"ogretmenler": self.ogretmen_verisi(gun), "gun": gun, "pin_sayisi": len(db.ayar("pinler"))})

    def p_ogretmenler_csv(self, y):
        gun = max(1, min(int(self.sorgu.get("gun") or 30), 365))
        tampon = io.StringIO()
        w = csv.writer(tampon, delimiter=";")
        w.writerow(["Öğretmen", "Toplam kullanım (saat)", "Gün sayısı", "En çok kullandığı tahtalar", "Son kullanım"])
        for o in self.ogretmen_verisi(gun):
            w.writerow([o["ad"], str(round(o["sure"] / 3600, 2)).replace(".", ","), o["gun"],
                        ", ".join(t for t, _ in o["tahtalar"][:3]), time.strftime("%d.%m.%Y %H:%M", time.localtime(o["son"]))])
        self.yanit(("﻿" + tampon.getvalue()).encode("utf-8"), mime="text/csv; charset=utf-8", basliklar={
            "Content-Disposition": "attachment; filename=ogretmen-kullanim-raporu.csv"})

    # ── panel: ortak klasör ──────────────────────────────────────────────────
    def p_ortak(self, y):
        o = depo.ozet_bilgi()
        cihazlar = []
        for r in db.q("SELECT * FROM tahta ORDER BY ad COLLATE NOCASE"):
            c = canli.get(r["id"])
            d = (c.durum if c else {}) or {}
            cihazlar.append({"id": r["id"], "ad": r["ad"], "tur": "tahta", "cevrimici": cevrimici_mi(c),
                             "ortak": d.get("ortak"), "son": r["son"]})
        for r in db.q("SELECT * FROM istemci ORDER BY ad COLLATE NOCASE"):
            b = json.loads(r["bilgi"] or "{}")
            cihazlar.append({"id": r["id"], "ad": r["ad"], "tur": "bilgisayar", "cevrimici": simdi() - (r["son"] or 0) < 150,
                             "ortak": b.get("ortak"), "son": r["son"], "kullanici": b.get("kullanici"), "ip": b.get("ip")})
        o.update(cihazlar=cihazlar, islemler=db.q("SELECT * FROM olay WHERE tur='ortak' ORDER BY zaman DESC LIMIT 25"),
                 adresler=yerel_adresler(), port=PORT, windows=os.name == "nt",
                 yerel=self.client_address[0] in ("127.0.0.1", "::1"))
        self.yanit(o)

    def p_ortak_ayar(self, y):
        g = self.json_oku()
        a = depo.ayar()
        if "etkin" in g:
            a["etkin"] = bool(g["etkin"])
        if "kota_gb" in g:
            a["kota_gb"] = max(1, min(int(g["kota_gb"] or 20), 4000))
        if g.get("tahta_izin") in ("tam", "ekleme"):
            a["tahta_izin"] = g["tahta_izin"]
        db.ayar_yaz("ortak", a)
        depo.bildir()
        hepsini_uyandir()
        self.yanit({"ok": True})

    def p_ortak_cop(self, y):
        self.yanit({"cop": depo.cop_listesi()})

    def p_ortak_geri(self, y):
        self.yanit(depo.geri_yukle(self.json_oku().get("id"), "Yönetici"))

    def p_ortak_cop_sil(self, y):
        g = self.json_oku()
        for r in (depo.cop_listesi() if g.get("hepsi") else [{"id": g.get("id")}]):
            depo.cop_sil(r["id"])
        self.yanit({"ok": True})

    def p_ortak_surumler(self, y):
        if self.sorgu.get("yol"):
            return self.yanit({"surumler": depo.surumler(self.sorgu["yol"])})
        self.yanit({"surumler": db.q("SELECT * FROM ortak_surum ORDER BY zaman DESC LIMIT 60")})

    def p_ortak_surum_geri(self, y):
        self.yanit(depo.surum_geri(self.json_oku().get("id"), "Yönetici"))

    def p_ortak_klasoru_ac(self, y):
        if os.name != "nt" or self.client_address[0] not in ("127.0.0.1", "::1"):
            raise Hata("Klasör yalnızca yönetim bilgisayarının kendisinden açılabilir")
        os.startfile(str(depo.kok))
        self.yanit({"ok": True})

    def p_tani(self, y):
        metin = tani_raporu()
        ad = "tani-raporu-{}.txt".format(datetime.now().strftime("%Y%m%d-%H%M"))
        self.yanit(("\ufeff" + metin).encode("utf-8"), mime="text/plain; charset=utf-8",
                   basliklar={"Content-Disposition": "attachment; filename=" + ad})

    def p_istemci_sil(self, y):
        db.x("DELETE FROM istemci WHERE id=?", (self.json_oku().get("id"),))
        self.yanit({"ok": True})

    # ── Ortak Klasör web sayfası (öğretmenler) ───────────────────────────────
    def o_giris(self, y):
        ip = self.client_address[0]
        anahtar = ("pin", ip)
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(anahtar, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        p = pin_bul(self.json_oku().get("pin"))
        if not p:
            denemeler.append(n)
            giris_denemeleri[anahtar] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(anahtar, None)
        b = secrets.token_urlsafe(32)
        db.x("INSERT INTO oturum(belirtec, bitis, tur, ad) VALUES(?,?,?,?)",
             (hashlib.sha256(b.encode()).hexdigest(), n + 12 * 3600, "ogretmen", p["ad"]))
        olay("", "giris", "Ortak Klasör sayfasına giriş: {} ({})".format(p["ad"], ip))
        self.yanit({"ok": True, "ad": p["ad"]}, basliklar={
            "Set-Cookie": "tyso={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(b, 12 * 3600)})

    def o_cikis(self, y):
        b = self.cerez("tyso")
        if b:
            db.x("DELETE FROM oturum WHERE belirtec=?", (hashlib.sha256(b.encode()).hexdigest(),))
        self.yanit({"ok": True}, basliklar={"Set-Cookie": "tyso=; Path=/; Max-Age=0"})

    def o_bilgi(self, y):
        k = self.kullanici
        kullanilan, sayi = depo.kullanilan()
        self.yanit({"okul_adi": db.ayar("okul_adi"), "giris": bool(k), "ad": k["ad"] if k else None,
                    "yonetici": bool(k and k["yonetici"]), "etkin": depo.etkin(), "kota": depo.kota(),
                    "kullanilan": kullanilan, "dosya": sayi, "kurulum_tamam": db.ayar("kurulum_tamam")})

    def o_kim(self):
        return self.kullanici["ad"] + ("" if self.kullanici["yonetici"] else " (web)")

    def o_liste(self, y):
        klasor, ogeler = depo.icerik(self.sorgu.get("klasor") or "")
        self.yanit({"klasor": klasor, "ogeler": ogeler})

    def o_indir(self, y):
        p, r = depo.indir_yolu(self.sorgu.get("yol") or "")
        mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        guvenli = mime == "application/pdf" or mime == "text/plain" or \
            mime.split("/")[0] in ("video", "audio") or mime in ("image/png", "image/jpeg", "image/gif", "image/webp")
        ac = self.sorgu.get("ac") == "1" and guvenli
        self.dosya_gonder(p, ad=p.name, satir_ici=ac, mime=mime if ac else "application/octet-stream")

    def o_yukle(self, y):
        if y != "POST":
            raise Hata("Geçersiz istek")
        n = int(self.headers.get("Content-Length") or 0)
        self.yanit(depo.yukle(unquote(self.headers.get("X-Yol") or ""), self.rfile, n, self.o_kim(),
                              mtime=float(self.headers.get("X-Mtime") or 0) or None, ustune=True))

    def o_klasor(self, y):
        self.yanit(depo.klasor(self.json_oku().get("yol") or "", self.o_kim()))

    def o_sil(self, y):
        self.yanit(depo.sil_agac(self.json_oku().get("yol") or "", self.o_kim()))

    def o_istemci_kur(self, y):
        host = (self.headers.get("Host") or "").strip()
        if not re.match(r"^[A-Za-z0-9.\-]+(:\d+)?$", host):
            raise Hata("Geçersiz adres")
        if host.split(":")[0] in ("localhost", "127.0.0.1"):
            host = "{}:{}".format((yerel_adresler() or ["127.0.0.1"])[0], PORT)
        if ":" not in host:
            host = "{}:{}".format(host, PORT)
        ps = KUR_PS1.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
        bat = (ISTEMCI_BAT.replace("__SUNUCU__", "http://" + host).replace("__ANAHTAR__", db.ayar("istemci_anahtar"))
               .replace("__KIMLIK__", db.ayar("kimlik")) + "#TYS-PS1#\n" + ps).replace("\n", "\r\n")
        self.yanit(bat.encode("utf-8"), mime="application/octet-stream", basliklar={
            "Content-Disposition": "attachment; filename=OrtakKlasor-Kurulum.bat"})

    def o_tahta_anahtar(self, y):
        """Windows tahta kurulumu (KUR.bat › 3): panel yönetici şifresiyle tahta anahtarını verir."""
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        yon = yonetici_bul(self.json_oku().get("sifre") or "")
        if not yon:
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        giris_denemeleri.pop(ip, None)
        olay("", "sistem", "Windows tahta kurulumu için anahtar verildi: {} ({})".format(yon["ad"], ip))
        self.yanit({"anahtar": db.ayar("anahtar"), "kimlik": db.ayar("kimlik")})

    def o_istemci_anahtar(self, y):
        ip = self.client_address[0]
        anahtar = ("pin", ip)
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(anahtar, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        p = pin_bul(self.json_oku().get("pin"))
        if not p:
            denemeler.append(n)
            giris_denemeleri[anahtar] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı", 401)
        olay("", "ortak", "Öğretmen bilgisayarı kurulumu: {} ({})".format(p["ad"], ip))
        self.yanit({"anahtar": db.ayar("istemci_anahtar"), "kimlik": db.ayar("kimlik"), "ad": socket.gethostname()})

    # ═════════════════════════════════════════════════════════════════════════
    # 4.0
    # ═════════════════════════════════════════════════════════════════════════
    def oturum_ozeti(self):
        b = self.cerez()
        return hashlib.sha256(b.encode()).hexdigest() if b else ""

    def goruntu_acik(self):
        k = self.oturum_ozeti()
        with GORUNTU_KILIT:
            v = GORUNTU.get(k)
            if v and v["bitis"] > simdi():
                return v
            GORUNTU.pop(k, None)
        return None

    def kim(self):
        y = self.yonetici()
        return y["ad"] if y else ""

    def panel_sifresi_dogrula(self, sifre):
        """Oturumu açık yöneticinin KENDİ tam şifresini doğrular (PIN geçmez)."""
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get(ip, []) if n - t < 300]
        if len(denemeler) >= 8:
            raise Hata("Çok fazla hatalı deneme. 5 dakika sonra tekrar deneyin.", 429)
        ben = self.yonetici()
        y = yonetici_bul(sifre or "")
        if not ben or not y or y["id"] != ben["id"]:
            denemeler.append(n)
            giris_denemeleri[ip] = denemeler
            time.sleep(0.6)
            raise Hata("Şifre hatalı (oturumu açık yöneticinin kendi şifresi gerekir)", 403)
        giris_denemeleri.pop(ip, None)
        return ben

    # ── ekran görüntüleri: göster / gizle ────────────────────────────────────
    def p_goruntu(self, y):
        if y == "POST":
            g = self.json_oku()
            islem = g.get("islem")
            k = self.oturum_ozeti()
            if islem == "goster":
                ben = self.panel_sifresi_dogrula(g.get("sifre"))
                with GORUNTU_KILIT:
                    GORUNTU[k] = {"bitis": simdi() + GORUNTU_SURE, "kim": ben["ad"]}
                olay("", "giris", "Ekran görüntüleri gösterildi: {} ({})".format(ben["ad"], self.client_address[0]))
                onizleme_iste()
            elif islem == "gizle":
                with GORUNTU_KILIT:
                    GORUNTU.pop(k, None)
            elif islem == "canli":
                with GORUNTU_KILIT:
                    v = GORUNTU.get(k)
                    if v and v["bitis"] > simdi():
                        v["bitis"] = simdi() + GORUNTU_SURE
        v = self.goruntu_acik()
        self.yanit({"acik": bool(v), "kalan": int(v["bitis"] - simdi()) if v else 0, "sure": GORUNTU_SURE})

    # ── nöbet çizelgesi ve belirli gün / haftalar ────────────────────────────
    def p_nobet(self, y):
        nobet = db.ayar("nobet") or {}
        if y == "POST":
            g = self.json_oku(sinir=4 * 1024 * 1024)
            islem = g.get("islem") or "kaydet"
            tablolar = list(nobet.get("tablolar") or [])
            if islem == "kaydet":
                t = nobet_dogrula(g.get("tablo") or {})
                anahtar = (t["tur"], t.get("hafta"), t.get("ay"), t.get("tarih"))
                tablolar = [x for x in tablolar if x.get("id") != t["id"] and
                            (x.get("tur"), x.get("hafta"), x.get("ay"), x.get("tarih")) != anahtar]
                tablolar.append(t)
                olay("", "sistem", "Nöbet çizelgesi kaydedildi ({})".format(
                    {"haftalik": "haftalık", "aylik": "aylık", "gunluk": "günlük"}[t["tur"]]))
            elif islem == "sil":
                tablolar = [x for x in tablolar if x.get("id") != g.get("id")]
            elif islem == "baslik":
                nobet["baslik"] = re.sub(r"\s+", " ", str(g.get("baslik") or "")).strip()[:60] or "Bugünün Nöbetçileri"
            else:
                raise Hata("Geçersiz işlem")
            tablolar.sort(key=lambda x: (x.get("tur"), x.get("hafta") or x.get("ay") or x.get("tarih") or ""))
            nobet["tablolar"] = tablolar[-300:]
            db.ayar_yaz("nobet", nobet)
            hepsini_uyandir()
        from datetime import date, timedelta
        bugun = date.fromtimestamp(simdi())
        onizleme = []
        for i in range(7):
            d = bugun + timedelta(days=i)
            n = nobet_gun(d, nobet)
            onizleme.append({"tarih": d.isoformat(), "satirlar": n["satirlar"], "kaynak": n["kaynak"], "tatil": n.get("tatil"),
                             **bgh_gun(d)})
        ogretmenler = sorted({p["ad"] for p in db.ayar("pinler") or [] if p.get("ad") and p["ad"] != "Ortak şifre"},
                             key=lambda s: s.lower())
        self.yanit({"nobet": nobet, "onizleme": onizleme, "ogretmenler": ogretmenler,
                    "gorunum": db.ayar("okul_gorunum"), "logo": db.ayar("okul_logo"), "kademe": db.ayar("kademe") or []})

    def p_bgh(self, y):
        if y == "POST":
            g = self.json_oku(sinir=2 * 1024 * 1024)
            if g.get("islem") == "hazir":
                db.ayar_yaz("bgh", {"liste": None})
                olay("", "sistem", "Belirli gün ve haftalar hazır listeye döndürüldü")
            else:
                db.ayar_yaz("bgh", {"liste": bgh_dogrula(g.get("liste"))})
                olay("", "sistem", "Belirli gün ve haftalar güncellendi")
            hepsini_uyandir()
        from datetime import date, timedelta
        liste = bgh_liste()
        bugun = date.fromtimestamp(simdi())
        yakin = []
        for e in liste:
            if not e.get("aktif", True):
                continue
            for yil in (bugun.year, bugun.year + 1):
                a = bgh_aralik(e, yil)
                if a and a[1] >= bugun and (a[0] - bugun).days <= 45:
                    yakin.append({"id": e["id"], "ad": e["ad"], "tur": e["tur"], "bas": a[0].isoformat(), "bit": a[1].isoformat()})
                    break
        yakin.sort(key=lambda x: x["bas"])
        kademe = db.ayar("kademe") or []
        for e in liste:
            a = bgh_aralik(e, bugun.year if bugun.month >= 9 else bugun.year - 1) or bgh_aralik(e, bugun.year)
            e["bu_yil"] = [a[0].isoformat(), a[1].isoformat()] if a else None
            e["kademede"] = not kademe or not e.get("kademe") or bool(set(kademe) & set(e["kademe"]))
        self.yanit({"liste": liste, "hazir": (db.ayar("bgh") or {}).get("liste") is None, "yakin": yakin[:20],
                    "kademe": kademe, "kademeler": KADEMELER})

    def p_okul_gorunum(self, y):
        g = self.json_oku()
        eski = db.ayar("okul_gorunum") or {}
        s = g.get("serit") or {}
        n = g.get("giris_notu") or {}
        yeni = {
            "mod": g.get("mod") if g.get("mod") in ("arka_plan", "serit", "ikisi", "kapali") else "arka_plan",
            "hedef": g.get("hedef") or eski.get("hedef") or {"hepsi": True},
            "bgh_goster": bool(g.get("bgh_goster", True)),
            "serit": {"taraf": "sol" if s.get("taraf") == "sol" else "sag",
                      "genislik": max(220, min(int(s.get("genislik") or 340), 900)),
                      "yazi": max(70, min(int(s.get("yazi") or 100), 200)),
                      "saydamlik": max(40, min(int(s.get("saydamlik") or 88), 100))},
            "giris_notu": {"etkin": bool(n.get("etkin")), "kaynak": "metin" if n.get("kaynak") == "metin" else "nobet",
                           "metin": str(n.get("metin") or "").strip()[:600]},
            "kaydedildi": True,
        }
        db.ayar_yaz("okul_gorunum", yeni)
        if "logo" in g:
            l = g.get("logo")
            if l and l.get("sha"):
                if not re.match(r"^[a-f0-9]{64}$", l["sha"]) or not (DEPO_DIZIN / l["sha"]).is_file():
                    raise Hata("Logo dosyası bulunamadı")
                db.ayar_yaz("okul_logo", {"sha": l["sha"], "ad": guvenli_ad(l.get("ad") or "logo.png")})
            else:
                db.ayar_yaz("okul_logo", None)
        olay("", "sistem", "Nöbet / belirli gün görünüm ayarı değişti")
        hepsini_uyandir()
        self.yanit({"ok": True, "gorunum": yeni})

    def p_kademe(self, y):
        g = self.json_oku()
        k = [x for x in (g.get("kademe") or []) if x in KADEME_KODLARI]
        db.ayar_yaz("kademe", k)
        olay("", "sistem", "Okul kademesi: {}".format(", ".join(a for c, a in KADEMELER if c in k) or "belirtilmedi"))
        hepsini_uyandir()
        self.yanit({"ok": True, "kademe": k})

    # ── açılış görselleri ────────────────────────────────────────────────────
    def p_acilis(self, y):
        liste = db.ayar("acilis_gorseller") or []
        if y == "POST":
            g = self.json_oku()
            if g.get("islem") == "sil":
                liste = [a for a in liste if a.get("id") != g.get("id")]
            else:
                a = g.get("gorsel") or {}
                if not re.match(r"^[a-f0-9]{64}$", str(a.get("sha") or "")) or not (DEPO_DIZIN / a["sha"]).is_file():
                    raise Hata("Görsel seçin")
                bas, bit = str(a.get("bas") or ""), str(a.get("bit") or a.get("bas") or "")
                if not TARIH_DESEN.match(bas) or not TARIH_DESEN.match(bit) or bit < bas:
                    raise Hata("Tarih aralığı geçersiz")
                saat = str(a.get("saat") or "")
                if saat and not SAAT_DESEN.match(saat):
                    raise Hata("Saat geçersiz")
                hedef = a.get("hedef") or {"hepsi": True}
                if not hedef_cozumle(hedef):
                    raise Hata("Seçili tahta yok")
                d = {"id": a.get("id") or uuid.uuid4().hex[:10], "ad": str(a.get("ad") or "Açılış görseli").strip()[:80],
                     "sha": a["sha"], "dosya": guvenli_ad(a.get("dosya") or "gorsel.png"), "bas": bas, "bit": bit,
                     "saat": saat, "sure": max(5, min(int(a.get("sure") or 30), 3600)),
                     "kapatilabilir": bool(a.get("kapatilabilir", True)), "hedef": hedef,
                     "aktif": bool(a.get("aktif", True)), "kim": self.kim(), "zaman": simdi()}
                liste = [x for x in liste if x.get("id") != d["id"]] + [d]
                olay("", "sistem", "Açılış görseli planlandı: {} ({} – {}{})".format(
                    d["ad"], bas, bit, ", " + saat if saat else ", ilk açılışta"))
            bugun = time.strftime("%Y-%m-%d")
            liste = [a for a in liste if a.get("bit", "") >= bugun or a.get("zaman", 0) > simdi() - 60 * 86400]
            liste.sort(key=lambda a: a.get("bas", ""))
            db.ayar_yaz("acilis_gorseller", liste[-200:])
            hepsini_uyandir()
        resimler = [{"sha": r["sha"], "ad": r["ad"]} for r in db.q(
            "SELECT sha, ad FROM depo WHERE tur='resim' ORDER BY eklenme DESC LIMIT 200")]
        for a in liste:
            a["hedef_yazi"] = hedef_yazi(a.get("hedef"), len(hedef_cozumle(a.get("hedef"))))
        self.yanit({"gorseller": liste, "resimler": resimler})

    def p_gorsel(self, y):
        """Panelde önizleme için depodaki resim (yalnızca resim türü)."""
        sha = self.sorgu.get("sha", "")
        r = db.bir("SELECT ad, tur FROM depo WHERE sha=?", (sha,)) if re.match(r"^[a-f0-9]{64}$", sha) else None
        logo = db.ayar("okul_logo")
        if not r and not (logo and logo.get("sha") == sha):
            raise Hata("Bulunamadı", 404)
        if r and r["tur"] != "resim":
            raise Hata("Bulunamadı", 404)
        p = DEPO_DIZIN / sha
        if not p.is_file():
            raise Hata("Bulunamadı", 404)
        ad = (r or {}).get("ad") or logo.get("ad") or "resim"
        mime = mimetypes.guess_type(ad)[0] or "image/png"
        if not mime.startswith("image/"):
            mime = "image/png"
        self.dosya_gonder(p, mime=mime, ek={"Cache-Control": "private, max-age=86400"})

    # ── işlem sonuçları ──────────────────────────────────────────────────────
    def p_islemler(self, y):
        sinir = max(1, min(int(self.sorgu.get("sayi") or 50), 300))
        self.yanit({"islemler": [islem_ozet(r) for r in db.q("SELECT * FROM islem ORDER BY zaman DESC LIMIT ?", (sinir,))]})

    def p_islem(self, y):
        r = db.bir("SELECT * FROM islem WHERE id=?", (self.sorgu.get("id", ""),))
        if not r:
            raise Hata("İşlem bulunamadı", 404)
        self.yanit(islem_ozet(r, ayrinti=True))

    def p_islem_tekrar(self, y):
        g = self.json_oku()
        r = db.bir("SELECT * FROM islem WHERE id=?", (g.get("id") or "",))
        if not r:
            raise Hata("İşlem bulunamadı", 404)
        o = islem_ozet(r, ayrinti=True)
        idler = [t["tahta"] for t in o["tahtalar"] if t["durum"] in ("hata", "yanitsiz", "kapali")]
        idler = [t for t in idler if db.bir("SELECT id FROM tahta WHERE id=?", (t,))]
        if not idler:
            raise Hata("Yeniden denenecek tahta yok")
        veri = json.loads(r["veri"] or "{}")
        if r["tur"] in ("sifre_degistir", "donem_temizle"):
            raise Hata("Bu işlem güvenlik nedeniyle yeniden gönderilemez; işlemi baştan başlatın")
        acik = [t for t in idler if cevrimici_mi(canli.get(t))]
        yeni = islem_baslat(r["tur"], r["ad"] + " (yeniden)", veri, idler, acik, self.kim(),
                            "{} tahta".format(len(idler)))
        olay("", "komut", "{} yeniden gönderildi → {} tahta".format(r["ad"], len(acik)))
        self.yanit({"ok": True, "id": yeni, "gonderilen": len(acik), "kapali": len(idler) - len(acik)})

    # ── tahta sağlığı ────────────────────────────────────────────────────────
    def a_saglik(self, g):
        tid = str(g.get("id") or "")
        if not db.bir("SELECT id FROM tahta WHERE id=?", (tid,)):
            raise Hata("Tahta bulunamadı", 404)
        v = g.get("veri") or {}
        if not isinstance(v, dict):
            raise Hata("Geçersiz veri")
        db.x("INSERT OR REPLACE INTO saglik(tahta, veri, zaman) VALUES(?,?,?)",
             (tid, json.dumps(v, ensure_ascii=False)[:60000], simdi()))
        return {"ok": True}

    def saglik_listesi(self):
        kayit = {r["tahta"]: r for r in db.q("SELECT * FROM saglik")}
        liste = []
        for t in db.q("SELECT * FROM tahta ORDER BY ad COLLATE NOCASE"):
            oz = tahta_ozeti(t)
            r = kayit.get(t["id"])
            v = json.loads(r["veri"]) if r else {}
            if oz["cevrimici"]:
                for k in ("disk", "ram", "sicaklik", "calisma_sn"):
                    if oz.get(k) is not None:
                        v[k] = oz[k]
            seviye, uyarilar = saglik_degerlendir(v, oz["cevrimici"], t["son"])
            liste.append({"id": t["id"], "ad": t["ad"], "grup": t["grup"] or "", "cevrimici": oz["cevrimici"],
                          "ip": oz["ip"], "mac": oz["mac"], "son": t["son"], "zaman": r["zaman"] if r else None,
                          "veri": v, "seviye": seviye, "uyarilar": uyarilar})
        liste.sort(key=lambda x: (-x["seviye"], x["ad"].lower()))
        return liste


    # ── 4.2: Tahta Onarım Belleği'nin kullandığı uçlar (belirteçle) ──────────
    def onarim_genel(self, yontem, ad):
        ip = self.client_address[0]
        n = simdi()
        denemeler = [t for t in giris_denemeleri.get("bellek:" + ip, []) if n - t < 300]
        if len(denemeler) >= 20:
            raise Hata("Çok fazla hatalı deneme", 429)
        try:
            bellek = bellek_dogrula(self.sorgu.get("b") or "")
        except Hata:
            giris_denemeleri["bellek:" + ip] = denemeler + [n]
            raise
        host = self.headers.get("Host")
        if yontem == "GET" and ad == "k":
            olay("", "sistem", "Onarım belleğiyle tahta kurulumu başladı ({})".format(ip))
            return self.kurulum_betigi(host, ad=self.sorgu.get("ad", ""))
        if yontem == "GET" and ad == "w":
            olay("", "sistem", "Onarım belleğiyle Windows tahta kurulumu başladı ({})".format(ip))
            return self.windows_kurulum(host)
        if yontem == "GET" and ad == "kimlik":
            tid = str(self.sorgu.get("id") or "")
            macler = {m.strip().lower() for m in str(self.sorgu.get("mac") or "").split(",") if m.strip()}
            r = db.bir("SELECT bilgi FROM tahta WHERE id=?", (tid,))
            kayitli = (json.loads(r["bilgi"] or "{}").get("mac") or "").lower() if r else ""
            # Kayıtlı tahta bu kimlikle başka bir ağ kartından bağlanıyorsa: aynı imajdan kurulmuş iki tahta
            cakisma = bool(r and kayitli and macler and kayitli not in macler and cevrimici_mi(canli.get(tid)))
            return self.yanit({"kayitli": bool(r), "cakisma": cakisma or (bool(r) and kimlik_cakisma(tid))})
        if yontem == "POST" and ad == "rapor":
            rapor = json.loads(self.ham_oku(2 * 1024 * 1024).decode("utf-8-sig") or "{}")
            tid, yeni = onarim_rapor_al(rapor, "bellek")
            if yeni:
                olay(tid if not tid.startswith("bellek:") else "", "sistem", "Onarım belleğinden rapor geldi: {}".format(
                    (rapor.get("cihaz") or {}).get("hostname") or ip))
            return self.yanit({"ok": True})
        raise Hata("Bulunamadı", 404)

    # ── 4.2: Tanıla ve onar (panel) ──────────────────────────────────────────
    def p_tani(self, y):
        if y == "POST":
            g = self.json_oku()
            if g.get("islem") == "sil":
                db.x("DELETE FROM tani WHERE tahta=?", (str(g.get("tahta") or ""),))
                return self.yanit({"ok": True})
            raise Hata("Geçersiz işlem")
        tid = self.sorgu.get("tahta")
        if tid:
            r = db.bir("SELECT * FROM tani WHERE tahta=? ORDER BY zaman DESC LIMIT 1", (tid,))
            gecmis = [{"zaman": x["zaman"], "kaynak": x["kaynak"], "ozet": json.loads(x["ozet"] or "{}")}
                      for x in db.q("SELECT zaman, kaynak, ozet FROM tani WHERE tahta=? ORDER BY zaman DESC LIMIT 10", (tid,))]
            return self.yanit({"tahta": tid, "ad": tahta_adi(tid) if not tid.startswith("bellek:") else tid.split(":")[1],
                               "son": dict(json.loads(r["veri"]), zaman_kayit=r["zaman"], kaynak=r["kaynak"]) if r else None,
                               "gecmis": gecmis, "cevrimici": cevrimici_mi(canli.get(tid)), "kimlik_cakisma": kimlik_cakisma(tid)})
        son = {}
        for x in db.q("SELECT tahta, zaman, kaynak, ozet FROM tani ORDER BY zaman"):
            son[x["tahta"]] = {"zaman": x["zaman"], "kaynak": x["kaynak"], "ozet": json.loads(x["ozet"] or "{}")}
        sert = db.ayar("ag_sertifika") or {}
        bellek = [dict(v, tahta=k, ad=k.split(":")[1]) for k, v in son.items() if k.startswith("bellek:")]
        self.yanit({"tahtalar": {k: v for k, v in son.items() if not k.startswith("bellek:")},
                    "bellek_raporlari": sorted(bellek, key=lambda x: -x["zaman"])[:50],
                    "sertifika": {k: sert.get(k) for k in ("ad", "konu", "veren", "bitis", "eklenme")} if sert.get("pem") else None})

    def p_ag_sertifika(self, y):
        if y != "POST":
            sert = db.ayar("ag_sertifika") or {}
            return self.yanit({k: sert.get(k) for k in ("ad", "konu", "veren", "bitis", "eklenme")} if sert.get("pem") else {})
        if (self.headers.get("Content-Type") or "").startswith("application/json"):
            g = self.json_oku()
            if g.get("islem") == "sil":
                db.ayar_yaz("ag_sertifika", {})
                olay("", "sistem", "Okul ağı sertifikası panelden kaldırıldı")
                return self.yanit({"ok": True})
            raise Hata("Geçersiz işlem")
        ham = self.ham_oku(256 * 1024)
        pem, bilgi = pem_cikar(ham)
        ad = guvenli_ad(unquote(self.headers.get("X-Dosya-Adi") or "sertifika.crt"))[:120]
        db.ayar_yaz("ag_sertifika", dict(bilgi, pem=pem, ad=ad, eklenme=simdi(), kim=self.kim()))
        olay("", "sistem", "Okul ağı sertifikası yüklendi: {} ({})".format(bilgi.get("konu") or ad, self.kim()))
        self.yanit({"ok": True, "konu": bilgi.get("konu"), "veren": bilgi.get("veren"), "bitis": bilgi.get("bitis")})

    # ── 4.2: Tahta Onarım Belleği (panel) ────────────────────────────────────
    def p_onarim_bellek(self, y):
        bellekler = db.ayar("onarim_bellekler") or []
        if y != "POST":
            return self.yanit({"bellekler": [{k: b.get(k) for k in ("id", "ad", "olusturma", "bitis", "iptal", "kim", "surucu")}
                                             for b in sorted(bellekler, key=lambda x: -x.get("olusturma", 0))[:30]],
                               "suruculer": cikarilabilir_suruculer(), "sure_gun": BELLEK_SURE_GUN,
                               "sertifika": bool((db.ayar("ag_sertifika") or {}).get("pem"))})
        g = self.json_oku()
        islem = g.get("islem")
        if islem == "iptal":
            for b in bellekler:
                if b.get("id") == g.get("id"):
                    b["iptal"] = simdi()
            db.ayar_yaz("onarim_bellekler", bellekler)
            olay("", "sistem", "Onarım belleği iptal edildi ({})".format(self.kim()))
            return self.yanit({"ok": True})
        if islem == "raporlari_al":
            alinan, yeni = 0, 0
            for sr in cikarilabilir_suruculer():
                for f in sorted(Path(sr["yol"]).glob("TahtaOnarim/raporlar/*.json"))[-300:]:
                    try:
                        _, y_ = onarim_rapor_al(json.loads(f.read_bytes().decode("utf-8-sig")), "bellek")
                        alinan += 1
                        yeni += int(y_)
                    except Exception:
                        pass
            return self.yanit({"ok": True, "alinan": alinan, "yeni": yeni})
        if islem != "olustur":
            raise Hata("Geçersiz işlem")
        adresler = [a for a in yerel_adresler() if not a.startswith(SANAL_AGLAR)] or yerel_adresler()
        if not adresler:
            raise Hata("Bu bilgisayarın ağ adresi bulunamadı")
        belirtec = secrets.token_urlsafe(24)
        n = simdi()
        bellek = {"id": uuid.uuid4().hex[:10], "ozet": hashlib.sha256(belirtec.encode()).hexdigest(), "olusturma": n,
                  "bitis": n + BELLEK_SURE_GUN * 86400, "iptal": None, "kim": self.kim(),
                  "ad": (str(g.get("ad") or "").strip()[:40] or "Onarım belleği")}
        dosyalar = onarim_dosyalari(belirtec, bellek, adresler)
        surucu = g.get("surucu")
        if surucu:
            gecerli = {d["yol"]: d for d in cikarilabilir_suruculer()}
            if surucu not in gecerli:
                raise Hata("USB bellek bulunamadı; çıkarılmış olabilir. Listeyi yenileyin.")
            kok = Path(surucu)
            for rel, veri in dosyalar.items():
                hedef = kok / rel
                hedef.parent.mkdir(parents=True, exist_ok=True)
                hedef.write_bytes(veri)
            bellek["surucu"] = gecerli[surucu]["ad"]
            bellekler.append(bellek)
            db.ayar_yaz("onarim_bellekler", bellekler[-50:])
            olay("", "sistem", "Onarım belleği hazırlandı: {} ({})".format(bellek["surucu"], self.kim()))
            return self.yanit({"ok": True, "surucu": bellek["surucu"], "bitis": bellek["bitis"]})
        import zipfile
        tampon = io.BytesIO()
        with zipfile.ZipFile(tampon, "w", zipfile.ZIP_DEFLATED) as z:
            for rel, veri in dosyalar.items():
                bilgi = zipfile.ZipInfo(rel, date_time=time.localtime(n)[:6])
                bilgi.external_attr = (0o755 if rel.endswith(".sh") else 0o644) << 16
                bilgi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(bilgi, veri)
        bellek["surucu"] = "ZIP olarak indirildi"
        bellekler.append(bellek)
        db.ayar_yaz("onarim_bellekler", bellekler[-50:])
        olay("", "sistem", "Onarım belleği (ZIP) hazırlandı ({})".format(self.kim()))
        self.yanit(tampon.getvalue(), mime="application/zip", basliklar={
            "Content-Disposition": "attachment; filename=TahtaOnarimBellegi.zip"})

    def p_onarim_rapor(self, y):
        """Panelden yüklenen bellek raporu (.json)."""
        ham = self.ham_oku(2 * 1024 * 1024)
        try:
            rapor = json.loads(ham.decode("utf-8-sig"))
        except ValueError:
            raise Hata("Dosya bir onarım raporu değil (.json)")
        tid, yeni = onarim_rapor_al(rapor, "bellek")
        self.yanit({"ok": True, "tahta": tid, "yeni": yeni})

    def p_yazici_firmware(self, y):
        """HP firmware'ini internetten (foo2zjs projesi) depoya indirir."""
        g = self.json_oku()
        ad = str(g.get("ad") or "")
        if not re.match(r"^sihpP?\d{4}$", ad):
            raise Hata("Geçersiz firmware adı")
        adres = "http://foo2zjs.linkevich.net/foo2zjs/firmware/{}.tar.gz".format(ad)
        try:
            with urllib.request.build_opener().open(adres, timeout=40) as yanit:
                veri = yanit.read(20 * 1024 * 1024)
        except Exception as e:
            raise Hata("İndirilemedi ({}). Dosyayı başka bir bilgisayardan indirip Sürücü yükle ile ekleyin: {}".format(e, adres))
        if len(veri) < 1000 or veri[:2] != b"\x1f\x8b":
            raise Hata("İndirilen dosya firmware değil. Dosyayı elle indirip Sürücü yükle ile ekleyin: " + adres)
        sha = hashlib.sha256(veri).hexdigest()
        DEPO_DIZIN.mkdir(parents=True, exist_ok=True)
        (DEPO_DIZIN / sha).write_bytes(veri)
        db.x("INSERT OR REPLACE INTO depo(sha, ad, boyut, tur, aciklama, eklenme, kim) VALUES(?,?,?,?,?,?,?)",
             (sha, ad + ".tar.gz", len(veri), "surucu", "HP firmware (internetten)", simdi(), self.kim()))
        olay("", "sistem", "HP firmware depoya indirildi: {}".format(ad))
        self.yanit({"ok": True})

    def p_saglik(self, y):
        if y == "POST":
            idler = [t for t in hedef_cozumle({"hepsi": True}) if cevrimici_mi(canli.get(t))]
            for tid in idler:
                komut_ekle(tid, "saglik", {})
            return self.yanit({"ok": True, "gonderilen": len(idler)})
        self.yanit({"tahtalar": self.saglik_listesi()})

    def p_saglik_csv(self, y):
        f = io.StringIO()
        w = csv.writer(f, delimiter=";")
        w.writerow(["Tahta", "Grup", "Durum", "Uyarılar", "Marka", "Model", "Seri no", "İşlemci", "Bellek (GB)",
                    "Disk %", "Boş disk (GB)", "Bellek %", "Sıcaklık °C", "Açık kalma (saat)", "İşletim sistemi", "Çekirdek",
                    "Bekleyen güncelleme", "Çözünürlük", "IP", "MAC", "Son bilgi"])
        for x in self.saglik_listesi():
            v = x["veri"]
            w.writerow([x["ad"], x["grup"], ["İyi", "Uyarı", "Kritik"][x["seviye"]], " · ".join(x["uyarilar"]),
                        v.get("marka") or "", v.get("model") or "", v.get("seri") or "", v.get("islemci") or "",
                        v.get("bellek_gb") or "", v.get("disk") if v.get("disk") is not None else "",
                        v.get("disk_bos_gb") if v.get("disk_bos_gb") is not None else "",
                        v.get("ram") if v.get("ram") is not None else "", v.get("sicaklik") if v.get("sicaklik") is not None else "",
                        round(v["calisma_sn"] / 3600, 1) if v.get("calisma_sn") else "", v.get("os") or "", v.get("cekirdek") or "",
                        v.get("guncelleme") if v.get("guncelleme") is not None else "", v.get("cozunurluk") or "",
                        x["ip"] or "", x["mac"] or "",
                        datetime.fromtimestamp(x["zaman"]).strftime("%d.%m.%Y %H:%M") if x["zaman"] else ""])
        self.yanit("﻿" + f.getvalue(), mime="text/csv; charset=utf-8",
                   basliklar={"Content-Disposition": "attachment; filename=tahta-sagligi-{}.csv".format(time.strftime("%Y%m%d"))})

    # ── yönetici şifresini tüm tahtalarda değiştirme ─────────────────────────
    def p_sifre_degistir(self, y):
        g = self.json_oku()
        ben = self.panel_sifresi_dogrula(g.get("panel_sifre"))
        kullanici = (g.get("kullanici") or "").strip()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_.\-]{0,31}$", kullanici):
            raise Hata("Geçerli bir kullanıcı adı girin (ör. etapadmin)")
        sifre = g.get("sifre") or ""
        if sifre != (g.get("sifre2") or ""):
            raise Hata("Yeni şifreler aynı değil")
        if len(sifre) < 6:
            raise Hata("Yeni şifre en az 6 karakter olmalı")
        if any(c in sifre for c in "\r\n\x00"):
            raise Hata("Şifrede geçersiz karakter var")
        idler = hedef_cozumle(g.get("hedef"))
        if not idler:
            raise Hata("Seçili tahta yok")
        acik = [t for t in idler if cevrimici_mi(canli.get(t))]
        veri = {"kullanici": kullanici, "linux": sha512_crypt(sifre), "windows": sifre_paketle(sifre, db.ayar("anahtar"))}
        iid = islem_baslat("sifre_degistir", "Yönetici şifresi değiştir: " + kullanici, veri, idler, acik, ben["ad"],
                           hedef_yazi(g.get("hedef"), len(idler)), omur=600, kayit_veri={"kullanici": kullanici})
        olay("", "komut", "Yönetici şifresi değiştirildi: {} → {} ({})".format(kullanici, hedef_yazi(g.get("hedef"), len(acik)), ben["ad"]))
        self.yanit({"ok": True, "islem": iid, "gonderilen": len(acik), "kapali": len(idler) - len(acik)})

    # ── yeni dönem temizliği ─────────────────────────────────────────────────
    def p_donem(self, y):
        g = self.json_oku()
        islem = g.get("islem")
        idler = hedef_cozumle(g.get("hedef"))
        if not idler:
            raise Hata("Seçili tahta yok")
        kullanicilar = [k for k in (g.get("kullanicilar") or []) if re.match(r"^[A-Za-z_][A-Za-z0-9_.\-]{0,31}\$?$", str(k))][:200]
        acik = [t for t in idler if cevrimici_mi(canli.get(t))]
        hy = hedef_yazi(g.get("hedef"), len(idler))
        if islem == "onizle":
            if not kullanicilar:
                raise Hata("Temizlenecek kullanıcıları seçin")
            iid = islem_baslat("donem_onizle", "Yeni dönem temizliği — ön izleme", {"kullanicilar": kullanicilar},
                               idler, acik, self.kim(), hy)
            return self.yanit({"ok": True, "islem": iid, "gonderilen": len(acik)})
        if islem == "temizle":
            if (g.get("onay") or "").strip().upper().replace("i", "İ") not in ("TEMİZLE", "TEMIZLE"):
                raise Hata("Onay için kutuya TEMİZLE yazın")
            on = db.bir("SELECT * FROM islem WHERE id=? AND tur='donem_onizle'", (g.get("onizleme") or "",))
            if not on or simdi() - on["zaman"] > 3600:
                raise Hata("Önce ön izlemeyi yapın (ön izleme 1 saat geçerlidir)")
            ben = self.panel_sifresi_dogrula(g.get("panel_sifre"))
            iid = islem_baslat("donem_temizle", "Yeni dönem temizliği", {"kullanicilar": kullanicilar, "gun": 7},
                               idler, acik, ben["ad"], hy, omur=900)
            olay("", "komut", "Yeni dönem temizliği: {} kullanıcı → {} ({})".format(len(kullanicilar), hy, ben["ad"]))
            return self.yanit({"ok": True, "islem": iid, "gonderilen": len(acik)})
        if islem == "geri_al":
            iid = islem_baslat("donem_geri_al", "Yeni dönem temizliğini geri al", {}, idler, acik, self.kim(), hy)
            olay("", "komut", "Yeni dönem temizliği geri alınıyor → {}".format(hy))
            return self.yanit({"ok": True, "islem": iid, "gonderilen": len(acik)})
        raise Hata("Geçersiz işlem")

    # ── ayar yedeği ──────────────────────────────────────────────────────────
    def p_yedek_al(self, y):
        g = self.json_oku()
        sifre = g.get("sifre") or ""
        if len(sifre) < 6:
            raise Hata("Yedek şifresi en az 6 karakter olmalı")
        if sifre != (g.get("sifre2") or sifre):
            raise Hata("Yedek şifreleri aynı değil")
        import tempfile
        fd, gecici = tempfile.mkstemp(prefix="tys-indir-", suffix=".tya", dir=str(VERI))
        os.close(fd)
        try:
            yedek_olustur(gecici, sifre, depo_dahil=bool(g.get("depo")))
            ad = "tahta-yonetim-yedek-{}{}.tya".format(time.strftime("%Y%m%d-%H%M"), "-depo" if g.get("depo") else "")
            olay("", "sistem", "Ayar yedeği indirildi{} ({})".format(" (depo dahil)" if g.get("depo") else "", self.kim()))
            self.dosya_gonder(Path(gecici), ad=ad)
        finally:
            try:
                os.remove(gecici)
            except OSError:
                pass

    def p_yedekler(self, y):
        if y == "POST":
            g = self.json_oku()
            if g.get("islem") == "simdi":
                ad = gunluk_yedek_al("elle", zorla=True)
                olay("", "sistem", "Ayar yedeği alındı: {}".format(ad))
            elif g.get("islem") == "ayar":
                db.ayar_yaz("yedek_ayar", {"gunluk": bool(g.get("gunluk", True))})
            elif g.get("islem") == "geri":
                ad = str(g.get("ad") or "")
                p = yedek_klasoru() / ad
                if not re.match(r"^yedek-[\w\-]+\.tya$", ad) or not p.is_file():
                    raise Hata("Yedek bulunamadı", 404)
                self.panel_sifresi_dogrula(g.get("panel_sifre"))
                self.yedekten_yukle(p, yerel_yedek_sifresi())
                olay("", "sistem", "Otomatik yedekten geri yüklendi: {} ({})".format(ad, self.kim()))
        liste = []
        for p in sorted(yedek_klasoru().glob("yedek-*.tya"), reverse=True):
            m = re.match(r"^yedek-(\d{8})-(\d{6})-([\w\-]+)\.tya$", p.name)
            liste.append({"ad": p.name, "boyut": p.stat().st_size, "zaman": p.stat().st_mtime,
                          "neden": {"gunluk": "Günlük", "elle": "Elle", "geri-yukleme-oncesi": "Geri yükleme öncesi"}.get(
                              m.group(3) if m else "", m.group(3) if m else "")})
        self.yanit({"yedekler": liste, "ayar": db.ayar("yedek_ayar") or {"gunluk": True}, "gun": YEDEK_GUN_SAYISI})

    def yedekten_yukle(self, yol, sifre):
        import zipfile
        import tempfile
        klasor = Path(tempfile.mkdtemp(prefix="tys-geri-", dir=str(VERI)))
        try:
            duz = klasor / "yedek.zip"
            yedek_coz(yol, duz, sifre)
            with zipfile.ZipFile(str(duz)) as z:
                icerik = json.loads(z.read("yedek.json").decode("utf-8"))
                depo_k = klasor / "depo"
                depo_k.mkdir()
                for ad in z.namelist():
                    if re.match(r"^depo/[a-f0-9]{64}$", ad):
                        with z.open(ad) as kaynak, open(str(depo_k / ad[5:]), "wb") as hedef:
                            shutil.copyfileobj(kaynak, hedef, 1024 * 1024)
            yedek_uygula(icerik, depo_k)
            return icerik
        finally:
            shutil.rmtree(str(klasor), ignore_errors=True)

    # ── ağdan toplu kurulum (SSH) ────────────────────────────────────────────
    def p_ag_tara(self, y):
        import ipaddress
        if y == "POST":
            g = self.json_oku()
            if AG_IS["tarama"].get("durum") == "calisiyor":
                raise Hata("Tarama sürüyor")
            aglar, ipler = [], []
            for parca in re.split(r"[,\s]+", str(g.get("aglar") or "")):
                if not parca:
                    continue
                try:
                    ag = ipaddress.ip_network(parca, strict=False)
                except ValueError:
                    raise Hata("Ağ adresi geçersiz: {} (ör. 192.168.1.0/24)".format(parca))
                if ag.version != 4 or ag.prefixlen < 22:
                    raise Hata("En çok /22 büyüklüğünde IPv4 ağı taranabilir: {}".format(parca))
                aglar.append(str(ag))
                ipler += [str(i) for i in ag.hosts()]
            ipler = list(dict.fromkeys(ipler))[:4096]
            if not ipler:
                raise Hata("Taranacak ağı yazın")
            AG_IS["tarama"] = {"durum": "calisiyor", "toplam": len(ipler), "biten": 0, "sonuclar": [], "aglar": aglar,
                               "baslama": simdi(), "kim": self.kim()}
            threading.Thread(target=ag_tara_is, args=(ipler,), daemon=True).start()
            olay("", "sistem", "Ağ taraması başladı: {} ({})".format(", ".join(aglar), self.kim()))
        t = dict(AG_IS["tarama"])
        oneri = []
        for a in yerel_adresler():
            try:
                import ipaddress as _ip
                oneri.append(str(_ip.ip_network(a + "/24", strict=False)))
            except ValueError:
                pass
        t["oneri"] = list(dict.fromkeys(oneri))
        self.yanit(t)

    def p_ag_kur(self, y):
        if y == "POST":
            g = self.json_oku()
            if AG_IS["kurulum"].get("durum") == "calisiyor":
                raise Hata("Kurulum sürüyor; bitmesini bekleyin")
            kullanici = (g.get("kullanici") or "").strip()
            if not re.match(r"^[A-Za-z_][A-Za-z0-9_.\-]{0,31}$", kullanici):
                raise Hata("Tahtaların yönetici kullanıcı adını yazın (ör. etapadmin)")
            sifre = g.get("sifre") or ""
            if not sifre or len(sifre) > 200 or "\n" in sifre:
                raise Hata("Tahtaların yönetici şifresini yazın")
            taranan = {s["ip"]: s for s in AG_IS["tarama"].get("sonuclar") or []}
            liste = []
            for k in (g.get("tahtalar") or [])[:300]:
                ip = str(k.get("ip") or "")
                s = taranan.get(ip)
                if not s or not s.get("parmak_izi"):
                    raise Hata("{} taramada bulunamadı; yeniden tarayın".format(ip))
                if k.get("parmak_izi") != s["parmak_izi"]:
                    raise Hata("{} kimliği taramadakinden farklı; yeniden tarayın".format(ip))
                liste.append({"ip": ip, "parmak_izi": s["parmak_izi"], "ad": tahta_adi_temizle(str(k.get("ad") or ""))})
            if not liste:
                raise Hata("Kurulacak tahtaları seçin")
            AG_IS["kurulum"] = {"durum": "calisiyor", "baslama": simdi(), "kim": self.kim(),
                                "tahtalar": [dict(x, durum="bekliyor", mesaj="") for x in liste]}
            threading.Thread(target=ag_kur_is, args=(kullanici, sifre), daemon=True).start()
            olay("", "sistem", "Ağdan toplu kurulum başladı: {} tahta ({})".format(len(liste), self.kim()))
        k = AG_IS["kurulum"]
        self.yanit({"durum": k.get("durum"), "baslama": k.get("baslama"),
                    "tahtalar": [{x: t.get(x) for x in ("ip", "ad", "durum", "mesaj", "parmak_izi")} for t in k.get("tahtalar") or []]})


class Sunucu(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = os.name != "nt"
    request_queue_size = 64

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        TCPServer.server_bind(self)
        self.server_name = "tys"
        self.server_port = self.server_address[1]

    def handle_error(self, request, client_address):
        e = sys.exc_info()[1]
        if not isinstance(e, (ConnectionError, TimeoutError)):
            log.exception("bağlantı hatası %s", client_address)


# ─────────────────────────────────────────────────────────────────────────────
# Başlatma
# ─────────────────────────────────────────────────────────────────────────────

def log_kur():
    VERI.mkdir(parents=True, exist_ok=True)
    h = RotatingFileHandler(str(VERI / "sunucu.log"), maxBytes=1024 * 1024, backupCount=3, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(h)
    log.setLevel(logging.INFO)
    if sys.stderr is not None and os.environ.get("TYS_KONSOL"):
        log.addHandler(logging.StreamHandler(sys.stderr))


def hazirla():
    global db, depo, dugum, AJAN_SURUM
    log_kur()
    db = Veritabani(VERI / "tahta.db")
    dugum = yedek_mod.Dugum(sys.modules[__name__])
    if dugum.yedek_mi():
        # yedek bilgisayar: ilk kopya gelene kadar ana bilgisayarın kimliğiyle tanıtılır
        if not dugum.kopya_zaman and dugum.kimlik0:
            db.ayar_yaz("kimlik", dugum.kimlik0)
    elif not db.ayar("yedek_anahtar"):
        db.ayar_yaz("yedek_anahtar", secrets.token_urlsafe(24))
    if not db.ayar("anahtar"):
        db.ayar_yaz("anahtar", secrets.token_urlsafe(24))
    zil_goc()
    if not db.ayar("istemci_anahtar"):
        db.ayar_yaz("istemci_anahtar", secrets.token_urlsafe(24))
    if not db.ayar("kimlik"):
        db.ayar_yaz("kimlik", uuid.uuid4().hex[:12])
    depo = ortak_mod.OrtakDepo(db, ORTAK_YOL, VERI, olay)
    AJAN_SURUM = ajan_surumu()


def calistir(port_bilgisi=None):
    """Sunucuyu başlatır ve kapanana kadar çalıştırır. Port doluysa OSError fırlatır."""
    hazirla()
    sunucu = Sunucu(("0.0.0.0", PORT), Isleyici)
    log.info("Tahta Yönetim Asistanı sunucusu %s başladı — port %s — veri %s", SURUM, PORT, VERI)
    for hedef in (arka_plan_sayac, arka_plan_zamanlayici, arka_plan_isaret, arka_plan_ortak, arka_plan_yedek):
        threading.Thread(target=hedef, daemon=True).start()
    dugum.baslat()
    if port_bilgisi:
        port_bilgisi()
    try:
        sunucu.serve_forever(poll_interval=1)
    finally:
        if dugum.aktif():
            kullanim_yaz()
            araliklari_yaz()


def sifre_sifirla():
    """Başlat menüsündeki 'Yönetici şifresini sıfırla' kısayolu bunu çalıştırır (ana yöneticinin şifresi)."""
    import getpass
    hazirla()
    print("\n  Tahta Yönetim Asistanı — Yönetici şifresini sıfırlama\n")
    while True:
        s1 = getpass.getpass("  Yeni şifre (en az 6 karakter, yazarken görünmez): ")
        if len(s1) < 6:
            print("  Şifre en az 6 karakter olmalı.\n")
            continue
        if getpass.getpass("  Yeni şifre (tekrar): ") != s1:
            print("  Şifreler aynı değil.\n")
            continue
        break
    db.ayar_yaz("sifre", sifre_ozet(s1))
    db.x("DELETE FROM oturum")
    olay("", "sistem", "Yönetici şifresi bu bilgisayardan sıfırlandı")
    print("\n  Şifre değiştirildi. Panele yeni şifreyle giriş yapabilirsiniz.\n")
    input("  Kapatmak için Enter'a basın...")


if __name__ == "__main__":
    if "--sifre-sifirla" in sys.argv:
        sifre_sifirla()
        sys.exit(0)
    os.environ.setdefault("TYS_KONSOL", "1")
    calistir(lambda: print("Panel: http://localhost:{}".format(PORT), flush=True))
