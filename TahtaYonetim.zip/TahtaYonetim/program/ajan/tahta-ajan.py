#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tahta Yönetim Sistemi — Tahta Ajanı (Pardus / ETAP ve Windows)
==============================================================
Pardus/ETAP'ta yönetici (root) hizmeti, Windows'ta SYSTEM hesabıyla Görev Zamanlayıcı
görevi olarak çalışır. Ek paket gerektirmez: Pardus'ta hazır gelen Python 3 ve GTK 3,
Windows'ta python.org Python'u ile gelen tkinter kullanılır.

  * Yönetim bilgisayarıyla haberleşir, komutları anında uygular
  * Kilit ekranı (dokunmatik şifre tuşları), duyuru ve mesaj pencereleri
  * Zil ve duyuru sesleri (dosya gerekmez, program kendisi üretir)
  * Ekran görüntüsü, dosya alma, boşta kalma algılama
  * Zamanlayıcı kuralları tahtanın kendisinde çalışır
    (yönetim bilgisayarı kapalı olsa bile zil çalar, tahta kapanır)
  * Yeni sürüm çıktığında kendini otomatik günceller

Kurulum betiği bu dosyayı /opt/tahta-ajan/ (Pardus) veya
%ProgramFiles%/TahtaYonetim/ajan/ (Windows) içine yerleştirir.
"""
SURUM = "3.4.0"

import os
import re
import sys
import json
import stat
import time
import math
import glob
import wave
import array
import queue
import struct
import socket
import select
import signal
import hashlib
import hmac
import shutil
import threading
import subprocess
import traceback
import urllib.request
import urllib.error
from urllib.parse import quote
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import pwd
except ImportError:  # pragma: no cover
    pwd = None
try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None

AJAN_YOLU = os.path.abspath(__file__)
ISTEMCI = "--istemci" in sys.argv          # Windows öğretmen bilgisayarı: yalnızca Ortak Klasör
WINDOWS = os.name == "nt"
WT = WINDOWS and not ISTEMCI               # Windows akıllı tahta


def _win_yonetici():
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


ROOT = (not ISTEMCI and not os.environ.get("TYS_AJAN_TEST") and
        ((hasattr(os, "geteuid") and os.geteuid() == 0) or (WT and _win_yonetici())))
TEST = not ROOT
WIN_PROGRAMDATA = os.environ.get("ProgramData") or r"C:\ProgramData"
WIN_ORTAK_PROFIL = os.environ.get("PUBLIC") or r"C:\Users\Public"   # tüm kullanıcıların ortak profili
if os.environ.get("TYS_AJAN_VERI"):
    VERI = os.environ["TYS_AJAN_VERI"]
elif ISTEMCI:
    VERI = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TahtaYonetim", "istemci")
elif WT:
    VERI = os.path.join(WIN_PROGRAMDATA, "TahtaYonetim", "tahta") if ROOT else os.path.join(
        os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TahtaYonetim", "tahta-test")
else:
    VERI = "/var/lib/tahta-ajan" if ROOT else os.path.expanduser("~/.tahta-ajan-test")
# Windows: oturumdaki kullanıcının da okuyup yazabildiği klasör (sesler, ekran görüntüsü, pencere günlüğü).
# Bağlantı anahtarının bulunduğu VERI klasörüne yalnızca SYSTEM ve yöneticiler erişir.
if os.environ.get("TYS_PAYLASIM"):
    PAYLASIM = os.environ["TYS_PAYLASIM"]
elif WT and not os.environ.get("TYS_AJAN_VERI"):
    PAYLASIM = os.path.join(WIN_PROGRAMDATA, "TahtaYonetim", "paylasim")
else:
    PAYLASIM = os.path.join(VERI, "paylasim")
ORTAK_AD = "Ortak Klasör"
if os.environ.get("TYS_ORTAK"):
    ORTAK_YOL = os.environ["TYS_ORTAK"]
elif ISTEMCI:
    ORTAK_YOL = os.path.join(os.path.expanduser("~"), ORTAK_AD)
elif WT:
    ORTAK_YOL = os.path.join(WIN_ORTAK_PROFIL, ORTAK_AD) if ROOT else os.path.join(VERI, ORTAK_AD)
else:
    ORTAK_YOL = "/home/" + ORTAK_AD if ROOT else os.path.join(VERI, ORTAK_AD)
# Windows: gönderilen dosyalar tüm kullanıcıların masaüstünde görünen klasöre gelir
GELEN_YOL = os.environ.get("TYS_GELEN") or (os.path.join(WIN_ORTAK_PROFIL, "Desktop", "Gelen Dosyalar") if ROOT
                                              else os.path.join(VERI, "Gelen Dosyalar"))
KOK_ONEK = os.environ.get("TYS_KOK", "")    # testte /etc yerine sahte kök
ARIZA_TURLERI = ["Ses yok", "Dokunmatik / kalem çalışmıyor", "Görüntü sorunu", "İnternet yok",
                 "Yavaş / donuyor", "Diğer"]
BAGLANTI = os.path.join(VERI, "baglanti.json")
AYAR_DOSYA = os.path.join(VERI, "ayar.json")
DURUM_DOSYA = os.path.join(VERI, "durum.json")
SES_DIZIN = os.path.join(PAYLASIM if WT else VERI, "sesler")
YEREL_PORT = int(os.environ.get("TYS_YEREL_PORT", "8767"))
KESIF_PORT = 8766

GUNLER = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
AYLAR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
         "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
KOMUT_ADI = {"kilitle": "Kilitle", "kilit_ac": "Kilidi aç", "kapat": "Kapat", "yeniden_baslat": "Yeniden başlat",
             "uyku": "Uyku modu", "duyuru": "Duyuru", "zil": "Zil", "kapat_iptal": "Kapatmayı iptal et",
             "icerik_ac": "Site / dosya aç", "guncelle": "Sistem güncellemesi", "paket_kur": "Uygulama kurma",
             "paket_kaldir": "Uygulama kaldırma", "engel_ara": "Site engeline ara", "tani": "Tanı raporu"}


# ═════════════════════════════════════════════════════════════════════════════
# Genel yardımcılar
# ═════════════════════════════════════════════════════════════════════════════

def log(*parca):
    try:
        print(time.strftime("%H:%M:%S"), *parca, flush=True)
    except Exception:
        pass


def dosya_oku(yol):
    try:
        with open(yol, encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return ""


def json_oku(yol, varsayilan=None):
    try:
        with open(yol, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return varsayilan


def json_yaz(yol, veri, mod=0o600):
    gecici = yol + ".tmp"
    with open(gecici, "w", encoding="utf-8") as f:
        json.dump(veri, f, ensure_ascii=False)
    os.chmod(gecici, mod)
    os.replace(gecici, yol)


def sure_yazi(sn):
    sn = int(sn)
    if sn < 60:
        return "{} saniye".format(sn)
    if sn % 60 == 0:
        return "{} dakika".format(sn // 60)
    return "{} dk {} sn".format(sn // 60, sn % 60)


def makine_kimligi():
    k = os.environ.get("TYS_AJAN_ID")
    if k:
        return k
    if WINDOWS:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as a:
                return "pc-" + winreg.QueryValueEx(a, "MachineGuid")[0]
        except Exception:
            pass
    for yol in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        k = dosya_oku(yol).strip()
        if len(k) >= 16:
            return k
    yol = os.path.join(VERI, "kimlik")
    k = dosya_oku(yol).strip()
    if not k:
        k = hashlib.sha1(os.urandom(32)).hexdigest()
        with open(yol, "w") as f:
            f.write(k)
    return k


def os_adi():
    if WINDOWS:
        return win_os_adi()
    for satir in dosya_oku("/etc/os-release").splitlines():
        if satir.startswith("PRETTY_NAME="):
            return satir.split("=", 1)[1].strip().strip('"')
    return "Linux"


def calisma_suresi():
    if WINDOWS:
        return win_calisma()
    try:
        return int(float(dosya_oku("/proc/uptime").split()[0]))
    except Exception:
        return None


def bellek_yuzde():
    if WINDOWS:
        return win_bellek()
    m = {}
    for satir in dosya_oku("/proc/meminfo").splitlines():
        p = satir.split()
        if len(p) >= 2 and p[1].isdigit():
            m[p[0].rstrip(":")] = int(p[1])
    if m.get("MemTotal"):
        return round(100 * (1 - m.get("MemAvailable", 0) / float(m["MemTotal"])))
    return None


def disk_yuzde():
    if WINDOWS:
        return win_disk()
    try:
        u = shutil.disk_usage("/")
        return round(100 * u.used / float(u.total))
    except Exception:
        return None


def sicaklik():
    if WINDOWS:
        return None
    en = None
    for yol in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            t = int(dosya_oku(yol).strip()) / 1000.0
            if 0 < t < 130 and (en is None or t > en):
                en = t
        except Exception:
            pass
    return round(en) if en else None


def ag_bilgisi(hedef_host):
    """Sunucuya giden arayüzün IP ve MAC adresi."""
    ip = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((hedef_host, 9))
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass
    if WINDOWS:
        return ip, win_mac(ip)
    mac = None
    adaylar = []
    for yol in sorted(glob.glob("/sys/class/net/*")):
        ad = os.path.basename(yol)
        if ad == "lo":
            continue
        adres = dosya_oku(yol + "/address").strip()
        if not adres or adres == "00:00:00:00:00:00":
            continue
        adaylar.append((ad, adres, os.path.exists(yol + "/wireless")))
        if ip and fcntl:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                ham = fcntl.ioctl(s.fileno(), 0x8915, struct.pack("256s", ad[:15].encode()))
                s.close()
                if socket.inet_ntoa(ham[20:24]) == ip:
                    mac = adres
            except OSError:
                pass
    if not mac:
        kablolu = [a for a in adaylar if not a[2] and os.path.exists("/sys/class/net/%s/device" % a[0])]
        if kablolu:
            mac = kablolu[0][1]
    return ip, mac


def guvenli_ad(ad):
    ad = re.sub(r'[\\/\x00-\x1f]', "_", ad or "").strip(" .")
    return (ad or "dosya")[:150]


# ═════════════════════════════════════════════════════════════════════════════
# Masaüstü oturumu bulma ve oturum kullanıcısı olarak program çalıştırma
# ═════════════════════════════════════════════════════════════════════════════

TERCIH = ("cinnamon-session", "cinnamon", "xfce4-session", "gnome-session-b", "gnome-shell",
          "plasmashell", "mate-session", "budgie-wm", "xfwm4", "muffin", "nemo-desktop", "cinnamon-launch")
SAKLA = ("DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS", "XDG_RUNTIME_DIR", "WAYLAND_DISPLAY",
         "HOME", "USER", "LOGNAME", "LANG", "LANGUAGE", "LC_ALL", "LC_MESSAGES", "PATH",
         "XDG_CURRENT_DESKTOP", "XDG_SESSION_TYPE", "XDG_DATA_DIRS", "PULSE_SERVER")
_oturum_onbellek = [0.0, None]


def _calistir_cikti(args, zaman=5):
    try:
        return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              universal_newlines=True, timeout=zaman).stdout
    except Exception:
        return ""


def _aktif_oturum_uid():
    if not shutil.which("loginctl"):
        return None
    for satir in _calistir_cikti(["loginctl", "list-sessions", "--no-legend"]).splitlines():
        p = satir.split()
        if not p:
            continue
        bilgi = _calistir_cikti(["loginctl", "show-session", p[0], "-p", "Active", "-p", "Type",
                                 "-p", "Class", "-p", "User"])
        d = dict(x.split("=", 1) for x in bilgi.splitlines() if "=" in x)
        if d.get("Active") == "yes" and d.get("Class") == "user" and d.get("Type") in ("x11", "wayland"):
            try:
                return int(d.get("User"))
            except (TypeError, ValueError):
                pass
    return None


def _oturum_ara():
    hedef_uid = _aktif_oturum_uid() if ROOT else os.getuid()
    aday = None
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            uid = os.stat("/proc/" + pid).st_uid
            if hedef_uid is not None and uid != hedef_uid:
                continue
            if hedef_uid is None and uid < 1000:
                continue
            with open("/proc/%s/environ" % pid, "rb") as f:
                ham = f.read()
        except (OSError, IOError):
            continue
        env = {}
        for kv in ham.split(b"\0"):
            if b"=" in kv:
                k, v = kv.split(b"=", 1)
                env[k.decode("utf-8", "replace")] = v.decode("utf-8", "replace")
        if "DISPLAY" not in env and "WAYLAND_DISPLAY" not in env:
            continue
        ad = dosya_oku("/proc/%s/comm" % pid).strip()
        puan = 2 if ad in TERCIH else 1
        if aday is None or puan > aday[0]:
            aday = (puan, uid, env)
        if puan == 2:
            break
    if aday is None or pwd is None:
        return None
    _, uid, env = aday
    try:
        pw = pwd.getpwuid(uid)
    except KeyError:
        return None
    temiz = {k: env[k] for k in SAKLA if k in env}
    temiz.setdefault("HOME", pw.pw_dir)
    temiz.setdefault("USER", pw.pw_name)
    temiz.setdefault("LOGNAME", pw.pw_name)
    temiz.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    calisma = "/run/user/%d" % uid
    if "XDG_RUNTIME_DIR" not in temiz and os.path.isdir(calisma):
        temiz["XDG_RUNTIME_DIR"] = calisma
    if "DBUS_SESSION_BUS_ADDRESS" not in temiz and os.path.exists(calisma + "/bus"):
        temiz["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=%s/bus" % calisma
    if "XAUTHORITY" not in temiz and os.path.exists(os.path.join(pw.pw_dir, ".Xauthority")):
        temiz["XAUTHORITY"] = os.path.join(pw.pw_dir, ".Xauthority")
    try:
        gruplar = os.getgrouplist(pw.pw_name, pw.pw_gid)
    except Exception:
        gruplar = [pw.pw_gid]
    return {"uid": uid, "gid": pw.pw_gid, "kullanici": pw.pw_name, "home": pw.pw_dir,
            "env": temiz, "gruplar": gruplar}


def oturum_bul():
    if time.time() - _oturum_onbellek[0] < 4:
        return _oturum_onbellek[1]
    try:
        o = win_oturum_bul() if WINDOWS else _oturum_ara()
    except Exception:
        o = None
    _oturum_onbellek[0] = time.time()
    _oturum_onbellek[1] = o
    return o


def _yetki_dusur(uid, gid, gruplar):
    def f():
        try:
            os.setgroups(gruplar)
        except Exception:
            pass
        os.setgid(gid)
        os.setuid(uid)
    return f


def oturumda(args, o, yakala=False, zaman_asimi=20, hata_akisi=None):
    """Bir programı masaüstü oturumundaki kullanıcı olarak çalıştırır."""
    if WINDOWS:
        return win_oturumda(args, o, yakala, zaman_asimi)
    env = dict(o["env"])
    env.update({"NO_AT_BRIDGE": "1", "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    kw = dict(env=env, cwd=o["home"] if os.path.isdir(o["home"]) else "/",
              stdin=subprocess.DEVNULL, stderr=hata_akisi or subprocess.DEVNULL,
              start_new_session=True, close_fds=True)
    if ROOT and o["uid"] != 0:
        if sys.version_info >= (3, 9):
            kw.update(user=o["uid"], group=o["gid"], extra_groups=o["gruplar"])
        else:
            kw["preexec_fn"] = _yetki_dusur(o["uid"], o["gid"], o["gruplar"])
    if yakala:
        return subprocess.run(args, stdout=subprocess.PIPE, timeout=zaman_asimi, **kw)
    return subprocess.Popen(args, stdout=subprocess.DEVNULL, **kw)


def proc_durdur(p):
    if p is None:
        return
    try:
        if p.poll() is None:
            p.terminate()
            try:
                p.wait(2)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait(2)
    except Exception:
        pass


def eski_arayuzleri_kapat():
    """Önceki çalışmadan kalan pencere süreçlerini kapatır (güncelleme sonrası)."""
    if WINDOWS:
        return win_eski_arayuzler()
    benim = os.getpid()
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == benim:
            continue
        try:
            with open("/proc/%s/cmdline" % pid, "rb") as f:
                cmd = f.read().split(b"\0")
            if any(AJAN_YOLU.encode() == c for c in cmd) and b"--arayuz" in cmd:
                os.kill(int(pid), signal.SIGTERM)
        except Exception:
            pass


# ═════════════════════════════════════════════════════════════════════════════
# Sesler — dosya gerekmez, program kendisi üretir
# ═════════════════════════════════════════════════════════════════════════════

def _can_sesi(f, t, sonum):
    return (math.sin(2 * math.pi * f * t)
            + 0.5 * math.sin(2 * math.pi * f * 2.0 * t) * math.exp(-t * 2.5)
            + 0.25 * math.sin(2 * math.pi * f * 3.01 * t) * math.exp(-t * 4)) * math.exp(-t * sonum)


def ses_uret(tur, yol):
    sr = 22050
    ornek = array.array("h")
    if tur == "siren":
        # Yükselip alçalan uyarı sireni (2 tur, ~6 sn)
        sure, faz = 6.0, 0.0
        for n in range(int(sr * sure)):
            t = n / float(sr)
            f = 650 + 550 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 3.0))
            faz += 2 * math.pi * f / sr
            x = 0.42 * (math.sin(faz) + 0.3 * math.sin(2 * faz) + 0.12 * math.sin(3 * faz))
            x *= min(1.0, t / 0.05) * min(1.0, (sure - t) / 0.1)
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    elif tur == "ders":
        # Klasik elektrikli okul zili
        sure = 3.6
        for n in range(int(sr * sure)):
            t = n / float(sr)
            faz = (t * 24.0) % 1.0
            vurus = math.exp(-faz * 7.0)
            ton = (math.sin(2 * math.pi * 1150 * t) + 0.6 * math.sin(2 * math.pi * 2390 * t)
                   + 0.35 * math.sin(2 * math.pi * 3520 * t) + 0.2 * math.sin(2 * math.pi * 4950 * t))
            zarf = min(1.0, t / 0.02) * min(1.0, (sure - t) / 0.3)
            x = 0.30 * ton * (0.25 + 0.75 * vurus) * zarf
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    else:
        if tur == "teneffus":      # Dört notalı melodik zil
            notalar, sure, sonum, kazanc = [(0.0, 659.25), (0.5, 523.25), (1.0, 587.33), (1.5, 392.0)], 3.8, 1.5, 0.26
        elif tur == "duyuru":      # Yükselen dört nota (anons sesi)
            notalar, sure, sonum, kazanc = [(0.0, 523.25), (0.3, 659.25), (0.6, 783.99), (0.9, 1046.5)], 2.8, 2.0, 0.24
        else:                      # Kısa bildirim
            notalar, sure, sonum, kazanc = [(0.0, 880.0), (0.14, 1318.5)], 1.0, 6.0, 0.30
        for n in range(int(sr * sure)):
            t = n / float(sr)
            x = 0.0
            for bas, f in notalar:
                if t >= bas:
                    x += _can_sesi(f, t - bas, sonum)
            x *= kazanc * min(1.0, (sure - t) / 0.2)
            ornek.append(int(max(-1.0, min(1.0, x)) * 32000))
    gecici = yol + ".tmp"
    w = wave.open(gecici, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes(ornek.tobytes())
    w.close()
    os.chmod(gecici, 0o644)
    os.replace(gecici, yol)


def oynatici(yol):
    uz = yol.rsplit(".", 1)[-1].lower()
    if uz == "wav":
        adaylar = [("pw-play", []), ("paplay", []), ("aplay", ["-q"])]
    else:
        adaylar = [("gst-play-1.0", ["-q"]), ("ffplay", ["-nodisp", "-autoexit", "-loglevel", "quiet"]),
                   ("mpv", ["--no-video", "--really-quiet"]), ("cvlc", ["--play-and-exit", "--quiet"]),
                   ("pw-play", []), ("paplay", [])]
    for ad, ek in adaylar:
        y = shutil.which(ad)
        if y:
            return [y] + ek + [yol]
    return None


def tk_var_mi():
    try:
        r = subprocess.run([pythonw_yolu(), "-c", "import tkinter; tkinter.Tcl()"], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=30, creationflags=CREATE_NO_WINDOW)
        return r.returncode == 0
    except Exception:
        return False


def gtk_var_mi():
    if WINDOWS:
        return tk_var_mi()
    try:
        r = subprocess.run([sys.executable, "-c",
                            "import gi; gi.require_version('Gtk','3.0'); gi.require_version('Gdk','3.0')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


# ═════════════════════════════════════════════════════════════════════════════
# Windows akıllı tahta — platform katmanı
# Ajan SYSTEM hesabıyla (Görev Zamanlayıcı) çalışır; pencereler, ekran görüntüsü ve
# ses, oturumu açık kullanıcının masaüstünde ayrı süreç olarak açılır.
# ═════════════════════════════════════════════════════════════════════════════

if WINDOWS:
    import ctypes
    from ctypes import wintypes
    try:
        import winreg
    except ImportError:  # pragma: no cover
        winreg = None

CREATE_NO_WINDOW = 0x08000000
DETACHED_PROCESS = 0x00000008
CREATE_NEW_PROCESS_GROUP = 0x00000200
WIN_GOREV = "Tahta Yonetim Ajani"
WIN_KURAL = "Tahta Yonetim Ajani"
KULLANICILAR_SID = "*S-1-5-32-545"
# Acil durum simgeleri (0-100 kutusunda): b = beyaz dolgu, k = koyu kırmızı dolgu
ACIL_SEKIL = {
    "genel": [("p", [50, 8, 95, 88, 5, 88], "b"), ("p", [45, 32, 55, 32, 53, 64, 47, 64], "k"), ("c", [50, 75, 5.5], "k")],
    "deprem": [("p", [50, 8, 94, 46, 83, 46, 83, 92, 17, 92, 17, 46, 6, 46], "b"),
               ("l", [54, 26, 44, 44, 57, 57, 45, 72, 54, 92], "k"), ("p", [26, 56, 38, 56, 38, 70, 26, 70], "k")],
    "yangin": [("p", [50, 4, 60, 20, 72, 32, 80, 50, 79, 68, 70, 84, 56, 94, 44, 94, 30, 84, 21, 68, 20, 50, 27, 36, 35, 46, 38, 28], "b"),
               ("p", [50, 50, 58, 62, 61, 74, 56, 86, 44, 86, 39, 74, 42, 62], "k")],
    "kilit": [("l", [30, 46, 30, 30, 35, 19, 43, 13, 50, 11, 57, 13, 65, 19, 70, 30, 70, 46], "b"),
              ("p", [18, 44, 82, 44, 82, 94, 18, 94], "b"), ("c", [50, 62, 7], "k"), ("p", [46.5, 64, 53.5, 64, 53.5, 82, 46.5, 82], "k")],
}
ACIL_UST = {True: "TATBİKAT  ·  Bu bir tatbikattır", False: "ACİL DURUM"}
PENCERE_TURLERI = ("kilit", "tam_ekran", "ariza", "duyuru", "bildirim", "geri_sayim", "acil")


def pythonw_yolu():
    """Pencere açmadan çalışan Python (pythonw.exe); yoksa çalışan Python."""
    if WINDOWS:
        y = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        if os.path.isfile(y):
            return y
    return sys.executable


def win_kod_sayfasi():
    try:
        return "cp%d" % ctypes.windll.kernel32.GetOEMCP()
    except Exception:
        return "cp857"


def win_gizli(args, zaman=60):
    """Konsol penceresi açmadan komut çalıştırır: (çıkış kodu, çıktı)."""
    try:
        r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                           timeout=zaman, creationflags=CREATE_NO_WINDOW)
        ham = r.stdout or b""
        try:
            metin = ham.decode("utf-8")
        except UnicodeDecodeError:
            metin = ham.decode(win_kod_sayfasi(), "replace")
        return r.returncode, metin
    except subprocess.TimeoutExpired:
        return -1, "zaman aşımı"
    except Exception as e:
        return -1, str(e)


def win_ps(betik, zaman=60):
    """PowerShell betiği çalıştırır (Türkçe karakterler bozulmasın diye kodlanmış olarak)."""
    import base64
    tam = "[Console]::OutputEncoding=[Text.Encoding]::UTF8;$ErrorActionPreference='Stop';" + betik
    kod = base64.b64encode(tam.encode("utf-16-le")).decode("ascii")
    return win_gizli(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                      "-EncodedCommand", kod], zaman)


def ps_metin(s):
    return "'" + str(s).replace("'", "''") + "'"


def win_dpi():
    """Ekran koordinatları gerçek piksel olsun (4K tahtalarda ölçek %200 olsa da)."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


# ── Sistem bilgileri ──────────────────────────────────────────────────────────
def win_os_adi():
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as a:
            def oku(ad):
                try:
                    return str(winreg.QueryValueEx(a, ad)[0])
                except OSError:
                    return ""
            ad, surum, yapi = oku("ProductName") or "Windows", oku("DisplayVersion") or oku("ReleaseId"), oku("CurrentBuild")
        if yapi.isdigit() and int(yapi) >= 22000:
            ad = ad.replace("Windows 10", "Windows 11")
        return (ad + (" " + surum if surum else "")).strip()
    except Exception:
        return "Windows"


def win_calisma():
    try:
        f = ctypes.windll.kernel32.GetTickCount64
        f.restype = ctypes.c_ulonglong
        return int(f() // 1000)
    except Exception:
        return None


def win_bellek():
    class DURUM(ctypes.Structure):
        _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD)] + \
                   [(a, ctypes.c_ulonglong) for a in ("t", "a", "tp", "ap", "tv", "av", "aev")]
    try:
        d = DURUM()
        d.dwLength = ctypes.sizeof(d)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(d)):
            return int(d.dwMemoryLoad)
    except Exception:
        pass
    return None


def win_disk():
    try:
        u = shutil.disk_usage((os.environ.get("SystemDrive") or "C:") + "\\")
        return round(100 * u.used / float(u.total))
    except Exception:
        return None


def win_acilis():
    """Açılış zamanı (yeniden başladı mı anlamak için)."""
    c = win_calisma()
    return "w:%d" % int(time.time() - c) if c is not None else ""


def acilis_degisti(yeni, eski):
    if not yeni:
        return False
    if str(yeni).startswith("w:") and str(eski or "").startswith("w:"):
        try:
            return abs(int(yeni[2:]) - int(eski[2:])) > 120
        except ValueError:
            return True
    return yeni != eski


_mac_onbellek = {}


def win_mac(ip):
    """Bu IP'nin bağlı olduğu ağ kartının MAC adresi (uzaktan başlatma için)."""
    if not ip:
        return None
    if ip in _mac_onbellek:
        return _mac_onbellek[ip]
    mac = None
    if re.match(r"^[0-9.]+$", ip):
        _, cikti = win_ps("(Get-NetIPAddress -IPAddress '%s' | Get-NetAdapter).MacAddress" % ip, 40)
        m = re.search(r"([0-9A-Fa-f]{2}[-:]){5}[0-9A-Fa-f]{2}", cikti)
        if m:
            mac = m.group(0).replace("-", ":").lower()
    if not mac:
        import uuid
        n = uuid.getnode()
        if not (n >> 40) & 1:
            mac = ":".join("%02x" % ((n >> s) & 0xff) for s in range(40, -1, -8))
    _mac_onbellek[ip] = mac
    return mac


# ── Oturum ve oturumdaki kullanıcı olarak program çalıştırma ─────────────────
def win_oturum_bul():
    k32 = ctypes.windll.kernel32
    wts = ctypes.windll.wtsapi32
    k32.WTSGetActiveConsoleSessionId.restype = wintypes.DWORD
    sid = k32.WTSGetActiveConsoleSessionId()
    if sid == 0xFFFFFFFF:
        return None
    wts.WTSQuerySessionInformationW.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_int,
                                                ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.DWORD)]
    wts.WTSFreeMemory.argtypes = [ctypes.c_void_p]
    tampon, n = ctypes.c_void_p(), wintypes.DWORD()
    if not wts.WTSQuerySessionInformationW(None, sid, 5, ctypes.byref(tampon), ctypes.byref(n)):   # WTSUserName
        return None
    try:
        ad = ctypes.wstring_at(tampon.value) if tampon.value else ""
    finally:
        wts.WTSFreeMemory(tampon)
    if not ad:
        return None          # oturum açılmamış (Windows giriş ekranı)
    return {"kullanici": ad, "oturum_id": int(sid), "home": "", "env": {}, "uid": None, "gid": None, "gruplar": []}


def win_sistem_mi():
    """Ajan SYSTEM hesabıyla mı çalışıyor (Görev Zamanlayıcı)?"""
    return os.environ.get("USERNAME", "").endswith("$") or "systemprofile" in os.environ.get("USERPROFILE", "").lower()


class WinSurec:
    """CreateProcessAsUser ile açılan sürecin subprocess.Popen benzeri sarmalayıcısı."""
    def __init__(self, tutamak, pid):
        self.h, self.pid, self.returncode = tutamak, pid, None
        self.k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.k32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        self.k32.WaitForSingleObject.restype = wintypes.DWORD
        self.k32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        self.k32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.k32.CloseHandle.argtypes = [wintypes.HANDLE]

    def poll(self):
        if self.returncode is None and self.h and self.k32.WaitForSingleObject(self.h, 0) == 0:
            kod = wintypes.DWORD()
            self.k32.GetExitCodeProcess(self.h, ctypes.byref(kod))
            self.returncode = int(kod.value)
            self.k32.CloseHandle(self.h)
            self.h = None
        return self.returncode

    def wait(self, timeout=None):
        if self.returncode is None and self.h:
            ms = 0xFFFFFFFF if timeout is None else int(timeout * 1000)
            if self.k32.WaitForSingleObject(self.h, ms) == 0x102:
                raise subprocess.TimeoutExpired("arayüz", timeout)
        return self.poll()

    def terminate(self):
        if self.poll() is None and self.h:
            self.k32.TerminateProcess(self.h, 1)

    kill = terminate

    def __del__(self):
        try:
            if self.h:
                self.k32.CloseHandle(self.h)
        except Exception:
            pass


def win_kullanicida(args, oturum_id):
    """Programı oturumu açık kullanıcının masaüstünde (onun hesabıyla) başlatır. SYSTEM gerekir."""
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    adv = ctypes.WinDLL("advapi32", use_last_error=True)
    wts = ctypes.WinDLL("wtsapi32", use_last_error=True)
    ue = ctypes.WinDLL("userenv", use_last_error=True)

    class STARTUPINFO(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("lpReserved", wintypes.LPWSTR), ("lpDesktop", wintypes.LPWSTR),
                    ("lpTitle", wintypes.LPWSTR), ("dwX", wintypes.DWORD), ("dwY", wintypes.DWORD),
                    ("dwXSize", wintypes.DWORD), ("dwYSize", wintypes.DWORD), ("dwXCountChars", wintypes.DWORD),
                    ("dwYCountChars", wintypes.DWORD), ("dwFillAttribute", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("wShowWindow", wintypes.WORD), ("cbReserved2", wintypes.WORD), ("lpReserved2", ctypes.c_void_p),
                    ("hStdInput", wintypes.HANDLE), ("hStdOutput", wintypes.HANDLE), ("hStdError", wintypes.HANDLE)]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [("hProcess", wintypes.HANDLE), ("hThread", wintypes.HANDLE),
                    ("dwProcessId", wintypes.DWORD), ("dwThreadId", wintypes.DWORD)]

    wts.WTSQueryUserToken.argtypes = [wintypes.ULONG, ctypes.POINTER(wintypes.HANDLE)]
    ue.CreateEnvironmentBlock.argtypes = [ctypes.POINTER(ctypes.c_void_p), wintypes.HANDLE, wintypes.BOOL]
    ue.DestroyEnvironmentBlock.argtypes = [ctypes.c_void_p]
    adv.CreateProcessAsUserW.argtypes = [wintypes.HANDLE, wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p,
                                         ctypes.c_void_p, wintypes.BOOL, wintypes.DWORD, ctypes.c_void_p,
                                         wintypes.LPCWSTR, ctypes.POINTER(STARTUPINFO),
                                         ctypes.POINTER(PROCESS_INFORMATION)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    jeton = wintypes.HANDLE()
    if not wts.WTSQueryUserToken(oturum_id, ctypes.byref(jeton)):
        raise OSError(ctypes.get_last_error(), "Kullanıcı oturumuna erişilemedi (WTSQueryUserToken)")
    ortam = ctypes.c_void_p()
    try:
        if not ue.CreateEnvironmentBlock(ctypes.byref(ortam), jeton, False):
            ortam = ctypes.c_void_p()
        si = STARTUPINFO()
        si.cb = ctypes.sizeof(si)
        si.lpDesktop = "winsta0\\default"
        pi = PROCESS_INFORMATION()
        komut = ctypes.create_unicode_buffer(subprocess.list2cmdline(args))
        bayrak = 0x00000400 | CREATE_NO_WINDOW          # CREATE_UNICODE_ENVIRONMENT
        if not adv.CreateProcessAsUserW(jeton, None, komut, None, None, False, bayrak,
                                        ortam if ortam.value else None, os.path.dirname(AJAN_YOLU),
                                        ctypes.byref(si), ctypes.byref(pi)):
            raise OSError(ctypes.get_last_error(), "Pencere açılamadı (CreateProcessAsUser)")
        k32.CloseHandle(pi.hThread)
        return WinSurec(pi.hProcess, pi.dwProcessId)
    finally:
        if ortam.value:
            ue.DestroyEnvironmentBlock(ortam)
        k32.CloseHandle(jeton)


def win_oturumda(args, o, yakala=False, zaman_asimi=20):
    if ROOT and win_sistem_mi() and o.get("oturum_id") is not None:
        p = win_kullanicida(args, o["oturum_id"])
    else:
        p = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             creationflags=CREATE_NO_WINDOW, close_fds=True)
    if yakala:
        try:
            kod = p.wait(zaman_asimi)
        except subprocess.TimeoutExpired:
            p.terminate()
            kod = -1
        import types
        return types.SimpleNamespace(returncode=kod, stdout=b"", stderr=b"")
    return p


def win_eski_arayuzler():
    win_ps("Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe' OR Name='python.exe'\" | Where-Object { "
           "$_.CommandLine -and $_.CommandLine.Contains(%s) -and $_.CommandLine.Contains('--arayuz') -and "
           "$_.ProcessId -ne %d } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
           % (ps_metin(AJAN_YOLU), os.getpid()), 60)


# ── Klasör izinleri, bağlantı (junction) koruması ────────────────────────────
def win_herkes_yazabilir(yol):
    """Klasörde tüm kullanıcılar dosya ekleyip değiştirebilsin (alt klasörler dahil)."""
    win_gizli(["icacls", yol, "/grant", KULLANICILAR_SID + ":(OI)(CI)M", "/Q"], 120)


def win_baglanti_mi(yol):
    """Junction veya sembolik bağlantı mı? (klasör dışına yönlendirme saldırısına karşı)"""
    try:
        st = os.lstat(yol)
    except OSError:
        return False
    return bool(getattr(st, "st_file_attributes", 0) & 0x400) or stat.S_ISLNK(st.st_mode)


def win_icinde_mi(yol, kok):
    try:
        g, k = os.path.normcase(os.path.realpath(yol)), os.path.normcase(os.path.realpath(kok))
    except OSError:
        return False
    return g == k or g.startswith(k.rstrip("\\") + "\\")


# ── Kilitliyken Görev Yöneticisi kapalı ──────────────────────────────────────
_gy_bizim = [False]


def win_gorev_yoneticisi(kapat):
    yol = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    try:
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0,
                                winreg.KEY_READ | winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as a:
            try:
                mevcut = winreg.QueryValueEx(a, "DisableTaskMgr")[0]
            except OSError:
                mevcut = None
            if kapat:
                if mevcut != 1:
                    winreg.SetValueEx(a, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
                    _gy_bizim[0] = True
                    json_yaz(os.path.join(VERI, "gorev-yoneticisi"), {"bizim": True})
            else:
                bizim = _gy_bizim[0] or (json_oku(os.path.join(VERI, "gorev-yoneticisi"), {}) or {}).get("bizim")
                if bizim and mevcut is not None:
                    winreg.DeleteValue(a, "DisableTaskMgr")
                if bizim:
                    _gy_bizim[0] = False
                    try:
                        os.remove(os.path.join(VERI, "gorev-yoneticisi"))
                    except OSError:
                        pass
    except Exception as e:
        log("Görev Yöneticisi ayarı yapılamadı:", e)


# ── Kısayol ──────────────────────────────────────────────────────────────────
def win_kisayol(yol, hedef, arg="", ikon="", aciklama=""):
    betik = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut(%s);$s.TargetPath=%s;$s.Arguments=%s;"
             "$s.WorkingDirectory=%s;$s.Description=%s;%s$s.Save()") % (
        ps_metin(yol), ps_metin(hedef), ps_metin(arg), ps_metin(os.path.dirname(hedef)), ps_metin(aciklama),
        ("$s.IconLocation=%s;" % ps_metin(ikon)) if ikon else "")
    kod, cikti = win_ps(betik, 60)
    if kod != 0:
        log("Kısayol oluşturulamadı:", yol, cikti.strip()[-200:])
    return kod == 0


# ── Site engeli: Chrome / Edge / Brave politikaları (kayıt defteri) ──────────
WIN_CHROMIUM = [r"SOFTWARE\Policies\Google\Chrome", r"SOFTWARE\Policies\Microsoft\Edge",
                r"SOFTWARE\Policies\BraveSoftware\Brave", r"SOFTWARE\Policies\Chromium",
                r"SOFTWARE\Policies\YandexBrowser"]


def win_chromium_uygula(alanlar, kayit):
    """URLBlocklist'e yalnızca bu programın eklediği değerleri yazar/siler; okulun kendi kurallarına dokunmaz."""
    bizim_hepsi = kayit.setdefault("win_url", {})
    for kok in WIN_CHROMIUM:
        yol = kok + r"\URLBlocklist"
        bizim = list(bizim_hepsi.get(yol) or [])
        if not alanlar and not bizim:
            continue
        try:
            with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0,
                                    winreg.KEY_ALL_ACCESS | winreg.KEY_WOW64_64KEY) as a:
                mevcut, i = {}, 0
                while True:
                    try:
                        ad, deger, _ = winreg.EnumValue(a, i)
                    except OSError:
                        break
                    mevcut[ad] = deger
                    i += 1
                for ad in bizim:
                    if ad in mevcut:
                        winreg.DeleteValue(a, ad)
                        mevcut.pop(ad)
                no = max([int(x) for x in mevcut if x.isdigit()] + [0]) + 1
                yeni = []
                for alan in alanlar:
                    winreg.SetValueEx(a, str(no), 0, winreg.REG_SZ, alan)
                    yeni.append(str(no))
                    no += 1
                bos = not mevcut and not yeni
            if yeni:
                bizim_hepsi[yol] = yeni
            else:
                bizim_hepsi.pop(yol, None)
            if bos:
                try:
                    winreg.DeleteKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, winreg.KEY_WOW64_64KEY, 0)
                except OSError:
                    pass
        except OSError as e:
            log("Tarayıcı politikası yazılamadı:", yol, e)


def win_firefox_hedefleri():
    hedefler = []
    for kok in {os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramW6432")}:
        if kok and os.path.isfile(os.path.join(kok, "Mozilla Firefox", "firefox.exe")):
            hedefler.append(os.path.join(kok, "Mozilla Firefox", "distribution", "policies.json"))
    return hedefler


# ── Güç ──────────────────────────────────────────────────────────────────────
def win_guc(islem):
    if islem == "poweroff":
        win_gizli(["shutdown", "/s", "/t", "0", "/f"], 30)
    elif islem == "reboot":
        win_gizli(["shutdown", "/r", "/t", "0", "/f"], 30)
    else:
        subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                          "Add-Type -AssemblyName System.Windows.Forms;"
                          "[System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"],
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=CREATE_NO_WINDOW)


# ── Uygulama kurma / güncelleme (winget + Windows Update) ────────────────────
def win_winget():
    w = shutil.which("winget")
    if w:
        return w
    kok = os.environ.get("ProgramW6432") or os.environ.get("ProgramFiles") or r"C:\Program Files"
    adaylar = glob.glob(os.path.join(kok, "WindowsApps", "Microsoft.DesktopAppInstaller_*_x64__8wekyb3d8bbwe", "winget.exe"))

    def surum(y):
        m = re.search(r"DesktopAppInstaller_([0-9.]+)_", y)
        return tuple(int(x) for x in m.group(1).split(".")) if m else ()
    return sorted(adaylar, key=surum)[-1] if adaylar else None


def win_paket_calistir(tur, paketler):
    """(başarılı mı, kısa mesaj, ayrıntılı çıktı)"""
    wg = win_winget()
    ortak = ["--accept-source-agreements", "--disable-interactivity"]
    cikti = ""
    if tur == "guncelle":
        for adim in ("StartScan", "StartDownload", "StartInstall"):
            kod, c = win_gizli(["UsoClient.exe", adim], 120)
            cikti += "$ UsoClient {}\n{}\n".format(adim, c)
        if not wg:
            return True, "Windows Update başlatıldı (winget yok; uygulamalar güncellenmedi)", cikti
        kod, c = win_gizli([wg, "upgrade", "--all", "--silent", "--include-unknown",
                            "--accept-package-agreements"] + ortak, 3 * 3600)
        cikti += "$ winget upgrade --all\n" + c
        n = len(re.findall(r"(Successfully installed|Başarıyla yüklendi|Yükleme başarılı)", c, re.I))
        if kod not in (0, -1978335189):          # 0x8A15002B: güncellenecek bir şey yok
            return False, "Windows Update başlatıldı; uygulama güncellemesi hata verdi (kod {})".format(kod), cikti
        return True, ("Windows Update başlatıldı · {} uygulama güncellendi".format(n) if n
                      else "Windows Update başlatıldı · uygulamalar güncel"), cikti
    if not wg:
        return False, "Bu tahtada winget (Uygulama Yükleyici) bulunamadı", cikti
    tamam = 0
    for p in paketler:
        if tur == "paket_kur":
            denemeler = [[wg, "install", "--id", p, "--exact", "--silent", "--scope", "machine", "--accept-package-agreements"],
                         [wg, "install", "--id", p, "--exact", "--silent", "--accept-package-agreements"],
                         [wg, "install", "--id", p, "--silent", "--accept-package-agreements"]]
        else:
            denemeler = [[wg, "uninstall", "--id", p, "--exact", "--silent"], [wg, "uninstall", "--id", p, "--silent"]]
        son = None
        for d in denemeler:
            kod, c = win_gizli(d + ortak, 3600)
            cikti += "$ " + " ".join(d[1:]) + "\n" + c + "\n"
            son = (kod, c)
            if kod == 0:
                tamam += 1
                break
        if son and son[0] != 0:
            satir = [s.strip() for s in son[1].splitlines() if s.strip() and not re.match(r"^[\s\-\\|/█▒]+$", s)]
            return False, "{}: {}".format(p, (satir[-1] if satir else "çıkış kodu {}".format(son[0]))[:200]), cikti
    ad = "kuruldu" if tur == "paket_kur" else "kaldırıldı"
    return True, "{} uygulama {}".format(tamam, ad), cikti


# ── Kaldırma ─────────────────────────────────────────────────────────────────
def win_kaldir_baslat():
    """Ajan kapandıktan sonra görevi, dosyaları ve izinleri silen betiği başlatır."""
    import tempfile
    kok_veri = os.path.dirname(VERI)
    ajan_dizin = os.path.dirname(AJAN_YOLU)
    betik = "\n".join([
        "Start-Sleep -Seconds 4",
        "schtasks /Delete /TN %s /F | Out-Null" % ps_metin(WIN_GOREV),
        "netsh advfirewall firewall delete rule name=%s | Out-Null" % ps_metin(WIN_KURAL),
        "Remove-Item -LiteralPath %s -Recurse -Force -ErrorAction SilentlyContinue" % ps_metin(ajan_dizin),
        "Remove-Item -LiteralPath %s -Recurse -Force -ErrorAction SilentlyContinue" % ps_metin(kok_veri),
        "Remove-Item 'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\TahtaYonetimTahta' -Recurse -Force -ErrorAction SilentlyContinue",
        "Remove-Item %s -Recurse -Force -ErrorAction SilentlyContinue" % ps_metin(os.path.join(
            os.environ.get("ProgramData", r"C:\ProgramData"), "Microsoft", "Windows", "Start Menu", "Programs", "Tahta Yönetim")),
    ])
    yol = os.path.join(tempfile.gettempdir(), "tys-kaldir.ps1")
    with open(yol, "w", encoding="utf-8-sig") as f:
        f.write(betik)
    subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", yol],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP, close_fds=True)


def win_temizle(engel_kayit):
    """Kaldırırken: site engeli, Görev Yöneticisi ayarı ve masaüstü kısayolları geri alınır."""
    try:
        hosts_uygula([])
        win_chromium_uygula([], engel_kayit)
        firefox_uygula([], engel_kayit)
    except Exception as e:
        log("Site engeli kaldırılamadı:", e)
    win_gorev_yoneticisi(False)
    masa = os.path.join(WIN_ORTAK_PROFIL, "Desktop")
    for ad in (ORTAK_AD + ".lnk", "Arıza Bildir.lnk"):
        try:
            os.remove(os.path.join(masa, ad))
        except OSError:
            pass


def gunluk_ac(yol):
    """pythonw ile çalışırken çıktı penceresi yoktur; günlük dosyaya yazılır."""
    try:
        os.makedirs(os.path.dirname(yol), exist_ok=True)
        if os.path.exists(yol) and os.path.getsize(yol) > 1024 * 1024:
            os.replace(yol, yol + ".1")
        f = open(yol, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = f
    except Exception:
        pass


def dosya_sonu(yol, satir=80):
    try:
        with open(yol, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 64 * 1024))
            return "\n".join(f.read().decode("utf-8", "replace").splitlines()[-satir:])
    except OSError:
        return "(yok)"


# ═════════════════════════════════════════════════════════════════════════════
# Sunucu bağlantısı (tahta ajanı ve öğretmen bilgisayarı ortak kullanır)
# ═════════════════════════════════════════════════════════════════════════════

class SinirliOkuyucu:
    """Dosyadan en fazla 'kalan' bayt okur (yükleme sırasında dosya büyürse taşmasın)."""
    def __init__(self, f, kalan):
        self.f, self.kalan = f, kalan

    def read(self, n=-1):
        if self.kalan <= 0:
            return b""
        n = self.kalan if (n is None or n < 0) else min(n, self.kalan)
        v = self.f.read(n)
        self.kalan -= len(v)
        return v


class Baglanti:
    sunucu = ""
    anahtar = ""
    id = ""
    cihaz_adi = ""
    acici = None

    def _istek_nesnesi(self, yol, veri=None, yontem=None):
        r = urllib.request.Request(self.sunucu + yol, data=veri, method=yontem or ("POST" if veri is not None else "GET"))
        r.add_header("X-Anahtar", self.anahtar)
        r.add_header("X-Cihaz", self.id)
        if self.cihaz_adi:
            r.add_header("X-Cihaz-Ad", quote(self.cihaz_adi))
        return r

    def istek(self, yol, govde=None, ham=None, zaman=15):
        veri = ham if ham is not None else (json.dumps(govde).encode("utf-8") if govde is not None else None)
        r = self._istek_nesnesi(yol, veri)
        if veri is not None:
            r.add_header("Content-Type", "application/octet-stream" if ham is not None else "application/json")
        with self.acici.open(r, timeout=zaman) as y:
            icerik = y.read()
            if (y.headers.get("Content-Type") or "").startswith("application/json"):
                return json.loads(icerik.decode("utf-8"))
            return icerik

    def ham_istek(self, yol, zaman=60):
        return self.acici.open(self._istek_nesnesi(yol), timeout=zaman)

    def istek_akis(self, yol, dosya, uzunluk, basliklar, zaman=900):
        r = self._istek_nesnesi(yol, SinirliOkuyucu(dosya, uzunluk), "POST")
        r.add_header("Content-Type", "application/octet-stream")
        r.add_header("Content-Length", str(uzunluk))
        for k, v in basliklar.items():
            r.add_header(k, v)
        with self.acici.open(r, timeout=zaman) as y:
            return json.loads(y.read().decode("utf-8"))

    def kesif_kontrol(self):
        """Yönetim bilgisayarının IP'si değiştiyse ağdaki yayından yeni adresi öğrenir."""
        isaret = self.son_isaret
        if isaret and time.time() - isaret[1] < 60 and isaret[0] != self.sunucu:
            log("Yönetim bilgisayarının yeni adresi bulundu:", isaret[0])
            self.sunucu = isaret[0]
            try:
                b = json_oku(BAGLANTI, {}) or {}
                b["sunucu"] = self.sunucu
                json_yaz(BAGLANTI, b)
            except Exception:
                pass

    def kesif_dinle(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", KESIF_PORT))
        except OSError as e:
            log("Keşif dinleyicisi açılamadı:", e)
            return
        while True:
            try:
                veri, (ip, _) = s.recvfrom(512)
                p = veri.decode("utf-8", "replace").split()
                if len(p) >= 3 and p[0] == "TYS1" and p[1] == self.kimlik:
                    self.son_isaret = ("http://{}:{}".format(ip, int(p[2])), time.time())
            except Exception:
                time.sleep(1)


# ═════════════════════════════════════════════════════════════════════════════
# Ortak Klasör — iki yönlü eşitleme
# ═════════════════════════════════════════════════════════════════════════════

ORTAK_YOKSAY = re.compile(r"^(~\$.*|\.~lock\..*#|.*\.(tmp|temp|part|partial|crdownload|swp|indiriliyor)|"
                          r"thumbs\.db|desktop\.ini|\.ds_store|\..*)$", re.I)
GECERSIZ_KAR = re.compile(r'[<>:"\\|?*\x00-\x1f]')
AYRILMIS_AD = {"con", "prn", "aux", "nul"} | {"com%d" % i for i in range(1, 10)} | {"lpt%d" % i for i in range(1, 10)}


def ortak_yoksay(ad):
    return bool(ORTAK_YOKSAY.match(ad))


def ortak_ad_hatasi(ad):
    if GECERSIZ_KAR.search(ad):
        return 'ad şu karakterleri içeremez: < > : " \\ | ? *'
    if ad.endswith((" ", ".")):
        return "ad boşluk veya noktayla bitemez"
    if ad.split(".")[0].strip().lower() in AYRILMIS_AD:
        return "bu ad Windows'ta kullanılamaz"
    return None


def ozet_hesapla(f):
    h = hashlib.sha1()
    for parca in iter(lambda: f.read(1 << 20), b""):
        h.update(parca)
    return h.hexdigest()


def win_kullanimda(yol):
    """Windows: dosya başka bir programda yazma amaçlı açıksa True."""
    if not WINDOWS:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateFileW.restype = wintypes.HANDLE
        k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
                                    wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        h = k32.CreateFileW(yol, 0x80000000, 0x00000001, None, 3, 0x80, None)
        if h == wintypes.HANDLE(-1).value:
            return ctypes.get_last_error() == 32
        k32.CloseHandle(h)
    except Exception:
        pass
    return False


O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
O_DIRECTORY = getattr(os, "O_DIRECTORY", 0)
O_BINARY = getattr(os, "O_BINARY", 0)


def fd_kapat(fd):
    if fd is not None:
        try:
            os.close(fd)
        except OSError:
            pass


class OrtakHata(Exception):
    pass


class OrtakEsitleyici:
    """
    Yerel klasörü yönetim bilgisayarındaki Ortak Klasör ile eşitler.
      1. Sunucudaki değişiklikleri al ve uygula (indir / sil / klasör aç)
      2. Yerelde değişenleri gönder (yükle / sil / klasör)
    İki taraf aynı dosyayı değiştirmişse ikisi de korunur: "Ad (Cihaz).uzantı".
    """

    def __init__(self, baglanti, kok, veri, ad_fonk, paylasimli=False):
        self.b = baglanti
        self.kok = kok
        self.dizin_dosya = os.path.join(veri, "ortak-dizin.json")
        self.ad_fonk = ad_fonk
        self.paylasimli = paylasimli       # tahtada: tüm kullanıcılar yazabilsin (0777 / 0666)
        d = json_oku(self.dizin_dosya, {}) or {}
        self.kimlik = d.get("kimlik")
        self.rev = int(d.get("rev") or 0)
        self.g = d.get("g") or {}
        self.uyandir = threading.Event()
        self.kilit = threading.Lock()
        self.onceki = {}
        self.ertele = {}
        self.atlanan = {}
        self.etkin = None
        self.izin = "tam"
        self.kota = (None, None)
        self.son_tur = 0.0
        self.bekleyen = False
        self.son_hata = None
        self.son_hata_zamani = 0.0
        self.hata_sayisi = 0
        self.uyari = None
        self.uyari_zamani = 0.0
        self.durum = {"durum": "baslatiliyor", "mesaj": "", "son": 0, "dosya": 0, "boyut": 0}

    # ── yardımcılar ──────────────────────────────────────────────────────────
    def kaydet(self):
        try:
            json_yaz(self.dizin_dosya, {"kimlik": self.kimlik, "rev": self.rev, "g": self.g})
        except Exception as e:
            log("Ortak klasör dizini kaydedilemedi:", e)

    def tam(self, yol):
        return os.path.join(self.kok, *yol.split("/"))

    def guvenli(self, yol):
        """Yazmadan önce: ara klasörlerin bağlantı (symlink) olmadığını doğrula."""
        cur = self.kok
        for p in yol.split("/")[:-1]:
            cur = os.path.join(cur, p)
            try:
                st = os.lstat(cur)
            except FileNotFoundError:
                break
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode) or (WINDOWS and win_baglanti_mi(cur)):
                raise OrtakHata("güvensiz klasör yolu")
        son = self.tam(yol)
        try:
            if stat.S_ISLNK(os.lstat(son).st_mode) or (WINDOWS and win_baglanti_mi(son)):
                raise OrtakHata("güvensiz dosya")
        except FileNotFoundError:
            pass
        return son

    # Tahtada klasör herkese açık (0777) ve ajan yönetici olarak çalışır. Bir kullanıcı
    # dosyayı son anda başka bir yere bağlantıyla (symlink) değiştirse bile ajanın
    # klasör dışına dokunmaması için işlemler açık dosya tanıtıcısı üzerinden yapılır
    # ve tanıtıcının gerçekten Ortak Klasör içinde olduğu doğrulanır.
    def _icerde(self, fd):
        if not self.paylasimli:
            return
        kok = os.path.realpath(self.kok)
        gercek = os.readlink("/proc/self/fd/%d" % fd)
        if gercek != kok and not gercek.startswith(kok + os.sep):
            raise OrtakHata("güvensiz yol (klasör dışı)")

    def _dizin_ac(self, dizin):
        fd = os.open(dizin, os.O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
        try:
            self._icerde(fd)
        except Exception:
            fd_kapat(fd)
            raise
        return fd

    def _ust(self, tam):
        """(klasör tanıtıcısı, ad). Paylaşımsız modda (Windows/test) tanıtıcı None, ad tam yoldur."""
        if not self.paylasimli:
            return None, tam
        dizin, ad = os.path.split(tam)
        return self._dizin_ac(dizin), ad

    def ac_oku(self, tam):
        if WINDOWS and (win_baglanti_mi(tam) or not win_icinde_mi(tam, self.kok)):
            raise OrtakHata("güvensiz yol (klasör dışı)")
        if not self.paylasimli:
            return open(tam, "rb")
        fd = os.open(tam, os.O_RDONLY | O_NOFOLLOW | os.O_NONBLOCK)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise OrtakHata("normal dosya değil")
            self._icerde(fd)
            os.set_blocking(fd, True)
        except Exception:
            fd_kapat(fd)
            raise
        return os.fdopen(fd, "rb")

    def ozet(self, tam):
        with self.ac_oku(tam) as f:
            return ozet_hesapla(f)

    def izin_ayarla(self, tam, dizin):
        if not self.paylasimli:
            return
        fd = None
        try:
            fd = os.open(tam, os.O_RDONLY | O_NOFOLLOW | os.O_NONBLOCK)
            st = os.fstat(fd)
            if not (stat.S_ISDIR(st.st_mode) if dizin else stat.S_ISREG(st.st_mode)):
                return
            self._icerde(fd)
            hedef = 0o777 if dizin else 0o666
            if stat.S_IMODE(st.st_mode) != hedef:
                os.fchmod(fd, hedef)
        except (OSError, OrtakHata):
            pass
        finally:
            fd_kapat(fd)

    def klasorleri_olustur(self, dizin):
        if os.path.normpath(dizin) == os.path.normpath(self.kok):
            os.makedirs(dizin, exist_ok=True)
            return
        if os.path.isdir(dizin) and not os.path.islink(dizin):
            return
        ust = os.path.dirname(dizin)
        if not os.path.isdir(ust):
            self.klasorleri_olustur(ust)
        dfd, ad = self._ust(dizin)
        try:
            os.mkdir(ad, 0o777, dir_fd=dfd)
        except FileExistsError:
            pass
        finally:
            fd_kapat(dfd)
        self.izin_ayarla(dizin, True)

    def yerel_sil(self, yol, dizin_mi):
        dfd, ad = self._ust(self.guvenli(yol))
        try:
            if not dizin_mi:
                os.remove(ad, dir_fd=dfd)
                return
            ifd = os.open(ad, os.O_RDONLY | O_DIRECTORY | O_NOFOLLOW, dir_fd=dfd) if dfd is not None else None
            try:
                for c in os.listdir(ifd if ifd is not None else ad):
                    if ortak_yoksay(c):        # Thumbs.db, ~$ gibi artıklar klasörü silmeye engel olmasın
                        try:
                            os.remove(c if ifd is not None else os.path.join(ad, c), dir_fd=ifd)
                        except OSError:
                            pass
            finally:
                fd_kapat(ifd)
            try:
                os.rmdir(ad, dir_fd=dfd)
            except OSError:
                pass
        finally:
            fd_kapat(dfd)

    def yerel_ayni(self, l, g):
        return l[0] == g.get("t") and (l[0] == "d" or (l[1] == g.get("b") and l[2] == g.get("m")))

    def uyar(self, mesaj):
        self.uyari = mesaj
        self.uyari_zamani = time.time()

    def beklet(self, yol):
        return time.time() < self.ertele.get(yol, 0)

    def hata_kaydet(self, yol, e, sure=30):
        self.ertele[yol] = time.time() + sure
        mesaj = "{}: {}".format(yol, e)
        if mesaj != self.son_hata:
            log("Ortak klasör:", mesaj)
        self.son_hata = mesaj
        self.son_hata_zamani = time.time()

    def cakisma_adi(self, yol):
        ad = GECERSIZ_KAR.sub("-", self.ad_fonk() or "cihaz").strip(" .") or "cihaz"
        kok, uz = os.path.splitext(yol)
        aday, i = "{} ({}){}".format(kok, ad, uz), 2
        while os.path.lexists(self.tam(aday)):
            aday = "{} ({} {}){}".format(kok, ad, i, uz)
            i += 1
        return aday

    def cakisma_tasi(self, yol):
        yeni = self.cakisma_adi(yol)
        self.guvenli(yeni)
        dfd, ad = self._ust(self.guvenli(yol))
        try:
            hedef = os.path.basename(yeni) if dfd is not None else self.tam(yeni)
            os.rename(ad, hedef, src_dir_fd=dfd, dst_dir_fd=dfd)
        finally:
            fd_kapat(dfd)
        log("Ortak klasör: çakışma — yerel kopya '{}' adıyla korundu".format(yeni))
        return yeni

    # ── yerel tarama ─────────────────────────────────────────────────────────
    def tara(self):
        sonuc = {}
        self.atlanan = {}
        if not os.path.isdir(self.kok):
            return sonuc
        for kok, dizinler, dosyalar in os.walk(self.kok):
            rel = os.path.relpath(kok, self.kok)
            rel = "" if rel == "." else rel.replace(os.sep, "/")
            tut = []
            for d in dizinler:
                tam = os.path.join(kok, d)
                if ortak_yoksay(d) or os.path.islink(tam) or (WINDOWS and win_baglanti_mi(tam)):
                    continue
                y = rel + "/" + d if rel else d
                hata = ortak_ad_hatasi(d) or ("yol çok uzun" if len(y) > 240 else None)
                if hata:
                    self.atlanan[y] = hata
                    continue
                tut.append(d)
                sonuc[y] = ("d", 0, 0)
                self.izin_ayarla(tam, True)
            dizinler[:] = tut
            for f in dosyalar:
                if ortak_yoksay(f):
                    continue
                tam = os.path.join(kok, f)
                try:
                    st = os.lstat(tam)
                except OSError:
                    continue
                if not stat.S_ISREG(st.st_mode) or (getattr(st, "st_file_attributes", 0) & 0x400):
                    continue
                y = rel + "/" + f if rel else f
                hata = ortak_ad_hatasi(f) or ("yol çok uzun" if len(y) > 240 else None)
                if hata:
                    self.atlanan[y] = hata
                    continue
                sonuc[y] = ("f", st.st_size, st.st_mtime_ns)
                if self.paylasimli and stat.S_IMODE(st.st_mode) & 0o666 != 0o666:
                    self.izin_ayarla(tam, False)
        return sonuc

    def degisti(self, yerel):
        if len(yerel) != len(self.g):
            return True
        for y, l in yerel.items():
            g = self.g.get(y)
            if g is None or not self.yerel_ayni(l, g):
                return True
        return False

    # ── döngüler ─────────────────────────────────────────────────────────────
    def calistir(self):
        threading.Thread(target=self.bekle_dongusu, daemon=True).start()
        while True:
            try:
                yerel = self.tara()
                n = time.time()
                gerek = (self.uyandir.is_set() or n - self.son_tur > 60 or
                         (self.etkin is not False and (self.bekleyen or self.degisti(yerel))))
                if gerek:
                    self.uyandir.clear()
                    self.tur()
                    self.hata_sayisi = 0
            except Exception as e:
                self.hata_sayisi += 1
                self.son_hata = "Yönetim bilgisayarına ulaşılamıyor" if isinstance(e, (urllib.error.URLError, OSError)) else str(e)
                self.son_hata_zamani = time.time()
                self.durum.update(durum="hata", mesaj=self.son_hata[:200])
                if self.hata_sayisi in (1, 5) or self.hata_sayisi % 50 == 0:
                    log("Ortak klasör eşitlenemedi:", e)
                self.uyandir.wait(min(60, 3 * self.hata_sayisi))
                continue
            self.uyandir.wait(3)

    def bekle_dongusu(self):
        hata = 0
        while True:
            try:
                c = self.b.istek("/api/a/ortak/bekle?rev=%d" % self.rev, zaman=40)
                hata = 0
                if int(c.get("rev") or 0) != self.rev:
                    self.uyandir.set()
                    time.sleep(2)
            except Exception:
                hata += 1
                time.sleep(min(30, 2 * hata))

    def dosya_bekle(self, yol, sure=90):
        """Uzaktan açılacak dosya henüz gelmediyse eşitlemeyi tetikleyip bekler."""
        bitis = time.time() + sure
        tam = self.tam(yol)
        while not os.path.exists(tam) and time.time() < bitis:
            self.uyandir.set()
            time.sleep(2)
        return tam if os.path.exists(tam) else None

    # ── bir eşitleme turu ────────────────────────────────────────────────────
    def tur(self):
        with self.kilit:
            c = self.b.istek("/api/a/ortak/liste?rev=%d" % (self.rev if self.kimlik else 0), zaman=60)
            self.son_tur = time.time()
            self.etkin = bool(c.get("etkin", True))
            self.izin = c.get("izin") or "tam"
            self.kota = (c.get("kota"), c.get("kullanilan"))
            if not self.etkin:
                self.durum.update(durum="kapali", mesaj="Ortak klasör yönetim panelinden kapatılmış")
                return
            if c.get("kimlik") != self.kimlik:
                if self.kimlik:
                    log("Ortak klasör: yeni depo algılandı; yerel dosyalar birleştirilecek")
                self.kimlik, self.g, self.rev = c.get("kimlik"), {}, 0
                if not c.get("tam"):
                    c = self.b.istek("/api/a/ortak/liste?rev=0", zaman=60)
            if not os.path.isdir(self.kok):
                os.makedirs(self.kok, exist_ok=True)
            self.izin_ayarla(self.kok, True)
            yerel = self.tara()
            girdiler = list(c.get("girdiler") or [])
            tam_liste = bool(c.get("tam"))
            if tam_liste:
                uzak = {e["yol"] for e in girdiler if not e.get("sil")}
                cikan = [y for y in self.g if y not in uzak]
                if len(cikan) > 20 and len(cikan) > 0.5 * len(self.g):
                    log("Ortak klasör: toplu silme engellendi; yerel dosyalar yeniden yüklenecek")
                    self.g, cikan = {}, []
                for y in cikan:
                    girdiler.append({"yol": y, "t": self.g[y].get("t"), "sil": 1, "r": 0})
            olustur = sorted([e for e in girdiler if not e.get("sil")], key=lambda e: (e["t"] != "d", e["yol"].count("/")))
            silinen = sorted([e for e in girdiler if e.get("sil")], key=lambda e: -e["yol"].count("/"))
            hepsi = True
            for e in olustur + silinen:
                try:
                    if not self.uzak_uygula(e, yerel, tam_liste):
                        hepsi = False
                except (OrtakHata, OSError) as h:
                    hepsi = False
                    self.hata_kaydet(e["yol"], h)
            if hepsi:
                self.rev = int(c.get("rev") or 0)
            self.kaydet()
            self.yerel_gonder(self.tara())
            self.kaydet()
            self.durum_guncelle(hepsi)

    def uzak_uygula(self, e, yerel, tam_liste):
        yol = e["yol"]
        g = self.g.get(yol)
        l = yerel.get(yol)
        if not tam_liste and g is not None and g.get("r", 0) >= e.get("r", 0):
            return True
        if self.beklet(yol):
            return False
        if e.get("sil"):
            if l is None or g is None:
                self.g.pop(yol, None)
                return True
            if l[0] == "d":
                self.yerel_sil(yol, True)
            elif self.yerel_ayni(l, g):
                self.yerel_sil(yol, False)
            self.g.pop(yol, None)        # yerelde değiştirilmişse silinmez, yeni dosya olarak geri yüklenir
            return True
        if e["t"] == "d":
            if l is not None and l[0] == "f":
                self.cakisma_tasi(yol)
                l = None
            if l is None:
                self.klasorleri_olustur(self.guvenli(yol))
            self.g[yol] = {"t": "d", "b": 0, "m": 0, "h": "", "r": e["r"]}
            return True
        if l is not None and l[0] == "d":
            self.hata_kaydet(yol, "aynı adda klasör var", 600)
            return True
        if l is None or (g is not None and self.yerel_ayni(l, g)):
            return self.indir(e)
        h = self.ozet(self.guvenli(yol))
        if h == e.get("h"):
            self.g[yol] = {"t": "f", "b": l[1], "m": l[2], "h": h, "r": e["r"]}
            return True
        self.cakisma_tasi(yol)
        return self.indir(e)

    def indir(self, e):
        yol = e["yol"]
        hedef = self.guvenli(yol)
        dizin = os.path.dirname(hedef)
        self.klasorleri_olustur(dizin)
        try:
            if shutil.disk_usage(dizin).free < int(e.get("b") or 0) + 300 * 1024 * 1024:
                self.hata_kaydet(yol, "diskte yeterli yer yok", 300)
                return False
        except OSError:
            pass
        dfd, ad = self._ust(hedef)
        gad = ".tys-indir-" + os.urandom(4).hex()
        gecici = gad if dfd is not None else os.path.join(dizin, gad)
        h = hashlib.sha1()
        olustu = False
        try:
            fd = os.open(gecici, os.O_WRONLY | os.O_CREAT | os.O_EXCL | O_NOFOLLOW | O_BINARY,
                         0o666 if self.paylasimli else 0o644, dir_fd=dfd)
            olustu = True
            with os.fdopen(fd, "wb") as f, \
                    self.b.ham_istek("/api/a/ortak/indir?yol=" + quote(yol), zaman=120) as yanit:
                for parca in iter(lambda: yanit.read(256 * 1024), b""):
                    f.write(parca)
                    h.update(parca)
                rev = int(yanit.headers.get("X-Rev") or 0)
                mt = float(yanit.headers.get("X-Mtime") or 0)
                if self.paylasimli:
                    os.fchmod(f.fileno(), 0o666)
            oz = h.hexdigest()
            if e.get("h") and oz != e["h"]:
                return False            # sunucuda bu arada değişmiş; sonraki turda
            m = float(e.get("m") or mt or 0)
            if m:
                os.utime(gecici, (m, m), dir_fd=dfd)
            os.replace(gecici, ad, src_dir_fd=dfd, dst_dir_fd=dfd)
            olustu = False
            st = os.stat(ad, dir_fd=dfd, follow_symlinks=False)
        except urllib.error.HTTPError as he:
            if he.code == 404:
                return True
            raise
        finally:
            if olustu:
                try:
                    os.remove(gecici, dir_fd=dfd)
                except OSError:
                    pass
            fd_kapat(dfd)
        self.g[yol] = {"t": "f", "b": st.st_size, "m": st.st_mtime_ns, "h": oz, "r": int(e.get("r") or rev)}
        return True

    # ── yerel değişiklikleri gönder ──────────────────────────────────────────
    def yerel_gonder(self, yerel):
        self.bekleyen = False
        n = time.time()
        for yol in sorted(yerel, key=lambda y: (y.count("/"), yerel[y][0] != "d")):
            l, g = yerel[yol], self.g.get(yol)
            if g is not None and self.yerel_ayni(l, g):
                self.onceki.pop(yol, None)
                continue
            if self.beklet(yol):
                self.bekleyen = True
                continue
            try:
                if l[0] == "d":
                    c = self.b.istek("/api/a/ortak/klasor", {"yol": yol})
                    self.g[yol] = {"t": "d", "b": 0, "m": 0, "h": "", "r": c.get("r", 0)}
                    continue
                o = self.onceki.get(yol)
                if not o or o[:2] != (l[1], l[2]):
                    self.onceki[yol] = (l[1], l[2], n)
                    self.bekleyen = True
                    continue
                if n - l[2] / 1e9 < 2:
                    self.bekleyen = True
                    continue
                tam = self.tam(yol)
                if win_kullanimda(tam) and n - o[2] < 60:
                    self.bekleyen = True
                    continue
                kota, kullanilan = self.kota
                eski = g.get("b", 0) if (g and g.get("t") == "f") else 0
                if kota and kullanilan is not None and kullanilan - eski + l[1] > kota:
                    self.hata_kaydet(yol, "ortak klasör dolu", 300)
                    continue
                temel = g.get("r", 0) if (g is not None and g.get("t") == "f") else 0
                with self.ac_oku(self.guvenli(yol)) as f:
                    st = os.fstat(f.fileno())
                    if (st.st_size, st.st_mtime_ns) != (l[1], l[2]):
                        self.bekleyen = True        # tarandıktan sonra değişti; sonraki turda
                        continue
                    h = ozet_hesapla(f)
                    if g is not None and g.get("t") == "f" and g.get("h") == h:
                        g["b"], g["m"] = l[1], l[2]
                        continue
                    f.seek(0)
                    c = self.b.istek_akis("/api/a/ortak/yukle", f, l[1], {
                        "X-Yol": quote(yol), "X-Temel": str(temel), "X-Mtime": repr(l[2] / 1e9)})
                self.g[yol] = {"t": "f", "b": l[1], "m": l[2], "h": c.get("h", h), "r": c.get("r", 0)}
                self.onceki.pop(yol, None)
            except urllib.error.HTTPError as e:
                self.http_hatasi(yol, e, temel if l[0] == "f" else 0)
            except (OrtakHata, OSError) as e:
                self.hata_kaydet(yol, e)
        for yol in sorted([y for y in self.g if y not in yerel], key=lambda y: -y.count("/")):
            if self.beklet(yol):
                continue
            g = self.g[yol]
            try:
                self.b.istek("/api/a/ortak/sil", {"yol": yol, "temel": g.get("r", 0)})
                self.g.pop(yol, None)
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    self.g.pop(yol, None)
                elif e.code in (403, 409):
                    self.g.pop(yol, None)
                    self.rev = 0            # tam liste ile geri getirilsin
                    self.uyandir.set()
                    if e.code == 403:
                        self.uyar("Bu tahtada Ortak Klasör'den silme izni yok; silinen dosyalar geri getirildi")
                elif e.code == 423:
                    self.hata_kaydet(yol, "yönetim bilgisayarında açık", 60)
                else:
                    self.hata_kaydet(yol, "sunucu hatası {}".format(e.code))
            except Exception as e:
                self.hata_kaydet(yol, e)

    def http_hatasi(self, yol, e, temel):
        try:
            mesaj = json.loads(e.read().decode("utf-8")).get("hata") or str(e.code)
        except Exception:
            mesaj = str(e.code)
        if e.code == 409:
            if temel == 0:
                try:
                    self.cakisma_tasi(yol)        # sunucuda aynı adda başka dosya var
                except OSError:
                    pass
                self.rev = 0
                self.uyandir.set()
            else:
                self.bekleyen = True
        elif e.code == 403:
            try:
                self.cakisma_tasi(yol)            # izin yok: değişiklik yeni dosya olarak korunsun
            except OSError:
                pass
            self.g.pop(yol, None)
            self.rev = 0
            self.uyar(mesaj)
            self.uyandir.set()
        elif e.code == 507:
            self.hata_kaydet(yol, mesaj, 300)
        elif e.code == 423:
            self.hata_kaydet(yol, mesaj, 60)
        elif e.code == 400:
            self.hata_kaydet(yol, mesaj, 3600)
        else:
            self.hata_kaydet(yol, mesaj)

    def durum_guncelle(self, hepsi):
        n = time.time()
        dosya = sum(1 for g in self.g.values() if g.get("t") == "f")
        boyut = sum(g.get("b", 0) for g in self.g.values() if g.get("t") == "f")
        if self.son_hata and n - self.son_hata_zamani < 120:
            durum, mesaj = "hata", self.son_hata
        elif self.bekleyen or not hepsi:
            durum, mesaj = "esitleniyor", ""
        else:
            durum, mesaj = "tamam", (self.uyari if n - self.uyari_zamani < 600 else "") or ""
        if not mesaj and self.atlanan:
            ornek = next(iter(self.atlanan))
            mesaj = "{} dosyanın adı uygun değil, eşitlenmedi (ör. {} — {})".format(len(self.atlanan), ornek, self.atlanan[ornek])
        self.durum = {"durum": durum, "mesaj": mesaj[:240], "son": n if durum == "tamam" else self.durum.get("son", 0),
                      "dosya": dosya, "boyut": boyut, "klasor": self.kok}


# ═════════════════════════════════════════════════════════════════════════════
# Site engeli (hosts dosyası + tarayıcı politikaları)
# ═════════════════════════════════════════════════════════════════════════════

ENGEL_BAS = "# >>> Tahta Yönetim — site engeli >>>"
ENGEL_SON = "# <<< Tahta Yönetim — site engeli <<<"
if WINDOWS:     # Windows hosts dosyası ANSI: işaret satırları yalnızca ASCII
    ENGEL_BAS = "# >>> Tahta Yonetim - site engeli >>>"
    ENGEL_SON = "# <<< Tahta Yonetim - site engeli <<<"
ENGEL_ONEKLER = ("", "www.", "m.", "mobile.", "web.")
CHROMIUM_POLITIKA = [
    ("/etc/chromium/policies/managed", ("chromium", "chromium-browser")),
    ("/etc/chromium-browser/policies/managed", ("chromium-browser",)),
    ("/etc/opt/chrome/policies/managed", ("google-chrome", "google-chrome-stable")),
    ("/etc/brave/policies/managed", ("brave-browser",)),
    ("/etc/opt/edge/policies/managed", ("microsoft-edge", "microsoft-edge-stable")),
    ("/etc/yandex-browser/policies/managed", ("yandex-browser",)),
]
FIREFOX_DAGITIM = ["/usr/lib/firefox-esr/distribution/policies.json", "/usr/lib/firefox/distribution/policies.json",
                   "/opt/firefox/distribution/policies.json"]
FIREFOX_SISTEM = "/etc/firefox/policies/policies.json"


def kok_yolu(y):
    return KOK_ONEK + y


def alan_temizle(s):
    s = str(s or "").strip().lower()
    s = re.sub(r"^[a-z]+://", "", s)
    s = s.split("/")[0].split("?")[0].split(":")[0].strip(".")
    if s.startswith("*."):
        s = s[2:]
    if s.startswith("www."):
        s = s[4:]
    try:
        s = s.encode("idna").decode("ascii")
    except Exception:
        return None
    return s if (len(s) <= 120 and re.match(r"^[a-z0-9-]+(\.[a-z0-9-]+)+$", s)) else None


def dosya_yaz_atomik(yol, icerik, mod=0o644):
    if os.path.exists(yol) and dosya_oku(yol) == icerik:
        return False
    os.makedirs(os.path.dirname(yol), exist_ok=True)
    gecici = yol + ".tys-gecici"
    with open(gecici, "w", encoding="utf-8") as f:
        f.write(icerik)
    os.chmod(gecici, mod)
    os.replace(gecici, yol)
    return True


def hosts_yolu():
    if WINDOWS and not KOK_ONEK:
        return os.path.join(os.environ.get("SystemRoot") or r"C:\Windows", "System32", "drivers", "etc", "hosts")
    return kok_yolu("/etc/hosts")


def hosts_uygula(alanlar):
    yol = hosts_yolu()
    if WINDOWS:
        # Windows hosts dosyası ANSI olabilir; baytlar latin-1 ile olduğu gibi korunur
        try:
            with open(yol, "r", encoding="latin-1", newline="") as f:
                eski = f.read()
        except OSError:
            eski = ""
    else:
        eski = dosya_oku(yol)
    if not eski and not alanlar:
        return
    temiz = re.sub(r"\n*" + re.escape(ENGEL_BAS) + r".*?" + re.escape(ENGEL_SON) + r"\n?", "\n", eski, flags=re.S)
    temiz = temiz.rstrip("\n") + "\n"
    if alanlar:
        satirlar = ["", ENGEL_BAS]
        for a in alanlar:
            for o in ENGEL_ONEKLER:
                satirlar += ["0.0.0.0 " + o + a, ":: " + o + a]
        satirlar.append(ENGEL_SON)
        temiz += "\n".join(satirlar) + "\n"
    if temiz != eski:
        if WINDOWS:
            with open(yol, "w", encoding="latin-1", newline="") as f:
                f.write(temiz)
            win_gizli(["ipconfig", "/flushdns"], 30)
        else:
            dosya_yaz_atomik(yol, temiz)


def chromium_uygula(alanlar, kayit=None):
    if WINDOWS and not KOK_ONEK:
        return win_chromium_uygula(alanlar, kayit if kayit is not None else {})
    for dizin, komutlar in CHROMIUM_POLITIKA:
        d = kok_yolu(dizin)
        dosya = os.path.join(d, "tahta-yonetim.json")
        var = any(shutil.which(k) for k in komutlar) or os.path.isdir(os.path.dirname(os.path.dirname(d)))
        if alanlar and var:
            dosya_yaz_atomik(dosya, json.dumps({"URLBlocklist": alanlar}, indent=1))
        elif os.path.exists(dosya):
            os.remove(dosya)


def firefox_uygula(desenler, durum):
    """Firefox politika dosyasına WebsiteFilter ekler; başkalarının ayarlarına dokunmaz."""
    if WINDOWS and not KOK_ONEK:
        hedefler = win_firefox_hedefleri()
    else:
        hedefler = [kok_yolu(y) for y in FIREFOX_DAGITIM if os.path.isfile(kok_yolu(y))]
        sistem = kok_yolu(FIREFOX_SISTEM)
        ff_var = shutil.which("firefox") or shutil.which("firefox-esr") or os.path.isdir(kok_yolu("/etc/firefox"))
        if os.path.isfile(sistem) or (not hedefler and ff_var):
            hedefler.append(sistem)
    yollar = durum.setdefault("yollar", {})
    olusturulan = durum.setdefault("olusturulan", [])
    for y in list(yollar):
        if y not in hedefler and os.path.isfile(y):
            hedefler.append(y)
    for y in hedefler:
        if os.path.exists(y):
            veri = json_oku(y, None)
            if not isinstance(veri, dict):
                continue
        elif desenler:
            veri = {}
        else:
            continue
        pol = veri.setdefault("policies", {})
        onceki = set(yollar.get(y, []))
        wf = dict(pol.get("WebsiteFilter") or {})
        blok = [b for b in (wf.get("Block") or []) if b not in onceki]
        if desenler:
            wf["Block"] = blok + [d for d in desenler if d not in blok]
            pol["WebsiteFilter"] = wf
            yollar[y] = list(desenler)
        else:
            if blok:
                wf["Block"] = blok
            else:
                wf.pop("Block", None)
            if wf:
                pol["WebsiteFilter"] = wf
            else:
                pol.pop("WebsiteFilter", None)
            yollar.pop(y, None)
        if not desenler and y in olusturulan and not pol and set(veri) == {"policies"}:
            os.remove(y)
            olusturulan.remove(y)
            continue
        if not os.path.exists(y):
            olusturulan.append(y)
        dosya_yaz_atomik(y, json.dumps(veri, indent=2, ensure_ascii=False))


# ═════════════════════════════════════════════════════════════════════════════
# Kullanıcı hesabında çalışan küçük betikler (root olarak kullanıcı klasörüne yazmamak için)
# ═════════════════════════════════════════════════════════════════════════════

MASAUSTU_BUL = r'''
import os, sys, json, shutil
from urllib.parse import quote
def masaustu():
    ev = os.path.expanduser("~")
    try:
        for s in open(os.path.join(ev, ".config", "user-dirs.dirs"), encoding="utf-8"):
            if s.startswith("XDG_DESKTOP_DIR="):
                y = s.split("=", 1)[1].strip().strip('"').replace("$HOME", ev)
                if y and y != ev:
                    return y
    except OSError:
        pass
    for a in ("Masaüstü", "Desktop"):
        if os.path.isdir(os.path.join(ev, a)):
            return os.path.join(ev, a)
    return None
'''

KOPYA_BETIGI = MASAUSTU_BUL + r'''
kaynak, ad, m = sys.argv[1], sys.argv[2], sys.argv[3] or masaustu() or os.path.expanduser("~")
klasor = os.path.join(m, "Gelen Dosyalar")
os.makedirs(klasor, exist_ok=True)
hedef = os.path.join(klasor, ad)
kok, uz = os.path.splitext(hedef)
i = 2
while os.path.lexists(hedef):
    hedef = "%s (%d)%s" % (kok, i, uz)
    i += 1
shutil.copyfile(kaynak, hedef)
print(hedef)
'''

SIMGE_BETIGI = MASAUSTU_BUL + r'''
a = json.loads(sys.argv[1])
m = masaustu()
if m and os.path.isdir(m):
    bag = os.path.join(m, a["ortak_ad"])
    if a["ortak"]:
        if not os.path.lexists(bag):
            os.symlink(a["ortak_hedef"], bag)
    elif os.path.islink(bag) and os.readlink(bag) == a["ortak_hedef"]:
        os.remove(bag)
    ar = os.path.join(m, "Arıza Bildir.desktop")
    if a["ariza"]:
        eski = open(ar, encoding="utf-8").read() if (os.path.isfile(ar) and not os.path.islink(ar)) else None
        if eski != a["ariza"] and not os.path.islink(ar):
            with open(ar + ".tmp", "w", encoding="utf-8") as f:
                f.write(a["ariza"])
            os.chmod(ar + ".tmp", 0o755)
            os.replace(ar + ".tmp", ar)
    elif os.path.isfile(ar) and not os.path.islink(ar) and "tahta-ajan" in open(ar, encoding="utf-8").read():
        os.remove(ar)
bm = os.path.join(os.path.expanduser("~"), ".config", "gtk-3.0", "bookmarks")
satir = "file://" + quote(a["ortak_hedef"]) + " " + a["ortak_ad"]
try:
    satirlar = open(bm, encoding="utf-8").read().splitlines() if os.path.isfile(bm) else []
    if a["ortak"] and satir not in satirlar:
        os.makedirs(os.path.dirname(bm), exist_ok=True)
        if not os.path.islink(bm):
            with open(bm, "a", encoding="utf-8") as f:
                f.write(satir + "\n")
    elif not a["ortak"] and satir in satirlar and not os.path.islink(bm):
        with open(bm, "w", encoding="utf-8") as f:
            f.write("\n".join(s for s in satirlar if s != satir) + "\n")
except OSError:
    pass
'''


def kullanicilar():
    if pwd is None:
        return []
    return [p for p in pwd.getpwall() if 1000 <= p.pw_uid < 60000 and p.pw_dir.startswith("/home/")
            and os.path.isdir(p.pw_dir) and not p.pw_shell.endswith(("nologin", "false"))]


def kullanici_baglami(p):
    try:
        gruplar = os.getgrouplist(p.pw_name, p.pw_gid)
    except Exception:
        gruplar = [p.pw_gid]
    env = {"HOME": p.pw_dir, "USER": p.pw_name, "LOGNAME": p.pw_name, "PATH": "/usr/local/bin:/usr/bin:/bin",
           "LANG": "C.UTF-8"}
    return {"uid": p.pw_uid, "gid": p.pw_gid, "kullanici": p.pw_name, "home": p.pw_dir, "env": env, "gruplar": gruplar}


def ariza_desktop():
    return ("[Desktop Entry]\nType=Application\nName=Arıza Bildir\nComment=Tahtadaki bir sorunu okul yönetimine bildirir\n"
            "Exec={} {} --arayuz ariza\nIcon=dialog-warning\nTerminal=false\nCategories=Utility;\n"
            "StartupNotify=false\n").format(sys.executable, AJAN_YOLU)


def temizle(engel_kayit=None):
    """Program kaldırılırken: site engelini ve masaüstü simgelerini geri alır.
    Ortak Klasör'deki dosyalar silinmez."""
    if engel_kayit is None:
        engel_kayit = (json_oku(DURUM_DOSYA, {}) or {}).get("engel") or {}
    if WT:
        return win_temizle(engel_kayit)
    try:
        hosts_uygula([])
        chromium_uygula([])
        firefox_uygula([], engel_kayit)
    except Exception as e:
        log("Site engeli kaldırılamadı:", e)
    arg = json.dumps({"ortak": False, "ortak_hedef": ORTAK_YOL, "ortak_ad": ORTAK_AD, "ariza": ""}, ensure_ascii=False)
    for p in kullanicilar():
        try:
            oturumda([sys.executable, "-c", SIMGE_BETIGI, arg], kullanici_baglami(p), yakala=True, zaman_asimi=20)
        except Exception:
            pass


# ═════════════════════════════════════════════════════════════════════════════
# Ajan (root hizmeti)
# ═════════════════════════════════════════════════════════════════════════════

class Ajan(Baglanti):
    def __init__(self):
        os.makedirs(VERI, exist_ok=True)
        os.makedirs(SES_DIZIN, exist_ok=True)
        os.chmod(SES_DIZIN, 0o755)
        if WT:
            for d in ("gecici", "gunluk"):
                os.makedirs(os.path.join(PAYLASIM, d), exist_ok=True)
        b = json_oku(BAGLANTI)
        if not b or not b.get("sunucu"):
            log("Bağlantı ayarı bulunamadı:", BAGLANTI, "— kurulum komutunu yeniden çalıştırın.")
            time.sleep(60)
            sys.exit(1)
        self.sunucu = b["sunucu"].rstrip("/")
        self.anahtar = b.get("anahtar", "")
        self.kimlik = b.get("kimlik", "")
        self.kurulum_ad = str(b.get("ad_istek") or "")[:60] or None
        self.id = makine_kimligi()
        a = json_oku(AYAR_DOSYA, {}) or {}
        self.ayar = a.get("ayar") or {}
        self.ayar_surum = a.get("surum")
        d = json_oku(DURUM_DOSYA, {}) or {}
        self.kilitli = bool(d.get("kilitli"))
        self.calisan = set(d.get("calisan") or [])
        self.ses_kilit = threading.Lock()
        self.acil_kilit = threading.Lock()
        self.acil_id = self.acil_veri = self.acil_surec = self.acil_ses = None
        self.acil_goruldu, self.acil_saat = False, 0.0
        self.ofset = float(d.get("ofset") or 0.0)
        self.utc_ofset = d.get("utc_ofset")
        self.son_kullanici = d.get("son_kullanici")
        self.onceki_acilis = d.get("acilis")
        self.acilis = win_acilis() if WINDOWS else dosya_oku("/proc/sys/kernel/random/boot_id").strip()

        self.kilit = threading.RLock()
        self.kuyruk = queue.Queue()
        self.sonuclar = []
        self.acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.son_giris = time.monotonic()
        self.giris_izlenebilir = False
        self.kilit_proc = None
        self.kilit_baslama = 0.0
        self.kilit_hatalari = []
        self.kilit_bekle = 0.0
        self.aralik = None          # şu an süren kilitli saat aralığı
        self.kilit_acilma = 0.0     # son kilit açılma zamanı (monotonic)
        self.yedek_kilit_zamani = 0.0
        self.kilit_kapat_gecikme = 0.0
        self.kapanis = None
        self.geri_sayim_proc = None
        self.geri_sayim_zamani = 0.0
        self.duyuru_proc = None
        self.bildirim_proc = None
        self.anlik = None
        self.pin_hata = 0
        self.pin_bekle = 0.0
        self.son_isaret = None
        self.son_basari = 0.0
        self.son_kayit = 0.0
        self.son_guncelleme = 0.0
        self.ekran_mesgul = set()
        self.ag = (0.0, None, None)
        self.gtk = False
        self.ses_var = False
        # v3.1
        self.acan = None                       # kilidi şifresiyle açan öğretmen
        self.apt = None                        # süren güncelleme / uygulama kurma işlemi
        self.bekleyen_guc = None               # güncelleme sürerken gelen kapatma isteği
        self.guncelleme_son = d.get("guncelleme")
        self.engel_kayit = d.get("engel") or {}
        self.engel_ara_bitis = float(d.get("engel_ara") or 0)
        self.engel_imza = None
        self.engel_son = 0.0
        self.engel_ozet = None
        self.tam_ekran = None                  # "sinav" | "saat" | "koruyucu"
        self.tam_ekran_anahtar = None
        self.tam_ekran_proc = None
        self.tam_ekran_baslama = 0.0
        self.tam_ekran_bekle = 0.0
        self.saat_kapatilan = set()
        self.sinav_sesleri = set()
        self.ariza_kuyruk = list(d.get("ariza_kuyruk") or [])
        self.ariza_zamanlari = []
        self.masaustu_imza = None
        self.masaustu_son = 0.0
        self.izleyici_proc = None              # Windows: oturumda boşta kalma süresini bildiren yardımcı
        self.izleyici_zamani = 0.0
        self.son_girdi_rapor = 0.0
        self.ortak = OrtakEsitleyici(self, ORTAK_YOL, VERI, lambda: self.ayar.get("ad") or socket.gethostname(),
                                     paylasimli=(ROOT and not WINDOWS) or bool(os.environ.get("TYS_PAYLASIMLI")))

    # ── yardımcılar ──────────────────────────────────────────────────────────
    def pinler_var(self):
        return bool(self.ayar.get("pinler"))

    def kilit_ayari(self):
        return self.ayar.get("kilit") or {}

    def durum_kaydet(self):
        try:
            bugun = time.strftime("%Y-%m-%d", self.sunucu_saati())
            self.calisan = {k for k in self.calisan if bugun in k}
            json_yaz(DURUM_DOSYA, {"kilitli": self.kilitli, "calisan": sorted(self.calisan),
                                   "ofset": self.ofset, "utc_ofset": self.utc_ofset,
                                   "son_kullanici": self.son_kullanici, "acilis": self.acilis,
                                   "guncelleme": self.guncelleme_son, "engel": self.engel_kayit,
                                   "engel_ara": self.engel_ara_bitis, "ariza_kuyruk": self.ariza_kuyruk[-20:]})
            self.son_kayit = time.time()
        except Exception:
            log("Durum kaydedilemedi:", traceback.format_exc().splitlines()[-1])

    def sunucu_saati(self):
        """Yönetim bilgisayarının saatine göre şu anki yerel zaman."""
        if self.utc_ofset is None:
            return time.localtime()
        return time.gmtime(time.time() + self.ofset + float(self.utc_ofset))

    def bosta_sn(self):
        if not self.giris_izlenebilir:
            return None
        return int(time.monotonic() - self.son_giris)

    def arayuz_log(self):
        yol = os.path.join(VERI, "arayuz.log")
        try:
            if os.path.exists(yol) and os.path.getsize(yol) > 512 * 1024:
                os.replace(yol, yol + ".1")
            return open(yol, "ab")
        except Exception:
            return None

    def ui(self, tur, arg=None, o=None, yakala=False, zaman_asimi=20):
        o = o or oturum_bul()
        if not o or (not self.gtk and (not WINDOWS or tur in PENCERE_TURLERI)):
            return None
        f = None if WINDOWS else self.arayuz_log()
        py = pythonw_yolu() if WINDOWS else sys.executable
        try:
            return oturumda([py, AJAN_YOLU, "--arayuz", tur, json.dumps(arg or {}, ensure_ascii=False)],
                            o, hata_akisi=f, yakala=yakala, zaman_asimi=zaman_asimi)
        except Exception:
            log("Pencere açılamadı:", tur, traceback.format_exc().splitlines()[-1])
            return None
        finally:
            if f:
                f.close()

    # ── ağ ───────────────────────────────────────────────────────────────────
    def durum_topla(self):
        o = oturum_bul()
        if o:
            self.son_kullanici = o["kullanici"]
        elif self.acan:
            self.acan = None                   # oturum kapandı
        if time.time() - self.ag[0] > 60:
            host = re.sub(r"^https?://", "", self.sunucu).split(":")[0].split("/")[0]
            ip, mac = ag_bilgisi(host)
            self.ag = (time.time(), ip, mac)
        return {
            "hostname": socket.gethostname(), "os": os_adi(), "surum": SURUM,
            "kurulum_ad": self.kurulum_ad, "ip": self.ag[1], "mac": self.ag[2],
            "kullanici": o["kullanici"] if o else None, "oturum": bool(o),
            "kilitli": self.kilitli, "bosta_sn": self.bosta_sn(), "calisma_sn": calisma_suresi(),
            "ram": bellek_yuzde(), "disk": disk_yuzde(), "sicaklik": sicaklik(),
            "kapanis": self.kapanis["bitis"] + self.ofset if self.kapanis else None,
            "ozellikler": {"gtk": self.gtk, "ses": self.ses_var, "giris": self.giris_izlenebilir, "yonetici": ROOT},
            "platform": "windows" if WINDOWS else "linux",
            "zaman": time.time(),
            "acan": None if self.kilitli else self.acan,
            "ortak": dict(self.ortak.durum, etkin=self.ortak.etkin),
            "engel": self.engel_ozet,
            "guncelleme": {"calisiyor": KOMUT_ADI.get(self.apt["tur"]) if self.apt else None,
                           "baslama": self.apt["baslama"] + self.ofset if self.apt else None,
                           "son": self.guncelleme_son},
            "tam_ekran": self.tam_ekran,
            "aralik": {x: self.aralik.get(x) for x in ("id", "ad", "bitis")} if self.aralik else None,
            "acil": self.acil_id if self.acil_goruldu else None,
        }

    def olay_gonder(self, tur=None, mesaj="", veri=None, bekle=False):
        def gonder():
            try:
                self.istek("/api/a/olay", {"id": self.id, "tur": tur, "mesaj": mesaj, "veri": veri,
                                           "durum": self.durum_topla()}, zaman=8)
            except Exception:
                pass
        if bekle:
            gonder()
        else:
            threading.Thread(target=gonder, daemon=True).start()

    def durum_bildir(self):
        self.olay_gonder(None)

    # ── senkronizasyon döngüsü ───────────────────────────────────────────────
    def senk_dongusu(self):
        hatalar = 0
        ilk = True
        while True:
            try:
                sonuclar, self.sonuclar = self.sonuclar, []
                govde = {"id": self.id, "durum": self.durum_topla(), "ayar_surum": self.ayar_surum,
                         "sonuclar": sonuclar, "hemen": ilk}
                cevap = self.istek("/api/a/senk", govde, zaman=40)
                if hatalar:
                    log("Yönetim bilgisayarına yeniden bağlanıldı:", self.sunucu)
                hatalar = 0
                ilk = False
                self.son_basari = time.time()
                if "sunucu_zaman" in cevap:
                    self.ofset = float(cevap["sunucu_zaman"]) - time.time()
                    self.utc_ofset = cevap.get("utc_ofset")
                if cevap.get("ayar") is not None:
                    self.ayar_uygula(cevap["ayar"], cevap.get("ayar_surum"))
                for k in cevap.get("komutlar") or []:
                    self.kuyruk.put(k)
                hedef = cevap.get("ajan_surum")
                if hedef and hedef not in ("?", SURUM):
                    self.guncelle(hedef)
            except urllib.error.HTTPError as e:
                hatalar += 1
                if e.code == 401:
                    log("Yönetim bilgisayarı bu tahtayı tanımıyor (anahtar geçersiz). Kurulum komutunu yeniden çalıştırın.")
                    time.sleep(60)
                else:
                    time.sleep(min(30, 2 * hatalar))
            except Exception as e:
                hatalar += 1
                if hatalar in (1, 5) or hatalar % 30 == 0:
                    log("Bağlantı yok ({}): {}".format(self.sunucu, e))
                if hatalar >= 3:
                    self.kesif_kontrol()
                time.sleep(min(20, 2 * hatalar))

    def ayar_uygula(self, ayar, surum):
        self.ayar = ayar
        self.ayar_surum = surum
        try:
            json_yaz(AYAR_DOSYA, {"surum": surum, "ayar": ayar})
        except Exception:
            pass
        threading.Thread(target=self.ozel_sesleri_indir, daemon=True).start()
        threading.Thread(target=self.acil_isle, daemon=True).start()

    # ── acil durum / tatbikat ────────────────────────────────────────────────
    def acil_isle(self):
        with self.acil_kilit:
            a = self.ayar.get("acil") or None
            if a and a.get("bitis") and time.time() + self.ofset >= a["bitis"]:
                a = None                       # süre doldu (sunucuya ulaşılamasa da biter)
            if not a:
                if self.acil_id:
                    self.acil_kapat()
                return
            if a.get("id") != self.acil_id:
                if self.acil_id:
                    self.acil_kapat(sessiz=True)
                self.acil_id, self.acil_veri, self.acil_goruldu = a["id"], a, False
                log("ACİL DURUM:", a.get("baslik"), "(tatbikat)" if a.get("tatbikat") else "")
                threading.Thread(target=self.acil_siren, args=(a["id"], a.get("ses") or "siren", int(a.get("tekrar") or 0)),
                                 daemon=True).start()
                self.acil_saat = time.time()
            o = oturum_bul()
            if o and not (WINDOWS or self.gtk):
                o = None                       # pencere açılamıyor: yalnızca siren
            if o and (self.acil_surec is None or self.acil_surec.poll() is not None):
                arg = {k: a.get(k) for k in ("senaryo", "baslik", "metin", "tatbikat")}
                arg.update(okul_adi=self.ayar.get("okul_adi") or "", ad=self.ayar.get("ad") or "", port=YEREL_PORT,
                           ofset=self.ofset, utc_ofset=self.utc_ofset)
                self.acil_surec = self.ui("acil", arg, o)
                if self.acil_surec is not None:
                    self.acil_goruldu = True
                    self.durum_bildir()
            elif not o and not self.acil_goruldu and time.time() - self.acil_saat > 3:
                self.acil_goruldu = True       # oturum yok: yalnızca siren çalar
                self.durum_bildir()

    def acil_kapat(self, sessiz=False):
        log("Acil durum bitti")
        self.acil_id, self.acil_veri, self.acil_goruldu = None, None, False
        s, self.acil_surec = self.acil_surec, None
        for p in (s, self.acil_ses):
            proc_durdur(p)
        self.acil_ses = None
        if not sessiz:
            self.durum_bildir()

    def acil_siren(self, aid, ref, tekrar):
        n, son = 0, time.time() + 30 * 60
        while self.acil_id == aid and time.time() < son and (tekrar <= 0 or n < tekrar):
            try:
                p = self.ses_cal(ref, zil=True, seviye=100)
            except Exception as e:
                log("Acil durum sesi çalınamadı:", e)
                return
            self.acil_ses = p
            n += 1
            bas = time.time()
            while self.acil_id == aid and time.time() - bas < 180:
                if p is None:
                    time.sleep(6)
                    break
                if p.poll() is not None:
                    break
                time.sleep(0.3)
            if self.acil_id != aid:
                proc_durdur(p)
                return
            time.sleep(0.8)

    # ── komutlar ─────────────────────────────────────────────────────────────
    def komut_isci(self):
        while True:
            k = self.kuyruk.get()
            tur = k.get("tur")
            try:
                self.komut_uygula(tur, k.get("veri") or {}, k.get("kaynak") or "yönetim panelinden")
            except Exception as e:
                log("Komut hatası:", tur, e)
                self.olay_gonder("hata", "{}: {}".format(KOMUT_ADI.get(tur, tur), str(e)[:200]))

    def komut_uygula(self, tur, v, kaynak):
        if tur != "ekran":
            log("Komut:", tur, "({})".format(kaynak))
        if tur == "kilitle":
            self.kilitle(kaynak)
        elif tur == "kilit_ac":
            self.kilit_ac(kaynak)
        elif tur == "kapat":
            self.kapat_planla(int(v.get("gecikme") or 0), kaynak)
        elif tur == "kapat_iptal":
            self.kapat_iptal(kaynak)
        elif tur == "yeniden_baslat":
            self.guc("reboot")
        elif tur == "uyku":
            self.guc("suspend")
        elif tur == "duyuru":
            self.duyuru(v)
        elif tur == "zil":
            ses = v.get("ses") or ("teneffus" if v.get("tur") == "teneffus" else "ders")
            self.ses_cal(ses, zil=True, sure=v.get("sure") or 0)
        elif tur == "ekran":
            boyut = v.get("boyut") if v.get("boyut") in ("kucuk", "buyuk", "tam") else "kucuk"
            threading.Thread(target=self.ekran_gonder, args=(boyut,), daemon=True).start()
        elif tur == "dosya":
            threading.Thread(target=self.dosya_al_guvenli, args=(v,), daemon=True).start()
        elif tur == "kaldir":
            self.kaldir()
        elif tur == "icerik_ac":
            self.arkada(self.icerik_ac, tur, v)
        elif tur in ("guncelle", "paket_kur", "paket_kaldir"):
            self.apt_baslat(tur, v)
        elif tur == "tani":
            self.arkada(self.tani_gonder, tur)
        elif tur == "engel_ara":
            dk = max(5, min(int(v.get("dk") or 45), 480))
            self.engel_ara_bitis = time.time() + dk * 60
            self.durum_kaydet()
            self.engel_uygula(zorla=True)
            self.olay_gonder("sistem", "Site engeline {} dakika ara verildi".format(dk))
        else:
            raise ValueError("Bilinmeyen komut: {}".format(tur))

    def arkada(self, fonk, tur, *args):
        """Uzun süren komutu ayrı iş parçacığında çalıştırır; hata olursa panele bildirir."""
        def calis():
            try:
                fonk(*args)
            except Exception as e:
                log("Komut hatası:", tur, e)
                self.olay_gonder("hata", "{}: {}".format(KOMUT_ADI.get(tur, tur), str(e)[:200]))
        threading.Thread(target=calis, daemon=True).start()

    # ── uzaktan site / dosya açma ────────────────────────────────────────────
    def icerik_ac(self, v):
        o = oturum_bul()
        if not o:
            raise RuntimeError("Tahtada açık masaüstü oturumu yok")
        if self.kilitli:
            raise RuntimeError("Tahta kilitli; önce kilidi açın")
        if self.tam_ekran == "sinav":
            raise RuntimeError("Tahtada sınav ekranı açık")
        if not WINDOWS and not shutil.which("xdg-open"):
            raise RuntimeError("Tahtada xdg-open bulunamadı")
        if v.get("tur") == "ortak":
            if self.ortak.etkin is False:
                raise RuntimeError("Ortak Klasör kapalı")
            hedef = self.ortak.dosya_bekle(v.get("yol") or "")
            if not hedef:
                raise RuntimeError("Dosya tahtaya henüz ulaşmadı: {}".format(v.get("yol")))
            ad = v.get("yol")
        else:
            hedef = ad = v.get("adres") or ""
            if not re.match(r"^https?://", hedef, re.I):
                raise RuntimeError("Geçersiz adres")
        if self.tam_ekran in ("saat", "koruyucu"):
            self.tam_ekran_kapat()
        if WINDOWS:
            self.ui("ac", {"hedef": hedef}, o)
        else:
            oturumda(["xdg-open", hedef], o)
        log("Açıldı:", ad)

    # ── sistem güncellemesi, uygulama kurma / kaldırma ───────────────────────
    def apt_baslat(self, tur, v):
        with self.kilit:
            if self.apt:
                raise RuntimeError("Tahtada zaten bir güncelleme sürüyor ({})".format(KOMUT_ADI.get(self.apt["tur"])))
            self.apt = {"tur": tur, "baslama": time.time(), "paketler": list(v.get("paketler") or [])}
        self.durum_bildir()
        threading.Thread(target=self.apt_calistir, daemon=True).start()

    def apt_calistir(self):
        a = self.apt
        tur, paketler = a["tur"], a["paketler"]
        apt = os.environ.get("TYS_APT_TEST") or shutil.which("apt-get") or "/usr/bin/apt-get"
        env = dict(os.environ, DEBIAN_FRONTEND="noninteractive", APT_LISTCHANGES_FRONTEND="none",
                   NEEDRESTART_MODE="a", LC_ALL="C", LANG="C")
        sec = ["-y", "-q", "-o", "DPkg::Lock::Timeout=600", "-o", "Dpkg::Options::=--force-confdef",
               "-o", "Dpkg::Options::=--force-confold"]
        adimlar = []
        if tur == "guncelle":
            if not os.environ.get("TYS_APT_TEST"):
                adimlar.append(["dpkg", "--configure", "-a", "--force-confdef", "--force-confold"])
            adimlar += [[apt] + sec + ["update"], [apt] + sec + ["upgrade", "--with-new-pkgs"]]
        elif tur == "paket_kur":
            adimlar += [[apt] + sec + ["update"], [apt] + sec + ["install"] + paketler]
        else:
            adimlar += [[apt] + sec + ["remove"] + paketler]
        ad = KOMUT_ADI.get(tur, tur) + (" ({})".format(", ".join(paketler)) if paketler else "")
        log("Başladı:", ad)
        self.olay_gonder("guncelleme", "{} başladı".format(ad))
        cikti, ok, mesaj = "", True, ""
        try:
            if WINDOWS:
                if not ROOT:
                    log("TEST: winget çalıştırılmadı")
                    mesaj = "test — çalıştırılmadı"
                else:
                    ok, mesaj, cikti = win_paket_calistir(tur, paketler)
            elif not ROOT and not os.environ.get("TYS_APT_TEST"):
                log("TEST: apt-get çalıştırılmadı")
                mesaj = "test — çalıştırılmadı"
            else:
                for komut in adimlar:
                    r = subprocess.run(komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                                       stdin=subprocess.DEVNULL, timeout=3 * 3600, universal_newlines=True,
                                       errors="replace")
                    cikti += "$ " + " ".join(komut) + "\n" + (r.stdout or "") + "\n"
                    if r.returncode != 0 and komut[0] != "dpkg":
                        ok = False
                        hatalar = [s[2:].strip() for s in (r.stdout or "").splitlines() if s.startswith(("E:", "Hata:"))]
                        mesaj = (hatalar[-1] if hatalar else "çıkış kodu {}".format(r.returncode))[:300]
                        break
                if ok:
                    m = re.findall(r"(\d+) upgraded, (\d+) newly installed, (\d+) to remove", cikti)
                    if m:
                        y, k, s = (int(x) for x in m[-1])
                        if tur == "guncelle":
                            mesaj = "{} paket güncellendi".format(y + k) if (y + k) else "Sistem zaten güncel"
                        elif tur == "paket_kur":
                            mesaj = "{} paket kuruldu".format(k) if k else "Zaten kurulu"
                        else:
                            mesaj = "{} paket kaldırıldı".format(s) if s else "Zaten kurulu değil"
                    else:
                        mesaj = "Tamamlandı"
        except subprocess.TimeoutExpired:
            ok, mesaj = False, "zaman aşımı (3 saat)"
        except Exception as e:
            ok, mesaj = False, str(e)[:300]
        try:
            yol = os.path.join(VERI, "guncelleme.log")
            with open(yol, "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + ad + "\n" + cikti[-200000:])
        except Exception:
            pass
        self.guncelleme_son = {"zaman": time.time() + self.ofset, "tur": tur, "ok": ok, "mesaj": mesaj,
                               "paketler": paketler}
        with self.kilit:
            self.apt = None
            bekleyen, self.bekleyen_guc = self.bekleyen_guc, None
        self.durum_kaydet()
        log("Bitti:", ad, "—", "başarılı" if ok else "HATA", mesaj)
        self.olay_gonder("guncelleme" if ok else "hata", "{}: {}".format(ad, mesaj))
        if bekleyen:
            log("Güncelleme bitti; bekleyen işlem uygulanıyor:", bekleyen)
            self.guc(bekleyen)

    # ── kilit ────────────────────────────────────────────────────────────────
    def kilitle(self, sebep):
        with self.kilit:
            if self.kilitli:
                return
            self.kilitli = True
            self.acan = None
            self.durum_kaydet()
            if WT and ROOT:
                win_gorev_yoneticisi(True)
            proc_durdur(self.geri_sayim_proc)
            self.geri_sayim_proc = None
        log("Kilitlendi:", sebep)
        self.olay_gonder("kilit", "Kilitlendi ({})".format(sebep))
        self.kilit_yonet()

    def kilit_ac(self, sebep, acan=None):
        with self.kilit:
            if not self.kilitli:
                return
            self.kilitli = False
            self.acan = acan
            self.kilit_acilma = time.monotonic()
            self.anlik = None
            self.pin_hata = 0
            self.durum_kaydet()
        if WT and ROOT:
            win_gorev_yoneticisi(False)
        log("Kilit açıldı:", sebep)
        self.kilit_yonet()
        self.olay_gonder("kilit", "Kilit açıldı ({})".format(sebep))
        if self.kapanis:
            self.geri_sayim_goster()

    def kilit_yonet(self):
        with self.kilit:
            p = self.kilit_proc
            calisiyor = p is not None and p.poll() is None
            if not self.kilitli:
                if calisiyor and time.time() < self.kilit_kapat_gecikme:
                    return  # "Hoş geldiniz" yazısı görünsün diye kısa bekleme
                if calisiyor:
                    proc_durdur(p)
                self.kilit_proc = None
                return
            if calisiyor:
                return
            n = time.time()
            if p is not None:
                self.kilit_proc = None
                if n - self.kilit_baslama < 5:
                    self.kilit_hatalari = [t for t in self.kilit_hatalari if n - t < 120] + [n]
                    if len(self.kilit_hatalari) >= 4:
                        log("Kilit ekranı açılamıyor; 60 sn sonra yeniden denenecek (ayrıntı: {}/arayuz.log)".format(VERI))
                        self.kilit_bekle = n + 60
                        self.kilit_hatalari = []
                        self.yedek_kilit()
            if n < self.kilit_bekle:
                return
            o = oturum_bul()
            if not o:
                return
            if not self.gtk:
                self.yedek_kilit()
                return
            self.kilit_proc = self.ui("kilit", {"port": YEREL_PORT}, o)
            self.kilit_baslama = n

    def yedek_kilit(self):
        """GTK yoksa masaüstünün kendi ekran kilidini kullanır."""
        if time.time() - self.yedek_kilit_zamani < 60 or not ROOT:
            return
        self.yedek_kilit_zamani = time.time()
        if WINDOWS:
            o = oturum_bul()
            if o:
                oturumda(["rundll32.exe", "user32.dll,LockWorkStation"], o)
            return
        subprocess.call(["loginctl", "lock-sessions"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def pin_dene(self, pin):
        n = time.time()
        if n < self.pin_bekle:
            return {"ok": False, "bekle": int(self.pin_bekle - n) + 1}
        pin = re.sub(r"\D", "", pin or "")[:12]
        if self.aralik and not self.aralik.get("ogretmen"):
            return {"ok": False, "hata": "Bu saatte tahta yalnızca yönetim panelinden açılabilir (kilit bitişi {}).".format(self.aralik.get("bitis"))}
        for p in self.ayar.get("pinler") or []:
            ozet = hashlib.sha256((p.get("tuz", "") + pin).encode()).hexdigest()
            if pin and hmac.compare_digest(ozet, p.get("ozet", "")):
                self.kilit_kapat_gecikme = time.time() + 1.5
                self.kilit_ac("{} şifresiyle".format(p.get("ad") or "öğretmen"), acan=p.get("ad") or "Öğretmen")
                return {"ok": True, "ad": p.get("ad")}
        self.pin_hata += 1
        if self.pin_hata >= 5:
            self.pin_hata = 0
            self.pin_bekle = n + 30
            self.olay_gonder("kilit", "Kilit ekranında 5 kez hatalı şifre girildi")
            return {"ok": False, "bekle": 30}
        return {"ok": False}

    def kilit_bilgisi(self):
        n = time.time()
        k = self.kilit_ayari()
        panolar = []
        if k.get("duyuru_goster", True):
            panolar = [p for p in self.ayar.get("panolar") or [] if p.get("bitis", 0) > n + self.ofset]
        anlik = self.anlik if self.anlik and self.anlik.get("bitis", 0) > n else None
        mesaj, pin_var = k.get("mesaj") or "Bu tahta kilitlidir.", self.pinler_var()
        a = self.aralik
        if a:
            mesaj = "{} · kilit bitişi {}.".format(a.get("ad") or "Kilitli saat aralığı", a.get("bitis"))
            if a.get("ogretmen") and pin_var:
                mesaj += " Gerekirse öğretmen şifrenizle açabilirsiniz."
            else:
                pin_var = False
        return {
            "okul_adi": self.ayar.get("okul_adi") or "", "ad": self.ayar.get("ad") or socket.gethostname(),
            "mesaj": mesaj, "pin_var": pin_var,
            "panolar": panolar, "anlik": anlik,
            "kapanis": self.kapanis["bitis"] if self.kapanis else None,
            "kapanis_bosta": bool(self.kapanis and self.kapanis.get("iptal_girdi")),
            "ofset": self.ofset, "utc_ofset": self.utc_ofset, "kilitli": self.kilitli,
            "tam_ekran": bool(self.tam_ekran_proc is not None and self.tam_ekran_proc.poll() is None) or self.acil_acik(),
            "acil": self.acil_acik(),
            "ariza_turleri": ARIZA_TURLERI,
        }

    def tam_ekran_bilgisi(self):
        n = time.time()
        anlik = self.anlik if self.anlik and self.anlik.get("bitis", 0) > n else None
        return {
            "tur": self.tam_ekran, "sinav": self.ayar.get("sinav"), "saat": self.ayar.get("saat_ekran"),
            "okul_adi": self.ayar.get("okul_adi") or "", "ad": self.ayar.get("ad") or socket.gethostname(),
            "anlik": anlik, "ofset": self.ofset, "utc_ofset": self.utc_ofset,
            "kapanis": self.kapanis["bitis"] if self.kapanis else None,
            "acil": self.acil_acik(),
        }

    def acil_acik(self):
        """Acil durum penceresi açık mı? (Kilit / sınav pencereleri bu sırada öne gelmez.)"""
        p = getattr(self, "acil_surec", None)
        return bool(p is not None and p.poll() is None)

    # ── güç ──────────────────────────────────────────────────────────────────
    def guc(self, islem):
        ad = {"poweroff": "Kapatılıyor", "reboot": "Yeniden başlatılıyor", "suspend": "Uyku moduna alınıyor"}[islem]
        with self.kilit:
            if self.apt:
                self.bekleyen_guc = islem
                log("Güncelleme sürüyor; '{}' işlemi güncelleme bitince yapılacak".format(ad))
                self.olay_gonder("guncelleme", "Güncelleme sürüyor; bitince {}".format(
                    {"poweroff": "kapanacak", "reboot": "yeniden başlayacak", "suspend": "uyku moduna geçecek"}[islem]))
                return
        log(ad)
        if islem == "suspend" and self.kilit_ayari().get("acilista", True) and self.pinler_var():
            self.kilitle("uyku moduna geçerken")
        self.olay_gonder("guc", ad, bekle=True)
        if TEST:
            log("TEST: güç işlemi", islem, "çalıştırılmadı")
            return
        if islem != "suspend":
            proc_durdur(self.geri_sayim_proc)
        if WINDOWS:
            win_guc(islem)
            return
        subprocess.Popen(["systemctl", islem], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def kapat_planla(self, gecikme, sebep, iptal_girdi=False):
        if gecikme <= 0:
            self.kapanis = None
            self.guc("poweroff")
            return
        self.kapanis = {"bitis": time.time() + gecikme, "sebep": sebep, "iptal_girdi": iptal_girdi}
        self.geri_sayim_goster()
        self.olay_gonder("guc", "{} sonra kapanacak ({})".format(sure_yazi(gecikme), sebep))

    def kapat_iptal(self, sebep):
        if not self.kapanis:
            return
        self.kapanis = None
        proc_durdur(self.geri_sayim_proc)
        self.geri_sayim_proc = None
        self.olay_gonder("guc", "Kapatma iptal edildi ({})".format(sebep))

    def geri_sayim_goster(self):
        proc_durdur(self.geri_sayim_proc)
        self.geri_sayim_proc = None
        if self.kapanis and not self.kilitli:
            self.geri_sayim_proc = self.ui("geri_sayim", {"bitis": self.kapanis["bitis"],
                                                         "bosta": bool(self.kapanis.get("iptal_girdi"))})
            self.geri_sayim_zamani = time.time()

    # ── duyuru, ses ──────────────────────────────────────────────────────────
    def duyuru(self, v):
        stil = "kucuk" if v.get("stil") == "kucuk" else "buyuk"
        sure = max(5, int(v.get("sure") or 20))
        if v.get("ses", True):
            self.ses_cal("duyuru" if stil == "buyuk" else "bildirim")
        o = oturum_bul()
        if self.kilitli or self.tam_ekran in ("sinav", "saat"):
            # Kilit ekranı veya sınav / saat ekranı açıkken duyuru o pencerenin içinde gösterilir
            self.anlik = {"baslik": v.get("baslik") or "", "metin": v.get("metin") or "", "bitis": time.time() + sure}
            return
        if self.tam_ekran == "koruyucu":
            self.tam_ekran_kapat()
        if not o:
            raise RuntimeError("Tahtada açık masaüstü oturumu yok, duyuru gösterilemedi")
        arg = {"baslik": v.get("baslik") or "", "metin": v.get("metin") or "", "sure": sure,
               "okul_adi": self.ayar.get("okul_adi") or ""}
        if self.gtk:
            if stil == "buyuk":
                proc_durdur(self.duyuru_proc)
                self.duyuru_proc = self.ui("duyuru", arg, o)
            else:
                proc_durdur(self.bildirim_proc)
                self.bildirim_proc = self.ui("bildirim", arg, o)
        elif not WINDOWS and shutil.which("notify-send"):
            oturumda(["notify-send", "-u", "critical" if stil == "buyuk" else "normal", "-t", str(sure * 1000),
                      arg["baslik"] or "Duyuru", arg["metin"]], o)
        else:
            raise RuntimeError("Bu tahtada pencere bileşeni ({}) yok".format("tkinter" if WINDOWS else "GTK"))

    def ses_yolu(self, ad):
        if ad.startswith("k:"):
            b = (self.ayar.get("zil_kitaplik") or {}).get(ad[2:])
            if b:
                yol = os.path.join(SES_DIZIN, "kit-{}.{}".format(ad[2:], b.get("uzanti", "mp3")))
                if os.path.exists(yol):
                    return yol
            log("Zil sesi henüz inmedi, ders zili çalınıyor:", ad)
            ad = "ders"
        ozel = (self.ayar.get("zil_ozel") or {}).get(ad)
        if ozel:
            yol = os.path.join(SES_DIZIN, "ozel-{}.{}".format(ad, ozel.get("uzanti", "wav")))
            if os.path.exists(yol):
                return yol
        yol = os.path.join(SES_DIZIN, ad + ".wav")
        if not os.path.exists(yol):
            ses_uret(ad, yol)
        return yol

    def ses_cal(self, ad, zil=False, sure=0, seviye=None):
        """Sesi çalar; çalan süreci döndürür (bilinmiyorsa None)."""
        yol = self.ses_yolu(ad)
        sure = max(0, min(int(sure or 0), 600))
        ac = bool(seviye or (zil and self.ayar.get("zil_sesi_ac", True)))
        if WINDOWS:
            o = oturum_bul()
            if o:
                return self.ui("ses", {"yol": yol, "ac": ac, "seviye": seviye or 70, "sure": sure}, o)
            elif yol.lower().endswith(".wav"):
                import winsound
                threading.Thread(target=winsound.PlaySound, args=(yol, winsound.SND_FILENAME), daemon=True).start()
            return None
        komut = oynatici(yol)
        if not komut:
            if zil:
                raise RuntimeError("Bu tahtada ses çalacak program bulunamadı")
            return None
        o = oturum_bul()
        if o:
            if ac:
                self.sesi_ac(o, seviye or 70)
            surec = oturumda(komut, o)
        elif ROOT and yol.endswith(".wav") and shutil.which("aplay"):
            surec = subprocess.Popen(["aplay", "-q", yol], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            return None
        if sure:
            t = threading.Timer(sure, proc_durdur, args=(surec,))
            t.daemon = True
            t.start()
        return surec

    def sesi_ac(self, o, seviye=70):
        """Zil duyulsun diye ses kapalıysa açar, çok kısıksa istenen düzeye (%70) çıkarır."""
        try:
            if shutil.which("pactl"):
                oturumda(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"], o, yakala=True, zaman_asimi=5)
                r = oturumda(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], o, yakala=True, zaman_asimi=5)
                yuzde = [int(x) for x in re.findall(rb"(\d+)%", r.stdout or b"")]
                if yuzde and max(yuzde) < seviye:
                    oturumda(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % seviye], o, yakala=True, zaman_asimi=5)
            elif shutil.which("wpctl"):
                oturumda(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"], o, yakala=True, zaman_asimi=5)
                r = oturumda(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], o, yakala=True, zaman_asimi=5)
                m = re.search(rb"([0-9.]+)", r.stdout or b"")
                if m and float(m.group(1)) < seviye / 100.0 - 0.005:
                    oturumda(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "%.2f" % (seviye / 100.0)], o, yakala=True, zaman_asimi=5)
        except Exception:
            pass

    def ozel_sesleri_indir(self):
        with self.ses_kilit:
            self._ozel_sesleri_indir()
            self.kitaplik_indir()

    def kitaplik_indir(self):
        """Zil programı ses kitaplığını tahtaya indirir (çevrimdışı çalabilmek için)."""
        kit = self.ayar.get("zil_kitaplik") or {}
        for eski in glob.glob(os.path.join(SES_DIZIN, "kit-*")):
            if eski.endswith(".ozet") or eski.endswith(".tmp"):
                continue
            sid = os.path.basename(eski)[4:].rsplit(".", 1)[0]
            b = kit.get(sid)
            if not b or not eski.endswith("." + b.get("uzanti", "")) or dosya_oku(eski + ".ozet").strip() != b.get("ozet"):
                for f in (eski, eski + ".ozet"):
                    try:
                        os.remove(f)
                    except OSError:
                        pass
        for sid, b in kit.items():
            if not re.match(r"^[0-9a-f]{6,32}$", sid) or not re.match(r"^[a-z0-9]{2,5}$", b.get("uzanti", "")):
                continue
            yol = os.path.join(SES_DIZIN, "kit-{}.{}".format(sid, b["uzanti"]))
            if os.path.exists(yol):
                continue
            try:
                veri = self.istek("/api/a/ses/k-" + sid, zaman=120)
                with open(yol + ".tmp", "wb") as f:
                    f.write(veri)
                os.chmod(yol + ".tmp", 0o644)
                os.replace(yol + ".tmp", yol)
                with open(yol + ".ozet", "w") as f:
                    f.write(b.get("ozet", ""))
                log("Zil sesi indirildi:", sid)
            except Exception as e:
                log("Zil sesi indirilemedi:", sid, e)

    def _ozel_sesleri_indir(self):
        ozel = self.ayar.get("zil_ozel") or {}
        for tur in ("ders", "teneffus"):
            for eski in glob.glob(os.path.join(SES_DIZIN, "ozel-{}.*".format(tur))):
                b = ozel.get(tur)
                if not b or not eski.endswith("." + b.get("uzanti", "")) or \
                        dosya_oku(eski + ".ozet").strip() != b.get("ozet"):
                    if not eski.endswith(".ozet"):
                        try:
                            os.remove(eski)
                            os.remove(eski + ".ozet")
                        except OSError:
                            pass
            b = ozel.get(tur)
            if not b:
                continue
            yol = os.path.join(SES_DIZIN, "ozel-{}.{}".format(tur, b.get("uzanti", "wav")))
            if os.path.exists(yol):
                continue
            try:
                veri = self.istek("/api/a/ses/" + tur, zaman=60)
                with open(yol, "wb") as f:
                    f.write(veri)
                os.chmod(yol, 0o644)
                with open(yol + ".ozet", "w") as f:
                    f.write(b.get("ozet", ""))
                log("Özel zil sesi indirildi:", tur)
            except Exception as e:
                log("Zil sesi indirilemedi:", e)

    # ── ekran görüntüsü ──────────────────────────────────────────────────────
    def ekran_gonder(self, boyut):
        if boyut in self.ekran_mesgul:
            return
        self.ekran_mesgul.add(boyut)
        try:
            o = oturum_bul()
            if not o:
                return
            veri = b""
            if WINDOWS:
                yol = os.path.join(PAYLASIM, "gecici", "ekran-{}-{}.jpg".format(boyut, hashlib.sha1(os.urandom(8)).hexdigest()[:10]))
                try:
                    self.ui("ekran_al", {"boyut": boyut, "cikis": yol}, o, yakala=True, zaman_asimi=20)
                    if os.path.isfile(yol) and not win_baglanti_mi(yol):
                        with open(yol, "rb") as f:
                            veri = f.read(16 * 1024 * 1024)
                finally:
                    try:
                        os.remove(yol)
                    except OSError:
                        pass
            elif self.gtk:
                r = oturumda([sys.executable, AJAN_YOLU, "--arayuz", "ekran_al", json.dumps({"boyut": boyut})],
                             o, yakala=True, zaman_asimi=20)
                veri = r.stdout or b""
            if len(veri) < 100 and not WINDOWS and shutil.which("scrot"):
                gecici = "/tmp/tys-ekran-{}.png".format(os.getpid())
                oturumda(["scrot", "-o", gecici], o, yakala=True, zaman_asimi=15)
                if os.path.exists(gecici):
                    with open(gecici, "rb") as f:
                        veri = f.read()
                    os.remove(gecici)
            if len(veri) >= 100:
                self.istek("/api/a/ekran?id={}&boyut={}".format(quote(self.id), boyut), ham=veri, zaman=30)
        except Exception as e:
            log("Ekran görüntüsü alınamadı:", e)
        finally:
            self.ekran_mesgul.discard(boyut)

    # ── dosya ────────────────────────────────────────────────────────────────
    def varsayilan_kullanici(self):
        if pwd is None:
            return None
        adaylar = []
        if self.son_kullanici:
            try:
                adaylar.append(pwd.getpwnam(self.son_kullanici))
            except KeyError:
                pass
        adaylar += kullanicilar()
        return kullanici_baglami(adaylar[0]) if adaylar else None

    def dosya_al_guvenli(self, v):
        try:
            self.dosya_al(v)
        except Exception as e:
            log("Dosya alınamadı:", e)
            self.olay_gonder("hata", "Dosya alınamadı ({}): {}".format(v.get("ad"), e))

    def dosya_al(self, v):
        """Dosyayı önce ajanın kendi geçici klasörüne indirir, sonra kullanıcı hesabıyla
        Masaüstü › Gelen Dosyalar klasörüne kopyalar (yönetici olarak kullanıcı klasörüne yazılmaz)."""
        import tempfile
        fid, ad = v["fid"], guvenli_ad(v.get("ad"))
        if WINDOWS:
            return self.dosya_al_win(fid, ad, v)
        o = oturum_bul()
        k = o or self.varsayilan_kullanici()
        if not k:
            raise RuntimeError("Dosyanın kaydedileceği kullanıcı bulunamadı")
        gecici_dizin = tempfile.mkdtemp(prefix="tys-gelen-")
        try:
            os.chmod(gecici_dizin, 0o711)
            gecici = os.path.join(gecici_dizin, "dosya")
            with self.ham_istek("/api/a/dosya/{}?id={}".format(fid, quote(self.id)), zaman=60) as y, \
                    open(gecici, "wb") as f:
                for parca in iter(lambda: y.read(256 * 1024), b""):
                    f.write(parca)
            os.chmod(gecici, 0o644)
            masaustu = os.path.join(VERI, "Masaustu") if TEST else ""
            r = oturumda([sys.executable, "-c", KOPYA_BETIGI, gecici, ad, masaustu], k, yakala=True, zaman_asimi=300,
                         hata_akisi=subprocess.PIPE)
            if r.returncode != 0:
                son = (r.stderr or b"").decode("utf-8", "replace").strip().splitlines()
                raise RuntimeError(son[-1] if son else "kopyalanamadı")
            hedef = (r.stdout or b"").decode("utf-8", "replace").strip()
        finally:
            shutil.rmtree(gecici_dizin, ignore_errors=True)
        log("Dosya alındı:", hedef)
        self.olay_gonder("dosya_teslim", veri={"fid": fid})
        if o and not self.kilitli and not self.tam_ekran:
            self.ui("bildirim", {"baslik": "Yeni dosya geldi", "metin": "{}\nMasaüstü › Gelen Dosyalar".format(ad),
                                 "sure": 10, "okul_adi": ""}, o)
            if v.get("ac") and shutil.which("xdg-open") and hedef:
                oturumda(["xdg-open", hedef], o)

    def dosya_al_win(self, fid, ad, v):
        """Windows: dosya tüm kullanıcıların masaüstündeki 'Gelen Dosyalar' klasörüne iner."""
        ad = re.sub(r'[<>:"|?*]', "_", ad)
        if ad.split(".")[0].lower() in AYRILMIS_AD:
            ad = "_" + ad
        ilk = not os.path.isdir(GELEN_YOL)
        os.makedirs(GELEN_YOL, exist_ok=True)
        if win_baglanti_mi(GELEN_YOL):
            raise RuntimeError("Gelen Dosyalar klasörü güvenli değil (bağlantı)")
        if ilk and ROOT:
            win_herkes_yazabilir(GELEN_YOL)
        hedef = os.path.join(GELEN_YOL, ad)
        kok, uz = os.path.splitext(hedef)
        i = 2
        while os.path.lexists(hedef):
            hedef = "%s (%d)%s" % (kok, i, uz)
            i += 1
        gecici = os.path.join(GELEN_YOL, ".{}.indiriliyor".format(hashlib.sha1(os.urandom(8)).hexdigest()[:10]))
        try:
            with self.ham_istek("/api/a/dosya/{}?id={}".format(fid, quote(self.id)), zaman=60) as y, \
                    open(gecici, "wb") as f:
                for parca in iter(lambda: y.read(256 * 1024), b""):
                    f.write(parca)
            os.replace(gecici, hedef)
        finally:
            try:
                os.remove(gecici)
            except OSError:
                pass
        log("Dosya alındı:", hedef)
        self.olay_gonder("dosya_teslim", veri={"fid": fid})
        o = oturum_bul()
        if o and not self.kilitli and not self.tam_ekran:
            self.ui("bildirim", {"baslik": "Yeni dosya geldi", "metin": "{}\nMasaüstü › Gelen Dosyalar".format(os.path.basename(hedef)),
                                 "sure": 10, "okul_adi": ""}, o)
            if v.get("ac"):
                self.ui("ac", {"hedef": hedef}, o)

    # ── tanı raporu ──────────────────────────────────────────────────────────
    def tani_raporu(self):
        o = oturum_bul()
        satirlar = [
            "Tahta programı: {}".format(SURUM), "İşletim sistemi: {}".format(os_adi()),
            "Python: {} ({})".format(sys.version.split()[0], sys.executable),
            "Yönetici yetkisi: {}{}".format("evet" if ROOT else "HAYIR", " (SYSTEM)" if WINDOWS and win_sistem_mi() else ""),
            "Bilgisayar adı: {}".format(socket.gethostname()), "Yönetim bilgisayarı: {}".format(self.sunucu),
            "Ağ: IP {} · MAC {}".format(self.ag[1], self.ag[2]),
            "Oturum: {}".format(o["kullanici"] if o else "yok (giriş ekranında)"),
            "Pencere bileşeni ({}): {}".format("tkinter" if WINDOWS else "GTK", "var" if self.gtk else "YOK"),
            "Boşta kalma izleme: {}".format("çalışıyor" if self.giris_izlenebilir else "yok"),
            "Kilitli: {} · Tam ekran: {} · Kilit penceresi: {}".format(
                self.kilitli, self.tam_ekran or "-", "açık" if (self.kilit_proc and self.kilit_proc.poll() is None) else "kapalı"),
            "Ortak Klasör: {} · {}".format(ORTAK_YOL, self.ortak.durum.get("durum")),
            "Site engeli: {}".format(self.engel_ozet), "Veri klasörü: {}".format(VERI),
        ]
        if WINDOWS:
            satirlar += ["", "── ajan.log (son satırlar) ──", dosya_sonu(os.path.join(VERI, "ajan.log"), 120)]
            for y in sorted(glob.glob(os.path.join(PAYLASIM, "gunluk", "*.log")))[-3:]:
                satirlar += ["", "── {} ──".format(os.path.basename(y)), dosya_sonu(y, 40)]
        else:
            _, cikti = (0, _calistir_cikti(["journalctl", "-u", "tahta-ajan", "-n", "120", "--no-pager"], 15))
            satirlar += ["", "── journalctl -u tahta-ajan ──", cikti, "", "── arayuz.log ──",
                         dosya_sonu(os.path.join(VERI, "arayuz.log"), 40)]
        return "\n".join(str(x) for x in satirlar) + "\n"

    def tani_gonder(self):
        self.istek("/api/a/tani", ham=self.tani_raporu().encode("utf-8"), zaman=30)
        log("Tanı raporu gönderildi")

    # ── güncelleme, kaldırma ─────────────────────────────────────────────────
    def guncelle(self, hedef_surum):
        if time.time() - self.son_guncelleme < 600 or TEST:
            return
        self.son_guncelleme = time.time()
        try:
            veri = self.istek("/api/a/kod", zaman=60)
            compile(veri, AJAN_YOLU, "exec")
            gecici = AJAN_YOLU + ".yeni"
            with open(gecici, "wb") as f:
                f.write(veri)
            os.chmod(gecici, 0o755)
            os.replace(gecici, AJAN_YOLU)
            log("Güncellendi: {} → {}. Yeniden başlatılıyor…".format(SURUM, hedef_surum))
            self.olay_gonder("sistem", "Tahta programı güncellendi ({} → {})".format(SURUM, hedef_surum), bekle=True)
            self.durum_kaydet()
            eski_arayuzleri_kapat()
            if WINDOWS:
                tek_ornek_birak()
                subprocess.Popen([sys.executable, AJAN_YOLU, "--devral"], close_fds=True,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW)
                os._exit(0)
            os.execv(sys.executable, [sys.executable, AJAN_YOLU])
        except Exception as e:
            log("Güncelleme başarısız:", e)

    def kaldir(self):
        self.olay_gonder("sistem", "Tahta programı kaldırılıyor", bekle=True)
        if TEST:
            log("TEST: kaldırma atlandı")
            return
        temizle(self.engel_kayit)
        if WINDOWS:
            win_kaldir_baslat()
            threading.Timer(2.0, lambda: os._exit(0)).start()
            return
        betik = ("sleep 2; systemctl disable --now tahta-ajan; rm -f /etc/systemd/system/tahta-ajan.service; "
                 "systemctl daemon-reload; rm -rf /opt/tahta-ajan /var/lib/tahta-ajan")
        if shutil.which("systemd-run"):
            subprocess.Popen(["systemd-run", "--no-block", "--collect", "/bin/bash", "-c", betik])
        else:
            subprocess.Popen(["/bin/bash", "-c", betik], start_new_session=True)

    # ── zamanlayıcı ve boşta kalma ───────────────────────────────────────────
    def zamanlayici(self):
        while True:
            time.sleep(5)
            for is_ in (self.acil_isle, self.kurallari_isle, self.ziller_isle, self.aralik_isle, self.bosta_isle, self.engel_uygula, self.masaustu_duzenle,
                        self.ariza_gonder):
                try:
                    is_()
                except Exception:
                    log("Zamanlayıcı hatası:", traceback.format_exc())
            if time.time() - self.son_kayit > 300:
                self.durum_kaydet()

    # ── site engeli ──────────────────────────────────────────────────────────
    def engel_alanlari(self):
        e = self.ayar.get("site_engel")
        if not e:
            return []
        if time.time() < self.engel_ara_bitis:
            return []
        if e.get("zaman") == "saatlerde":
            t = self.sunucu_saati()
            gun, hm = t.tm_wday + 1, "%02d:%02d" % (t.tm_hour, t.tm_min)
            if not any(gun in (a.get("gunler") or []) and a.get("bas", "") <= hm < a.get("bit", "")
                       for a in e.get("araliklar") or []):
                return []
        alanlar = []
        for x in e.get("siteler") or []:
            a = alan_temizle(x)
            if a and a not in alanlar:
                alanlar.append(a)
        return alanlar

    def engel_uygula(self, zorla=False):
        alanlar = self.engel_alanlari()
        imza = json.dumps(alanlar)
        n = time.time()
        ara = self.engel_ara_bitis > n
        if imza != self.engel_imza or zorla or n - self.engel_son > 600:
            self.engel_son = n
            if ROOT or KOK_ONEK:
                try:
                    hosts_uygula(alanlar)
                    chromium_uygula(alanlar, self.engel_kayit)
                    desenler = []
                    for a in alanlar:
                        desenler += ["*://{}/*".format(a), "*://*.{}/*".format(a)]
                    firefox_uygula(desenler, self.engel_kayit)
                    hata = None
                except Exception as e:
                    hata = str(e)[:200]
                    log("Site engeli uygulanamadı:", e)
            else:
                hata = None
            if imza != self.engel_imza:
                if self.engel_imza is not None or alanlar:
                    log("Site engeli:", "{} site engellendi".format(len(alanlar)) if alanlar else "kaldırıldı")
                self.engel_imza = imza
                self.durum_kaydet()
            self.engel_ozet = None if not (alanlar or ara or self.ayar.get("site_engel")) else {
                "aktif": bool(alanlar), "sayi": len(alanlar), "hata": hata,
                "ara": self.engel_ara_bitis + self.ofset if ara else None}
        elif self.engel_ozet:
            self.engel_ozet["ara"] = self.engel_ara_bitis + self.ofset if ara else None

    # ── masaüstü simgeleri (Ortak Klasör, Arıza Bildir) ──────────────────────
    def masaustu_duzenle(self, zorla=False):
        if WINDOWS:
            return self.masaustu_duzenle_win(zorla)
        if not ROOT and not os.environ.get("TYS_MASAUSTU_TEST"):
            return
        arg = {"ortak": bool(self.ayar.get("ortak_etkin", True)), "ortak_hedef": ORTAK_YOL, "ortak_ad": ORTAK_AD,
               "ariza": ariza_desktop() if self.ayar.get("ariza_simge") else ""}
        imza = json.dumps(arg, sort_keys=True)
        if imza == self.masaustu_imza and not zorla and time.time() - self.masaustu_son < 900:
            return
        if arg["ortak"] and not os.path.isdir(ORTAK_YOL):
            try:
                self.ortak.klasorleri_olustur(ORTAK_YOL)
                self.ortak.izin_ayarla(ORTAK_YOL, True)
            except Exception:
                pass
        self.masaustu_imza, self.masaustu_son = imza, time.time()
        hedefler = [kullanici_baglami(p) for p in kullanicilar()] if ROOT else [dict(
            uid=os.getuid(), gid=os.getgid(), kullanici="test", home=os.path.expanduser("~"), gruplar=[],
            env={"HOME": os.path.expanduser("~"), "PATH": "/usr/bin:/bin"})]
        for k in hedefler:
            try:
                r = oturumda([sys.executable, "-c", SIMGE_BETIGI, json.dumps(arg, ensure_ascii=False)], k,
                             yakala=True, zaman_asimi=20, hata_akisi=subprocess.PIPE)
                if r.returncode != 0:
                    log("Masaüstü simgeleri ({}):".format(k["kullanici"]),
                        (r.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-1:])
            except Exception as e:
                log("Masaüstü simgeleri ({}): {}".format(k["kullanici"], e))

    def masaustu_duzenle_win(self, zorla=False):
        """Windows: tüm kullanıcıların masaüstüne Ortak Klasör ve Arıza Bildir kısayolları."""
        if not ROOT:
            return
        ortak, ariza = bool(self.ayar.get("ortak_etkin", True)), bool(self.ayar.get("ariza_simge"))
        imza = json.dumps([ortak, ariza])
        if imza == self.masaustu_imza and not zorla and time.time() - self.masaustu_son < 900:
            return
        self.masaustu_imza, self.masaustu_son = imza, time.time()
        if ortak and not os.path.isdir(ORTAK_YOL):
            try:
                os.makedirs(ORTAK_YOL, exist_ok=True)
                win_herkes_yazabilir(ORTAK_YOL)
            except OSError as e:
                log("Ortak Klasör oluşturulamadı:", e)
        masa = os.path.join(WIN_ORTAK_PROFIL, "Desktop")
        for ad, iste, hedef, arg, ikon, aciklama in (
                (ORTAK_AD + ".lnk", ortak, ORTAK_YOL, "", os.path.join(os.environ.get("SystemRoot") or r"C:\Windows",
                 "System32", "imageres.dll") + ",-1023", "Okulun ortak dosyaları (tahtalarla eşitlenir)"),
                ("Arıza Bildir.lnk", ariza, pythonw_yolu(), '"{}" --arayuz ariza'.format(AJAN_YOLU),
                 os.path.join(os.environ.get("SystemRoot") or r"C:\Windows", "System32", "imageres.dll") + ",-84",
                 "Tahtadaki bir sorunu okul yönetimine bildirir")):
            yol = os.path.join(masa, ad)
            if iste and not os.path.exists(yol):
                win_kisayol(yol, hedef, arg, ikon, aciklama)
            elif not iste and os.path.exists(yol):
                try:
                    os.remove(yol)
                except OSError:
                    pass

    # ── arıza bildirimi ──────────────────────────────────────────────────────
    def ariza_ekle(self, g):
        n = time.time()
        self.ariza_zamanlari = [t for t in self.ariza_zamanlari if n - t < 600]
        if len(self.ariza_zamanlari) >= 5:
            return {"ok": False, "hata": "Çok sık bildirim yapıldı. Biraz sonra tekrar deneyin."}
        self.ariza_zamanlari.append(n)
        kategori = g.get("kategori") if g.get("kategori") in ARIZA_TURLERI else "Diğer"
        a = {"kategori": kategori, "aciklama": str(g.get("aciklama") or "").strip()[:500],
             "bildiren": str(g.get("bildiren") or self.acan or "").strip()[:60], "yer": g.get("yer") or ""}
        a["zaman"] = n
        with self.kilit:
            self.ariza_kuyruk.append(a)
        self.durum_kaydet()
        log("Arıza bildirildi:", kategori)
        threading.Thread(target=self.ariza_gonder, daemon=True).start()
        return {"ok": True}

    def ariza_gonder(self):
        while self.ariza_kuyruk:
            with self.kilit:
                if not self.ariza_kuyruk:
                    return
                a = dict(self.ariza_kuyruk[0])
            try:
                self.istek("/api/a/ariza", {"id": self.id, "kategori": a["kategori"], "aciklama": a["aciklama"],
                                            "bildiren": a["bildiren"], "zaman": a["zaman"] + self.ofset}, zaman=10)
            except urllib.error.HTTPError as e:
                if e.code < 500:
                    log("Arıza kaydı reddedildi:", e.code)
                else:
                    return
            except Exception:
                return
            with self.kilit:
                if self.ariza_kuyruk and self.ariza_kuyruk[0].get("zaman") == a["zaman"]:
                    self.ariza_kuyruk.pop(0)
            self.durum_kaydet()

    # ── sınav ve saat ekranı ─────────────────────────────────────────────────
    def tam_ekran_hedefi(self):
        ns = time.time() + self.ofset
        s = self.ayar.get("sinav")
        if s and ns < float(s.get("bitis") or 0) + 180:
            return ("sinav", s.get("id"))
        sa = self.ayar.get("saat_ekran")
        if sa and sa.get("id") not in self.saat_kapatilan:
            return ("saat", sa.get("id"))
        dk = int(self.ayar.get("saat_koruyucu_dk") or 0)
        b = self.bosta_sn()
        if dk and b is not None and b >= dk * 60 and not self.kilitli and not self.kapanis:
            return ("koruyucu", None)
        return None

    def tam_ekran_kapat(self):
        if self.tam_ekran == "saat" and self.tam_ekran_anahtar:
            self.saat_kapatilan.add(self.tam_ekran_anahtar[1])
        proc_durdur(self.tam_ekran_proc)
        self.tam_ekran_proc = None
        self.tam_ekran = None
        self.tam_ekran_anahtar = None

    def tam_ekran_yonet(self):
        hedef = self.tam_ekran_hedefi()
        p = self.tam_ekran_proc
        calisiyor = p is not None and p.poll() is None
        n = time.time()
        if hedef != self.tam_ekran_anahtar:
            if calisiyor:
                proc_durdur(p)
            self.tam_ekran_proc = None
            self.tam_ekran_anahtar = hedef
            self.tam_ekran = hedef[0] if hedef else None
            self.tam_ekran_bekle = 0.0
            calisiyor = False
            if hedef:
                log("Tam ekran:", hedef[0])
            self.durum_bildir()
        if not hedef or calisiyor:
            return
        if p is not None:
            # Pencere kendiliğinden kapandı (ekran koruyucuya dokunuldu ya da pencere açılamadı)
            self.tam_ekran_proc = None
            if hedef[0] == "koruyucu":
                self.tam_ekran_bekle = n + 120
            elif n - self.tam_ekran_baslama < 5:
                self.tam_ekran_bekle = n + 30      # açılır açılmaz kapanıyorsa bir süre bekle
        if n < self.tam_ekran_bekle or not self.gtk:
            return
        o = oturum_bul()
        if not o:
            return
        self.tam_ekran_proc = self.ui("tam_ekran", {"port": YEREL_PORT, "tur": hedef[0]}, o)
        self.tam_ekran_baslama = n

    def sinav_sesleri_cal(self):
        s = self.ayar.get("sinav")
        if not s or not s.get("ses"):
            return
        ns = time.time() + self.ofset
        bas, bitis, uyari = float(s.get("bas") or 0), float(s.get("bitis") or 0), int(s.get("uyari_dk") or 0)
        olaylar = [("bas", bas, "bildirim"), ("bitis", bitis, "teneffus")]
        if uyari and bitis - uyari * 60 > bas:
            olaylar.append(("uyari", bitis - uyari * 60, "duyuru"))
        for ad, zaman, ses in olaylar:
            anahtar = "{}|{}|{:.0f}".format(s.get("id"), ad, zaman)
            if anahtar in self.sinav_sesleri:
                continue
            if 0 <= ns - zaman < 30:
                self.sinav_sesleri.add(anahtar)
                try:
                    self.ses_cal(ses, zil=(ad == "bitis"))
                except Exception as e:
                    log("Sınav sesi çalınamadı:", e)
            elif ns - zaman >= 30:
                self.sinav_sesleri.add(anahtar)

    def kurallari_isle(self):
        if not self.ayar.get("zamanlayici_etkin", True):
            return
        t = self.sunucu_saati()
        gun = t.tm_wday + 1
        simdi_sn = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec
        tarih = time.strftime("%Y-%m-%d", t)
        for k in self.ayar.get("kurallar") or []:
            if gun not in (k.get("gunler") or []) or k.get("tur") == "kilit_araligi":
                continue
            try:
                sa, dk = [int(x) for x in k["saat"].split(":")]
            except Exception:
                continue
            fark = simdi_sn - (sa * 3600 + dk * 60)
            anahtar = "{}|{}|{}".format(k.get("id"), tarih, k["saat"])
            if 0 <= fark < 90 and anahtar not in self.calisan:
                self.calisan.add(anahtar)
                self.durum_kaydet()
                ad = KOMUT_ADI.get(k["tur"], k["tur"])
                log("Zamanlayıcı:", k["saat"], ad)
                self.olay_gonder("kural", "Zamanlayıcı {}: {}".format(k["saat"], ad))
                self.kuyruk.put({"tur": k["tur"], "veri": k.get("veri") or {},
                                 "kaynak": "zamanlayıcı {}".format(k["saat"])})

    def ziller_isle(self):
        ziller = self.ayar.get("ziller") or []
        if not ziller:
            return
        acil = bool(self.acil_id)
        t = self.sunucu_saati()
        tarih = time.strftime("%Y-%m-%d", t)
        if any(a <= tarih <= b for a, b in (self.ayar.get("zil_tatil") or [])):
            return
        gun = t.tm_wday + 1
        simdi_sn = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec
        for z in ziller:
            if gun not in (z.get("gunler") or []):
                continue
            try:
                sa, dk = [int(x) for x in z["saat"].split(":")]
            except Exception:
                continue
            fark = simdi_sn - (sa * 3600 + dk * 60)
            anahtar = "zil|{}|{}".format(tarih, z["saat"])
            if 0 <= fark < 90 and anahtar not in self.calisan:
                self.calisan.add(anahtar)
                self.durum_kaydet()
                if acil:                       # acil durum sürerken zil susar (sonradan da çalmaz)
                    log("Zil atlandı (acil durum):", z["saat"])
                    continue
                ad = z.get("ad") or "Zil"
                log("Zil programı:", z["saat"], ad)
                self.olay_gonder("kural", "Zil {}: {}".format(z["saat"], ad))
                self.kuyruk.put({"tur": "zil", "veri": {"ses": z.get("ses") or "ders", "sure": z.get("sure") or 0},
                                 "kaynak": "zil programı {}".format(z["saat"])})

    def aralik_bul(self):
        """Şu an süren kilitli saat aralığı kuralı (yoksa None)."""
        if not self.ayar.get("zamanlayici_etkin", True):
            return None
        t = self.sunucu_saati()
        gun = t.tm_wday + 1
        simdi = "{:02d}:{:02d}".format(t.tm_hour, t.tm_min)
        atla = set(self.ayar.get("aralik_atla") or [])
        for k in self.ayar.get("kurallar") or []:
            v = k.get("veri") or {}
            if (k.get("tur") == "kilit_araligi" and gun in (k.get("gunler") or []) and k.get("id") not in atla
                    and k.get("saat", "99:99") <= simdi < v.get("bitis", "00:00")):
                return {"id": k.get("id"), "ad": k.get("aciklama") or "", "bitis": v.get("bitis"),
                        "ogretmen": bool(v.get("ogretmen", True)), "bitince_ac": bool(v.get("bitince_ac", True))}
        return None

    def aralik_isle(self):
        """Kilitli saat aralığı: aralık başlayınca kilitler, açılırsa 5 dk kullanılmayınca yeniden
        kilitler, bitince (isteğe bağlı) kilidi açar. Aralık içinde açılan tahta da kilitlenir."""
        yeni = self.aralik_bul()
        eski = self.aralik
        if (yeni or {}).get("id") != (eski or {}).get("id"):
            self.aralik = yeni
            if eski and eski.get("bitince_ac") and self.kilitli and eski.get("kilitledi"):
                self.kilit_ac("kilitli saat aralığı bitti")
            if yeni:
                yeni["kilitledi"] = not self.kilitli
                self.kilitle("kilitli saat aralığı {}–{}".format(
                    next((k.get("saat") for k in self.ayar.get("kurallar") or [] if k.get("id") == yeni["id"]), ""),
                    yeni["bitis"]))
            return
        if yeni and not self.kilitli:
            bosta = self.bosta_sn()
            if bosta is None:
                return
            bosta = min(bosta, time.monotonic() - self.kilit_acilma)
            if bosta >= 300:
                yeni["kilitledi"] = True
                self.kilitle("kilitli saat aralığında 5 dakika kullanılmadığı için")

    def bosta_isle(self):
        bosta = self.bosta_sn()
        if bosta is None:
            return
        k = self.kilit_ayari()
        kilit_dk = int(k.get("bosta_kilit_dk") or 0)
        kapat_dk = int(k.get("bosta_kapat_dk") or 0)
        if kilit_dk and bosta >= kilit_dk * 60 and not self.kilitli and self.pinler_var():
            self.kilitle("{} dakika kullanılmadığı için".format(kilit_dk))
        if kapat_dk and bosta >= kapat_dk * 60 and not self.kapanis:
            self.kapat_planla(60, "{} dakika kullanılmadığı için".format(kapat_dk), iptal_girdi=True)

    def giris_izle(self):
        """Dokunmatik ekran, klavye ve fare hareketlerini izler (boşta kalma süresi için).
        Windows'ta oturumdaki küçük yardımcı süreç (--arayuz izleyici) /girdi ile bildirir."""
        if not ROOT or WINDOWS:
            return
        atla = ("accel", "lid switch", "power button", "sleep button", "video bus", "pc speaker",
                "hdmi", "headphone", " mic", "hda ", "jack")
        acik = {}
        son_tarama = 0.0
        while True:
            if time.time() - son_tarama > 30:
                son_tarama = time.time()
                for yol in glob.glob("/dev/input/event*"):
                    if yol in acik:
                        continue
                    ad = dosya_oku("/sys/class/input/%s/device/name" % os.path.basename(yol)).lower()
                    if any(x in ad for x in atla):
                        continue
                    try:
                        acik[yol] = os.open(yol, os.O_RDONLY | os.O_NONBLOCK)
                    except OSError:
                        pass
                self.giris_izlenebilir = bool(acik)
            if not acik:
                time.sleep(5)
                continue
            try:
                hazir, _, _ = select.select(list(acik.values()), [], [], 5)
            except (OSError, ValueError):
                for fd in acik.values():
                    try:
                        os.close(fd)
                    except OSError:
                        pass
                acik = {}
                continue
            if hazir:
                self.son_giris = time.monotonic()
                for fd in hazir:
                    try:
                        while os.read(fd, 4096):
                            pass
                    except BlockingIOError:
                        pass
                    except OSError:
                        for yol, f in list(acik.items()):
                            if f == fd:
                                acik.pop(yol)
                                try:
                                    os.close(fd)
                                except OSError:
                                    pass

    # ── bekçi: pencereleri ve geri sayımı yönetir ────────────────────────────
    def bekci(self):
        while True:
            time.sleep(1)
            try:
                self.kilit_yonet()
                if WINDOWS:
                    self.izleyici_yonet()
                n = time.time()
                if self.kapanis:
                    if self.kapanis.get("iptal_girdi"):
                        b = self.bosta_sn()
                        if b is not None and b < 3:
                            self.kapat_iptal("tahta kullanılmaya başlandı")
                            continue
                    if n >= self.kapanis["bitis"]:
                        self.kapanis = None
                        self.guc("poweroff")
                        continue
                    p = self.geri_sayim_proc
                    if self.kilitli and p is not None:
                        proc_durdur(p)
                        self.geri_sayim_proc = None
                    elif not self.kilitli and (p is None or p.poll() is not None) and n - self.geri_sayim_zamani > 10:
                        self.geri_sayim_goster()
                for ad in ("duyuru_proc", "bildirim_proc"):
                    p = getattr(self, ad)
                    if p is not None and p.poll() is not None:
                        setattr(self, ad, None)
                if self.anlik and self.anlik.get("bitis", 0) < n:
                    self.anlik = None
                self.tam_ekran_yonet()
                self.sinav_sesleri_cal()
            except Exception:
                log("Bekçi hatası:", traceback.format_exc())

    def izleyici_yonet(self):
        if time.monotonic() - self.son_girdi_rapor > 20:
            self.giris_izlenebilir = False
        o = oturum_bul()
        p = self.izleyici_proc
        if o and (p is None or p.poll() is not None) and time.time() - self.izleyici_zamani > 15:
            self.izleyici_zamani = time.time()
            self.izleyici_proc = self.ui("izleyici", {"port": YEREL_PORT}, o)

    # ── yerel API (kilit ekranı penceresi için) ──────────────────────────────
    def yerel_api(self):
        ajan = self

        class Isleyici(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def yanit(self, obj):
                b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                if self.path.startswith("/bilgi"):
                    return self.yanit(ajan.kilit_bilgisi())
                if self.path.startswith("/tam_ekran"):
                    return self.yanit(ajan.tam_ekran_bilgisi())
                if self.path.startswith("/ariza"):
                    return self.yanit({"turler": ARIZA_TURLERI, "ad": ajan.ayar.get("ad") or socket.gethostname(),
                                       "okul_adi": ajan.ayar.get("okul_adi") or "", "acan": ajan.acan})
                self.send_error(404)

            def do_POST(self):
                n = min(int(self.headers.get("Content-Length") or 0), 4000)
                try:
                    g = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                except Exception:
                    g = {}
                if self.path.startswith("/pin"):
                    return self.yanit(ajan.pin_dene(str(g.get("pin", ""))))
                if self.path.startswith("/ariza"):
                    return self.yanit(ajan.ariza_ekle(g))
                if self.path.startswith("/girdi"):
                    try:
                        bosta = max(0.0, float(g.get("bosta_ms") or 0) / 1000.0)
                    except (TypeError, ValueError):
                        bosta = 0.0
                    ajan.son_giris = time.monotonic() - bosta
                    ajan.son_girdi_rapor = time.monotonic()
                    ajan.giris_izlenebilir = True
                    return self.yanit({"ok": True})
                if self.path.startswith("/tam_ekran/kapat"):
                    sa = ajan.ayar.get("saat_ekran") or {}
                    if ajan.tam_ekran == "saat" and sa.get("kapatilabilir"):
                        ajan.tam_ekran_kapat()
                        return self.yanit({"ok": True})
                    if ajan.tam_ekran == "koruyucu":
                        ajan.tam_ekran_kapat()
                        ajan.son_giris = time.monotonic()
                        return self.yanit({"ok": True})
                    return self.yanit({"ok": False})
                self.send_error(404)

        for deneme in range(60):
            try:
                s = ThreadingHTTPServer(("127.0.0.1", YEREL_PORT), Isleyici)
                break
            except OSError as e:
                if deneme in (0, 59):
                    log("Yerel arayüz bağlantı noktası açılamadı:", e)
                time.sleep(1)
        else:
            return
        s.daemon_threads = True
        s.serve_forever()

    # ── başlat ───────────────────────────────────────────────────────────────
    def calistir(self):
        log("Tahta Yönetim Ajanı {} başladı — sunucu {} — kimlik {}".format(SURUM, self.sunucu, self.id[:12]))
        eski_arayuzleri_kapat()
        self.gtk = gtk_var_mi()
        self.ses_var = True if WINDOWS else bool(oynatici("x.wav"))
        if not self.gtk:
            log("Uyarı: {} bulunamadı; kilit ekranı ve duyuru pencereleri sınırlı çalışacak.".format(
                "tkinter" if WINDOWS else "GTK"))
        if acilis_degisti(self.acilis, self.onceki_acilis):
            # Tahta yeni açıldı. (Çalışmış kurallar listesi korunur: aksi halde
            # "08:00 yeniden başlat" kuralı açılışta tekrar tekrar çalışırdı.)
            if self.kilit_ayari().get("acilista", True) and self.pinler_var():
                self.kilitli = True
        self.durum_kaydet()
        if WT and ROOT:
            win_gorev_yoneticisi(self.kilitli)
            for d in (os.path.join(PAYLASIM, "gecici"), os.path.join(PAYLASIM, "gunluk")):
                win_herkes_yazabilir(d)

        def ses_hazirla():
            for ad in ("ders", "teneffus", "duyuru", "bildirim"):
                yol = os.path.join(SES_DIZIN, ad + ".wav")
                if not os.path.exists(yol):
                    try:
                        ses_uret(ad, yol)
                    except Exception as e:
                        log("Ses üretilemedi:", ad, e)

        for hedef in (ses_hazirla, self.senk_dongusu, self.komut_isci, self.bekci, self.zamanlayici,
                      self.giris_izle, self.kesif_dinle, self.yerel_api, self.ozel_sesleri_indir,
                      self.ortak.calistir):
            threading.Thread(target=hedef, daemon=True).start()

        def bitir(*_):
            proc_durdur(self.kilit_proc)
            proc_durdur(self.tam_ekran_proc)
            proc_durdur(self.geri_sayim_proc)
            proc_durdur(self.duyuru_proc)
            proc_durdur(self.bildirim_proc)
            self.durum_kaydet()
            os._exit(0)

        signal.signal(signal.SIGTERM, bitir)
        signal.signal(signal.SIGINT, bitir)
        while True:
            time.sleep(3600)


# ═════════════════════════════════════════════════════════════════════════════
# Öğretmen bilgisayarı (Windows) — yalnızca Ortak Klasör eşitlemesi
# ═════════════════════════════════════════════════════════════════════════════

class IstemciAjan(Baglanti):
    def __init__(self):
        os.makedirs(VERI, exist_ok=True)
        b = json_oku(BAGLANTI)
        if not b or not b.get("sunucu"):
            log("Bağlantı ayarı bulunamadı:", BAGLANTI, "— kurulumu yeniden yapın.")
            sys.exit(1)
        self.sunucu = b["sunucu"].rstrip("/")
        self.anahtar = b.get("anahtar", "")
        self.kimlik = b.get("kimlik", "")
        try:
            import getpass
            self.kullanici = getpass.getuser()
        except Exception:
            self.kullanici = os.environ.get("USERNAME") or "kullanici"
        self.id = (makine_kimligi()[:40] + "-" + hashlib.sha1(self.kullanici.lower().encode("utf-8")).hexdigest()[:6])
        self.cihaz_adi = (b.get("ad") or socket.gethostname())[:60]
        self.sunucu_ad = b.get("sunucu_ad") or ""
        self.acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.son_isaret = None
        self.son_kesif = 0.0
        self.son_guncelleme = 0.0
        self.ortak = OrtakEsitleyici(self, ORTAK_YOL, VERI, lambda: self.cihaz_adi)

    def kesif_kontrol(self):
        """Yönetim bilgisayarının IP adresi değiştiyse bilgisayar adından yeni adresi bulur.
        (Öğretmen bilgisayarında UDP dinlenmez; Windows güvenlik duvarı uyarısı çıkmasın diye.)"""
        if not self.sunucu_ad or time.time() - self.son_kesif < 120:
            return
        self.son_kesif = time.time()
        try:
            ip = socket.gethostbyname(self.sunucu_ad)
            port = int((re.search(r":(\d+)$", self.sunucu) or [None, "8765"])[1])
        except (OSError, ValueError):
            return
        yeni = "http://{}:{}".format(ip, port)
        if yeni == self.sunucu:
            return
        try:
            with self.acici.open(yeni + "/api/saglik", timeout=5) as y:
                if b"TahtaYonetim" not in y.read():
                    return
        except Exception:
            return
        log("Yönetim bilgisayarının yeni adresi bulundu:", yeni)
        self.sunucu = yeni
        try:
            b = json_oku(BAGLANTI, {}) or {}
            b["sunucu"] = yeni
            json_yaz(BAGLANTI, b)
        except Exception:
            pass

    def os_bilgisi(self):
        try:
            import platform
            return "{} {}".format(platform.system(), platform.release())
        except Exception:
            return "Windows"

    def kalp(self):
        hata = 0
        while True:
            try:
                c = self.istek("/api/a/istemci", {
                    "id": self.id, "ad": self.cihaz_adi, "kullanici": self.kullanici, "surum": SURUM,
                    "os": self.os_bilgisi(), "ortak": dict(self.ortak.durum, etkin=self.ortak.etkin),
                    "klasor": ORTAK_YOL}, zaman=15)
                if hata:
                    log("Yönetim bilgisayarına yeniden bağlanıldı:", self.sunucu)
                hata = 0
                hedef = c.get("ajan_surum")
                if hedef and hedef not in ("?", SURUM):
                    self.guncelle(hedef)
            except urllib.error.HTTPError as e:
                hata += 1
                if e.code == 401 and hata in (1, 10):
                    log("Yönetim bilgisayarı bu bilgisayarı tanımıyor. Kurulumu yeniden yapın.")
            except Exception as e:
                hata += 1
                if hata in (1, 5) or hata % 30 == 0:
                    log("Bağlantı yok ({}): {}".format(self.sunucu, e))
                if hata >= 3:
                    self.kesif_kontrol()
            time.sleep(60 if not hata else min(60, 10 * hata))

    def guncelle(self, hedef_surum):
        if time.time() - self.son_guncelleme < 600:
            return
        self.son_guncelleme = time.time()
        try:
            veri = self.istek("/api/a/kod", zaman=60)
            compile(veri, AJAN_YOLU, "exec")
            gecici = AJAN_YOLU + ".yeni"
            with open(gecici, "wb") as f:
                f.write(veri)
            os.replace(gecici, AJAN_YOLU)
            log("Güncellendi: {} → {}. Yeniden başlatılıyor…".format(SURUM, hedef_surum))
            tek_ornek_birak()
            if WINDOWS:
                subprocess.Popen([sys.executable, AJAN_YOLU, "--istemci"], close_fds=True,
                                 creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) |
                                 getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
                os._exit(0)
            os.execv(sys.executable, [sys.executable, AJAN_YOLU, "--istemci"])
        except Exception as e:
            log("Güncelleme başarısız:", e)

    def calistir(self):
        log("Tahta Yönetimi — öğretmen bilgisayarı {} — sunucu {} — klasör {}".format(SURUM, self.sunucu, ORTAK_YOL))
        try:
            os.makedirs(ORTAK_YOL, exist_ok=True)
        except OSError as e:
            log("Ortak Klasör oluşturulamadı:", e)
        for hedef in (self.kalp, self.ortak.calistir):
            threading.Thread(target=hedef, daemon=True).start()
        while True:
            time.sleep(3600)


_tek_soket = [None]


def tek_ornek(port=None, deneme=30):
    """Aynı kullanıcıda ikinci kopya çalışmasın (güncellemeden sonra eskisinin kapanmasını bekler)."""
    port = port or int(os.environ.get("TYS_ISTEMCI_PORT", "8768"))
    for _ in range(deneme):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if WINDOWS and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            s.bind(("127.0.0.1", port))
            s.listen(1)
            _tek_soket[0] = s
            return True
        except OSError:
            s.close()
            time.sleep(1)
    return False


def tek_ornek_birak():
    if _tek_soket[0] is not None:
        try:
            _tek_soket[0].close()
        except OSError:
            pass
        _tek_soket[0] = None


def istemci_gunlugu():
    """pythonw ile çalışırken çıktı penceresi yoktur; günlük dosyaya yazılır."""
    try:
        os.makedirs(VERI, exist_ok=True)
        yol = os.path.join(VERI, "istemci.log")
        if os.path.exists(yol) and os.path.getsize(yol) > 1024 * 1024:
            os.replace(yol, yol + ".1")
        f = open(yol, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = f
    except Exception:
        pass


# ═════════════════════════════════════════════════════════════════════════════
# ARAYÜZ — masaüstü oturumundaki kullanıcı olarak çalışır (Pardus: GTK 3, Windows: tkinter)
# ═════════════════════════════════════════════════════════════════════════════

ARAYUZ_CSS = """
.tys-arka { background-color: #0a0f1f; background-image: linear-gradient(155deg, #0a0f1f 0%, #101a3a 55%, #0d2350 100%); }
.tys-seffaf { background-color: transparent; background-image: none; }
.tys-ust { color: #8ea2d8; font-size: @s20px; font-weight: 600; }
.tys-saat { color: #ffffff; font-size: @s128px; font-weight: 200; }
.tys-tarih { color: #b7c3e6; font-size: @s26px; }
.tys-baslik { color: #ffffff; font-size: @s34px; font-weight: 700; }
.tys-mesaj { color: #9fb0da; font-size: @s20px; }
.tys-kart { background-color: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.10);
            border-radius: @s28px; padding: @s32px; }
.tys-pin-baslik { color: #c9d4f5; font-size: @s20px; font-weight: 600; }
.tys-pin { color: #ffffff; font-size: @s44px; }
.tys-tus { background-image: none; background-color: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14);
           border-radius: @s20px; color: #ffffff; font-size: @s36px; font-weight: 500; min-width: @s116px;
           min-height: @s92px; box-shadow: none; text-shadow: none; -gtk-icon-shadow: none; }
.tys-tus label { color: #ffffff; }
.tys-tus:hover { background-color: rgba(255,255,255,0.15); }
.tys-tus:active { background-color: rgba(80,130,255,0.55); }
.tys-tus-ana { background-color: #2f6bff; border-color: #2f6bff; font-size: @s28px; font-weight: 700; }
.tys-tus-ana:hover { background-color: #4a7fff; }
.tys-tus-ikincil { font-size: @s24px; }
.tys-hata { color: #ff8a94; font-size: @s20px; }
.tys-basari { color: #6ee7a8; font-size: @s22px; font-weight: 700; }
.tys-pano { background-color: rgba(255,209,102,0.10); border: 1px solid rgba(255,209,102,0.35);
            border-radius: @s20px; padding: @s20px @s26px; }
.tys-pano-anlik { background-color: rgba(255,90,90,0.16); border-color: rgba(255,120,120,0.6); }
.tys-pano-baslik { color: #ffd166; font-size: @s20px; font-weight: 700; }
.tys-pano-metin { color: #ffffff; font-size: @s24px; }
.tys-uyari { background-color: #c0262d; border-radius: @s16px; padding: @s14px @s24px; color: #ffffff;
             font-size: @s24px; font-weight: 700; }
.tys-rozet { background-color: #ffd166; color: #1a1300; border-radius: @s40px; padding: @s8px @s24px;
             font-size: @s22px; font-weight: 800; }
.tys-d-baslik { color: #ffd166; font-size: @s48px; font-weight: 800; }
.tys-d-metin-b { color: #ffffff; font-size: @s64px; font-weight: 600; }
.tys-d-metin-o { color: #ffffff; font-size: @s46px; font-weight: 500; }
.tys-d-metin-k { color: #ffffff; font-size: @s32px; }
.tys-alt { color: #8ea2d8; font-size: @s20px; }
.tys-dugme { background-image: none; background-color: #2f6bff; color: #ffffff; border: none; border-radius: @s16px;
             font-size: @s26px; font-weight: 700; padding: @s14px @s56px; box-shadow: none; text-shadow: none; }
.tys-dugme label { color: #ffffff; }
.tys-dugme:hover { background-color: #4a7fff; }
.tys-bildirim { background-color: #141c35; border: 1px solid #34457a; border-radius: @s20px; padding: @s20px @s24px; }
.tys-b-baslik { color: #ffd166; font-size: @s20px; font-weight: 700; }
.tys-b-metin { color: #ffffff; font-size: @s22px; }
.tys-kapat { background-image: none; background-color: transparent; border: none; color: #8ea2d8;
             font-size: @s24px; box-shadow: none; padding: 0 @s8px; min-height: 0; min-width: 0; }
.tys-geri { background-color: #8f1d22; border-radius: 0 0 @s22px @s22px; padding: @s18px @s34px; }
.tys-g-baslik { color: #ffffff; font-size: @s22px; font-weight: 700; }
.tys-g-sure { color: #ffffff; font-size: @s52px; font-weight: 800; }
.tys-g-aciklama { color: #ffd7d9; font-size: @s18px; }
.tys-duz-bildirim { background-color: #141c35; }
.tys-duz-bildirim .tys-bildirim { border-radius: 0; }
.tys-duz-geri { background-color: #8f1d22; }
.tys-duz-geri .tys-geri { border-radius: 0; }
.tys-alt-dugme { background-image: none; background-color: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.14);
                 border-radius: @s14px; color: #c9d4f5; font-size: @s20px; padding: @s10px @s22px; box-shadow: none;
                 text-shadow: none; }
.tys-alt-dugme label { color: #c9d4f5; }
.tys-alt-dugme:hover { background-color: rgba(255,255,255,0.14); }
.tys-ariza-tus { background-image: none; background-color: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14);
                 border-radius: @s16px; color: #ffffff; font-size: @s22px; font-weight: 600; min-height: @s76px;
                 min-width: @s200px; padding: @s8px @s16px; box-shadow: none; text-shadow: none; }
.tys-ariza-tus label { color: #ffffff; }
.tys-ariza-tus:hover { background-color: rgba(255,255,255,0.15); }
.tys-ariza-tus:checked, .tys-ariza-tus:active { background-color: rgba(255,170,60,0.30); border-color: #ffb347; }
.tys-giris { background-image: none; background-color: rgba(255,255,255,0.08); color: #ffffff; caret-color: #ffffff;
             border: 1px solid rgba(255,255,255,0.18); border-radius: @s12px; font-size: @s22px; padding: @s10px @s14px;
             box-shadow: none; }
.tys-etiket { color: #c9d4f5; font-size: @s20px; font-weight: 600; }
.tys-te-rozet { background-color: #2f6bff; color: #ffffff; border-radius: @s40px; padding: @s8px @s28px;
                font-size: @s24px; font-weight: 800; }
.tys-te-baslik { color: #ffffff; font-size: @s60px; font-weight: 700; }
.tys-te-sure { color: #ffffff; font-size: @s250px; font-weight: 300; }
.tys-te-uyari { color: #ffd166; }
.tys-te-bitti { color: #ff6b6b; }
.tys-te-durum { color: #b7c3e6; font-size: @s34px; font-weight: 500; }
.tys-te-bilgi { color: #8ea2d8; font-size: @s28px; }
.tys-te-saat { color: #ffffff; font-size: @s300px; font-weight: 200; }
.tys-te-saniye { color: #6f86c4; font-size: @s96px; font-weight: 300; }
.tys-te-tarih { color: #b7c3e6; font-size: @s44px; }
.tys-te-mesaj { color: #ffd166; font-size: @s40px; font-weight: 600; }
.tys-te-ipucu { color: #6f86c4; font-size: @s24px; }
"""


def ekran_al(arg):
    """Masaüstünün görüntüsünü JPEG olarak stdout'a yazar."""
    import gi
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import Gdk, GdkPixbuf
    Gdk.init([])
    w = Gdk.get_default_root_window()
    if w is None:
        return 1
    # Ekranların kapladığı alan, GTK'nın ölçekli birimiyle (4K + %200 tahtalarda kök pencere
    # fiziksel pikseli verdiği için görüntü sol üst çeyreğe sıkışıyordu)
    X0 = Y0 = 0
    G, Y = w.get_width(), w.get_height()
    try:
        gosterge = Gdk.Display.get_default()
        alan = [gosterge.get_monitor(i).get_geometry() for i in range(gosterge.get_n_monitors())]
        alan = [g for g in alan if g.width > 0 and g.height > 0]
        if alan:
            X0, Y0 = min(g.x for g in alan), min(g.y for g in alan)
            G = max(g.x + g.width for g in alan) - X0
            Y = max(g.y + g.height for g in alan) - Y0
    except Exception:
        pass
    pb = Gdk.pixbuf_get_from_window(w, X0, Y0, G, Y)
    if pb is None:
        return 1
    pg, py = pb.get_width(), pb.get_height()
    boyut = arg.get("boyut")
    hedef = {"buyuk": min(1600, pg), "tam": min(2560, pg)}.get(boyut, 480)
    if pg > hedef:
        pb = pb.scale_simple(hedef, max(1, int(py * hedef / float(pg))),
                             GdkPixbuf.InterpType.HYPER if boyut == "tam" else GdkPixbuf.InterpType.BILINEAR)
    ok, tampon = pb.save_to_bufferv("jpeg", ["quality"], [{"buyuk": "72", "tam": "80"}.get(boyut, "55")])
    if ok:
        sys.stdout.buffer.write(tampon)
        sys.stdout.flush()
    return 0


# ═════════════════════════════════════════════════════════════════════════════
# ARAYÜZ — Windows (tkinter). Oturumdaki kullanıcı olarak çalışır; ajanla yalnızca
# 127.0.0.1 üzerindeki yerel bağlantıdan konuşur.
# ═════════════════════════════════════════════════════════════════════════════

WRENK = {
    "arka": "#0d1630", "kart": "#1a2340", "kart_kenar": "#2b3554", "ust": "#8ea2d8", "beyaz": "#ffffff",
    "tarih": "#b7c3e6", "mesaj": "#9fb0da", "pin_baslik": "#c9d4f5", "tus": "#202a45", "tus_ust": "#2f3a5a",
    "tus_kenar": "#36415f", "basili": "#3a5bb0", "ana": "#2f6bff", "ana_ust": "#4a7fff", "hata": "#ff8a94",
    "basari": "#6ee7a8", "pano": "#262a37", "pano_kenar": "#6e6240", "pano_anlik": "#382236",
    "pano_anlik_kenar": "#a24a55", "sari": "#ffd166", "kirmizi": "#c0262d", "koyu_kirmizi": "#8f1d22",
    "acik_kirmizi": "#ffd7d9", "bildirim": "#141c35", "bildirim_kenar": "#34457a", "ipucu": "#6f86c4",
    "alt": "#1c2541", "alt_ust": "#2a3456", "alt_kenar": "#323d5e", "secili": "#4a3a2a", "secili_kenar": "#ffb347",
    "giris": "#1f2944", "giris_kenar": "#3a4566", "bitti": "#ff6b6b", "cubuk": "#253051",
}


def win_ekran_al(arg):
    """Masaüstünün görüntüsünü (tüm ekranlar) küçültüp JPEG olarak arg['cikis'] dosyasına yazar."""
    win_dpi()
    u32, g32 = ctypes.WinDLL("user32"), ctypes.WinDLL("gdi32")
    for f, res, ar in (
            (u32.GetDC, ctypes.c_void_p, [ctypes.c_void_p]), (u32.ReleaseDC, ctypes.c_int, [ctypes.c_void_p, ctypes.c_void_p]),
            (g32.CreateCompatibleDC, ctypes.c_void_p, [ctypes.c_void_p]),
            (g32.CreateCompatibleBitmap, ctypes.c_void_p, [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]),
            (g32.SelectObject, ctypes.c_void_p, [ctypes.c_void_p, ctypes.c_void_p]),
            (g32.SetStretchBltMode, ctypes.c_int, [ctypes.c_void_p, ctypes.c_int]),
            (g32.SetBrushOrgEx, ctypes.c_int, [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]),
            (g32.StretchBlt, ctypes.c_int, [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                            ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.DWORD]),
            (g32.DeleteDC, ctypes.c_int, [ctypes.c_void_p]), (g32.DeleteObject, ctypes.c_int, [ctypes.c_void_p])):
        f.restype, f.argtypes = res, ar
    gsm = u32.GetSystemMetrics
    x, y, w, h = gsm(76), gsm(77), gsm(78), gsm(79)
    if w <= 0 or h <= 0:
        x, y, w, h = 0, 0, gsm(0), gsm(1)
    boyut = arg.get("boyut")
    hedef = {"buyuk": 1600, "tam": 2560}.get(boyut, 480)
    tw = min(hedef, w)
    th = max(1, int(round(h * tw / float(w))))
    ekran = u32.GetDC(None)
    dc = g32.CreateCompatibleDC(ekran)
    bmp = g32.CreateCompatibleBitmap(ekran, tw, th)
    eski = g32.SelectObject(dc, bmp)
    try:
        g32.SetStretchBltMode(dc, 4)                       # HALFTONE: küçültürken yumuşak
        g32.SetBrushOrgEx(dc, 0, 0, None)
        g32.StretchBlt(dc, 0, 0, tw, th, ekran, x, y, w, h, 0x00CC0020 | 0x40000000)   # SRCCOPY | CAPTUREBLT
        g32.SelectObject(dc, eski)
        cikis = arg.get("cikis")
        kalite = {"buyuk": 72, "tam": 80}.get(boyut, 55)
        try:
            win_jpeg_kaydet(bmp, cikis, kalite)
        except Exception:
            traceback.print_exc()
            win_png_kaydet(dc, bmp, tw, th, cikis)
    finally:
        g32.DeleteObject(bmp)
        g32.DeleteDC(dc)
        u32.ReleaseDC(None, ekran)
    return 0


class _GUID(ctypes.Structure if WINDOWS else object):
    if WINDOWS:
        _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
                    ("Data4", ctypes.c_ubyte * 8)]


def _guid(metin):
    import uuid
    return _GUID.from_buffer_copy(uuid.UUID(metin).bytes_le)


def win_jpeg_kaydet(bmp, yol, kalite):
    """GDI+ ile JPEG (Windows'la gelir; ek kütüphane gerekmez)."""
    gdip = ctypes.WinDLL("gdiplus")

    class Giris(ctypes.Structure):
        _fields_ = [("GdiplusVersion", ctypes.c_uint32), ("DebugEventCallback", ctypes.c_void_p),
                    ("SuppressBackgroundThread", wintypes.BOOL), ("SuppressExternalCodecs", wintypes.BOOL)]

    class Parametre(ctypes.Structure):
        _fields_ = [("Guid", _GUID), ("NumberOfValues", ctypes.c_ulong), ("Type", ctypes.c_ulong), ("Value", ctypes.c_void_p)]

    class Parametreler(ctypes.Structure):
        _fields_ = [("Count", ctypes.c_uint), ("Parameter", Parametre * 1)]

    gdip.GdiplusStartup.argtypes = [ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(Giris), ctypes.c_void_p]
    gdip.GdipCreateBitmapFromHBITMAP.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    gdip.GdipSaveImageToFile.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.POINTER(_GUID), ctypes.POINTER(Parametreler)]
    gdip.GdipDisposeImage.argtypes = [ctypes.c_void_p]
    gdip.GdiplusShutdown.argtypes = [ctypes.c_size_t]
    belirtec = ctypes.c_size_t()
    g = Giris(1, None, False, False)
    if gdip.GdiplusStartup(ctypes.byref(belirtec), ctypes.byref(g), None) != 0:
        raise OSError("GdiplusStartup")
    resim = ctypes.c_void_p()
    try:
        if gdip.GdipCreateBitmapFromHBITMAP(bmp, None, ctypes.byref(resim)) != 0:
            raise OSError("GdipCreateBitmapFromHBITMAP")
        k = ctypes.c_ulong(int(kalite))
        p = Parametreler()
        p.Count = 1
        p.Parameter[0].Guid = _guid("1d5be4b5-fa4a-452d-9cdd-5db35105e7eb")      # EncoderQuality
        p.Parameter[0].NumberOfValues = 1
        p.Parameter[0].Type = 4                                                    # Long
        p.Parameter[0].Value = ctypes.cast(ctypes.pointer(k), ctypes.c_void_p)
        jpeg = _guid("557cf401-1a04-11d3-9a73-0000f81ef32e")
        if gdip.GdipSaveImageToFile(resim, yol, ctypes.byref(jpeg), ctypes.byref(p)) != 0:
            raise OSError("GdipSaveImageToFile")
    finally:
        if resim.value:
            gdip.GdipDisposeImage(resim)
        gdip.GdiplusShutdown(belirtec)


def win_png_kaydet(dc, bmp, w, h, yol):
    """GDI+ çalışmazsa: ham pikselleri PNG olarak yazar (zlib ile)."""
    import zlib

    class BIH(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                    ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]
    g32 = ctypes.WinDLL("gdi32")
    g32.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_uint]
    b = BIH()
    b.biSize, b.biWidth, b.biHeight, b.biPlanes, b.biBitCount = ctypes.sizeof(BIH), w, -h, 1, 32
    tampon = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(dc, bmp, 0, h, tampon, ctypes.byref(b), 0)
    ham = tampon.raw
    rgb = bytearray(w * h * 3)
    rgb[0::3], rgb[1::3], rgb[2::3] = ham[2::4], ham[1::4], ham[0::4]
    satir = w * 3
    veri = b"".join(b"\x00" + bytes(rgb[i * satir:(i + 1) * satir]) for i in range(h))

    def parca(tur, icerik):
        return struct.pack(">I", len(icerik)) + tur + icerik + struct.pack(">I", zlib.crc32(tur + icerik) & 0xffffffff)
    with open(yol, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + parca(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) +
                parca(b"IDAT", zlib.compress(veri, 6)) + parca(b"IEND", b""))


def win_sesi_ac(seviye=70):
    """Zil duyulsun diye: ses kapalıysa açar, istenen düzeyin altındaysa yükseltir (Windows ses API'si)."""
    hedef = max(0.1, min(1.0, seviye / 100.0))
    ole32 = ctypes.WinDLL("ole32")
    ole32.CoInitialize(None)
    HR = ctypes.HRESULT

    def metot(nesne, sira, *argturleri):
        tablo = ctypes.cast(nesne, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
        f = ctypes.WINFUNCTYPE(HR, ctypes.c_void_p, *argturleri)(tablo[sira])
        return lambda *a: f(nesne, *a)
    ole32.CoCreateInstance.argtypes = [ctypes.POINTER(_GUID), ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_GUID),
                                       ctypes.POINTER(ctypes.c_void_p)]
    sayici, aygit, ses = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
    try:
        ole32.CoCreateInstance(ctypes.byref(_guid("bcde0395-e52f-467c-8e3d-c4579291692e")), None, 0x17,
                               ctypes.byref(_guid("a95664d2-9614-4f35-a746-de8db63617e6")), ctypes.byref(sayici))
        metot(sayici, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))(0, 1, ctypes.byref(aygit))
        metot(aygit, 3, ctypes.POINTER(_GUID), wintypes.DWORD, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p))(
            ctypes.byref(_guid("5cdf2c82-841e-4546-9722-0cf74078229a")), 0x17, None, ctypes.byref(ses))
        sessiz = wintypes.BOOL()
        metot(ses, 15, ctypes.POINTER(wintypes.BOOL))(ctypes.byref(sessiz))
        if sessiz.value:
            metot(ses, 14, wintypes.BOOL, ctypes.c_void_p)(False, None)
        duzey = ctypes.c_float()
        metot(ses, 9, ctypes.POINTER(ctypes.c_float))(ctypes.byref(duzey))
        if duzey.value < hedef - 0.005:
            metot(ses, 7, ctypes.c_float, ctypes.c_void_p)(hedef, None)
    finally:
        for n in (ses, aygit, sayici):
            if n.value:
                metot(n, 2)()


def win_ses(arg):
    if arg.get("ac"):
        try:
            win_sesi_ac(int(arg.get("seviye") or 70))
        except Exception:
            traceback.print_exc()
    yol = arg.get("yol") or ""
    sure = int(arg.get("sure") or 0)
    if yol.lower().endswith(".wav"):
        import winsound
        if sure:
            winsound.PlaySound(yol, winsound.SND_FILENAME | winsound.SND_ASYNC)
            time.sleep(sure)
            winsound.PlaySound(None, 0)
        else:
            winsound.PlaySound(yol, winsound.SND_FILENAME)
        return 0
    mci = ctypes.WinDLL("winmm").mciSendStringW
    mci.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p]
    mci('open "%s" type mpegvideo alias tyszil' % yol, None, 0, None)
    if not sure:
        mci("play tyszil wait", None, 0, None)
    else:
        mci("play tyszil", None, 0, None)
        tampon = ctypes.create_unicode_buffer(64)
        bitis = time.time() + sure
        while time.time() < bitis:
            time.sleep(0.25)
            mci("status tyszil mode", tampon, 64, None)
            if tampon.value.lower() not in ("playing", "seeking", ""):
                break
        mci("stop tyszil", None, 0, None)
    mci("close tyszil", None, 0, None)
    return 0


def win_izleyici(arg):
    """Oturumda çalışır: son dokunma / klavye / fare hareketinden beri geçen süreyi ajana bildirir."""
    class LII(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]
    u32, k32 = ctypes.WinDLL("user32"), ctypes.WinDLL("kernel32")
    k32.GetTickCount.restype = wintypes.DWORD
    acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    adres = "http://127.0.0.1:%d/girdi" % int(arg.get("port") or YEREL_PORT)
    hata = 0
    while True:
        l = LII()
        l.cbSize = ctypes.sizeof(l)
        bosta = 0
        if u32.GetLastInputInfo(ctypes.byref(l)):
            bosta = (k32.GetTickCount() - l.dwTime) & 0xFFFFFFFF
        try:
            r = urllib.request.Request(adres, data=json.dumps({"bosta_ms": bosta}).encode(),
                                       headers={"Content-Type": "application/json"})
            acici.open(r, timeout=5).read()
            hata = 0
        except Exception:
            hata += 1
            if hata > 40:
                return 0
        time.sleep(2)


_KANCALAR = []


def win_klavye_kancasi():
    """Kilit ekranında Windows tuşu, Alt+Tab, Alt+F4, Ctrl+Esc gibi kısayolları engeller."""
    u32, k32 = ctypes.WinDLL("user32"), ctypes.WinDLL("kernel32")
    LRESULT = ctypes.c_ssize_t
    Kanca = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

    class KBD(ctypes.Structure):
        _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]
    u32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    u32.CallNextHookEx.restype = LRESULT
    u32.SetWindowsHookExW.argtypes = [ctypes.c_int, Kanca, ctypes.c_void_p, wintypes.DWORD]
    u32.SetWindowsHookExW.restype = ctypes.c_void_p
    u32.GetAsyncKeyState.restype = ctypes.c_short
    k32.GetModuleHandleW.restype = ctypes.c_void_p

    def kanca(n, w, l):
        if n == 0:
            k = ctypes.cast(l, ctypes.POINTER(KBD)).contents
            alt = bool(k.flags & 0x20)
            ctrl = bool(u32.GetAsyncKeyState(0x11) & 0x8000)
            vk = k.vkCode
            if vk in (0x5B, 0x5C, 0x5D) or (alt and vk in (0x09, 0x1B, 0x73, 0x20)) or (ctrl and vk == 0x1B):
                return 1
        return u32.CallNextHookEx(None, n, w, l)
    cb = Kanca(kanca)
    h = u32.SetWindowsHookExW(13, cb, k32.GetModuleHandleW(None), 0)    # WH_KEYBOARD_LL
    _KANCALAR.append((h, cb))   # geri çağırma nesnesi süreç boyunca yaşamalı
    return (h, cb)


def arayuz_win(tur, arg):
    if tur == "ekran_al":
        return win_ekran_al(arg)
    if tur == "ses":
        return win_ses(arg)
    if tur == "ac":
        os.startfile(arg.get("hedef") or "")
        return 0
    if tur == "izleyici":
        return win_izleyici(arg)
    win_dpi()
    import tkinter as tk
    import tkinter.font as tkfont
    u32 = ctypes.WinDLL("user32")
    gsm = u32.GetSystemMetrics
    VX, VY, VW, VH = gsm(76), gsm(77), gsm(78), gsm(79)
    PW, PH = gsm(0), gsm(1)
    if VW <= 0 or VH <= 0:
        VX, VY, VW, VH = 0, 0, PW, PH
    olcek = max(0.55, min(2.6, min(PW / 1920.0, PH / 1080.0)))
    R = WRENK

    def px(n):
        return max(1, int(round(n * olcek)))

    def yazi(boy, agirlik="normal"):
        aile = {"ince": "Segoe UI Light", "yari": "Segoe UI Semibold"}.get(agirlik, "Segoe UI")
        return (aile, -px(boy), "bold" if agirlik == "kalin" else "normal")

    kok = tk.Tk()
    kok.withdraw()
    kok.title("Tahta Yönetim")
    kok.configure(bg=R["arka"])
    kuyruk = queue.Queue()

    def arkada(is_, sonra=None):
        def calis():
            try:
                sonuc = is_()
            except Exception as e:
                sonuc = e
            if sonra:
                kuyruk.put((sonra, sonuc))
        threading.Thread(target=calis, daemon=True).start()

    def kuyruk_isle():
        try:
            while True:
                f, v = kuyruk.get_nowait()
                try:
                    f(v)
                except Exception:
                    traceback.print_exc()
        except queue.Empty:
            pass
        kok.after(80, kuyruk_isle)
    kok.after(80, kuyruk_isle)
    acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def yerel(yol, govde=None):
        veri = json.dumps(govde).encode() if govde is not None else None
        r = urllib.request.Request("http://127.0.0.1:%d%s" % (int(arg.get("port") or YEREL_PORT), yol), data=veri,
                                   headers={"Content-Type": "application/json"})
        with acici.open(r, timeout=5) as y:
            return json.loads(y.read().decode("utf-8"))

    def zaman_yapisi(ofset, utc):
        if utc is None:
            return time.localtime(time.time() + (ofset or 0))
        return time.gmtime(time.time() + (ofset or 0) + float(utc))

    def kapat():
        try:
            kok.destroy()
        except Exception:
            pass

    def etiket(e, metin="", font=None, fg=None, bg=None, sar=0, hiza="w", yasla="left"):
        return tk.Label(e, text=metin, font=font or yazi(20), fg=fg or R["beyaz"], bg=bg or e["bg"], anchor=hiza,
                        justify=yasla, wraplength=sar, bd=0, padx=0, pady=0)

    def yuvarlak(c, x1, y1, x2, y2, r, **kw):
        r = max(0, min(r, (x2 - x1) / 2.0, (y2 - y1) / 2.0))
        n = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
             x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        return c.create_polygon(n, smooth=True, **kw)

    def dugme(e, metin, komut, bg, fg=None, ust=None, font=None, padx=22, pady=10, kenar=None, w=None, h=None, r=14):
        """Yuvarlak köşeli, dokunmatikte anında tepki veren düğme."""
        font = font or yazi(20)
        f = tkfont.Font(root=kok, font=font)
        satirlar = metin.split("\n")
        W = w or max(f.measure(s) for s in satirlar) + 2 * px(padx)
        H = h or f.metrics("linespace") * len(satirlar) + 2 * px(pady)
        c = tk.Canvas(e, width=W, height=H, bg=e["bg"], highlightthickness=0, bd=0, cursor="hand2")
        sekil = yuvarlak(c, 1, 1, W - 1, H - 1, px(r), fill=bg, outline=kenar or bg)
        yid = c.create_text(W / 2.0, H / 2.0, text=metin, fill=fg or R["beyaz"], font=font, justify="center",
                            width=W - px(10))
        c.durum = {"bg": bg, "ust": ust or bg, "kenar": kenar or bg, "etkin": True, "komut": komut}

        def boya(x=None):
            c.itemconfigure(sekil, fill=x or c.durum["bg"], outline=c.durum["kenar"])

        def bas(_):
            if not c.durum["etkin"]:
                return
            boya(R["basili"] if c.durum["bg"] != R["ana"] else R["ana_ust"])
            c.after(140, boya)
            c.durum["komut"]()
        c.bind("<Button-1>", bas)
        c.bind("<Enter>", lambda _: c.durum["etkin"] and boya(c.durum["ust"]))
        c.bind("<Leave>", lambda _: boya())
        c.metin = lambda m: c.itemconfigure(yid, text=m)
        c.renk = lambda bg=None, kenar=None: (c.durum.update({k: v for k, v in (("bg", bg), ("kenar", kenar)) if v}), boya())
        c.etkin = lambda e_=True: (c.durum.update(etkin=e_), c.itemconfigure(yid, fill=(fg or R["beyaz"]) if e_ else R["ust"]))
        return c

    def hap(e, metin, bg, fg, font, padx=24, pady=8):
        f = tkfont.Font(root=kok, font=font)
        W, H = f.measure(metin) + 2 * px(padx), f.metrics("linespace") + 2 * px(pady)
        c = tk.Canvas(e, width=W, height=H, bg=e["bg"], highlightthickness=0, bd=0)
        yuvarlak(c, 0, 0, W, H, H / 2.0, fill=bg, outline=bg)
        c.create_text(W / 2.0, H / 2.0, text=metin, fill=fg, font=font)
        return c

    def tam_ekran_yap():
        kok.overrideredirect(True)
        kok.geometry("%dx%d+%d+%d" % (VW, VH, VX, VY))
        kok.attributes("-topmost", True)
        ic = tk.Frame(kok, bg=R["arka"])
        ic.place(x=-VX, y=-VY, width=PW, height=PH)       # içerik ana ekranda
        return ic

    def one_al():
        try:
            kok.lift()
            kok.attributes("-topmost", True)
            u32.SetForegroundWindow(int(kok.wm_frame(), 16))
            kok.focus_force()
        except Exception:
            pass

    def kilit_ikonu(e, boyut):
        c = tk.Canvas(e, width=boyut, height=boyut, bg=e["bg"], highlightthickness=0, bd=0)
        s = boyut / 64.0
        k = max(2, int(5 * s))
        c.create_arc(19 * s, 13 * s, 45 * s, 39 * s, start=0, extent=180, style="arc", outline="#e8ecf8", width=k)
        c.create_line(19 * s, 26 * s, 19 * s, 31 * s, fill="#e8ecf8", width=k)
        c.create_line(45 * s, 26 * s, 45 * s, 31 * s, fill="#e8ecf8", width=k)
        yuvarlak(c, 12 * s, 29 * s, 52 * s, 59 * s, 6 * s, fill=R["ana"], outline=R["ana"])
        c.create_oval(28 * s, 38 * s, 36 * s, 46 * s, fill="#ffffff", outline="")
        c.create_rectangle(30.5 * s, 43 * s, 33.5 * s, 51 * s, fill="#ffffff", outline="")
        return c

    def tarih_yazi(t):
        return "{} {} {}, {}".format(t.tm_mday, AYLAR[t.tm_mon - 1], t.tm_year, GUNLER[t.tm_wday])

    # ── ACİL DURUM ───────────────────────────────────────────────────────────
    if tur == "acil":
        tatbikat = bool(arg.get("tatbikat"))
        sekiller = ACIL_SEKIL.get(arg.get("senaryo") or "genel", ACIL_SEKIL["genel"])
        win_klavye_kancasi()
        ic = tam_ekran_yap()
        c = tk.Canvas(ic, width=PW, height=PH, highlightthickness=0, bd=0, bg="#b8121a")
        c.pack(fill="both", expand=True)
        kok.protocol("WM_DELETE_WINDOW", lambda: None)
        durum = {"faz": 0}

        def ciz():
            W, H = PW, PH
            c.delete("all")
            koyu = durum["faz"] % 2 == 1
            c.configure(bg="#8c0a0f" if koyu else "#b8121a")
            bant = H * 0.1
            c.create_rectangle(0, 0, W, bant, fill="#ffcc00" if tatbikat else "#ffffff", outline="")
            c.create_text(W / 2.0, bant / 2.0, text=ACIL_UST[tatbikat], fill="#1a0d05" if tatbikat else "#b8121a",
                          font=("Segoe UI", -int(bant * 0.42), "bold"))
            boy = H * 0.26
            oy = bant + H * 0.05
            r0 = boy * 0.62
            c.create_oval(W / 2.0 - r0, oy + boy / 2.0 - r0, W / 2.0 + r0, oy + boy / 2.0 + r0, outline="#ffffff",
                          width=max(3, int(boy * 0.035)))
            icb = boy * 0.8
            ix, iy = W / 2.0 - icb / 2.0, oy + (boy - icb) / 2.0
            for tur_, n, renk in sekiller:
                rk = "#ffffff" if renk == "b" else "#730509"
                if tur_ == "c":
                    x, y, rr = ix + n[0] * icb / 100.0, iy + n[1] * icb / 100.0, n[2] * icb / 100.0
                    c.create_oval(x - rr, y - rr, x + rr, y + rr, fill=rk, outline="")
                    continue
                nok = [ix + n[i] * icb / 100.0 if i % 2 == 0 else iy + n[i] * icb / 100.0 for i in range(len(n))]
                if tur_ == "p":
                    c.create_polygon(nok, fill=rk, outline="", smooth=(arg.get("senaryo") == "yangin"))
                else:
                    c.create_line(nok, fill=rk, width=int(icb * 0.07), joinstyle="round", capstyle="round")
            y = oy + boy + H * 0.08
            t = c.create_text(W / 2.0, y, text=arg.get("baslik") or "ACİL DURUM", fill="#ffffff", anchor="n",
                              font=("Segoe UI", -int(H * 0.085), "bold"), width=W * 0.92, justify="center")
            y = c.bbox(t)[3] + H * 0.025
            if arg.get("metin"):
                c.create_text(W / 2.0, y, text=arg["metin"], fill="#ffeded", anchor="n", font=("Segoe UI", -int(H * 0.042)),
                              width=W * 0.8, justify="center")
            alt = "  ·  ".join(x for x in (arg.get("okul_adi"), arg.get("ad"),
                                           time.strftime("%H:%M", zaman_yapisi(arg.get("ofset"), arg.get("utc_ofset")))) if x)
            c.create_text(W / 2.0, H * 0.88, text="Öğretmeninizin talimatlarını izleyin.", fill="#ffffff",
                          font=("Segoe UI", -int(H * 0.03), "bold"))
            c.create_text(W / 2.0, H * 0.93, text=alt, fill="#ffd9d9", font=("Segoe UI", -int(H * 0.024)))

        def tik():
            durum["faz"] += 1
            ciz()
            one_al()
            kok.after(1000, tik)
        kok.deiconify()
        ciz()
        kok.after(200, one_al)
        kok.after(1000, tik)
        kok.mainloop()
        return 0

    # ── KİLİT EKRANI ─────────────────────────────────────────────────────────
    if tur == "kilit":
        bilgi = {"okul_adi": "", "ad": "", "mesaj": "Bu tahta kilitlidir.", "pin_var": True, "panolar": [],
                 "anlik": None, "kapanis": None, "ofset": 0, "utc_ofset": None}
        try:
            bilgi.update(yerel("/bilgi"))
        except Exception:
            pass
        ic = tam_ekran_yap()
        win_klavye_kancasi()
        bosluk = px(44)
        ust = tk.Frame(ic, bg=R["arka"])
        ust.pack(fill="x", padx=bosluk, pady=(bosluk, 0))
        e_okul = etiket(ust, font=yazi(20, "yari"), fg=R["ust"])
        e_okul.pack(side="left")
        e_tahta = etiket(ust, font=yazi(20, "yari"), fg=R["ust"])
        e_tahta.pack(side="right")
        e_uyari = tk.Label(ic, bg=R["kirmizi"], fg="#ffffff", font=yazi(24, "kalin"), padx=px(24), pady=px(14))
        alt = tk.Frame(ic, bg=R["arka"])
        alt.pack(side="bottom", fill="x", padx=bosluk, pady=(0, bosluk))
        orta = tk.Frame(ic, bg=R["arka"])
        orta.place(relx=0.5, rely=0.5, anchor="center")

        sol = tk.Frame(orta, bg=R["arka"])
        sol.grid(row=0, column=0, padx=(0, px(110)), sticky="w")
        e_saat = etiket(sol, font=yazi(128, "ince"))
        e_saat.pack(anchor="w")
        e_tarih = etiket(sol, font=yazi(26), fg=R["tarih"])
        e_tarih.pack(anchor="w")
        satir = tk.Frame(sol, bg=R["arka"])
        satir.pack(anchor="w", pady=(px(40), 0))
        kilit_ikonu(satir, px(56)).pack(side="left")
        etiket(satir, "Tahta kilitli", font=yazi(34, "kalin")).pack(side="left", padx=(px(16), 0))
        e_mesaj = etiket(sol, font=yazi(20), fg=R["mesaj"], sar=px(560))
        e_mesaj.pack(anchor="w", pady=(px(6), 0))
        pano = tk.Frame(sol, bg=R["pano"], highlightthickness=1, highlightbackground=R["pano_kenar"])
        e_pano_b = etiket(pano, font=yazi(20, "kalin"), fg=R["sari"], sar=px(520))
        e_pano_b.pack(anchor="w", padx=px(26), pady=(px(18), px(4)))
        e_pano_m = etiket(pano, font=yazi(24), sar=px(520))
        e_pano_m.pack(anchor="w", padx=px(26), pady=(0, px(18)))

        sag = tk.Frame(orta, bg=R["kart"], highlightthickness=1, highlightbackground=R["kart_kenar"])
        sag.grid(row=0, column=1)
        e_pinsiz = etiket(orta, "Bu tahta yönetim panelinden açılabilir.", font=yazi(22), fg=R["mesaj"], hiza="center")
        pin_sayfa = tk.Frame(sag, bg=R["kart"])
        ariza_sayfa = tk.Frame(sag, bg=R["kart"])
        etiket(pin_sayfa, "Öğretmen şifresi", font=yazi(20, "yari"), fg=R["pin_baslik"], hiza="center").pack(fill="x")
        e_pin = etiket(pin_sayfa, font=yazi(44), hiza="center")
        e_pin.pack(fill="x", pady=px(10))
        izgara = tk.Frame(pin_sayfa, bg=R["kart"])
        izgara.pack()
        e_durum = etiket(pin_sayfa, " ", font=yazi(20), fg=R["hata"], hiza="center", sar=px(420), yasla="center")
        e_durum.pack(fill="x", pady=(px(12), 0))
        girilen, mesgul = [], [False]

        def pin_goster():
            e_pin.configure(text="  ".join("●" for _ in girilen) if girilen else "· · · ·")

        def durum_yaz(metin, basari=False):
            e_durum.configure(text=metin or " ", fg=R["basari"] if basari else R["hata"])

        def sonuc(c):
            mesgul[0] = False
            if isinstance(c, Exception):
                c = {"ok": False, "hata": "Bağlantı hatası, tekrar deneyin."}
            if c.get("ok"):
                durum_yaz("Hoş geldiniz" + (", " + c["ad"] if c.get("ad") else ""), True)
                kok.after(600, kapat)
            elif c.get("bekle"):
                durum_yaz("Çok fazla hatalı deneme. {} sn bekleyin.".format(c["bekle"]))
            else:
                durum_yaz(c.get("hata") or "Şifre hatalı, tekrar deneyin.")

        def onayla():
            if not girilen or mesgul[0]:
                return
            pin = "".join(girilen)
            del girilen[:]
            pin_goster()
            mesgul[0] = True
            durum_yaz("Kontrol ediliyor…", True)
            arkada(lambda: yerel("/pin", {"pin": pin}), sonuc)

        def rakam(d):
            if len(girilen) < 8:
                girilen.append(d)
                durum_yaz("")
                pin_goster()

        def sil():
            if girilen:
                girilen.pop()
                pin_goster()

        for metin, x, yy in [("1", 0, 0), ("2", 1, 0), ("3", 2, 0), ("4", 0, 1), ("5", 1, 1), ("6", 2, 1),
                             ("7", 0, 2), ("8", 1, 2), ("9", 2, 2), ("Sil", 0, 3), ("0", 1, 3), ("Aç", 2, 3)]:
            if metin == "Aç":
                d = dugme(izgara, metin, onayla, R["ana"], ust=R["ana_ust"], font=yazi(28, "kalin"), w=px(116), h=px(92), r=20)
            elif metin == "Sil":
                d = dugme(izgara, metin, sil, R["tus"], ust=R["tus_ust"], kenar=R["tus_kenar"], font=yazi(24),
                          w=px(116), h=px(92), r=20)
            else:
                d = dugme(izgara, metin, lambda m=metin: rakam(m), R["tus"], ust=R["tus_ust"], kenar=R["tus_kenar"],
                          font=yazi(36), w=px(116), h=px(92), r=20)
            d.grid(row=yy, column=x, padx=px(7), pady=px(7))

        # Arıza bildirme sayfası (dokunarak)
        etiket(ariza_sayfa, "Arıza bildir", font=yazi(20, "yari"), fg=R["pin_baslik"], hiza="center").pack(fill="x")
        etiket(ariza_sayfa, "Sorun nedir? Okul yönetimine iletilir.", font=yazi(20), fg=R["mesaj"],
               hiza="center").pack(fill="x", pady=(px(8), px(10)))
        a_izgara = tk.Frame(ariza_sayfa, bg=R["kart"])
        a_izgara.pack()
        e_a_durum = etiket(ariza_sayfa, " ", font=yazi(22, "kalin"), fg=R["basari"], hiza="center")
        e_a_durum.pack(fill="x", pady=px(10))
        ariza_modu = [False, 0]

        def sayfa(ad):
            ariza_modu[0] = ad == "ariza"
            ariza_modu[1] += 1
            belirtec = ariza_modu[1]
            e_a_durum.configure(text=" ")
            pin_sayfa.pack_forget()
            ariza_sayfa.pack_forget()
            (ariza_sayfa if ariza_modu[0] else pin_sayfa).pack(padx=px(32), pady=px(32))
            bilgi_uygula()
            if ariza_modu[0]:
                kok.after(45000, lambda: ariza_modu[1] == belirtec and ariza_modu[0] and sayfa("pin"))

        def ariza_sonuc(c):
            if isinstance(c, Exception) or not c.get("ok"):
                e_a_durum.configure(text=(None if isinstance(c, Exception) else c.get("hata")) or "Gönderilemedi, tekrar deneyin.",
                                    fg=R["hata"])
                return
            e_a_durum.configure(text="Bildirildi. Teşekkürler!", fg=R["basari"])
            belirtec = ariza_modu[1]
            kok.after(2500, lambda: ariza_modu[1] == belirtec and sayfa("pin"))

        def ariza_gonder(k):
            e_a_durum.configure(text="Gönderiliyor…", fg=R["basari"])
            arkada(lambda: yerel("/ariza", {"kategori": k, "yer": "kilit ekranı"}), ariza_sonuc)

        for i, k in enumerate(bilgi.get("ariza_turleri") or ARIZA_TURLERI):
            dugme(a_izgara, k, lambda k=k: ariza_gonder(k), R["tus"], ust=R["tus_ust"], kenar=R["tus_kenar"],
                  font=yazi(22, "yari"), w=px(220), h=px(76), r=16).grid(row=i // 2, column=i % 2, padx=px(6), pady=px(6))
        dugme(ariza_sayfa, "Vazgeç", lambda: sayfa("pin"), R["alt"], fg=R["pin_baslik"], ust=R["alt_ust"],
              kenar=R["alt_kenar"], font=yazi(20)).pack()
        dugme(alt, "⚠  Arıza bildir", lambda: sayfa("pin" if ariza_modu[0] else "ariza"), R["alt"], fg=R["pin_baslik"],
              ust=R["alt_ust"], kenar=R["alt_kenar"], font=yazi(20)).pack(side="left")
        pano_sira = [0, 0.0]

        def bilgi_uygula():
            e_okul.configure(text=bilgi.get("okul_adi") or "")
            e_tahta.configure(text=bilgi.get("ad") or "")
            e_mesaj.configure(text=bilgi.get("mesaj") or "")
            pin_var = bilgi.get("pin_var", True)
            if pin_var or ariza_modu[0]:
                e_pinsiz.grid_remove()
                sag.grid(row=0, column=1)
            else:
                sag.grid_remove()
                e_pinsiz.grid(row=0, column=1)
            anlik, liste = bilgi.get("anlik"), bilgi.get("panolar") or []
            if anlik or liste:
                if anlik:
                    pano.configure(bg=R["pano_anlik"], highlightbackground=R["pano_anlik_kenar"])
                    b, m = anlik.get("baslik") or "DUYURU", anlik.get("metin") or ""
                else:
                    pano.configure(bg=R["pano"], highlightbackground=R["pano_kenar"])
                    if time.time() - pano_sira[1] > 8:
                        pano_sira[0] = (pano_sira[0] + 1) % len(liste)
                        pano_sira[1] = time.time()
                    p = liste[pano_sira[0] % len(liste)]
                    b, m = p.get("baslik") or "Duyuru", p.get("metin") or ""
                for e_ in (e_pano_b, e_pano_m):
                    e_.configure(bg=pano["bg"])
                e_pano_b.configure(text=b)
                e_pano_m.configure(text=m)
                if not pano.winfo_ismapped():
                    pano.pack(anchor="w", pady=(px(30), 0))
            elif pano.winfo_ismapped():
                pano.pack_forget()

        def bilgi_yenile():
            def sonra(yeni):
                if isinstance(yeni, Exception):
                    return
                bilgi.update(yeni)
                if not yeni.get("kilitli", True):
                    kapat()
                    return
                bilgi_uygula()
            arkada(lambda: yerel("/bilgi"), sonra)
            kok.after(2000, bilgi_yenile)

        def saat_tik():
            t = zaman_yapisi(bilgi.get("ofset"), bilgi.get("utc_ofset"))
            e_saat.configure(text=time.strftime("%H:%M", t))
            e_tarih.configure(text=tarih_yazi(t))
            k = bilgi.get("kapanis")
            if k:
                kalan = max(0, int(k - time.time()))
                e_uyari.configure(text="Tahta {:d}:{:02d} sonra kapanacak{}".format(
                    kalan // 60, kalan % 60, " — devam etmek için ekrana dokunun" if bilgi.get("kapanis_bosta") else ""))
                if not e_uyari.winfo_ismapped():
                    e_uyari.place(relx=0.5, y=bosluk + px(40), anchor="n")
            elif e_uyari.winfo_ismapped():
                e_uyari.place_forget()
            kok.after(1000, saat_tik)

        def yakala():
            if not bilgi.get("tam_ekran"):       # sınav / saat ekranı kilidin üstünde görünsün
                one_al()
            kok.after(1500, yakala)

        def tus(o):
            if o.char and o.char.isdigit():
                rakam(o.char)
            elif o.keysym == "BackSpace":
                sil()
            elif o.keysym in ("Return", "KP_Enter"):
                onayla()
            elif o.keysym == "Escape":
                del girilen[:]
                pin_goster()
        kok.bind("<Key>", tus)
        kok.protocol("WM_DELETE_WINDOW", lambda: None)
        pin_goster()
        sayfa("pin")
        saat_tik()
        kok.deiconify()
        kok.after(300, yakala)
        kok.after(2000, bilgi_yenile)
        kok.mainloop()
        return 0

    # ── SINAV / SAAT / EKRAN KORUYUCU (tam ekran) ────────────────────────────
    if tur == "tam_ekran":
        mod = arg.get("tur") or "saat"
        bilgi = {"tur": mod, "sinav": None, "saat": None, "okul_adi": "", "ad": "", "anlik": None,
                 "ofset": 0, "utc_ofset": None, "kapanis": None}
        try:
            bilgi.update(yerel("/tam_ekran"))
        except Exception:
            pass
        ic = tam_ekran_yap()
        if mod == "sinav":
            win_klavye_kancasi()
        bosluk = px(44)
        ust = tk.Frame(ic, bg=R["arka"])
        ust.pack(fill="x", padx=bosluk, pady=(bosluk, 0))
        e_okul = etiket(ust, font=yazi(20, "yari"), fg=R["ust"])
        e_okul.pack(side="left")
        e_tahta = etiket(ust, font=yazi(20, "yari"), fg=R["ust"])
        e_tahta.pack(side="right")
        alt = tk.Frame(ic, bg=R["arka"])
        alt.pack(side="bottom", fill="x", padx=bosluk, pady=(0, bosluk))
        e_kapanis = tk.Label(alt, bg=R["kirmizi"], fg="#ffffff", font=yazi(24, "kalin"), padx=px(24), pady=px(14))
        pano = tk.Frame(alt, bg=R["pano_anlik"], highlightthickness=1, highlightbackground=R["pano_anlik_kenar"])
        e_pano_b = etiket(pano, font=yazi(20, "kalin"), fg=R["sari"], sar=px(1200), hiza="center", yasla="center")
        e_pano_b.pack(fill="x", padx=px(26), pady=(px(16), px(4)))
        e_pano_m = etiket(pano, font=yazi(24), sar=px(1200), hiza="center", yasla="center")
        e_pano_m.pack(fill="x", padx=px(26), pady=(0, px(16)))
        alt_satir = tk.Frame(alt, bg=R["arka"])
        alt_satir.pack(side="bottom", fill="x")
        e_ipucu = etiket(alt_satir, font=yazi(24), fg=R["ipucu"])
        e_ipucu.pack(side="left")
        kapaniyor = [False]

        def kapat_istegi(*_):
            if kapaniyor[0]:
                return
            kapaniyor[0] = True
            arkada(lambda: yerel("/tam_ekran/kapat", {}), lambda _: kapat())
        b_kapat = dugme(alt_satir, "Kapat", kapat_istegi, R["alt"], fg=R["pin_baslik"], ust=R["alt_ust"],
                        kenar=R["alt_kenar"], font=yazi(20))
        orta = tk.Frame(ic, bg=R["arka"])
        orta.place(relx=0.5, rely=0.47, anchor="center")
        if mod == "sinav":
            hap(orta, "SINAV", R["ana"], "#ffffff", yazi(24, "kalin"), 28, 8).pack(pady=(0, px(6)))
            e_baslik = etiket(orta, font=yazi(60, "kalin"), sar=px(1500), hiza="center", yasla="center")
            e_baslik.pack()
            e_durum = etiket(orta, font=yazi(34, "yari"), fg=R["tarih"], hiza="center")
            e_durum.pack(pady=(px(18), 0))
            e_sure = etiket(orta, font=yazi(250, "ince"), hiza="center")
            e_sure.pack()
            CG, CY = int(PW * 0.55), px(16)
            cubuk = tk.Canvas(orta, width=CG, height=CY, bg=R["arka"], highlightthickness=0, bd=0)
            cubuk.pack(pady=px(10))
            e_bilgi = etiket(orta, font=yazi(28), fg=R["ust"], hiza="center")
            e_bilgi.pack(pady=(px(14), 0))

            def cubuk_ciz(oran, renk):
                cubuk.delete("all")
                yuvarlak(cubuk, 0, 0, CG, CY, CY / 2.0, fill=R["cubuk"], outline=R["cubuk"])
                g = CG * max(0.0, min(1.0, oran))
                if g >= 2:
                    yuvarlak(cubuk, 0, 0, max(CY, g), CY, CY / 2.0, fill=renk, outline=renk)
        else:
            satir = tk.Frame(orta, bg=R["arka"])
            satir.pack()
            e_saat = etiket(satir, font=yazi(300, "ince"))
            e_saat.pack(side="left")
            e_saniye = etiket(satir, font=yazi(96, "ince"), fg=R["ipucu"])
            e_saniye.pack(side="left", anchor="s", pady=(0, px(60)), padx=(px(14), 0))
            e_tarih = etiket(orta, font=yazi(44), fg=R["tarih"], hiza="center")
            e_tarih.pack()
            e_mesaj = etiket(orta, font=yazi(40, "yari"), fg=R["sari"], sar=px(1400), hiza="center", yasla="center")
            if mod == "koruyucu":
                e_ipucu.configure(text="Kullanmak için ekrana dokunun")
                kok.bind("<Button-1>", kapat_istegi)
                kok.bind("<Key>", kapat_istegi)

        def sure_metni(sn):
            sn = max(0, int(math.ceil(sn)))
            sa, kalan = divmod(sn, 3600)
            dk, sn = divmod(kalan, 60)
            return "{:d}:{:02d}:{:02d}".format(sa, dk, sn) if sa else "{:02d}:{:02d}".format(dk, sn)

        def tik():
            t = zaman_yapisi(bilgi.get("ofset"), bilgi.get("utc_ofset"))
            ns = time.time() + float(bilgi.get("ofset") or 0)
            e_okul.configure(text=bilgi.get("okul_adi") or "")
            e_tahta.configure(text=bilgi.get("ad") or "")
            if mod == "sinav":
                s = bilgi.get("sinav") or {}
                bas, bitis = float(s.get("bas") or ns), float(s.get("bitis") or ns)
                uyari = int(s.get("uyari_dk") or 0)
                e_baslik.configure(text=s.get("baslik") or "Sınav")

                def saat_yazi(z):
                    return time.strftime("%H:%M", zaman_yapisi(z - time.time(), bilgi.get("utc_ofset")))
                e_bilgi.configure(text="Başlangıç {}   ·   Bitiş {}   ·   Saat {}".format(
                    saat_yazi(bas), saat_yazi(bitis), time.strftime("%H:%M", t)))
                if ns < bas:
                    e_durum.configure(text="Sınavın başlamasına", fg=R["tarih"])
                    e_sure.configure(text=sure_metni(bas - ns), fg=R["beyaz"])
                    cubuk_ciz(0.0, R["ana"])
                elif ns < bitis:
                    kalan = bitis - ns
                    son = uyari and kalan <= uyari * 60
                    e_durum.configure(text="Son {} dakika".format(uyari) if son else "Kalan süre",
                                      fg=R["sari"] if son else R["tarih"])
                    e_sure.configure(text=sure_metni(kalan), fg=R["sari"] if son else R["beyaz"])
                    cubuk_ciz((ns - bas) / max(1.0, bitis - bas), R["sari"] if son else R["ana"])
                else:
                    e_durum.configure(text="Lütfen kâğıtlarınızı teslim edin", fg=R["tarih"])
                    e_sure.configure(text="SÜRE DOLDU", fg=R["bitti"])
                    cubuk_ciz(1.0, R["bitti"])
            else:
                e_saat.configure(text=time.strftime("%H:%M", t))
                e_saniye.configure(text=time.strftime("%S", t))
                e_tarih.configure(text=tarih_yazi(t))
                sa = bilgi.get("saat") or {}
                mesaj = sa.get("mesaj") if mod == "saat" else ""
                e_mesaj.configure(text=mesaj or "")
                if mesaj and not e_mesaj.winfo_ismapped():
                    e_mesaj.pack(pady=(px(30), 0))
                elif not mesaj and e_mesaj.winfo_ismapped():
                    e_mesaj.pack_forget()
                goster = mod == "saat" and bool(sa.get("kapatilabilir"))
                if goster and not b_kapat.winfo_ismapped():
                    b_kapat.pack(side="right")
                elif not goster and b_kapat.winfo_ismapped():
                    b_kapat.pack_forget()
            anlik = bilgi.get("anlik")
            if anlik:
                e_pano_b.configure(text=anlik.get("baslik") or "DUYURU")
                e_pano_m.configure(text=anlik.get("metin") or "")
                if not pano.winfo_ismapped():
                    pano.pack(side="bottom", pady=(0, px(14)))
            elif pano.winfo_ismapped():
                pano.pack_forget()
            k = bilgi.get("kapanis")
            if k:
                kalan = max(0, int(k - time.time()))
                e_kapanis.configure(text="Tahta {:d}:{:02d} sonra kapanacak".format(kalan // 60, kalan % 60))
                if not e_kapanis.winfo_ismapped():
                    e_kapanis.pack(side="bottom", pady=(0, px(14)))
            elif e_kapanis.winfo_ismapped():
                e_kapanis.pack_forget()
            kok.after(250, tik)

        def yenile():
            def sonra(yeni):
                if isinstance(yeni, Exception):
                    return
                bilgi.update(yeni)
                if yeni.get("tur") != mod:
                    kapat()
            arkada(lambda: yerel("/tam_ekran"), sonra)
            kok.after(1000, yenile)

        def yakala():
            if not bilgi.get("acil"):            # acil durum uyarısı en üstte kalsın
                one_al()
            kok.after(1500, yakala)
        kok.protocol("WM_DELETE_WINDOW", lambda: None)
        tik()
        kok.deiconify()
        kok.after(300, yakala)
        kok.after(1000, yenile)
        kok.mainloop()
        return 0

    # ── ARIZA BİLDİR (masaüstü simgesinden) ──────────────────────────────────
    if tur == "ariza":
        try:
            bilgi = yerel("/ariza")
        except Exception:
            bilgi = None
        kok.title("Arıza Bildir")
        kok.attributes("-topmost", True)
        kok.resizable(False, False)
        kutu = tk.Frame(kok, bg=R["arka"])
        kutu.pack(padx=px(34), pady=px(30))
        etiket(kutu, "Arıza Bildir", font=yazi(34, "kalin")).pack(anchor="w")
        if bilgi is None:
            etiket(kutu, "Tahta programına ulaşılamadı. Tahtayı yeniden başlatıp tekrar deneyin.", font=yazi(20),
                   fg=R["hata"], sar=px(560)).pack(anchor="w", pady=px(10))
            dugme(kutu, "Kapat", kapat, R["ana"], ust=R["ana_ust"], font=yazi(24, "kalin"), padx=40).pack(anchor="e")
        else:
            etiket(kutu, "{} · Bildiriminiz okul yönetimine iletilir.".format(bilgi.get("ad") or ""), font=yazi(20),
                   fg=R["mesaj"], sar=px(640)).pack(anchor="w", pady=(px(4), px(12)))
            etiket(kutu, "Sorun nedir?", font=yazi(20, "yari"), fg=R["pin_baslik"]).pack(anchor="w", pady=(px(4), px(6)))
            izgara = tk.Frame(kutu, bg=R["arka"])
            izgara.pack(anchor="w")
            secili = [None]
            dugmeler = {}

            def sec(k):
                secili[0] = k
                for ad, d in dugmeler.items():
                    d.renk(R["secili"] if ad == k else R["tus"], R["secili_kenar"] if ad == k else R["tus_kenar"])
            for i, k in enumerate(bilgi.get("turler") or ARIZA_TURLERI):
                d = dugme(izgara, k, lambda k=k: sec(k), R["tus"], ust=R["tus_ust"], kenar=R["tus_kenar"],
                          font=yazi(22, "yari"), w=px(310), h=px(76), r=16)
                d.grid(row=i // 2, column=i % 2, padx=px(5), pady=px(5))
                dugmeler[k] = d

            def giris_kutusu(baslik, metin=""):
                etiket(kutu, baslik, font=yazi(20, "yari"), fg=R["pin_baslik"]).pack(anchor="w", pady=(px(14), px(6)))
                g = tk.Entry(kutu, font=yazi(22), bg=R["giris"], fg="#ffffff", insertbackground="#ffffff", relief="flat",
                             highlightthickness=1, highlightbackground=R["giris_kenar"], highlightcolor=R["ana"])
                g.insert(0, metin)
                g.pack(fill="x", ipady=px(8))
                return g
            g_aciklama = giris_kutusu("Açıklama (isteğe bağlı)")
            g_ad = giris_kutusu("Adınız (isteğe bağlı)", bilgi.get("acan") or "")
            e_durum = etiket(kutu, " ", font=yazi(20), fg=R["hata"], hiza="center")
            e_durum.pack(fill="x", pady=px(10))
            satir = tk.Frame(kutu, bg=R["arka"])
            satir.pack(anchor="e")

            def a_sonuc(c):
                if not isinstance(c, Exception) and c.get("ok"):
                    e_durum.configure(text="Bildiriminiz iletildi. Teşekkürler!", fg=R["basari"])
                    kok.after(2000, kapat)
                else:
                    e_durum.configure(text=(None if isinstance(c, Exception) else c.get("hata")) or "Gönderilemedi, tekrar deneyin.",
                                      fg=R["hata"])
                    gonder.etkin(True)

            def gonder_tik():
                if not secili[0]:
                    e_durum.configure(text="Lütfen sorunun türünü seçin.", fg=R["hata"])
                    return
                gonder.etkin(False)
                govde = {"kategori": secili[0], "aciklama": g_aciklama.get()[:500], "bildiren": g_ad.get()[:60],
                         "yer": "masaüstü"}
                arkada(lambda: yerel("/ariza", govde), a_sonuc)
            dugme(satir, "Vazgeç", kapat, R["alt"], fg=R["pin_baslik"], ust=R["alt_ust"], kenar=R["alt_kenar"],
                  font=yazi(20)).pack(side="left", padx=(0, px(12)))
            gonder = dugme(satir, "Gönder", gonder_tik, R["ana"], ust=R["ana_ust"], font=yazi(24, "kalin"), padx=46)
            gonder.pack(side="left")
        kok.update_idletasks()
        g, y = kok.winfo_reqwidth(), kok.winfo_reqheight()
        kok.geometry("+%d+%d" % (max(0, (PW - g) // 2), max(0, (PH - y) // 2)))
        kok.protocol("WM_DELETE_WINDOW", kapat)
        kok.deiconify()
        kok.after(200, one_al)
        kok.mainloop()
        return 0

    # ── BÜYÜK DUYURU ─────────────────────────────────────────────────────────
    if tur == "duyuru":
        ic = tam_ekran_yap()
        kutu = tk.Frame(ic, bg=R["arka"])
        kutu.place(relx=0.5, rely=0.5, anchor="center")
        hap(kutu, "DUYURU", R["sari"], "#1a1300", yazi(22, "kalin"), 24, 8).pack(pady=(0, px(26)))
        if arg.get("baslik"):
            etiket(kutu, arg["baslik"], font=yazi(48, "kalin"), fg=R["sari"], sar=px(1500), hiza="center",
                   yasla="center").pack(pady=(0, px(20)))
        metin = arg.get("metin") or ""
        boy, gen = (64, 1500) if len(metin) <= 90 else ((46, 1550) if len(metin) <= 260 else (32, 1600))
        etiket(kutu, metin, font=yazi(boy, "yari" if boy > 40 else "normal"), sar=px(gen), hiza="center",
               yasla="center").pack()
        e_alt = etiket(kutu, font=yazi(20), fg=R["ust"], hiza="center")
        e_alt.pack(pady=(px(26), px(20)))
        dugme(kutu, "Tamam", kapat, R["ana"], ust=R["ana_ust"], font=yazi(26, "kalin"), padx=56, pady=14, r=16).pack()
        kalan = [int(arg.get("sure") or 20)]
        okul = arg.get("okul_adi") or ""

        def tik():
            parcalar = ([okul] if okul else []) + [time.strftime("%H:%M"), "{} sn sonra kapanacak".format(kalan[0])]
            e_alt.configure(text="   ·   ".join(parcalar))
            kalan[0] -= 1
            if kalan[0] < 0:
                kapat()
                return
            kok.after(1000, tik)
        kok.bind("<Escape>", lambda _: kapat())
        kok.bind("<Return>", lambda _: kapat())
        tik()
        kok.deiconify()
        kok.after(300, one_al)
        kok.after(1200, one_al)
        kok.mainloop()
        return 0

    # ── KÜÇÜK BİLDİRİM ───────────────────────────────────────────────────────
    if tur == "bildirim":
        kok.overrideredirect(True)
        kok.attributes("-topmost", True)
        kok.configure(bg=R["bildirim_kenar"])
        kart = tk.Frame(kok, bg=R["bildirim"])
        kart.pack(padx=1, pady=1, fill="both", expand=True)
        ic = tk.Frame(kart, bg=R["bildirim"])
        ic.pack(padx=px(24), pady=px(20))
        ust = tk.Frame(ic, bg=R["bildirim"])
        ust.pack(fill="x")
        etiket(ust, arg.get("baslik") or "Mesaj", font=yazi(20, "kalin"), fg=R["sari"], sar=px(440)).pack(side="left")
        x = etiket(ust, "✕", font=yazi(22), fg=R["ust"])
        x.pack(side="right")
        e_m = etiket(ic, arg.get("metin") or "", font=yazi(22), sar=px(500))
        e_m.pack(anchor="w", pady=(px(8), 0))
        ic.configure(width=px(512))
        for w_ in (kok, kart, ic, ust, x, e_m):
            w_.bind("<Button-1>", lambda _: kapat())

        class RECT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]
        alan = RECT(0, 0, PW, PH)
        try:
            u32.SystemParametersInfoW(0x30, 0, ctypes.byref(alan), 0)      # SPI_GETWORKAREA
        except Exception:
            pass
        kok.update_idletasks()
        g, y = max(px(560), kok.winfo_reqwidth()), kok.winfo_reqheight()
        kok.geometry("%dx%d+%d+%d" % (g, y, alan.r - g - px(32), alan.b - y - px(32)))
        kok.deiconify()
        kok.after(max(3, int(arg.get("sure") or 10)) * 1000, kapat)
        kok.mainloop()
        return 0

    # ── KAPANMA GERİ SAYIMI ──────────────────────────────────────────────────
    if tur == "geri_sayim":
        kok.overrideredirect(True)
        kok.attributes("-topmost", True)
        kok.configure(bg=R["koyu_kirmizi"])
        kart = tk.Frame(kok, bg=R["koyu_kirmizi"])
        kart.pack(padx=px(34), pady=px(18), fill="x")
        sol = tk.Frame(kart, bg=R["koyu_kirmizi"])
        sol.pack(side="left", fill="x", expand=True)
        etiket(sol, "Tahta kapanıyor", font=yazi(22, "kalin")).pack(anchor="w")
        aciklama = ("Kullanılmadığı için kapanacak. Devam etmek için ekrana dokunun."
                    if arg.get("bosta") else "Lütfen çalışmalarınızı kaydedin.")
        etiket(sol, aciklama, font=yazi(18), fg=R["acik_kirmizi"], sar=px(480)).pack(anchor="w")
        e_sure = etiket(kart, font=yazi(52, "kalin"))
        e_sure.pack(side="right", padx=(px(26), 0))
        bitis = float(arg.get("bitis") or time.time() + 60)

        def tik():
            k = max(0, int(bitis - time.time()))
            e_sure.configure(text="{:d}:{:02d}".format(k // 60, k % 60))
            kok.after(1000, tik)

        def yukari():
            try:
                kok.lift()
                kok.attributes("-topmost", True)
            except Exception:
                pass
            kok.after(2000, yukari)
        tik()
        kok.update_idletasks()
        g, y = px(780), kok.winfo_reqheight()
        kok.geometry("%dx%d+%d+%d" % (g, y, (PW - g) // 2, 0))
        kok.deiconify()
        yukari()
        kok.mainloop()
        return 0
    return 2


def arayuz(tur, arg):
    if WINDOWS:
        return arayuz_win(tur, arg)
    if tur == "ekran_al":
        return ekran_al(arg)
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Gtk, Gdk, GLib

    ekran = Gdk.Screen.get_default()
    gosterge = Gdk.Display.get_default()

    def ekran_olcusu():
        """Ana ekranın konumu ve boyutu, GTK'nın kullandığı (ölçekli) birimle.
        4K tahtalarda %200 ölçekte kök pencere fiziksel pikseli verir; ekran bilgisi ise doğru birimi."""
        try:
            mon = gosterge.get_primary_monitor() or gosterge.get_monitor_at_point(0, 0) or gosterge.get_monitor(0)
            g = mon.get_geometry()
            if g.width > 0 and g.height > 0:
                return g.x, g.y, g.width, g.height
        except Exception:
            pass
        k = Gdk.get_default_root_window()
        o = max(1, k.get_scale_factor())
        return 0, 0, k.get_width() // o, k.get_height() // o

    # Ekran ölçeği ayarları (HiDPI) oturum açılırken biraz geç gelebilir; pencereleri kurmadan önce bekle
    bitis_bekle = time.time() + 0.6
    while time.time() < bitis_bekle:
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        time.sleep(0.03)
    X0, Y0, G, Y = ekran_olcusu()

    def olcek_hesapla(g, y):
        return max(0.55, min(1.8, min(g / 1920.0, y / 1080.0)))
    olcek = olcek_hesapla(G, Y)
    stil = {"carpan": 1.0}
    saglayici = Gtk.CssProvider()

    def stil_yukle():
        o = olcek_hesapla(G, Y) * stil["carpan"]
        css = re.sub(r"@s(\d+)", lambda m: str(max(1, int(int(m.group(1)) * o))), ARAYUZ_CSS)
        saglayici.load_from_data(css.encode("utf-8"))
    stil_yukle()
    Gtk.StyleContext.add_provider_for_screen(ekran, saglayici, Gtk.STYLE_PROVIDER_PRIORITY_USER + 10)

    tam_pencereler = []

    def tam_ekran_yap(win):
        win.move(X0, Y0)
        win.set_default_size(G, Y)
        win.resize(G, Y)
        tam_pencereler.append(win)

    def sigdir():
        """Tam ekran pencereleri ekrana oturtur: ekran ölçüsü değiştiyse yeniden boyutlar,
        içerik ekrandan taşıyorsa yazıları küçültür."""
        nonlocal X0, Y0, G, Y
        yeni = ekran_olcusu()
        degisti = yeni != (X0, Y0, G, Y)
        if degisti:
            X0, Y0, G, Y = yeni
            stil["carpan"] = 1.0
            stil_yukle()
        for w in tam_pencereler:
            cocuk = w.get_child()
            if cocuk is not None and stil["carpan"] > 0.45:
                mg = cocuk.get_preferred_width()[0]
                my = cocuk.get_preferred_height()[0]
                if mg > G + 2 or my > Y + 2:
                    stil["carpan"] *= max(0.6, min(G / float(max(mg, 1)), Y / float(max(my, 1))) * 0.95)
                    stil_yukle()
                    degisti = True
            if degisti or tuple(w.get_size()) != (G, Y) or tuple(w.get_position()) != (X0, Y0):
                w.move(X0, Y0)
                w.resize(G, Y)
        return True
    GLib.timeout_add(1200, sigdir)
    GLib.timeout_add(250, lambda: sigdir() and False)

    def sinif(w, *adlar):
        for a in adlar:
            w.get_style_context().add_class(a)
        return w

    def etiket(metin, *siniflar, sar=False, hiza=0.0, genislik=None):
        e = Gtk.Label(label=metin)
        e.set_xalign(hiza)
        if sar:
            e.set_line_wrap(True)
            e.set_line_wrap_mode(2)  # WORD_CHAR
            if genislik:
                e.set_max_width_chars(genislik)
        return sinif(e, *siniflar)

    def seffaf_yap(win):
        gorsel = ekran.get_rgba_visual()
        if gorsel is not None and ekran.is_composited():
            win.set_visual(gorsel)
            win.set_app_paintable(True)
            sinif(win, "tys-seffaf")
            return True
        return False

    def zaman_yapisi(ofset, utc):
        if utc is None:
            return time.localtime(time.time() + (ofset or 0))
        return time.gmtime(time.time() + (ofset or 0) + float(utc))

    def yakala_pencere(gw):
        """Pencereyi en öne getirir, dokunma/klavye girişini kendine alır."""
        try:
            gw.raise_()
        except Exception:
            pass
        try:
            koltuk = Gdk.Display.get_default().get_default_seat()
            koltuk.grab(gw, Gdk.SeatCapabilities.ALL, True, None, None, None)
        except Exception:
            try:
                Gdk.keyboard_grab(gw, True, Gdk.CURRENT_TIME)
            except Exception:
                pass
        return True

    def kilit_ikonu(boyut):
        alan = Gtk.DrawingArea()
        alan.set_size_request(boyut, boyut)

        def ciz(_, cr):
            s = boyut / 64.0
            cr.set_source_rgba(1, 1, 1, 0.9)
            cr.set_line_width(5 * s)
            cr.arc(32 * s, 26 * s, 13 * s, math.pi, 0)
            cr.line_to(45 * s, 30 * s)
            cr.move_to(19 * s, 26 * s)
            cr.line_to(19 * s, 30 * s)
            cr.stroke()
            x, y, w, h, r = 12 * s, 29 * s, 40 * s, 30 * s, 6 * s
            cr.new_sub_path()
            cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
            cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
            cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
            cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
            cr.close_path()
            cr.set_source_rgba(0.18, 0.42, 1, 1)
            cr.fill()
            cr.set_source_rgba(1, 1, 1, 0.95)
            cr.arc(32 * s, 42 * s, 4 * s, 0, 2 * math.pi)
            cr.fill()
            cr.rectangle(30.5 * s, 43 * s, 3 * s, 8 * s)
            cr.fill()
            return False
        alan.connect("draw", ciz)
        return alan

    def yerel_baglanti():
        acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))

        def yerel(yol, govde=None):
            veri = json.dumps(govde).encode() if govde is not None else None
            r = urllib.request.Request("http://127.0.0.1:%d%s" % (int(arg.get("port") or YEREL_PORT), yol), data=veri,
                                       headers={"Content-Type": "application/json"})
            with acici.open(r, timeout=5) as y:
                return json.loads(y.read().decode("utf-8"))
        return yerel

    # ── ACİL DURUM ───────────────────────────────────────────────────────────
    if tur == "acil":
        try:
            gi.require_version("PangoCairo", "1.0")
            from gi.repository import Pango, PangoCairo
        except Exception:
            Pango = PangoCairo = None
        tatbikat = bool(arg.get("tatbikat"))
        sekiller = ACIL_SEKIL.get(arg.get("senaryo") or "genel", ACIL_SEKIL["genel"])
        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        tam_ekran_yap(win)
        alan = Gtk.DrawingArea()
        alan.set_can_focus(True)
        win.add(alan)
        durum = {"faz": 0}

        def yazi_yaz(cr, metin, boy, x, y, gen, renk, kalin=True):
            if PangoCairo is None:
                cr.select_font_face("Sans", 0, 1 if kalin else 0)
                cr.set_font_size(boy)
                e = cr.text_extents(metin)
                cr.set_source_rgb(*renk)
                cr.move_to(x - e.width / 2, y + boy)
                cr.show_text(metin)
                return boy * 1.3
            lay = PangoCairo.create_layout(cr)
            fd = Pango.FontDescription("Sans Bold" if kalin else "Sans")
            fd.set_absolute_size(max(8, boy) * Pango.SCALE)
            lay.set_font_description(fd)
            lay.set_width(int(gen * Pango.SCALE))
            lay.set_alignment(Pango.Alignment.CENTER)
            lay.set_wrap(Pango.WrapMode.WORD_CHAR)
            lay.set_text(metin, -1)
            cr.set_source_rgb(*renk)
            cr.move_to(x - gen / 2.0, y)
            PangoCairo.show_layout(cr, lay)
            return lay.get_pixel_size()[1]

        def ciz(w, cr):
            W, H = w.get_allocated_width(), w.get_allocated_height()
            koyu = durum["faz"] % 2 == 1
            arka = (0.55, 0.04, 0.06) if koyu else (0.72, 0.07, 0.09)
            cr.set_source_rgb(*arka)
            cr.paint()
            bant = H * 0.1
            cr.set_source_rgb(*((1, 0.8, 0) if tatbikat else (1, 1, 1)))
            cr.rectangle(0, 0, W, bant)
            cr.fill()
            yazi_yaz(cr, ACIL_UST[tatbikat], bant * 0.42, W / 2.0, bant * 0.26, W * 0.95, (0.1, 0.05, 0.02) if tatbikat else (0.72, 0.07, 0.09))
            # simge
            boy = H * 0.26
            oy = bant + H * 0.05
            cr.set_source_rgb(1, 1, 1)
            cr.set_line_width(max(3, boy * 0.035))
            cr.new_path()
            cr.arc(W / 2.0, oy + boy / 2.0, boy * 0.62, 0, 2 * math.pi)
            cr.stroke()
            ic = boy * 0.8
            ix, iy = W / 2.0 - ic / 2.0, oy + (boy - ic) / 2.0
            for tur_, n, renk in sekiller:
                cr.set_source_rgb(*((1, 1, 1) if renk == "b" else (0.45, 0.02, 0.04)))
                cr.new_path()
                if tur_ == "c":
                    cr.arc(ix + n[0] * ic / 100.0, iy + n[1] * ic / 100.0, n[2] * ic / 100.0, 0, 2 * math.pi)
                    cr.fill()
                    continue
                cr.move_to(ix + n[0] * ic / 100.0, iy + n[1] * ic / 100.0)
                for i in range(2, len(n), 2):
                    cr.line_to(ix + n[i] * ic / 100.0, iy + n[i + 1] * ic / 100.0)
                if tur_ == "p":
                    cr.close_path()
                    cr.fill()
                else:
                    cr.set_line_width(ic * 0.07)
                    cr.set_line_join(1)
                    cr.stroke()
            y = oy + boy + H * 0.08
            y += yazi_yaz(cr, arg.get("baslik") or "ACİL DURUM", H * 0.085, W / 2.0, y, W * 0.92, (1, 1, 1)) + H * 0.025
            if arg.get("metin"):
                yazi_yaz(cr, arg["metin"], H * 0.042, W / 2.0, y, W * 0.8, (1, 0.93, 0.93), kalin=False)
            alt = "  ·  ".join(x for x in (arg.get("okul_adi"), arg.get("ad"),
                                           time.strftime("%H:%M", zaman_yapisi(arg.get("ofset"), arg.get("utc_ofset")))) if x)
            yazi_yaz(cr, "Öğretmeninizin talimatlarını izleyin.", H * 0.03, W / 2.0, H * 0.86, W * 0.9, (1, 1, 1))
            yazi_yaz(cr, alt, H * 0.024, W / 2.0, H * 0.92, W * 0.9, (1, 0.85, 0.85), kalin=False)
            return False
        alan.connect("draw", ciz)

        def tik():
            durum["faz"] += 1
            alan.queue_draw()
            gw = win.get_window()
            if gw:
                yakala_pencere(gw)
            return True
        win.connect("delete-event", lambda *_: True)
        win.show_all()
        GLib.timeout_add(1000, tik)
        GLib.timeout_add(300, lambda: (win.get_window() and yakala_pencere(win.get_window())) and False)
        Gtk.main()
        return 0

    # ── KİLİT EKRANI ─────────────────────────────────────────────────────────
    if tur == "kilit":
        yerel = yerel_baglanti()

        bilgi = {"okul_adi": "", "ad": "", "mesaj": "Bu tahta kilitlidir.", "pin_var": True, "panolar": [],
                 "anlik": None, "kapanis": None, "ofset": 0, "utc_ofset": None}
        try:
            bilgi.update(yerel("/bilgi"))
        except Exception:
            pass

        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        sinif(win, "tys-arka")
        tam_ekran_yap(win)

        kok = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        kok.set_border_width(int(44 * olcek))
        win.add(kok)

        ust = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        e_okul = etiket(bilgi["okul_adi"], "tys-ust")
        e_tahta = etiket(bilgi["ad"], "tys-ust", hiza=1.0)
        ust.pack_start(e_okul, True, True, 0)
        ust.pack_end(e_tahta, False, False, 0)
        kok.pack_start(ust, False, False, 0)

        e_uyari = etiket("", "tys-uyari", hiza=0.5)
        e_uyari.set_halign(Gtk.Align.CENTER)
        e_uyari.set_no_show_all(True)
        kok.pack_start(e_uyari, False, False, int(12 * olcek))

        orta = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(110 * olcek))
        orta.set_halign(Gtk.Align.CENTER)
        orta.set_valign(Gtk.Align.CENTER)
        kok.pack_start(orta, True, True, 0)

        sol = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(6 * olcek))
        sol.set_valign(Gtk.Align.CENTER)
        e_saat = etiket("", "tys-saat")
        e_tarih = etiket("", "tys-tarih")
        sol.pack_start(e_saat, False, False, 0)
        sol.pack_start(e_tarih, False, False, 0)
        satir = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(16 * olcek))
        satir.set_margin_top(int(40 * olcek))
        satir.pack_start(kilit_ikonu(int(56 * olcek)), False, False, 0)
        satir.pack_start(etiket("Tahta kilitli", "tys-baslik"), False, False, 0)
        sol.pack_start(satir, False, False, 0)
        e_mesaj = etiket(bilgi["mesaj"], "tys-mesaj", sar=True, genislik=44)
        e_mesaj.set_margin_top(int(6 * olcek))
        sol.pack_start(e_mesaj, False, False, 0)
        pano = sinif(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(6 * olcek)), "tys-pano")
        pano.set_margin_top(int(30 * olcek))
        e_pano_b = etiket("", "tys-pano-baslik", sar=True, genislik=40)
        e_pano_m = etiket("", "tys-pano-metin", sar=True, genislik=40)
        pano.pack_start(e_pano_b, False, False, 0)
        pano.pack_start(e_pano_m, False, False, 0)
        pano.set_no_show_all(True)
        e_pano_b.show()
        e_pano_m.show()
        sol.pack_start(pano, False, False, 0)
        orta.pack_start(sol, False, False, 0)

        sag = sinif(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0), "tys-kart")
        sag.set_valign(Gtk.Align.CENTER)
        yigin = Gtk.Stack()
        yigin.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        sag.pack_start(yigin, False, False, 0)
        pin_sayfa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(14 * olcek))
        yigin.add_named(pin_sayfa, "pin")
        pin_sayfa.pack_start(etiket("Öğretmen şifresi", "tys-pin-baslik", hiza=0.5), False, False, 0)
        e_pin = etiket("", "tys-pin", hiza=0.5)
        e_pin.set_size_request(-1, int(64 * olcek))
        pin_sayfa.pack_start(e_pin, False, False, 0)
        izgara = Gtk.Grid()
        izgara.set_row_spacing(int(14 * olcek))
        izgara.set_column_spacing(int(14 * olcek))
        izgara.set_halign(Gtk.Align.CENTER)
        pin_sayfa.pack_start(izgara, False, False, 0)
        e_durum = etiket("", "tys-hata", hiza=0.5)
        e_durum.set_size_request(-1, int(34 * olcek))
        pin_sayfa.pack_start(e_durum, False, False, 0)

        # Arıza bildirme sayfası (dokunarak, klavyesiz)
        ariza_sayfa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(14 * olcek))
        yigin.add_named(ariza_sayfa, "ariza")
        ariza_sayfa.pack_start(etiket("Arıza bildir", "tys-pin-baslik", hiza=0.5), False, False, 0)
        ariza_sayfa.pack_start(etiket("Sorun nedir? Okul yönetimine iletilir.", "tys-mesaj", hiza=0.5), False, False, 0)
        a_izgara = Gtk.Grid()
        a_izgara.set_row_spacing(int(12 * olcek))
        a_izgara.set_column_spacing(int(12 * olcek))
        a_izgara.set_column_homogeneous(True)
        a_izgara.set_halign(Gtk.Align.CENTER)
        ariza_sayfa.pack_start(a_izgara, False, False, 0)
        e_a_durum = etiket("", "tys-basari", hiza=0.5)
        e_a_durum.set_size_request(-1, int(34 * olcek))
        ariza_sayfa.pack_start(e_a_durum, False, False, 0)
        vazgec = sinif(Gtk.Button(label="Vazgeç"), "tys-alt-dugme")
        vazgec.set_can_focus(False)
        vazgec.set_halign(Gtk.Align.CENTER)
        ariza_sayfa.pack_start(vazgec, False, False, 0)

        orta.pack_start(sag, False, False, 0)
        e_pinsiz = etiket("Bu tahta yönetim panelinden açılabilir.", "tys-mesaj", hiza=0.5)
        e_pinsiz.set_no_show_all(True)
        orta.pack_start(e_pinsiz, False, False, 0)

        alt_cubuk = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        ariza_dugme = sinif(Gtk.Button(label="⚠  Arıza bildir"), "tys-alt-dugme")
        ariza_dugme.set_can_focus(False)
        alt_cubuk.pack_start(ariza_dugme, False, False, 0)
        kok.pack_end(alt_cubuk, False, False, 0)
        ariza_modu = [False, 0]

        girilen = []
        mesgul = [False]

        def pin_goster():
            e_pin.set_text("  ".join("●" for _ in girilen) if girilen else "· · · ·")

        def durum_yaz(metin, basari=False):
            ctx = e_durum.get_style_context()
            ctx.remove_class("tys-hata")
            ctx.remove_class("tys-basari")
            ctx.add_class("tys-basari" if basari else "tys-hata")
            e_durum.set_text(metin)

        def sonuc(c):
            mesgul[0] = False
            if c.get("ok"):
                durum_yaz("Hoş geldiniz" + (", " + c["ad"] if c.get("ad") else ""), True)
                GLib.timeout_add(600, Gtk.main_quit)
            elif c.get("bekle"):
                durum_yaz("Çok fazla hatalı deneme. {} sn bekleyin.".format(c["bekle"]))
            else:
                durum_yaz(c.get("hata") or "Şifre hatalı, tekrar deneyin.")
            return False

        def kontrol(pin):
            try:
                c = yerel("/pin", {"pin": pin})
            except Exception:
                c = {"ok": False, "hata": "Bağlantı hatası, tekrar deneyin."}
            GLib.idle_add(sonuc, c)

        def onayla(*_):
            if not girilen or mesgul[0]:
                return
            pin = "".join(girilen)
            del girilen[:]
            pin_goster()
            mesgul[0] = True
            durum_yaz("Kontrol ediliyor…", True)
            threading.Thread(target=kontrol, args=(pin,), daemon=True).start()

        def rakam(d):
            if len(girilen) < 8:
                girilen.append(d)
                e_durum.set_text("")
                pin_goster()

        def sil(*_):
            if girilen:
                girilen.pop()
                pin_goster()

        duzen = [("1", 0, 0), ("2", 1, 0), ("3", 2, 0), ("4", 0, 1), ("5", 1, 1), ("6", 2, 1),
                 ("7", 0, 2), ("8", 1, 2), ("9", 2, 2), ("Sil", 0, 3), ("0", 1, 3), ("Aç", 2, 3)]
        for metin, x, yy in duzen:
            d = Gtk.Button(label=metin)
            d.set_can_focus(False)
            sinif(d, "tys-tus")
            if metin == "Aç":
                sinif(d, "tys-tus-ana")
                d.connect("clicked", onayla)
            elif metin == "Sil":
                sinif(d, "tys-tus-ikincil")
                d.connect("clicked", sil)
            else:
                d.connect("clicked", lambda _b, r=metin: rakam(r))
            izgara.attach(d, x, yy, 1, 1)

        def tus(_, olay):
            ad = Gdk.keyval_name(olay.keyval) or ""
            if ad.startswith("KP_"):
                ad = ad[3:]
            if len(ad) == 1 and ad.isdigit():
                rakam(ad)
            elif ad == "BackSpace":
                sil()
            elif ad in ("Return", "Enter"):
                onayla()
            elif ad == "Escape":
                del girilen[:]
                pin_goster()
            return True
        win.connect("key-press-event", tus)
        win.connect("delete-event", lambda *a: True)

        pano_sira = [0, 0.0]

        def sayfa(ad):
            ariza_modu[0] = ad == "ariza"
            ariza_modu[1] += 1
            belirtec = ariza_modu[1]
            e_a_durum.set_text("")
            yigin.set_visible_child_name(ad)
            bilgi_uygula()
            if ariza_modu[0]:
                GLib.timeout_add_seconds(45, lambda: (ariza_modu[1] == belirtec and ariza_modu[0] and sayfa("pin")) and False)

        def ariza_sonuc(c):
            ctx = e_a_durum.get_style_context()
            ctx.remove_class("tys-hata")
            ctx.remove_class("tys-basari")
            if c.get("ok"):
                ctx.add_class("tys-basari")
                e_a_durum.set_text("Bildirildi. Teşekkürler!")
                belirtec = ariza_modu[1]
                GLib.timeout_add(2500, lambda: (ariza_modu[1] == belirtec and sayfa("pin")) and False)
            else:
                ctx.add_class("tys-hata")
                e_a_durum.set_text(c.get("hata") or "Gönderilemedi, tekrar deneyin.")
            return False

        def ariza_gonder(kategori):
            def is_():
                try:
                    c = yerel("/ariza", {"kategori": kategori, "yer": "kilit ekranı"})
                except Exception:
                    c = {"ok": False}
                GLib.idle_add(ariza_sonuc, c)
            e_a_durum.set_text("Gönderiliyor…")
            threading.Thread(target=is_, daemon=True).start()

        for i, k in enumerate(bilgi.get("ariza_turleri") or ARIZA_TURLERI):
            d = sinif(Gtk.Button(label=k), "tys-ariza-tus")
            d.set_can_focus(False)
            cocuk = d.get_child()
            if isinstance(cocuk, Gtk.Label):
                cocuk.set_line_wrap(True)
                cocuk.set_max_width_chars(14)
                cocuk.set_justify(Gtk.Justification.CENTER)
            d.connect("clicked", lambda _b, k=k: ariza_gonder(k))
            a_izgara.attach(d, i % 2, i // 2, 1, 1)
        vazgec.connect("clicked", lambda *_: sayfa("pin"))
        ariza_dugme.connect("clicked", lambda *_: sayfa("pin" if ariza_modu[0] else "ariza"))

        def bilgi_uygula():
            e_okul.set_text(bilgi.get("okul_adi") or "")
            e_tahta.set_text(bilgi.get("ad") or "")
            e_mesaj.set_text(bilgi.get("mesaj") or "")
            pin_var = bilgi.get("pin_var", True)
            sag.set_visible(pin_var or ariza_modu[0])
            e_pinsiz.set_visible(not pin_var and not ariza_modu[0])
            anlik = bilgi.get("anlik")
            liste = bilgi.get("panolar") or []
            ctx = pano.get_style_context()
            if anlik:
                ctx.add_class("tys-pano-anlik")
                e_pano_b.set_text(anlik.get("baslik") or "DUYURU")
                e_pano_m.set_text(anlik.get("metin") or "")
                pano.show()
            elif liste:
                ctx.remove_class("tys-pano-anlik")
                if time.time() - pano_sira[1] > 8:
                    pano_sira[0] = (pano_sira[0] + 1) % len(liste)
                    pano_sira[1] = time.time()
                p = liste[pano_sira[0] % len(liste)]
                e_pano_b.set_text(p.get("baslik") or "Duyuru")
                e_pano_m.set_text(p.get("metin") or "")
                pano.show()
            else:
                pano.hide()
            return False

        def bilgi_yenile():
            def is_():
                try:
                    yeni = yerel("/bilgi")
                except Exception:
                    return
                bilgi.update(yeni)
                if not yeni.get("kilitli", True):
                    GLib.idle_add(Gtk.main_quit)
                GLib.idle_add(bilgi_uygula)
            threading.Thread(target=is_, daemon=True).start()
            return True

        def saat_tik():
            t = zaman_yapisi(bilgi.get("ofset"), bilgi.get("utc_ofset"))
            e_saat.set_text(time.strftime("%H:%M", t))
            e_tarih.set_text("{} {} {}, {}".format(t.tm_mday, AYLAR[t.tm_mon - 1], t.tm_year, GUNLER[t.tm_wday]))
            k = bilgi.get("kapanis")
            if k:
                kalan = max(0, int(k - time.time()))
                e_uyari.set_text("Tahta {:d}:{:02d} sonra kapanacak{}".format(
                    kalan // 60, kalan % 60, " — devam etmek için ekrana dokunun" if bilgi.get("kapanis_bosta") else ""))
                e_uyari.show()
            else:
                e_uyari.hide()
            return True

        birakildi = [False]

        def yakala():
            gw = win.get_window()
            if gw is None:
                return True
            if bilgi.get("tam_ekran"):
                # Sınav / saat ekranı kilidin üstünde görünsün: öne gelme ve dokunuşları bırak
                if not birakildi[0]:
                    birakildi[0] = True
                    try:
                        Gdk.Display.get_default().get_default_seat().ungrab()
                    except Exception:
                        pass
                return True
            birakildi[0] = False
            return yakala_pencere(gw)

        pin_goster()
        bilgi_uygula()
        saat_tik()
        win.show_all()
        bilgi_uygula()
        GLib.timeout_add_seconds(1, saat_tik)
        GLib.timeout_add_seconds(2, bilgi_yenile)
        GLib.timeout_add(300, lambda: yakala() and False)
        GLib.timeout_add(1500, yakala)
        Gtk.main()
        return 0

    # ── SINAV / SAAT / EKRAN KORUYUCU (tam ekran) ────────────────────────────
    if tur == "tam_ekran":
        yerel = yerel_baglanti()
        mod = arg.get("tur") or "saat"
        bilgi = {"tur": mod, "sinav": None, "saat": None, "okul_adi": "", "ad": "", "anlik": None,
                 "ofset": 0, "utc_ofset": None, "kapanis": None}
        try:
            bilgi.update(yerel("/tam_ekran"))
        except Exception:
            pass

        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        sinif(win, "tys-arka")
        tam_ekran_yap(win)
        olay = Gtk.EventBox()
        olay.set_visible_window(False)
        win.add(olay)
        kok = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        kok.set_border_width(int(44 * olcek))
        olay.add(kok)

        ust = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        e_okul = etiket("", "tys-ust")
        e_tahta = etiket("", "tys-ust", hiza=1.0)
        ust.pack_start(e_okul, True, True, 0)
        ust.pack_end(e_tahta, False, False, 0)
        kok.pack_start(ust, False, False, 0)

        orta = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(10 * olcek))
        orta.set_halign(Gtk.Align.CENTER)
        orta.set_valign(Gtk.Align.CENTER)
        kok.pack_start(orta, True, True, 0)

        alt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(14 * olcek))
        kok.pack_end(alt, False, False, 0)
        e_kapanis = etiket("", "tys-uyari", hiza=0.5)
        e_kapanis.set_halign(Gtk.Align.CENTER)
        e_kapanis.set_no_show_all(True)
        alt.pack_start(e_kapanis, False, False, 0)
        pano = sinif(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(6 * olcek)), "tys-pano", "tys-pano-anlik")
        pano.set_halign(Gtk.Align.CENTER)
        e_pano_b = etiket("", "tys-pano-baslik", sar=True, hiza=0.5, genislik=70)
        e_pano_m = etiket("", "tys-pano-metin", sar=True, hiza=0.5, genislik=70)
        pano.pack_start(e_pano_b, False, False, 0)
        pano.pack_start(e_pano_m, False, False, 0)
        pano.set_no_show_all(True)
        e_pano_b.show()
        e_pano_m.show()
        alt.pack_start(pano, False, False, 0)
        alt_satir = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        alt.pack_start(alt_satir, False, False, 0)
        e_ipucu = etiket("", "tys-te-ipucu")
        alt_satir.pack_start(e_ipucu, True, True, 0)
        kapat = sinif(Gtk.Button(label="Kapat"), "tys-alt-dugme")
        kapat.set_can_focus(False)
        kapat.set_no_show_all(True)
        alt_satir.pack_end(kapat, False, False, 0)

        kapaniyor = [False]

        def kapat_istegi(*_):
            if kapaniyor[0]:
                return True
            kapaniyor[0] = True

            def is_():
                try:
                    yerel("/tam_ekran/kapat", {})
                except Exception:
                    pass
                GLib.idle_add(Gtk.main_quit)
            threading.Thread(target=is_, daemon=True).start()
            return True
        kapat.connect("clicked", kapat_istegi)

        if mod == "sinav":
            rozet = etiket("SINAV", "tys-te-rozet", hiza=0.5)
            rozet.set_halign(Gtk.Align.CENTER)
            orta.pack_start(rozet, False, False, int(6 * olcek))
            e_baslik = etiket("", "tys-te-baslik", sar=True, hiza=0.5, genislik=40)
            e_baslik.set_justify(Gtk.Justification.CENTER)
            orta.pack_start(e_baslik, False, False, 0)
            e_durum = etiket("", "tys-te-durum", hiza=0.5)
            e_durum.set_margin_top(int(18 * olcek))
            orta.pack_start(e_durum, False, False, 0)
            e_sure = etiket("", "tys-te-sure", hiza=0.5)
            orta.pack_start(e_sure, False, False, 0)
            cubuk = Gtk.DrawingArea()
            cubuk.set_size_request(int(G * 0.55), int(16 * olcek))
            cubuk.set_halign(Gtk.Align.CENTER)
            orta.pack_start(cubuk, False, False, int(10 * olcek))
            e_bilgi = etiket("", "tys-te-bilgi", hiza=0.5)
            e_bilgi.set_margin_top(int(14 * olcek))
            orta.pack_start(e_bilgi, False, False, 0)
            oran = [0.0, (0.18, 0.42, 1.0)]

            def cubuk_ciz(w, cr):
                gen, yuk = w.get_allocated_width(), w.get_allocated_height()
                r = yuk / 2.0

                def yuvarlak(gen_):
                    if gen_ <= 0:
                        return
                    rr = min(r, gen_ / 2.0)
                    cr.new_sub_path()
                    cr.arc(gen_ - rr, rr, rr, -math.pi / 2, math.pi / 2)
                    cr.arc(rr, rr, rr, math.pi / 2, 3 * math.pi / 2)
                    cr.close_path()
                    cr.fill()
                cr.set_source_rgba(1, 1, 1, 0.12)
                yuvarlak(gen)
                cr.set_source_rgb(*oran[1])
                yuvarlak(gen * max(0.0, min(1.0, oran[0])))
                return False
            cubuk.connect("draw", cubuk_ciz)
        else:
            satir = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(14 * olcek))
            satir.set_halign(Gtk.Align.CENTER)
            e_saat = etiket("", "tys-te-saat")
            e_saniye = etiket("", "tys-te-saniye")
            e_saniye.set_valign(Gtk.Align.END)
            e_saniye.set_margin_bottom(int(50 * olcek))
            satir.pack_start(e_saat, False, False, 0)
            satir.pack_start(e_saniye, False, False, 0)
            orta.pack_start(satir, False, False, 0)
            e_tarih = etiket("", "tys-te-tarih", hiza=0.5)
            orta.pack_start(e_tarih, False, False, 0)
            e_mesaj = etiket("", "tys-te-mesaj", sar=True, hiza=0.5, genislik=50)
            e_mesaj.set_justify(Gtk.Justification.CENTER)
            e_mesaj.set_margin_top(int(30 * olcek))
            e_mesaj.set_no_show_all(True)
            orta.pack_start(e_mesaj, False, False, 0)
            if mod == "koruyucu":
                e_ipucu.set_text("Kullanmak için ekrana dokunun")
                olay.connect("button-press-event", kapat_istegi)
                olay.connect("touch-event", kapat_istegi)
                win.connect("key-press-event", kapat_istegi)

        def sure_metni(sn):
            sn = max(0, int(math.ceil(sn)))
            sa, kalan = divmod(sn, 3600)
            dk, sn = divmod(kalan, 60)
            return "{:d}:{:02d}:{:02d}".format(sa, dk, sn) if sa else "{:02d}:{:02d}".format(dk, sn)

        def renk(e, ad):
            ctx = e.get_style_context()
            for c in ("tys-te-uyari", "tys-te-bitti"):
                ctx.remove_class(c)
            if ad:
                ctx.add_class(ad)

        def tik():
            t = zaman_yapisi(bilgi.get("ofset"), bilgi.get("utc_ofset"))
            ns = time.time() + float(bilgi.get("ofset") or 0)
            e_okul.set_text(bilgi.get("okul_adi") or "")
            e_tahta.set_text(bilgi.get("ad") or "")
            if mod == "sinav":
                s = bilgi.get("sinav") or {}
                bas, bitis = float(s.get("bas") or ns), float(s.get("bitis") or ns)
                uyari = int(s.get("uyari_dk") or 0)
                e_baslik.set_text(s.get("baslik") or "Sınav")

                def saat_yazi(z):
                    return time.strftime("%H:%M", zaman_yapisi(z - time.time(), bilgi.get("utc_ofset")))
                e_bilgi.set_text("Başlangıç {}   ·   Bitiş {}   ·   Saat {}".format(
                    saat_yazi(bas), saat_yazi(bitis), time.strftime("%H:%M", t)))
                if ns < bas:
                    e_durum.set_text("Sınavın başlamasına")
                    e_sure.set_text(sure_metni(bas - ns))
                    renk(e_sure, None)
                    oran[0], oran[1] = 0.0, (0.18, 0.42, 1.0)
                elif ns < bitis:
                    kalan = bitis - ns
                    son = uyari and kalan <= uyari * 60
                    e_durum.set_text("Son {} dakika".format(uyari) if son else "Kalan süre")
                    e_sure.set_text(sure_metni(kalan))
                    renk(e_sure, "tys-te-uyari" if son else None)
                    renk(e_durum, "tys-te-uyari" if son else None)
                    oran[0] = (ns - bas) / max(1.0, bitis - bas)
                    oran[1] = (1.0, 0.82, 0.4) if son else (0.18, 0.42, 1.0)
                else:
                    e_durum.set_text("Lütfen kâğıtlarınızı teslim edin")
                    e_sure.set_text("SÜRE DOLDU")
                    renk(e_sure, "tys-te-bitti")
                    renk(e_durum, None)
                    oran[0], oran[1] = 1.0, (1.0, 0.42, 0.42)
                cubuk.queue_draw()
            else:
                e_saat.set_text(time.strftime("%H:%M", t))
                e_saniye.set_text(time.strftime("%S", t))
                e_tarih.set_text("{} {} {}, {}".format(t.tm_mday, AYLAR[t.tm_mon - 1], t.tm_year, GUNLER[t.tm_wday]))
                sa = bilgi.get("saat") or {}
                mesaj = sa.get("mesaj") if mod == "saat" else ""
                e_mesaj.set_text(mesaj or "")
                e_mesaj.set_visible(bool(mesaj))
                kapat.set_visible(mod == "saat" and bool(sa.get("kapatilabilir")))
            anlik = bilgi.get("anlik")
            if anlik:
                e_pano_b.set_text(anlik.get("baslik") or "DUYURU")
                e_pano_m.set_text(anlik.get("metin") or "")
                pano.show()
            else:
                pano.hide()
            k = bilgi.get("kapanis")
            if k:
                kalan = max(0, int(k - time.time()))
                e_kapanis.set_text("Tahta {:d}:{:02d} sonra kapanacak".format(kalan // 60, kalan % 60))
                e_kapanis.show()
            else:
                e_kapanis.hide()
            return True

        def yenile():
            def is_():
                try:
                    yeni = yerel("/tam_ekran")
                except Exception:
                    return
                bilgi.update(yeni)
                if yeni.get("tur") != mod:
                    GLib.idle_add(Gtk.main_quit)
            threading.Thread(target=is_, daemon=True).start()
            return True

        win.connect("delete-event", lambda *a: True)
        tik()
        win.show_all()
        tik()
        GLib.timeout_add(250, tik)
        GLib.timeout_add_seconds(1, yenile)
        GLib.timeout_add(300, lambda: (win.get_window() and yakala_pencere(win.get_window())) and False)
        GLib.timeout_add(1500, lambda: (win.get_window() and not bilgi.get("acil") and yakala_pencere(win.get_window())) or True)
        Gtk.main()
        return 0

    # ── ARIZA BİLDİR (masaüstü simgesinden) ──────────────────────────────────
    if tur == "ariza":
        yerel = yerel_baglanti()
        try:
            bilgi = yerel("/ariza")
        except Exception:
            bilgi = None
        win = Gtk.Window()
        win.set_title("Arıza Bildir")
        win.set_keep_above(True)
        win.set_position(Gtk.WindowPosition.CENTER)
        win.set_resizable(False)
        sinif(win, "tys-arka")
        kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(12 * olcek))
        kutu.set_border_width(int(34 * olcek))
        win.add(kutu)
        kutu.pack_start(etiket("Arıza Bildir", "tys-baslik"), False, False, 0)
        if bilgi is None:
            kutu.pack_start(etiket("Tahta programına ulaşılamadı. Tahtayı yeniden başlatıp tekrar deneyin.",
                                   "tys-hata", sar=True, genislik=40), False, False, 0)
            d = sinif(Gtk.Button(label="Kapat"), "tys-dugme")
            d.connect("clicked", lambda *_: Gtk.main_quit())
            kutu.pack_start(d, False, False, int(10 * olcek))
        else:
            kutu.pack_start(etiket("{} · Bildiriminiz okul yönetimine iletilir.".format(bilgi.get("ad") or ""),
                                   "tys-mesaj", sar=True, genislik=50), False, False, 0)
            kutu.pack_start(etiket("Sorun nedir?", "tys-etiket"), False, False, int(8 * olcek))
            izgara = Gtk.Grid()
            izgara.set_row_spacing(int(10 * olcek))
            izgara.set_column_spacing(int(10 * olcek))
            izgara.set_column_homogeneous(True)
            kutu.pack_start(izgara, False, False, 0)
            secili = [None]
            dugmeler = []

            def sec(d, k):
                if not d.get_active():
                    if secili[0] == k:
                        d.set_active(True)
                    return
                secili[0] = k
                for x in dugmeler:
                    if x is not d and x.get_active():
                        x.set_active(False)
            for i, k in enumerate(bilgi.get("turler") or ARIZA_TURLERI):
                d = sinif(Gtk.ToggleButton(label=k), "tys-ariza-tus")
                d.set_can_focus(False)
                d.connect("toggled", lambda d, k=k: sec(d, k))
                dugmeler.append(d)
                izgara.attach(d, i % 2, i // 2, 1, 1)
            kutu.pack_start(etiket("Açıklama (isteğe bağlı)", "tys-etiket"), False, False, int(8 * olcek))
            g_aciklama = sinif(Gtk.Entry(), "tys-giris")
            g_aciklama.set_max_length(500)
            g_aciklama.set_placeholder_text("Örn. sol hoparlörden ses gelmiyor")
            kutu.pack_start(g_aciklama, False, False, 0)
            kutu.pack_start(etiket("Adınız (isteğe bağlı)", "tys-etiket"), False, False, int(8 * olcek))
            g_ad = sinif(Gtk.Entry(), "tys-giris")
            g_ad.set_max_length(60)
            g_ad.set_text(bilgi.get("acan") or "")
            kutu.pack_start(g_ad, False, False, 0)
            e_durum = etiket("", "tys-hata", hiza=0.5)
            kutu.pack_start(e_durum, False, False, int(6 * olcek))
            satir = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(12 * olcek))
            satir.set_halign(Gtk.Align.END)
            vazgec = sinif(Gtk.Button(label="Vazgeç"), "tys-alt-dugme")
            vazgec.connect("clicked", lambda *_: Gtk.main_quit())
            gonder = sinif(Gtk.Button(label="Gönder"), "tys-dugme")
            satir.pack_start(vazgec, False, False, 0)
            satir.pack_start(gonder, False, False, 0)
            kutu.pack_start(satir, False, False, 0)

            def a_sonuc(c):
                ctx = e_durum.get_style_context()
                ctx.remove_class("tys-hata")
                ctx.remove_class("tys-basari")
                if c.get("ok"):
                    ctx.add_class("tys-basari")
                    e_durum.set_text("Bildiriminiz iletildi. Teşekkürler!")
                    GLib.timeout_add(2000, Gtk.main_quit)
                else:
                    ctx.add_class("tys-hata")
                    e_durum.set_text(c.get("hata") or "Gönderilemedi, tekrar deneyin.")
                    gonder.set_sensitive(True)
                return False

            def gonder_tik(*_):
                if not secili[0]:
                    e_durum.set_text("Lütfen sorunun türünü seçin.")
                    return
                gonder.set_sensitive(False)
                govde = {"kategori": secili[0], "aciklama": g_aciklama.get_text(), "bildiren": g_ad.get_text(),
                         "yer": "masaüstü"}

                def is_():
                    try:
                        c = yerel("/ariza", govde)
                    except Exception:
                        c = {"ok": False}
                    GLib.idle_add(a_sonuc, c)
                threading.Thread(target=is_, daemon=True).start()
            gonder.connect("clicked", gonder_tik)
        win.connect("delete-event", lambda *a: Gtk.main_quit())
        win.show_all()
        win.present()
        Gtk.main()
        return 0

    # ── BÜYÜK DUYURU ─────────────────────────────────────────────────────────
    if tur == "duyuru":
        win = Gtk.Window()
        win.set_title("Duyuru")
        win.set_decorated(False)
        win.set_keep_above(True)
        win.set_skip_taskbar_hint(True)
        sinif(win, "tys-arka")
        win.fullscreen()
        kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(26 * olcek))
        kutu.set_halign(Gtk.Align.CENTER)
        kutu.set_valign(Gtk.Align.CENTER)
        kutu.set_margin_start(int(80 * olcek))
        kutu.set_margin_end(int(80 * olcek))
        win.add(kutu)
        rozet = etiket("DUYURU", "tys-rozet", hiza=0.5)
        rozet.set_halign(Gtk.Align.CENTER)
        kutu.pack_start(rozet, False, False, 0)
        if arg.get("baslik"):
            b = etiket(arg["baslik"], "tys-d-baslik", sar=True, hiza=0.5, genislik=36)
            b.set_justify(Gtk.Justification.CENTER)
            kutu.pack_start(b, False, False, 0)
        metin = arg.get("metin") or ""
        boy = "b" if len(metin) <= 90 else ("o" if len(metin) <= 260 else "k")
        m = etiket(metin, "tys-d-metin-" + boy, sar=True, hiza=0.5, genislik={"b": 30, "o": 42, "k": 64}[boy])
        m.set_justify(Gtk.Justification.CENTER)
        kutu.pack_start(m, False, False, 0)
        alt = etiket("", "tys-alt", hiza=0.5)
        kutu.pack_start(alt, False, False, 0)
        dugme = sinif(Gtk.Button(label="Tamam"), "tys-dugme")
        dugme.set_halign(Gtk.Align.CENTER)
        dugme.connect("clicked", lambda *_: Gtk.main_quit())
        kutu.pack_start(dugme, False, False, int(10 * olcek))
        kalan = [int(arg.get("sure") or 20)]
        okul = arg.get("okul_adi") or ""

        def tik():
            parcalar = ([okul] if okul else []) + [time.strftime("%H:%M"), "{} sn sonra kapanacak".format(kalan[0])]
            alt.set_text("   ·   ".join(parcalar))
            kalan[0] -= 1
            if kalan[0] < 0:
                Gtk.main_quit()
                return False
            return True

        win.connect("key-press-event", lambda _w, o: Gtk.main_quit() if Gdk.keyval_name(o.keyval) in
                    ("Escape", "Return", "KP_Enter") else None)
        win.connect("delete-event", lambda *a: Gtk.main_quit())
        tik()
        win.show_all()
        win.present()
        GLib.timeout_add_seconds(1, tik)
        GLib.timeout_add(800, lambda: win.present() or False)
        Gtk.main()
        return 0

    # ── KÜÇÜK BİLDİRİM ───────────────────────────────────────────────────────
    if tur == "bildirim":
        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        if not seffaf_yap(win):
            sinif(win, "tys-duz-bildirim")
        genislik = int(560 * olcek)
        kart = sinif(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(8 * olcek)), "tys-bildirim")
        kart.set_size_request(genislik, -1)
        olay_kutusu = Gtk.EventBox()
        olay_kutusu.set_visible_window(False)
        olay_kutusu.add(kart)
        win.add(olay_kutusu)
        ust = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        ust.pack_start(etiket(arg.get("baslik") or "Mesaj", "tys-b-baslik", sar=True, genislik=30), True, True, 0)
        kapat = sinif(Gtk.Button(label="✕"), "tys-kapat")
        kapat.connect("clicked", lambda *_: Gtk.main_quit())
        ust.pack_end(kapat, False, False, 0)
        kart.pack_start(ust, False, False, 0)
        kart.pack_start(etiket(arg.get("metin") or "", "tys-b-metin", sar=True, genislik=36), False, False, 0)
        olay_kutusu.connect("button-press-event", lambda *_: Gtk.main_quit())
        win.show_all()
        _, yuk = win.get_preferred_height()
        win.move(X0 + G - genislik - int(32 * olcek), Y0 + Y - yuk - int(90 * olcek))
        GLib.timeout_add_seconds(max(3, int(arg.get("sure") or 10)), Gtk.main_quit)
        Gtk.main()
        return 0

    # ── KAPANMA GERİ SAYIMI ──────────────────────────────────────────────────
    if tur == "geri_sayim":
        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        if not seffaf_yap(win):
            sinif(win, "tys-duz-geri")
        genislik = int(780 * olcek)
        kart = sinif(Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(26 * olcek)), "tys-geri")
        kart.set_size_request(genislik, -1)
        win.add(kart)
        sol = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(4 * olcek))
        sol.set_valign(Gtk.Align.CENTER)
        sol.pack_start(etiket("Tahta kapanıyor", "tys-g-baslik"), False, False, 0)
        aciklama = ("Kullanılmadığı için kapanacak. Devam etmek için ekrana dokunun."
                    if arg.get("bosta") else "Lütfen çalışmalarınızı kaydedin.")
        sol.pack_start(etiket(aciklama, "tys-g-aciklama", sar=True, genislik=40), False, False, 0)
        kart.pack_start(sol, True, True, 0)
        e_sure = etiket("", "tys-g-sure", hiza=1.0)
        kart.pack_end(e_sure, False, False, 0)
        bitis = float(arg.get("bitis") or time.time() + 60)

        def tik():
            k = max(0, int(bitis - time.time()))
            e_sure.set_text("{:d}:{:02d}".format(k // 60, k % 60))
            return True
        tik()
        win.show_all()
        win.move(X0 + (G - genislik) // 2, Y0)
        GLib.timeout_add_seconds(1, tik)
        GLib.timeout_add(2000, lambda: (win.get_window() and win.get_window().raise_()) or True)
        Gtk.main()
        return 0
    return 2


# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--arayuz":
        if WINDOWS:
            gunluk_ac(os.path.join(PAYLASIM, "gunluk", "arayuz-{}.log".format(
                re.sub(r"[^\w.-]", "_", os.environ.get("USERNAME") or "kullanici"))))
        try:
            arguman = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
            sys.exit(arayuz(sys.argv[2], arguman) or 0)
        except SystemExit:
            raise
        except Exception:
            traceback.print_exc()
            sys.exit(1)
    if "--temizle" in sys.argv:
        temizle()
        sys.exit(0)
    if ISTEMCI:
        if WINDOWS or sys.stdout is None or os.environ.get("TYS_GUNLUK_DOSYA"):
            istemci_gunlugu()
        if not tek_ornek():
            log("Program zaten çalışıyor.")
            sys.exit(0)
        IstemciAjan().calistir()
    else:
        if WT:
            if not os.environ.get("TYS_GUNLUK_KONSOL"):
                gunluk_ac(os.path.join(VERI, "ajan.log"))
            if not tek_ornek(int(os.environ.get("TYS_TEK_PORT", "8769")), 60 if "--devral" in sys.argv else 3):
                log("Tahta programı zaten çalışıyor.")
                sys.exit(0)
        Ajan().calistir()
