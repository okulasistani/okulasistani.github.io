#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Tahta Yönetim Sistemi — Tahta tanı raporu
#  Kullanım:  wget -qO- <adres>/tani | sudo bash
#  Tahtanın durumunu ekrana yazar ve yönetim bilgisayarına gönderir.
#  Şifre ve anahtar içermez.
# ─────────────────────────────────────────────────────────────
SUNUCU="__SUNUCU__"
ANAHTAR="__ANAHTAR__"
Y='\033[1;32m'; K='\033[1;31m'; M='\033[1;36m'; N='\033[0m'
RAPOR=$(mktemp /tmp/tys-tani-XXXXXX.txt)
trap 'rm -f "$RAPOR"' EXIT
baslik() { echo; echo "── $1"; }

{
echo "TAHTA TANI RAPORU — $(date '+%Y-%m-%d %H:%M:%S')"
echo "Tahta adı (sistem): $(hostname)"
[ -r /etc/os-release ] && . /etc/os-release && echo "Sistem: ${PRETTY_NAME:-?}"
echo "Çekirdek: $(uname -r) · Python: $(python3 --version 2>&1)"
[ "$(id -u)" -eq 0 ] || echo "Not: sudo olmadan çalıştırıldı; bazı bilgiler eksik olabilir."

baslik "Ağ"
ip -4 -br addr 2>/dev/null
ip route 2>/dev/null | head -5

baslik "Yönetim bilgisayarı ($SUNUCU)"
python3 - "$SUNUCU" <<'PY'
import sys, re, socket, time, urllib.request
s = sys.argv[1]
m = re.match(r"^https?://([^/:]+)(?::(\d+))?", s)
h, p = m.group(1), int(m.group(2) or 8765)
t = time.time()
try:
    socket.create_connection((h, p), timeout=6).close()
    print("Bağlantı: tamam (%d ms)" % ((time.time() - t) * 1000))
except Exception as e:
    print("Bağlantı: OLMADI — %s" % e)
try:
    a = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with a.open(s + "/api/saglik", timeout=10) as y:
        print("Yanıt:", y.read(300).decode("utf-8", "replace"))
except Exception as e:
    print("Yanıt: YOK — %s" % e)
PY

baslik "Tahta programı"
if [ -f /opt/tahta-ajan/tahta-ajan.py ]; then
  echo "Sürüm: $(grep -m1 '^SURUM' /opt/tahta-ajan/tahta-ajan.py | cut -d'"' -f2)"
  echo "Hizmet: $(systemctl is-active tahta-ajan 2>/dev/null) / açılışta: $(systemctl is-enabled tahta-ajan 2>/dev/null)"
  python3 - <<'PY'
import json
try:
    b = json.load(open("/var/lib/tahta-ajan/baglanti.json"))
    print("Kayıtlı yönetim bilgisayarı:", b.get("sunucu"))
except Exception as e:
    print("Bağlantı ayarı okunamadı:", e)
try:
    d = json.load(open("/var/lib/tahta-ajan/durum.json"))
    print("Kilitli:", d.get("kilitli"), "· Son kullanıcı:", d.get("son_kullanici"))
    g = d.get("guncelleme")
    if g:
        print("Son güncelleme:", "başarılı" if g.get("ok") else "HATA", "-", g.get("mesaj"))
except Exception:
    pass
PY
else
  echo "Tahta programı KURULU DEĞİL."
fi

baslik "Masaüstü oturumu ve ekran"
loginctl list-sessions --no-legend 2>/dev/null | head -5
for d in /sys/class/drm/card*-*; do
  [ -r "$d/status" ] && [ "$(cat "$d/status")" = connected ] && echo "$(basename "$d"): $(head -1 "$d/modes" 2>/dev/null)"
done
python3 -c "import gi; gi.require_version('Gtk','3.0'); print('Ekran bileşenleri (GTK): var')" 2>/dev/null || echo "Ekran bileşenleri (GTK): YOK"

baslik "Ortak Klasör ve disk"
ls -ld "/home/Ortak Klasör" 2>/dev/null || echo "Ortak Klasör yok"
df -h / 2>/dev/null | tail -1

baslik "Son kayıtlar (tahta programı)"
journalctl -u tahta-ajan -n 40 --no-pager -o short 2>/dev/null | cut -c1-220
} > "$RAPOR" 2>&1

cat "$RAPOR"
echo
python3 - "$SUNUCU" "$ANAHTAR" "$RAPOR" <<'PY'
import sys, socket, urllib.request
s, a, r = sys.argv[1:4]
try:
    veri = open(r, "rb").read()[:200000]
    istek = urllib.request.Request(s + "/api/a/tani", data=veri, headers={
        "X-Anahtar": a, "X-Cihaz-Ad": socket.gethostname(), "Content-Type": "text/plain; charset=utf-8"})
    urllib.request.build_opener(urllib.request.ProxyHandler({})).open(istek, timeout=15).read()
    print("\033[1;32m  ✓ Rapor yönetim bilgisayarına gönderildi.\033[0m Panelde: Ayarlar → Tanı raporu indir.")
except Exception:
    print("\033[1;31m  ✗ Rapor yönetim bilgisayarına gönderilemedi.\033[0m Bu ekranın fotoğrafını çekip gönderin.")
PY
