#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Tahta Yönetim Sistemi — Tahta (Pardus/ETAP) kurulumu
#  Bu dosya yönetim bilgisayarı tarafından otomatik hazırlanır.
#  Kullanım:  wget -qO- <adres>/k | sudo bash
#        veya: sudo bash tahta-kur.sh
# ─────────────────────────────────────────────────────────────
SUNUCU="__SUNUCU__"
ANAHTAR="__ANAHTAR__"
KIMLIK="__KIMLIK__"

Y='\033[1;32m'; K='\033[1;31m'; S='\033[1;33m'; M='\033[1;36m'; N='\033[0m'
hata()  { echo -e "\n${K}  ✗ $1${N}\n"; exit 1; }
adim()  { echo -e "${M}  ▸${N} $1"; }
tamam() { echo -e "${Y}  ✓${N} $1"; }

echo -e "\n${M}  ══ Tahta Yönetim Sistemi — Tahta Kurulumu ══${N}\n"

[ "$(id -u)" -eq 0 ] || hata "Yönetici yetkisi gerekli. Komutun başına 'sudo' ekleyip tekrar deneyin."
command -v python3 >/dev/null 2>&1 || hata "Bu tahtada python3 bulunamadı."
command -v systemctl >/dev/null 2>&1 || hata "Bu sistem desteklenmiyor (systemd yok)."

adim "Program yönetim bilgisayarından indiriliyor…"
mkdir -p /opt/tahta-ajan /var/lib/tahta-ajan
chmod 755 /opt/tahta-ajan /var/lib/tahta-ajan
python3 - "$SUNUCU" "$ANAHTAR" <<'PY' || hata "Yönetim bilgisayarına ulaşılamadı ($SUNUCU). Bilgisayar açık mı, panel çalışıyor mu?"
import sys, urllib.request
sunucu, anahtar = sys.argv[1], sys.argv[2]
acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))
istek = urllib.request.Request(sunucu + "/api/a/kod", headers={"X-Anahtar": anahtar})
veri = acici.open(istek, timeout=20).read()
compile(veri, "tahta-ajan.py", "exec")
with open("/opt/tahta-ajan/tahta-ajan.py.yeni", "wb") as f:
    f.write(veri)
PY
mv -f /opt/tahta-ajan/tahta-ajan.py.yeni /opt/tahta-ajan/tahta-ajan.py
chmod 755 /opt/tahta-ajan/tahta-ajan.py
tamam "Program indirildi"

cat > /var/lib/tahta-ajan/baglanti.json <<EOF
{"sunucu": "$SUNUCU", "anahtar": "$ANAHTAR", "kimlik": "$KIMLIK"}
EOF
chmod 600 /var/lib/tahta-ajan/baglanti.json

if ! python3 -c "import gi; gi.require_version('Gtk','3.0'); gi.require_version('Gdk','3.0')" >/dev/null 2>&1; then
  adim "Ekran bileşenleri kuruluyor (birkaç dakika sürebilir)…"
  timeout 600 apt-get install -y python3-gi gir1.2-gtk-3.0 </dev/null >/dev/null 2>&1 \
    && tamam "Ekran bileşenleri kuruldu" \
    || echo -e "${S}  ! Ekran bileşenleri kurulamadı; kilit ekranı ve duyurular sınırlı çalışabilir.${N}"
fi

adim "Uzaktan açma (Wake-on-LAN) etkinleştiriliyor…"
if command -v nmcli >/dev/null 2>&1; then
  nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS= read -r satir; do
    tur="${satir##*:}"; ad="${satir%:*}"
    if [ "$tur" = "802-3-ethernet" ]; then
      nmcli connection modify "$ad" 802-3-ethernet.wake-on-lan magic >/dev/null 2>&1
    fi
  done
fi
if command -v ethtool >/dev/null 2>&1; then
  for yol in /sys/class/net/*; do
    arayuz="$(basename "$yol")"
    [ -e "$yol/device" ] && ethtool -s "$arayuz" wol g >/dev/null 2>&1
  done
fi

adim "Arka plan hizmeti kuruluyor…"
cat > /etc/systemd/system/tahta-ajan.service <<'EOF'
[Unit]
Description=Tahta Yonetim Ajani
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/tahta-ajan/tahta-ajan.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable tahta-ajan >/dev/null 2>&1
systemctl restart tahta-ajan
sleep 3
if systemctl is-active --quiet tahta-ajan; then
  tamam "Hizmet çalışıyor"
else
  hata "Hizmet başlatılamadı. Ayrıntı için: sudo journalctl -u tahta-ajan -n 30"
fi

echo -e "\n${Y}  ══════════════════════════════════════════════════${N}"
echo -e "${Y}   KURULUM TAMAMLANDI${N}"
echo -e "   Bu tahta birkaç saniye içinde yönetim panelinde görünecek."
echo -e "   Tahta adı: ${M}$(hostname)${N}  (panelden değiştirebilirsiniz)"
echo -e "${Y}  ══════════════════════════════════════════════════${N}\n"
