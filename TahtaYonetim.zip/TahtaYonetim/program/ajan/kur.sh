#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Tahta Yönetim Sistemi — Tahta (Pardus/ETAP) kurulumu
#  Bu dosya yönetim bilgisayarı tarafından otomatik hazırlanır.
#  Kullanım:  wget -qO- <adres>/k | sudo bash
#        veya: sudo bash tahta-kur.sh
# ─────────────────────────────────────────────────────────────
SUNUCU="__SUNUCU__"
ANAHTAR="__ANAHTAR__"
KIMLIK="__KIMLIK__"
ADRESLER="__ADRESLER__"
TAHTA_AD="__TAHTA_AD__"

Y='\033[1;32m'; K='\033[1;31m'; S='\033[1;33m'; M='\033[1;36m'; N='\033[0m'
hata()  { echo -e "\n${K}  ✗ $1${N}\n"; exit 1; }
adim()  { echo -e "${M}  ▸${N} $1"; }
tamam() { echo -e "${Y}  ✓${N} $1"; }

echo -e "\n${M}  ══ Tahta Yönetim Sistemi — Tahta Kurulumu ══${N}\n"

[ "$(id -u)" -eq 0 ] || hata "Yönetici yetkisi gerekli. Komutun başına 'sudo' ekleyip tekrar deneyin."
command -v python3 >/dev/null 2>&1 || hata "Bu tahtada python3 bulunamadı."
command -v systemctl >/dev/null 2>&1 || hata "Bu sistem desteklenmiyor (systemd yok)."

adim "Yönetim bilgisayarına bağlanılıyor…"
mkdir -p /opt/tahta-ajan /var/lib/tahta-ajan
chmod 755 /opt/tahta-ajan /var/lib/tahta-ajan
# Bağlanamazsa nedenini açıkça yazar; adres değişmişse yönetim bilgisayarını ağda kendisi arar.
YENI_SUNUCU=$(python3 - "$SUNUCU" "$ANAHTAR" "$KIMLIK" "$ADRESLER" <<'PY'
import sys, os, re, json, time, errno, socket, subprocess, ipaddress, urllib.request, urllib.error
sunucu, anahtar, kimlik, adresler = sys.argv[1:5]
K, S, N = "\033[1;31m", "\033[1;33m", "\033[0m"
acici = urllib.request.build_opener(urllib.request.ProxyHandler({}))
m = re.match(r"^https?://([^/:]+)(?::(\d+))?", sunucu)
host0, port = m.group(1), int(m.group(2) or 8765)

def ayir(adres):
    m = re.match(r"^https?://([^/:]+)(?::(\d+))?", adres)
    return m.group(1), int(m.group(2) or 8765)

def dene(adres):
    """None: başarılı (program indirildi). Aksi halde hata türü."""
    h, p = ayir(adres)
    try:
        socket.create_connection((h, p), timeout=6).close()
    except socket.timeout:
        return "zaman"
    except ConnectionRefusedError:
        return "red"
    except OSError as e:
        if e.errno in (errno.EHOSTUNREACH, errno.ENETUNREACH, getattr(errno, "EHOSTDOWN", -1)):
            return "yol"
        if isinstance(e, socket.gaierror):
            return "ad"
        return "ag:" + (e.strerror or str(e))
    try:
        with acici.open(adres + "/api/saglik", timeout=12) as y:
            if b"TahtaYonetim" not in y.read(4096):
                return "baska"
    except urllib.error.HTTPError:
        return "baska"
    except Exception:
        return "yanit"
    try:
        istek = urllib.request.Request(adres + "/api/a/kod", headers={"X-Anahtar": anahtar})
        with acici.open(istek, timeout=40) as y:
            veri = y.read()
    except urllib.error.HTTPError as e:
        return "yetki" if e.code in (401, 403) else "http:%d" % e.code
    except Exception:
        return "yanit"
    try:
        compile(veri, "tahta-ajan.py", "exec")
    except Exception:
        return "bozuk"
    with open("/opt/tahta-ajan/tahta-ajan.py.yeni", "wb") as f:
        f.write(veri)
    return None

def tahta_aglari():
    """Tahtanın IPv4 ağları; öğrenilemezse None."""
    try:
        r = subprocess.run(["ip", "-4", "-o", "addr", "show", "scope", "global"], stdout=subprocess.PIPE,
                           stderr=subprocess.DEVNULL, universal_newlines=True, timeout=5)
        if r.returncode != 0:
            return None
        return [ipaddress.ip_interface(a) for a in re.findall(r"inet (\d+\.\d+\.\d+\.\d+/\d+)", r.stdout)]
    except Exception:
        return None

def isaret_ara(sure=12):
    """Yönetim bilgisayarının 10 saniyede bir yaptığı ağ duyurusunu dinler."""
    bulunan, baska = [], False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        s.bind(("", 8766))
        s.settimeout(1)
    except OSError:
        return bulunan, baska
    bitis = time.time() + sure
    while time.time() < bitis and not bulunan:
        try:
            veri, (ip, _) = s.recvfrom(256)
        except socket.timeout:
            continue
        except OSError:
            break
        p = veri.decode("utf-8", "replace").split()
        if len(p) >= 3 and p[0] == "TYS1":
            if p[1] == kimlik:
                bulunan.append("http://%s:%s" % (ip, p[2]))
            else:
                baska = True
    s.close()
    return bulunan, baska

def yaz(m):
    sys.stderr.write(m + "\n")
    sys.stderr.flush()

adaylar = [sunucu]
for a in adresler.split():
    a = "http://%s:%d" % (a, port)
    if a not in adaylar:
        adaylar.append(a)
sonuclar = {}
for a in adaylar:
    sonuclar[a] = dene(a)
    if sonuclar[a] is None:
        if a != sunucu:
            yaz("  ✓ Yönetim bilgisayarına %s adresinden ulaşıldı." % a)
        print(a)
        sys.exit(0)
    if sonuclar[a] == "yetki":
        break

ana = sonuclar[sunucu]
baska_kurulum = False
if ana != "yetki":
    yaz("  ▸ %s adresine ulaşılamadı; yönetim bilgisayarı ağda aranıyor (en fazla 12 sn)…" % sunucu)
    bulunan, baska_kurulum = isaret_ara()
    for a in bulunan:
        if a in sonuclar:
            continue
        sonuc = dene(a)
        if sonuc is None:
            yaz("  ✓ Yönetim bilgisayarı yeni adresinde bulundu: %s" % a)
            print(a)
            sys.exit(0)
        sonuclar[a] = sonuc

aglar = tahta_aglari()
try:
    sunucu_ip = ipaddress.ip_address(host0)
except ValueError:
    sunucu_ip = None
ayni_ag = aglar is None or sunucu_ip is None or any(sunucu_ip in a.network for a in aglar)
tahta_ip = ", ".join(str(a.ip) for a in aglar or []) or "bilinmiyor"
adr = "%s:%d" % (host0, port)
ulasildi = any(v not in ("yol", "zaman", "ad") and not str(v).startswith("ag:") for v in sonuclar.values())

if aglar == [] and not ulasildi:
    neden = ["Bu tahtanın ağ bağlantısı yok.",
             "Ağ kablosunun takılı olduğunu ve sağ üstteki ağ simgesinin bağlı göründüğünü kontrol edin."]
elif ana == "yetki":
    neden = ["Bu kurulum komutu ya da dosyası bu yönetim bilgisayarına ait değil (eski ya da başka bir kuruluma ait).",
             "Paneldeki 'Tahta Ekle' sayfasından güncel komutu alıp tekrar çalıştırın."]
elif ana == "red":
    neden = ["Yönetim bilgisayarı (%s) açık ama Tahta Yönetim programı çalışmıyor." % host0,
             "Bilgisayarda masaüstündeki 'Tahta Yönetim Paneli' simgesine çift tıklayın, panel açılınca tekrar deneyin."]
elif ana == "yol":
    neden = ["Tahta, yönetim bilgisayarını (%s) ağda göremiyor." % host0,
             "Bilgisayar kapalı ya da uykuda olabilir veya ağ kablosu çıkmış olabilir.",
             "Bilgisayarı açın ya da uyandırın, panelin açıldığını görün, sonra komutu tekrar çalıştırın."]
elif ana == "zaman":
    neden = ["Yönetim bilgisayarı (%s) bağlantıya hiç yanıt vermedi." % adr,
             "En sık neden Windows güvenlik duvarı ya da antivirüs programıdır: bilgisayarda KUR.bat'ı yeniden",
             "çalıştırıp izin sorusuna 'Evet' deyin; antivirüs varsa 8765 numaralı bağlantı noktasına izin verin.",
             "Bilgisayar uykuya geçerken de bu hata görülebilir."]
elif ana == "yanit":
    neden = ["Yönetim bilgisayarı bağlantıyı aldı ama yanıt vermedi.",
             "Bilgisayar uykuya geçiyor olabilir ya da program takılmış olabilir. Bilgisayarı uyandırıp panelde F5'e",
             "basın; panel de açılmıyorsa bilgisayarda KUR.bat'ı yeniden çalıştırın."]
elif ana == "baska":
    neden = ["%s adresinde Tahta Yönetim programı yok, başka bir program yanıt veriyor." % adr,
             "Yönetim bilgisayarının adresi değişmiş olabilir. Paneldeki 'Tahta Ekle' sayfasından güncel komutu alın."]
elif ana == "ad":
    neden = ["'%s' adı çözülemedi. Paneldeki 'Tahta Ekle' sayfasında yazan IP adresli komutu kullanın." % host0]
elif ana == "bozuk":
    neden = ["Program eksik indirildi. Ağ bağlantısını kontrol edip tekrar deneyin."]
else:
    neden = ["Bağlantı hatası (%s)." % ana]
if aglar and not ayni_ag and ana in ("yol", "zaman", "yanit"):
    neden += ["",
              "Not: Tahta (%s) ile yönetim bilgisayarı (%s) farklı ağlarda görünüyor." % (tahta_ip, host0),
              "Okulun ağını kuran kişiden, tahtaların bulunduğu ağdan %s adresine erişim izni isteyin." % adr]
if baska_kurulum and ana != "yetki":
    neden += ["", "Ağda başka bir Tahta Yönetim bilgisayarı var; bu komut ona ait değil."]
yaz("\n" + K + "  ✗ " + neden[0] + N)
for satir in neden[1:]:
    yaz("    " + satir)
yaz("\n  Tahtanın adresi: %s · Denenen: %s" % (tahta_ip, ", ".join(sonuclar)))
sys.exit(1)
PY
) || { echo; exit 1; }
SUNUCU="$YENI_SUNUCU"
mv -f /opt/tahta-ajan/tahta-ajan.py.yeni /opt/tahta-ajan/tahta-ajan.py
chmod 755 /opt/tahta-ajan/tahta-ajan.py
tamam "Program indirildi"

cat > /var/lib/tahta-ajan/baglanti.json <<EOF
{"sunucu": "$SUNUCU", "anahtar": "$ANAHTAR", "kimlik": "$KIMLIK", "ad_istek": "$TAHTA_AD"}
EOF
chmod 600 /var/lib/tahta-ajan/baglanti.json

if ! python3 -c "import gi; gi.require_version('Gtk','3.0'); gi.require_version('Gdk','3.0')" >/dev/null 2>&1; then
  adim "Ekran bileşenleri kuruluyor (birkaç dakika sürebilir)…"
  timeout 600 apt-get install -y python3-gi gir1.2-gtk-3.0 </dev/null >/dev/null 2>&1 \
    && tamam "Ekran bileşenleri kuruldu" \
    || echo -e "${S}  ! Ekran bileşenleri kurulamadı; kilit ekranı ve duyurular sınırlı çalışabilir.${N}"
fi

adim "Uzaktan açma (Wake-on-LAN) etkinleştiriliyor…"
if command -v nmcli >/dev/null 2>&1; then
  nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS= read -r satir; do
    tur="${satir##*:}"; ad="${satir%:*}"
    if [ "$tur" = "802-3-ethernet" ]; then
      nmcli connection modify "$ad" 802-3-ethernet.wake-on-lan magic >/dev/null 2>&1
    fi
  done
fi
if command -v ethtool >/dev/null 2>&1; then
  for yol in /sys/class/net/*; do
    arayuz="$(basename "$yol")"
    [ -e "$yol/device" ] && ethtool -s "$arayuz" wol g >/dev/null 2>&1
  done
fi

adim "Arka plan hizmeti kuruluyor…"
cat > /etc/systemd/system/tahta-ajan.service <<'EOF'
[Unit]
Description=Tahta Yonetim Ajani
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/tahta-ajan/tahta-ajan.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable tahta-ajan >/dev/null 2>&1
systemctl restart tahta-ajan
sleep 3
if systemctl is-active --quiet tahta-ajan; then
  tamam "Hizmet çalışıyor"
else
  hata "Hizmet başlatılamadı. Ayrıntı için: sudo journalctl -u tahta-ajan -n 30"
fi

echo -e "\n${Y}  ══════════════════════════════════════════════════${N}"
echo -e "${Y}   KURULUM TAMAMLANDI${N}"
echo -e "   Bu tahta birkaç saniye içinde yönetim panelinde görünecek."
echo -e "   Tahta adı: ${M}${TAHTA_AD:-$(hostname)}${N}  (panelden değiştirebilirsiniz)"
echo -e "${Y}  ══════════════════════════════════════════════════${N}\n"
