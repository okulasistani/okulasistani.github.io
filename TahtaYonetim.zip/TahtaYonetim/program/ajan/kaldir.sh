#!/bin/bash
# Tahta Yönetim Sistemi — tahtadan kaldırma
# Kullanım:  wget -qO- <adres>/kaldir | sudo bash
[ "$(id -u)" -eq 0 ] || { echo "Komutun başına sudo ekleyin."; exit 1; }
# Site engelini ve masaüstü simgelerini geri al (Ortak Klasör'deki dosyalar silinmez)
[ -f /opt/tahta-ajan/tahta-ajan.py ] && timeout 60 python3 /opt/tahta-ajan/tahta-ajan.py --temizle >/dev/null 2>&1
systemctl disable --now tahta-ajan >/dev/null 2>&1
rm -f /etc/systemd/system/tahta-ajan.service
systemctl daemon-reload
pkill -f /opt/tahta-ajan/tahta-ajan.py >/dev/null 2>&1
rm -rf /opt/tahta-ajan /var/lib/tahta-ajan
echo "Tahta Yönetim ajanı bu tahtadan kaldırıldı."
