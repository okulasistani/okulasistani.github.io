# -*- coding: utf-8 -*-
"""Okul modülü (4.0): nöbet çizelgesi ve belirli gün/haftalar (tahta kenarında şerit ya da masaüstü resmine
çizili), açılış görseli, giriş ekranı notu, tahta sağlığı, yönetici şifresini değiştirme ve yeni dönem temizliği.
Ajan root/SYSTEM olarak çalışır; pencereler oturumdaki kullanıcı olarak ayrı süreçte açılır (arayuz)."""
SURUM = "4.1"
C = None

import os
import re
import sys
import json
import time
import shutil
import hashlib
import threading
import subprocess

AYLAR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
GUNLER = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
NOT_DOSYA = "/usr/share/backgrounds/tahta-yonetim/giris-notu.txt"
COP_GUN = 7


def tarih_yazi(t):
    """'2026-11-19' → '19 Kasım 2026, Perşembe'"""
    y, a, g = (int(x) for x in t.split("-"))
    import datetime
    return "{} {} {}, {}".format(g, AYLAR[a - 1], y, GUNLER[datetime.date(y, a, g).weekday()])


def gi_python():
    """GTK / cairo kullanabilen Python (çizim için)."""
    adaylar = [os.environ.get("TYS_GI_PY"), sys.executable, "/usr/bin/python3", shutil.which("python3.12"),
               shutil.which("python3.11"), shutil.which("python3")]
    for p in adaylar:
        if not p or not os.path.exists(p):
            continue
        if _GI_SONUC.get(p) is None:
            try:
                r = subprocess.run([p, "-c", "import gi; gi.require_version('PangoCairo','1.0'); "
                                             "from gi.repository import PangoCairo, GdkPixbuf; import cairo"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
                _GI_SONUC[p] = r.returncode == 0
            except Exception:
                _GI_SONUC[p] = False
        if _GI_SONUC[p]:
            return p
    return None


_GI_SONUC = {}


# ═════════════════════════════════════════════════════════════════════════════
# Çizim (cairo + Pango) — hem masaüstü resmi hem kenar şeridi aynı kartı çizer
# ═════════════════════════════════════════════════════════════════════════════

def kart_ciz(cr, veri, x0, y0, olcek=1.0, saydam=0.80, yukseklik=None, ciz=True):
    """Nöbet kartını (x0, y0) noktasına çizer; (genişlik, yükseklik) döner. ciz=False ise yalnızca ölçer.
    veri: baslik, tarih, nobet [[yer, kişi]], tatil, gunler, haftalar, bgh_goster, alt"""
    import gi
    gi.require_version("Pango", "1.0")
    gi.require_version("PangoCairo", "1.0")
    from gi.repository import Pango, PangoCairo

    s = olcek
    pad = 26 * s
    ng = 330 * s
    bg = 230 * s
    bgh = bool(veri.get("bgh_goster", True)) and bool(veri.get("gunler") or veri.get("haftalar"))
    nobet = veri.get("nobet") or []
    nobet_var = bool(nobet) or not bgh

    def yerlesim(metin, boy, kalin=False, genislik=None, aralik=0):
        lay = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription("Sans {} {}".format("Bold" if kalin else "", boy * s).replace("  ", " "))
        lay.set_font_description(fd)
        if aralik:
            al = Pango.AttrList()
            al.insert(Pango.attr_letter_spacing_new(int(aralik * s * Pango.SCALE)))
            lay.set_attributes(al)
        if genislik:
            lay.set_width(int(genislik * Pango.SCALE))
            lay.set_wrap(Pango.WrapMode.WORD_CHAR)
        lay.set_text(metin, -1)
        return lay

    def boy(lay):
        return lay.get_pixel_size()[1]

    def yaz(lay, x, y, renk):
        if ciz:
            cr.set_source_rgba(*renk)
            cr.move_to(x, y)
            PangoCairo.show_layout(cr, lay)

    AKSAN = (1.0, 0.82, 0.48, 1)
    BEYAZ = (1, 1, 1, 1)
    SOLUK = (0.80, 0.86, 0.95, 0.86)
    CIZGI = (1, 1, 1, 0.14)

    # ── nöbet sütunu
    sutunlar = []
    if nobet_var:
        parcalar = []
        parcalar.append(("b", yerlesim((veri.get("baslik") or "Bugünün Nöbetçileri").upper(), 12.5, True, ng, 1.6), AKSAN, 4))
        parcalar.append(("t", yerlesim(veri.get("tarih") or "", 11.5, False, ng), SOLUK, 16))
        if nobet:
            for i, (yer, kisi) in enumerate(nobet):
                parcalar.append(("y", yerlesim(yer, 10.5, False, ng, 0.6), SOLUK, 2))
                parcalar.append(("k", yerlesim(kisi, 17, True, ng), BEYAZ, 12 if i < len(nobet) - 1 else 2))
        else:
            parcalar.append(("k", yerlesim(veri.get("tatil") or "Bugün için nöbet çizelgesi girilmedi", 13, False, ng), SOLUK, 2))
        sutunlar.append((ng, parcalar))
    if bgh:
        parcalar = [("b", yerlesim("BELİRLİ GÜN VE HAFTALAR", 12.5, True, bg, 1.6), AKSAN, 14)]
        if veri.get("gunler"):
            parcalar.append(("y", yerlesim("BUGÜN", 10, False, bg, 1.0), SOLUK, 3))
            for a in veri["gunler"]:
                parcalar.append(("k", yerlesim(a, 15, True, bg), BEYAZ, 8))
            parcalar.append(("ara", None, None, 8))
        if veri.get("haftalar"):
            parcalar.append(("y", yerlesim("BU HAFTA", 10, False, bg, 1.0), SOLUK, 3))
            for a in veri["haftalar"]:
                parcalar.append(("k", yerlesim(a, 15, True, bg), BEYAZ, 8))
        sutunlar.append((bg, parcalar))

    yuks = []
    for _, parcalar in sutunlar:
        h = 0
        for tur, lay, _, ara in parcalar:
            h += (boy(lay) if lay else 0) + ara * s
        yuks.append(h)
    ara_sutun = 30 * s
    alt = veri.get("alt")
    alt_lay = yerlesim(alt, 10, False, sum(g for g, _ in sutunlar) + ara_sutun * (len(sutunlar) - 1)) if alt else None
    G = pad * 2 + sum(g for g, _ in sutunlar) + ara_sutun * (len(sutunlar) - 1)
    H = pad * 2 + (max(yuks) if yuks else 0) + ((boy(alt_lay) + 18 * s) if alt_lay else 0)
    if yukseklik:
        H = max(H, yukseklik)
    if not ciz:
        return G, H
    r = 18 * s if not yukseklik else 0
    cr.new_path()
    cr.arc(x0 + G - r, y0 + r, r, -1.5708, 0) if r else cr.move_to(x0 + G, y0)
    cr.arc(x0 + G - r, y0 + H - r, r, 0, 1.5708) if r else cr.line_to(x0 + G, y0 + H)
    cr.arc(x0 + r, y0 + H - r, r, 1.5708, 3.1416) if r else cr.line_to(x0, y0 + H)
    cr.arc(x0 + r, y0 + r, r, 3.1416, 4.7124) if r else cr.line_to(x0, y0)
    cr.close_path()
    cr.set_source_rgba(0.03, 0.08, 0.17, saydam)
    cr.fill()
    x = x0 + pad
    for i, (g, parcalar) in enumerate(sutunlar):
        y = y0 + pad
        if i:
            cr.set_source_rgba(*CIZGI)
            cr.set_line_width(max(1, 1.2 * s))
            cr.move_to(x - ara_sutun / 2, y0 + pad)
            cr.line_to(x - ara_sutun / 2, y0 + H - pad)
            cr.stroke()
        for tur, lay, renk, ara in parcalar:
            if lay:
                yaz(lay, x, y, renk)
                y += boy(lay)
            y += ara * s
        x += g + ara_sutun
    if alt_lay:
        yaz(alt_lay, x0 + pad, y0 + H - pad - boy(alt_lay), SOLUK)
    return G, H


def arkaplan_ciz(arg):
    """Masaüstü resmini üretir: taban resim (yoksa okul tasarımı) + sağda nöbet kartı."""
    import gi
    gi.require_version("Pango", "1.0")
    gi.require_version("PangoCairo", "1.0")
    gi.require_version("GdkPixbuf", "2.0")
    gi.require_version("Gdk", "3.0")
    from gi.repository import Pango, PangoCairo, GdkPixbuf, Gdk
    import cairo
    W, H = int(arg.get("w") or 1920), int(arg.get("h") or 1080)
    taban = arg.get("taban")
    if taban and os.path.exists(taban):
        pb = GdkPixbuf.Pixbuf.new_from_file(taban)
        if pb.get_width() >= 1280:
            W, H = pb.get_width(), pb.get_height()
    s = H / 1080.0
    yuzey = cairo.ImageSurface(cairo.FORMAT_RGB24, W, H)
    cr = cairo.Context(yuzey)
    if taban and os.path.exists(taban):
        olc = max(W / pb.get_width(), H / pb.get_height())
        pw, ph = pb.get_width() * olc, pb.get_height() * olc
        cr.save()
        cr.translate((W - pw) / 2, (H - ph) / 2)
        cr.scale(olc, olc)
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint()
        cr.restore()
    else:
        gr = cairo.LinearGradient(0, 0, W, H)
        gr.add_color_stop_rgb(0, 0.04, 0.24, 0.57)
        gr.add_color_stop_rgb(1, 0.12, 0.48, 0.88)
        cr.set_source(gr)
        cr.paint()
        cr.set_source_rgba(1, 1, 1, 0.08)
        cr.arc(W * 0.12, H * 0.92, 300 * s, 0, 6.3)
        cr.fill()
        cr.arc(W * 0.48, H * 0.05, 240 * s, 0, 6.3)
        cr.fill()
        merkez = W * 0.36
        y = H * 0.22
        logo = arg.get("logo")
        if logo and os.path.exists(logo):
            try:
                lp = GdkPixbuf.Pixbuf.new_from_file(logo)
                lo = min(300 * s / lp.get_width(), 300 * s / lp.get_height())
                cr.save()
                cr.translate(merkez - lp.get_width() * lo / 2, y)
                cr.scale(lo, lo)
                Gdk.cairo_set_source_pixbuf(cr, lp, 0, 0)
                cr.paint()
                cr.restore()
                y += lp.get_height() * lo + 40 * s
            except Exception:
                pass
        else:
            y = H * 0.36
        for metin, boy, kalin, alfa in ((arg.get("tahta") or "", 150, True, 1), (arg.get("okul") or "", 40, False, 0.9)):
            if not metin:
                continue
            lay = PangoCairo.create_layout(cr)
            lay.set_font_description(Pango.FontDescription("Sans {}{}".format("Bold " if kalin else "", boy * s)))
            lay.set_width(int(W * 0.62 * Pango.SCALE))
            lay.set_alignment(Pango.Alignment.CENTER)
            lay.set_wrap(Pango.WrapMode.WORD_CHAR)
            lay.set_text(metin, -1)
            pw, ph = lay.get_pixel_size()
            cr.set_source_rgba(1, 1, 1, alfa)
            cr.move_to(merkez - W * 0.31, y)
            PangoCairo.show_layout(cr, lay)
            y += ph + 12 * s
    veri = arg.get("veri") or {}
    if veri.get("nobet") or veri.get("gunler") or veri.get("haftalar") or veri.get("tatil") is not None or veri.get("goster_bos"):
        olcek = s * 1.15
        g, h = kart_ciz(cr, veri, 0, 0, olcek, ciz=False)
        x = W - g - 70 * s
        y = max(60 * s, min(H * 0.14, H - h - 110 * s))
        kart_ciz(cr, veri, x, y, olcek, saydam=0.80)
    cikti = arg["cikti"]
    yuzey.write_to_png(cikti + ".tmp")
    os.replace(cikti + ".tmp", cikti)
    return 0


# ═════════════════════════════════════════════════════════════════════════════
# Pencereler (oturumdaki kullanıcı olarak ayrı süreçte): kenar şeridi ve açılış görseli
# ═════════════════════════════════════════════════════════════════════════════

def arayuz(tur, arg):
    if os.name == "nt":
        return arayuz_win(tur, arg)
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
    gosterge = Gdk.Display.get_default()
    try:
        mon = gosterge.get_primary_monitor() or gosterge.get_monitor(0)
        geo = mon.get_geometry()
        X0, Y0, GW, GH = geo.x, geo.y, geo.width, geo.height
        try:
            wa = mon.get_workarea()
            AY0, AH = wa.y, wa.height
        except Exception:
            AY0, AH = Y0, GH
    except Exception:
        X0, Y0, GW, GH = 0, 0, 1920, 1080
        AY0, AH = Y0, GH

    if tur == "okul_serit":
        ayar = arg.get("ayar") or {}
        olcek = (GH / 1080.0) * (int(ayar.get("yazi") or 100) / 100.0)
        saydam = int(ayar.get("saydamlik") or 88) / 100.0
        win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        win.set_title("Nöbet Çizelgesi")
        win.set_decorated(False)
        win.set_resizable(False)
        win.set_skip_taskbar_hint(True)
        win.set_skip_pager_hint(True)
        win.set_accept_focus(False)
        win.set_focus_on_map(False)
        win.set_keep_below(True)
        win.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        win.stick()
        ekr = win.get_screen()
        vis = ekr.get_rgba_visual()
        if vis is not None and ekr.is_composited():
            win.set_visual(vis)
            win.set_app_paintable(True)
        import cairo
        olc_yuzey = cairo.ImageSurface(cairo.FORMAT_ARGB32, 10, 10)
        istenen = int(int(ayar.get("genislik") or 340) * GH / 1080.0)
        g, _ = kart_ciz(cairo.Context(olc_yuzey), arg.get("veri") or {}, 0, 0, olcek, ciz=False)
        if g > istenen:                      # yöneticinin belirlediği genişliğe sığdır
            olcek *= istenen / g
            g, _ = kart_ciz(cairo.Context(olc_yuzey), arg.get("veri") or {}, 0, 0, olcek, ciz=False)
        g = max(int(g), istenen)
        h = AH
        alan = Gtk.DrawingArea()
        alan.set_size_request(g, h)

        def ciz(w, cr):
            cr.set_operator(cairo.OPERATOR_SOURCE)
            cr.set_source_rgba(0, 0, 0, 0)
            cr.paint()
            cr.set_operator(cairo.OPERATOR_OVER)
            kart_ciz(cr, arg.get("veri") or {}, 0, 0, olcek, saydam=saydam, yukseklik=h)
            return False
        alan.connect("draw", ciz)
        win.add(alan)
        win.set_default_size(g, h)
        x = X0 + (GW - g if ayar.get("taraf") != "sol" else 0)
        win.move(x, AY0)

        def gercekle(*_):
            try:
                win.input_shape_combine_region(cairo.Region())      # tıklamalar arkadaki masaüstüne geçer
            except Exception:
                pass
        win.connect("realize", gercekle)
        win.connect("delete-event", lambda *_: True)                 # öğretmen kapatamaz (ajan yeniden açar)

        def koru():
            try:
                win.set_keep_below(True)
                win.move(x, AY0)
                gdkw = win.get_window()
                if gdkw is not None:
                    gdkw.lower()
            except Exception:
                pass
            return True
        GLib.timeout_add_seconds(3, koru)
        win.show_all()
        gercekle()
        Gtk.main()
        return 0

    if tur == "okul_gorsel":
        yol = arg.get("yol") or ""
        sure = max(3, int(arg.get("sure") or 30))
        win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        win.set_title(arg.get("ad") or "Açılış görseli")
        win.set_decorated(False)
        win.set_keep_above(True)
        win.set_skip_taskbar_hint(True)
        win.move(X0, Y0)
        win.set_default_size(GW, GH)
        css = Gtk.CssProvider()
        css.load_from_data(b"window{background:#000}.tys-gk{background:rgba(0,0,0,.55);color:#fff;border-radius:22px;"
                           b"padding:8px 18px;font-size:15px;border:1px solid rgba(255,255,255,.25)}"
                           b"label.tys-gs{color:rgba(255,255,255,.75);font-size:14px;margin:12px 18px}")
        Gtk.StyleContext.add_provider_for_screen(win.get_screen(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        kat = Gtk.Overlay()
        win.add(kat)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(yol)
            o = min(GW / pb.get_width(), GH / pb.get_height())
            pb = pb.scale_simple(max(1, int(pb.get_width() * o)), max(1, int(pb.get_height() * o)), GdkPixbuf.InterpType.BILINEAR)
            resim = Gtk.Image.new_from_pixbuf(pb)
        except Exception:
            resim = Gtk.Label(label=arg.get("ad") or "")
        kat.add(resim)
        ust = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        ust.set_halign(Gtk.Align.END)
        ust.set_valign(Gtk.Align.START)
        e_sure = Gtk.Label(label="")
        e_sure.get_style_context().add_class("tys-gs")
        ust.pack_start(e_sure, False, False, 0)
        if arg.get("kapatilabilir", True):
            b = Gtk.Button(label="Kapat  ✕")
            b.get_style_context().add_class("tys-gk")
            b.set_margin_top(14)
            b.set_margin_end(18)
            b.connect("clicked", lambda *_: Gtk.main_quit())
            ust.pack_start(b, False, False, 0)
        kat.add_overlay(ust)
        bitis = time.time() + sure

        def tik():
            k = int(bitis - time.time() + 0.99)
            if k <= 0:
                Gtk.main_quit()
                return False
            e_sure.set_text("{} sn".format(k))
            return True
        tik()
        GLib.timeout_add(500, tik)
        win.connect("delete-event", lambda *_: not arg.get("kapatilabilir", True))
        win.show_all()
        win.fullscreen()
        win.present()
        Gtk.main()
        return 0
    return 2


def arayuz_win(tur, arg):
    """Windows: tkinter ile kenar şeridi ve açılış görseli."""
    import ctypes
    import tkinter as tk
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
    u32 = ctypes.WinDLL("user32")
    PW, PH = u32.GetSystemMetrics(0), u32.GetSystemMetrics(1)
    s = PH / 1080.0

    if tur == "okul_serit":
        ayar = arg.get("ayar") or {}
        veri = arg.get("veri") or {}
        olcek = s * int(ayar.get("yazi") or 100) / 100.0
        kok = tk.Tk()
        kok.overrideredirect(True)
        kok.attributes("-alpha", int(ayar.get("saydamlik") or 88) / 100.0)
        kok.configure(bg="#08142b")
        bgh = bool(veri.get("bgh_goster", True)) and bool(veri.get("gunler") or veri.get("haftalar"))
        istenen = int(int(ayar.get("genislik") or 340) * s)
        dogal = (330 + (230 + 30 if bgh else 0) + 52) * olcek
        if dogal > istenen:                  # yöneticinin belirlediği genişliğe sığdır
            olcek *= istenen / dogal
        g_n = int(330 * olcek)
        g_b = int(230 * olcek) if bgh else 0
        G = max(istenen, g_n + g_b + int((52 + (30 if bgh else 0)) * olcek))
        x = PW - G if ayar.get("taraf") != "sol" else 0
        kok.geometry("{}x{}+{}+0".format(G, PH, x))
        c = tk.Canvas(kok, width=G, height=PH, bg="#08142b", highlightthickness=0)
        c.pack(fill="both", expand=True)

        def f(boy, kalin=False):
            return ("Segoe UI Semibold" if kalin else "Segoe UI", -int(boy * 1.33 * olcek))
        pad = int(26 * olcek)
        y = pad
        c.create_text(pad, y, anchor="nw", text=(veri.get("baslik") or "Bugünün Nöbetçileri").upper(), fill="#ffd27a",
                      font=f(12.5, True), width=g_n)
        y += int(26 * olcek)
        c.create_text(pad, y, anchor="nw", text=veri.get("tarih") or "", fill="#cbd9ee", font=f(11.5), width=g_n)
        y += int(36 * olcek)
        for yer, kisi in veri.get("nobet") or []:
            i = c.create_text(pad, y, anchor="nw", text=yer, fill="#cbd9ee", font=f(10.5), width=g_n)
            y = c.bbox(i)[3] + int(2 * olcek)
            i = c.create_text(pad, y, anchor="nw", text=kisi, fill="#ffffff", font=f(17, True), width=g_n)
            y = c.bbox(i)[3] + int(12 * olcek)
        if not veri.get("nobet"):
            c.create_text(pad, y, anchor="nw", text=veri.get("tatil") or "Bugün için nöbet çizelgesi girilmedi",
                          fill="#cbd9ee", font=f(13), width=g_n)
        if bgh:
            bx = pad + g_n + int(30 * olcek)
            c.create_line(bx - int(15 * olcek), pad, bx - int(15 * olcek), PH - pad, fill="#33405a")
            y = pad
            c.create_text(bx, y, anchor="nw", text="BELİRLİ GÜN VE HAFTALAR", fill="#ffd27a", font=f(12.5, True), width=g_b)
            y += int(40 * olcek)
            for etiket, liste in (("BUGÜN", veri.get("gunler")), ("BU HAFTA", veri.get("haftalar"))):
                if not liste:
                    continue
                c.create_text(bx, y, anchor="nw", text=etiket, fill="#cbd9ee", font=f(10), width=g_b)
                y += int(20 * olcek)
                for a in liste:
                    i = c.create_text(bx, y, anchor="nw", text=a, fill="#ffffff", font=f(15, True), width=g_b)
                    y = c.bbox(i)[3] + int(8 * olcek)
                y += int(8 * olcek)
        kok.update_idletasks()
        hwnd = u32.GetParent(kok.winfo_id()) or kok.winfo_id()
        GWL_EXSTYLE, WS_EX_LAYERED, WS_EX_TRANSPARENT, WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE = -20, 0x80000, 0x20, 0x80, 0x08000000
        try:
            st = u32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            u32.SetWindowLongW(hwnd, GWL_EXSTYLE, st | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE)
        except Exception:
            pass

        def alta():
            try:
                u32.SetWindowPos(hwnd, 1, 0, 0, 0, 0, 0x0002 | 0x0001 | 0x0010)      # HWND_BOTTOM, NOMOVE|NOSIZE|NOACTIVATE
            except Exception:
                pass
            kok.after(2000, alta)
        alta()
        kok.protocol("WM_DELETE_WINDOW", lambda: None)
        kok.mainloop()
        return 0

    if tur == "okul_gorsel":
        sure = max(3, int(arg.get("sure") or 30))
        kok = tk.Tk()
        kok.overrideredirect(True)
        kok.geometry("{}x{}+0+0".format(PW, PH))
        kok.configure(bg="black")
        kok.attributes("-topmost", True)
        try:
            foto = tk.PhotoImage(file=arg.get("yol") or "")
            k = max(1, -(-foto.width() // PW), -(-foto.height() // PH))
            if k > 1:
                foto = foto.subsample(k, k)
            tk.Label(kok, image=foto, bg="black").place(relx=0.5, rely=0.5, anchor="center")
        except Exception:
            tk.Label(kok, text=arg.get("ad") or "", fg="white", bg="black", font=("Segoe UI", -int(40 * s))).place(
                relx=0.5, rely=0.5, anchor="center")
        e = tk.Label(kok, text="", fg="#dddddd", bg="black", font=("Segoe UI", -int(18 * s)))
        e.place(relx=1.0, x=-int(150 * s), y=int(18 * s), anchor="ne")
        if arg.get("kapatilabilir", True):
            tk.Button(kok, text="Kapat  ✕", command=kok.destroy, fg="white", bg="#333333", relief="flat",
                      font=("Segoe UI", -int(18 * s)), padx=int(14 * s)).place(relx=1.0, x=-int(18 * s), y=int(14 * s), anchor="ne")
        bitis = time.time() + sure

        def tik():
            k = int(bitis - time.time() + 0.99)
            if k <= 0:
                kok.destroy()
                return
            e.configure(text="{} sn".format(k))
            kok.after(500, tik)
        tik()
        kok.protocol("WM_DELETE_WINDOW", (lambda: kok.destroy()) if arg.get("kapatilabilir", True) else (lambda: None))
        kok.mainloop()
        return 0
    return 2


# ═════════════════════════════════════════════════════════════════════════════
# Windows: masaüstü resmini PowerShell (System.Drawing) ile üretme
# ═════════════════════════════════════════════════════════════════════════════

WIN_CIZ = r'''
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$a = Get-Content -Raw -Encoding UTF8 -LiteralPath $args[0] | ConvertFrom-Json
$W = 1920; $H = 1080
$taban = $null
if ($a.taban -and (Test-Path -LiteralPath $a.taban)) { $taban = [System.Drawing.Image]::FromFile($a.taban); if ($taban.Width -ge 1280) { $W = $taban.Width; $H = $taban.Height } }
$s = $H / 1080.0
$bmp = New-Object System.Drawing.Bitmap $W, $H
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = "AntiAlias"; $g.TextRenderingHint = "AntiAliasGridFit"; $g.InterpolationMode = "HighQualityBicubic"
if ($taban) {
  $o = [Math]::Max($W / $taban.Width, $H / $taban.Height); $pw = $taban.Width * $o; $ph = $taban.Height * $o
  $g.DrawImage($taban, [single](($W - $pw) / 2), [single](($H - $ph) / 2), [single]$pw, [single]$ph)
} else {
  $gr = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point 0,0), (New-Object System.Drawing.Point $W,$H), ([System.Drawing.Color]::FromArgb(10,61,145)), ([System.Drawing.Color]::FromArgb(31,122,224))
  $g.FillRectangle($gr, 0, 0, $W, $H)
  $y = $H * 0.36
  $sf = New-Object System.Drawing.StringFormat; $sf.Alignment = "Center"
  if ($a.logo -and (Test-Path -LiteralPath $a.logo)) {
    $l = [System.Drawing.Image]::FromFile($a.logo); $lo = [Math]::Min(300 * $s / $l.Width, 300 * $s / $l.Height)
    $g.DrawImage($l, [single]($W * 0.36 - $l.Width * $lo / 2), [single]($H * 0.22), [single]($l.Width * $lo), [single]($l.Height * $lo)); $y = $H * 0.22 + $l.Height * $lo + 40 * $s
  }
  $f1 = New-Object System.Drawing.Font "Segoe UI Semibold", ([single](110 * $s)), ([System.Drawing.GraphicsUnit]::Pixel)
  $f2 = New-Object System.Drawing.Font "Segoe UI", ([single](40 * $s)), ([System.Drawing.GraphicsUnit]::Pixel)
  $r = New-Object System.Drawing.RectangleF ([single]($W * 0.05)), ([single]$y), ([single]($W * 0.62)), ([single](400 * $s))
  $g.DrawString([string]$a.tahta, $f1, [System.Drawing.Brushes]::White, $r, $sf)
  $r2 = New-Object System.Drawing.RectangleF ([single]($W * 0.05)), ([single]($y + 170 * $s)), ([single]($W * 0.62)), ([single](200 * $s))
  $g.DrawString([string]$a.okul, $f2, [System.Drawing.Brushes]::White, $r2, $sf)
}
$v = $a.veri
$ks = $s * 1.15
$pad = 26 * $ks; $ng = 330 * $ks; $bg = 230 * $ks
$bgh = $v.bgh_goster -and (($v.gunler | Measure-Object).Count -gt 0 -or ($v.haftalar | Measure-Object).Count -gt 0)
$px = { param($b) [single]($b * 1.33 * $ks) }
$fB = New-Object System.Drawing.Font "Segoe UI Semibold", (& $px 12.5), ([System.Drawing.GraphicsUnit]::Pixel)
$fT = New-Object System.Drawing.Font "Segoe UI", (& $px 11.5), ([System.Drawing.GraphicsUnit]::Pixel)
$fY = New-Object System.Drawing.Font "Segoe UI", (& $px 10.5), ([System.Drawing.GraphicsUnit]::Pixel)
$fK = New-Object System.Drawing.Font "Segoe UI Semibold", (& $px 17), ([System.Drawing.GraphicsUnit]::Pixel)
$fG = New-Object System.Drawing.Font "Segoe UI Semibold", (& $px 15), ([System.Drawing.GraphicsUnit]::Pixel)
$aksan = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255,210,122))
$soluk = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(220,204,219,242))
$satir = @()
$satir += ,@($fB, $aksan, ([string]$v.baslik).ToUpper(), 4); $satir += ,@($fT, $soluk, [string]$v.tarih, 16)
if (($v.nobet | Measure-Object).Count -gt 0) { foreach ($n in $v.nobet) { $satir += ,@($fY, $soluk, [string]$n[0], 2); $satir += ,@($fK, [System.Drawing.Brushes]::White, [string]$n[1], 12) } }
else { $t = if ($v.tatil) { [string]$v.tatil } else { "Bugün için nöbet çizelgesi girilmedi" }; $satir += ,@($fT, $soluk, $t, 2) }
$h1 = 0; foreach ($x in $satir) { $h1 += $g.MeasureString($x[2], $x[0], [int]$ng).Height + $x[3] * $ks }
$sag = @()
if ($bgh) {
  $sag += ,@($fB, $aksan, "BELİRLİ GÜN VE HAFTALAR", 14)
  if (($v.gunler | Measure-Object).Count -gt 0) { $sag += ,@($fY, $soluk, "BUGÜN", 3); foreach ($x in $v.gunler) { $sag += ,@($fG, [System.Drawing.Brushes]::White, [string]$x, 8) } }
  if (($v.haftalar | Measure-Object).Count -gt 0) { $sag += ,@($fY, $soluk, "BU HAFTA", 3); foreach ($x in $v.haftalar) { $sag += ,@($fG, [System.Drawing.Brushes]::White, [string]$x, 8) } }
}
$h2 = 0; foreach ($x in $sag) { $h2 += $g.MeasureString($x[2], $x[0], [int]$bg).Height + $x[3] * $ks }
$KG = $pad * 2 + $ng + $(if ($bgh) { 30 * $ks + $bg } else { 0 }); $KH = $pad * 2 + [Math]::Max($h1, $h2)
$kx = $W - $KG - 70 * $s; $ky = [Math]::Max(60 * $s, [Math]::Min($H * 0.14, $H - $KH - 110 * $s))
$yol = New-Object System.Drawing.Drawing2D.GraphicsPath; $r = 36 * $s
$yol.AddArc([single]$kx, [single]$ky, [single]$r, [single]$r, 180, 90); $yol.AddArc([single]($kx + $KG - $r), [single]$ky, [single]$r, [single]$r, 270, 90)
$yol.AddArc([single]($kx + $KG - $r), [single]($ky + $KH - $r), [single]$r, [single]$r, 0, 90); $yol.AddArc([single]$kx, [single]($ky + $KH - $r), [single]$r, [single]$r, 90, 90); $yol.CloseFigure()
$g.FillPath((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(204,8,20,43))), $yol)
$y = $ky + $pad
foreach ($x in $satir) { $rr = New-Object System.Drawing.RectangleF ([single]($kx + $pad)), ([single]$y), ([single]$ng), ([single]1000); $g.DrawString($x[2], $x[0], $x[1], $rr); $y += $g.MeasureString($x[2], $x[0], [int]$ng).Height + $x[3] * $ks }
$y = $ky + $pad; $bx = $kx + $pad + $ng + 30 * $ks
foreach ($x in $sag) { $rr = New-Object System.Drawing.RectangleF ([single]$bx), ([single]$y), ([single]$bg), ([single]1000); $g.DrawString($x[2], $x[0], $x[1], $rr); $y += $g.MeasureString($x[2], $x[0], [int]$bg).Height + $x[3] * $ks }
$g.Dispose()
$bmp.Save($a.cikti + ".tmp", [System.Drawing.Imaging.ImageFormat]::Png)
Move-Item -Force -LiteralPath ($a.cikti + ".tmp") -Destination $a.cikti
'''

WIN_PNG = r'''
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$i = [System.Drawing.Image]::FromFile($args[0])
$o = [Math]::Min(1.0, [Math]::Min(1920.0 / $i.Width, 1080.0 / $i.Height))
$b = New-Object System.Drawing.Bitmap ([int]($i.Width * $o)), ([int]($i.Height * $o))
$g = [System.Drawing.Graphics]::FromImage($b); $g.InterpolationMode = "HighQualityBicubic"
$g.DrawImage($i, 0, 0, $b.Width, $b.Height); $g.Dispose()
$b.Save($args[1], [System.Drawing.Imaging.ImageFormat]::Png)
'''

WIN_SAGLIK = r'''
$ErrorActionPreference = "SilentlyContinue"
$cs = Get-CimInstance Win32_ComputerSystem; $bios = Get-CimInstance Win32_BIOS; $os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1; $vc = Get-CimInstance Win32_VideoController | Select-Object -First 1
$t = $null
try { $z = Get-CimInstance -Namespace root/wmi MSAcpi_ThermalZoneTemperature | Select-Object -First 1; if ($z) { $t = [Math]::Round($z.CurrentTemperature / 10 - 273.15) } } catch {}
$g = $null
if ($args.Count -gt 0 -and $args[0] -eq "guncelleme") { try { $se = (New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher(); $g = $se.Search("IsInstalled=0 and IsHidden=0").Updates.Count } catch {} }
[ordered]@{ marka = $cs.Manufacturer; model = $cs.Model; seri = $bios.SerialNumber; islemci = $cpu.Name;
  bellek_gb = [Math]::Round($cs.TotalPhysicalMemory / 1GB, 1); os = $os.Caption; cekirdek = $os.Version;
  cozunurluk = $(if ($vc.CurrentHorizontalResolution) { "{0}x{1}" -f $vc.CurrentHorizontalResolution, $vc.CurrentVerticalResolution } else { $null });
  sicaklik = $t; guncelleme = $g } | ConvertTo-Json -Compress
'''


# ═════════════════════════════════════════════════════════════════════════════
# Modül
# ═════════════════════════════════════════════════════════════════════════════

class Okul:
    def __init__(self, ajan):
        self.a = ajan
        self.yol = os.path.join(C.VERI, "okul.json")
        self.d = C.json_oku(self.yol, {}) or {}
        self.kilit = threading.Lock()
        self.olay = threading.Event()
        self.serit_proc = None
        self.serit_imza = None
        self.serit_zaman = 0.0
        self.gorsel_proc = None
        self.gorsel_bitis = 0.0
        self.son_ciz_hata = ""
        self.saglik_son = 0.0
        self.guncelleme_onbellek = (0.0, None)

    def kaydet(self):
        try:
            C.json_yaz(self.yol, self.d)
        except Exception as e:
            C.log("Okul durumu kaydedilemedi:", e)

    # ── ayarlar ─────────────────────────────────────────────────────────────
    def ayar(self):
        return (self.a.ayar or {}).get("okul") or {}

    def bugun(self):
        return time.strftime("%Y-%m-%d", self.a.sunucu_saati())

    def kart_verisi(self):
        o = self.ayar()
        g = (o.get("gunluk") or {}).get(self.bugun()) or {}
        return {"baslik": o.get("baslik") or "Bugünün Nöbetçileri", "tarih": tarih_yazi(self.bugun()),
                "nobet": g.get("nobet") or [], "tatil": g.get("tatil"), "gunler": g.get("gunler") or [],
                "haftalar": g.get("haftalar") or [], "bgh_goster": bool(o.get("bgh_goster", True))}

    def mod(self):
        return self.ayar().get("mod") or "kapali"

    def arkaplan_imza(self):
        """Masaüstü resmine çizilen içerik (değişince resim yeniden üretilir); çizim kapalıysa ''."""
        if self.mod() not in ("arka_plan", "ikisi"):
            return ""
        o = self.ayar()
        veri = self.kart_verisi()
        m = json.dumps([veri, (o.get("logo") or {}).get("sha"), self.a.ayar.get("ad"), self.a.ayar.get("okul_adi")],
                       sort_keys=True, ensure_ascii=False)
        return hashlib.sha1(m.encode("utf-8")).hexdigest()[:16]

    def depo_dosyasi(self, sha, ad=""):
        if not sha:
            return None
        try:
            yol = self.a.modul("depo").indir(sha)
        except Exception as e:
            C.log("Depodan alınamadı:", sha[:12], e)
            return None
        uz = os.path.splitext(ad or "")[1].lower()
        if uz not in (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".svg"):
            return yol
        hedef = yol + uz
        if not os.path.exists(hedef):
            try:
                os.link(yol, hedef)
            except OSError:
                shutil.copy(yol, hedef)
        return hedef

    # ── masaüstü resmine çizim (oturum modülü çağırır) ─────────────────────
    def arkaplan_birlestir(self, taban, klasor):
        """taban resmin (ya da okul tasarımının) üstüne bugünkü nöbet kartını çizer → yeni resim yolu.
        Çizim kapalıysa ya da başarısızsa taban döner."""
        if not self.arkaplan_imza():
            return taban
        o = self.ayar()
        logo = self.depo_dosyasi((o.get("logo") or {}).get("sha"), (o.get("logo") or {}).get("dosya"))
        imza = self.arkaplan_imza()
        cikti = os.path.join(klasor, "nobet-{}-{}.png".format(imza, hashlib.sha1((taban or "-").encode()).hexdigest()[:6]))
        if os.path.exists(cikti):
            return cikti
        arg = {"taban": taban, "cikti": cikti, "veri": self.kart_verisi(), "logo": logo,
               "tahta": self.a.ayar.get("ad") or "", "okul": self.a.ayar.get("okul_adi") or ""}
        try:
            if C.WINDOWS:
                self.win_ciz(arg)
            else:
                py = gi_python()
                if not py:
                    raise RuntimeError("çizim bileşeni (python3-gi, cairo) yok")
                r = subprocess.run([py, os.path.abspath(__file__), "--ciz", json.dumps(arg, ensure_ascii=False)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
                if r.returncode != 0 or not os.path.exists(cikti):
                    raise RuntimeError((r.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-1:] or "çizilemedi")
            os.chmod(cikti, 0o644)
            self.son_ciz_hata = ""
            for eski in os.listdir(klasor):
                if eski.startswith("nobet-") and eski != os.path.basename(cikti):
                    try:
                        os.remove(os.path.join(klasor, eski))
                    except OSError:
                        pass
            return cikti
        except Exception as e:
            self.son_ciz_hata = str(e)[:200]
            C.log("Nöbet resmi çizilemedi:", e)
            return taban

    def win_ciz(self, arg):
        import tempfile
        fd, j = tempfile.mkstemp(suffix=".json", dir=C.VERI)
        os.close(fd)
        try:
            with open(j, "w", encoding="utf-8-sig") as f:
                json.dump(arg, f, ensure_ascii=False)
            betik = os.path.join(C.VERI, "nobet-ciz.ps1")
            with open(betik, "w", encoding="utf-8-sig") as f:
                f.write(WIN_CIZ)
            r = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", betik, j],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180, creationflags=C.CREATE_NO_WINDOW)
            if r.returncode != 0 or not os.path.exists(arg["cikti"]):
                raise RuntimeError((r.stderr or b"").decode("utf-8", "replace").strip()[-200:] or "çizilemedi")
        finally:
            try:
                os.remove(j)
            except OSError:
                pass

    # ── giriş ekranı notu ──────────────────────────────────────────────────
    def giris_notu_yolu(self):
        n = self.ayar().get("giris_notu") or {}
        return NOT_DOSYA if (n.get("etkin") and not C.WINDOWS and C.ROOT) else None

    def giris_notu_metni(self):
        n = self.ayar().get("giris_notu") or {}
        if n.get("kaynak") == "metin":
            return (n.get("metin") or "").strip()
        v = self.kart_verisi()
        satirlar = ["{} — {}".format(v["baslik"], v["tarih"])]
        if v["nobet"]:
            satirlar += ["{}: {}".format(y, k) for y, k in v["nobet"]]
        else:
            satirlar.append(v["tatil"] or "Bugün için nöbet çizelgesi girilmedi")
        if v["bgh_goster"]:
            if v["gunler"]:
                satirlar += ["", "Bugün: " + ", ".join(v["gunler"])]
            if v["haftalar"]:
                satirlar += ["" if not v["gunler"] else "", "Bu hafta: " + ", ".join(v["haftalar"])]
        return "\n".join(satirlar).replace("\n\n\n", "\n\n")

    def giris_notu_yaz(self):
        yol = self.giris_notu_yolu()
        etkin = bool(yol)
        if etkin:
            metin = self.giris_notu_metni()
            os.makedirs(os.path.dirname(yol), exist_ok=True)
            eski = None
            try:
                eski = open(yol, encoding="utf-8").read()
            except OSError:
                pass
            if eski != metin:
                with open(yol + ".tmp", "w", encoding="utf-8") as f:
                    f.write(metin)
                os.chmod(yol + ".tmp", 0o644)
                os.replace(yol + ".tmp", yol)
        if self.d.get("not_etkin") != etkin:
            self.d["not_etkin"] = etkin
            self.kaydet()
            ot = self.a.modul("oturum")
            if ot and hasattr(ot, "greeter_yaz"):
                ot.greeter_yaz()

    # ── kenar şeridi ───────────────────────────────────────────────────────
    def serit_yonet(self):
        istenen = self.mod() in ("serit", "ikisi")
        o = C.oturum_bul() if istenen else None
        if not istenen or not o or not self.a.gtk:
            self.serit_durdur()
            return
        arg = {"veri": self.kart_verisi(), "ayar": self.ayar().get("serit") or {}}
        imza = hashlib.sha1(json.dumps([arg, o.get("kullanici")], sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        calisiyor = self.serit_proc is not None and self.serit_proc.poll() is None
        if calisiyor and imza == self.serit_imza:
            return
        if not calisiyor and time.time() - self.serit_zaman < 20:
            return                                   # çok sık yeniden açmayı önle
        self.serit_durdur()
        self.serit_zaman = time.time()
        self.serit_proc = self.a.ui("okul_serit", arg, o)
        self.serit_imza = imza if self.serit_proc is not None else None

    def serit_durdur(self):
        if self.serit_proc is not None:
            C.proc_durdur(self.serit_proc)
        self.serit_proc, self.serit_imza = None, None

    # ── açılış görseli ─────────────────────────────────────────────────────
    def acilis_kontrol(self):
        if self.gorsel_proc is not None and self.gorsel_proc.poll() is None:
            if time.time() < self.gorsel_bitis + 30:
                return
            C.proc_durdur(self.gorsel_proc)
        self.gorsel_proc = None
        bugun = self.bugun()
        saat = time.strftime("%H:%M", self.a.sunucu_saati())
        gosterilen = self.d.setdefault("gosterilen", {})
        for k in [k for k in gosterilen if not k.endswith(bugun)]:
            gosterilen.pop(k, None)
        for g in self.ayar().get("acilis") or []:
            if not (g.get("bas", "") <= bugun <= g.get("bit", "")):
                continue
            anahtar = "{}:{}".format(g.get("id"), bugun)
            if anahtar in gosterilen:
                continue
            if g.get("saat") and saat < g["saat"]:
                continue
            if self.a.kilitli or self.a.tam_ekran or getattr(self.a, "acil_id", None):
                return
            o = C.oturum_bul()
            if not o or not self.a.gtk:
                return
            yol = self.depo_dosyasi(g.get("sha"), g.get("dosya"))
            if not yol:
                return
            if C.WINDOWS:
                yol = self.win_png(yol, g.get("sha"))
            arg = {"yol": yol, "sure": int(g.get("sure") or 30), "kapatilabilir": bool(g.get("kapatilabilir", True)),
                   "ad": g.get("ad") or ""}
            p = self.a.ui("okul_gorsel", arg, o)
            if p is None:
                return
            self.gorsel_proc, self.gorsel_bitis = p, time.time() + arg["sure"]
            gosterilen[anahtar] = time.time()
            self.kaydet()
            C.log("Açılış görseli gösterildi:", g.get("ad"))
            self.a.olay_gonder("sistem", "Açılış görseli gösterildi: {}".format(g.get("ad") or ""))
            return

    def win_png(self, yol, sha):
        klasor = os.path.join(C.PAYLASIM, "gorsel")
        os.makedirs(klasor, exist_ok=True)
        hedef = os.path.join(klasor, (sha or "x")[:16] + ".png")
        if not os.path.exists(hedef):
            betik = os.path.join(C.VERI, "png.ps1")
            with open(betik, "w", encoding="utf-8-sig") as f:
                f.write(WIN_PNG)
            subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", betik, yol, hedef],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120, creationflags=C.CREATE_NO_WINDOW)
        return hedef if os.path.exists(hedef) else yol

    # ── döngüler ───────────────────────────────────────────────────────────
    def donguler(self):
        return [self.dongu, self.saglik_dongu]

    def ayar_degisti(self):
        self.olay.set()

    def dongu(self):
        time.sleep(8)
        while True:
            for adim in (self.giris_notu_yaz, self.serit_yonet, self.acilis_kontrol, self.cop_temizle):
                try:
                    adim()
                except Exception as e:
                    C.log("Okul modülü:", adim.__name__, e)
            ot = self.a.modul("oturum")
            if ot and hasattr(ot, "arkaplan_kontrol"):
                try:
                    ot.arkaplan_kontrol()
                except Exception as e:
                    C.log("Arka plan kontrolü:", e)
            self.olay.wait(15)
            self.olay.clear()

    def durum(self):
        return {"okul": {"serit": self.serit_proc is not None and self.serit_proc.poll() is None,
                         "ciz_hata": self.son_ciz_hata or None}}

    # ── tahta sağlığı ──────────────────────────────────────────────────────
    def saglik_dongu(self):
        time.sleep(40)
        while True:
            try:
                self.saglik_gonder()
            except Exception as e:
                C.log("Sağlık bilgisi gönderilemedi:", e)
            time.sleep(1800)

    def saglik_gonder(self):
        v = self.saglik_topla()
        self.a.istek("/api/a/saglik", {"id": self.a.id, "veri": v}, zaman=30)
        self.saglik_son = time.time()
        return v

    def saglik_topla(self):
        v = {"ram": C.bellek_yuzde() if not C.WINDOWS else None, "disk": None, "sicaklik": None,
             "calisma_sn": C.calisma_suresi() if not C.WINDOWS else None, "os": C.os_adi(), "zaman": time.time()}
        try:
            kok = os.environ.get("SystemDrive", "C:") + "\\" if C.WINDOWS else "/"
            du = shutil.disk_usage(kok)
            v["disk"] = round(100.0 * du.used / du.total, 1)
            v["disk_bos_gb"] = round(du.free / 1024 ** 3, 1)
            v["disk_toplam_gb"] = round(du.total / 1024 ** 3, 1)
        except Exception:
            pass
        if C.WINDOWS:
            try:
                v["ram"] = C.win_bellek()
                v["calisma_sn"] = C.win_calisma()
            except Exception:
                pass
            yeni = time.time() - self.guncelleme_onbellek[0] > 6 * 3600
            try:
                betik = os.path.join(C.VERI, "saglik.ps1")
                with open(betik, "w", encoding="utf-8-sig") as f:
                    f.write(WIN_SAGLIK)
                r = subprocess.run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", betik]
                                   + (["guncelleme"] if yeni else []), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   timeout=240, creationflags=C.CREATE_NO_WINDOW)
                w = json.loads((r.stdout or b"{}").decode("utf-8", "replace") or "{}")
                for k, x in w.items():
                    if x not in (None, ""):
                        v[k] = x
                if yeni and w.get("guncelleme") is not None:
                    self.guncelleme_onbellek = (time.time(), w["guncelleme"])
                elif self.guncelleme_onbellek[1] is not None:
                    v["guncelleme"] = self.guncelleme_onbellek[1]
            except Exception as e:
                C.log("Windows sağlık bilgisi:", e)
            return v
        v["sicaklik"] = C.sicaklik()
        oku = lambda y: (C.dosya_oku(y) or "").strip()
        dmi = "/sys/class/dmi/id/"
        v["marka"] = oku(dmi + "sys_vendor") or oku(dmi + "board_vendor") or None
        v["model"] = oku(dmi + "product_name") or oku(dmi + "board_name") or None
        seri = oku(dmi + "product_serial") or oku(dmi + "board_serial")
        v["seri"] = seri if seri and seri.lower() not in ("to be filled by o.e.m.", "default string", "none", "0") else None
        try:
            for s in open("/proc/cpuinfo", encoding="utf-8", errors="replace"):
                if s.startswith("model name"):
                    v["islemci"] = re.sub(r"\s+", " ", s.split(":", 1)[1]).strip()
                    break
            for s in open("/proc/meminfo"):
                if s.startswith("MemTotal:"):
                    v["bellek_gb"] = round(int(s.split()[1]) / 1024 / 1024, 1)
                    break
        except OSError:
            pass
        try:
            v["cekirdek"] = os.uname().release
        except Exception:
            pass
        try:
            import glob
            for d in sorted(glob.glob("/sys/class/drm/card*-*")):
                if oku(os.path.join(d, "status")) == "connected":
                    m = oku(os.path.join(d, "modes")).splitlines()
                    if m:
                        v["cozunurluk"] = m[0]
                        break
            listeler = glob.glob("/var/lib/apt/lists/*_Packages") or glob.glob("/var/lib/apt/lists/*Packages*")
            if listeler:
                v["paket_listesi"] = max(os.path.getmtime(p) for p in listeler)
        except Exception:
            pass
        if time.time() - self.guncelleme_onbellek[0] > 6 * 3600 and shutil.which("apt-get") and C.ROOT:
            try:
                r = subprocess.run(["apt-get", "-s", "-o", "Debug::NoLocking=1", "upgrade"], stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, timeout=180, env=dict(os.environ, LC_ALL="C"))
                self.guncelleme_onbellek = (time.time(), sum(1 for s in (r.stdout or b"").decode().splitlines() if s.startswith("Inst ")))
            except Exception:
                pass
        if self.guncelleme_onbellek[1] is not None:
            v["guncelleme"] = self.guncelleme_onbellek[1]
        return v

    # ── komutlar ───────────────────────────────────────────────────────────
    def komut(self, tur, v, kaynak):
        if tur == "saglik":
            self.saglik_gonder()
            return {"mesaj": "Sağlık bilgisi gönderildi"}
        if tur == "sifre_degistir":
            return self.sifre_degistir(v)
        if tur == "donem_onizle":
            return self.donem_onizle(v)
        if tur == "donem_temizle":
            return self.donem_temizle(v)
        if tur == "donem_geri_al":
            return self.donem_geri_al()
        return None

    # ── yönetici şifresini değiştirme ──────────────────────────────────────
    def sifre_degistir(self, v):
        kullanici = str(v.get("kullanici") or "")
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_.\-]{0,31}$", kullanici):
            raise RuntimeError("Kullanıcı adı geçersiz")
        if C.WINDOWS:
            sifre = self.sifre_coz(v.get("windows") or {})
            betik = ("$p = [Console]::In.ReadLine(); $s = ConvertTo-SecureString $p -AsPlainText -Force; "
                     "Set-LocalUser -Name '{}' -Password $s".format(kullanici.replace("'", "")))
            if not C.ROOT:
                return {"mesaj": "Test: {} şifresi değişecekti".format(kullanici)}
            r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", betik], input=(sifre + "\n").encode("utf-8"),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, creationflags=C.CREATE_NO_WINDOW)
            if r.returncode != 0:
                hata = (r.stderr or b"").decode("utf-8", "replace").strip().splitlines()
                raise RuntimeError("Şifre değiştirilemedi: " + (hata[0][:200] if hata else "bilinmeyen hata")
                                   + (" (bu kullanıcı yok)" if b"not found" in (r.stderr or b"").lower() or b"bulunamad" in (r.stderr or b"").lower() else ""))
            return {"mesaj": "{} şifresi değiştirildi".format(kullanici)}
        ozet = str(v.get("linux") or "")
        if not ozet.startswith("$6$"):
            raise RuntimeError("Şifre özeti geçersiz")
        import pwd
        if C.ROOT:
            try:
                pwd.getpwnam(kullanici)
            except KeyError:
                raise RuntimeError("Bu tahtada '{}' kullanıcısı yok".format(kullanici))
            r = subprocess.run(["usermod", "-p", ozet, kullanici], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            if r.returncode != 0:
                raise RuntimeError("Şifre değiştirilemedi: " + (r.stderr or b"").decode("utf-8", "replace").strip()[:200])
        else:
            with open(os.path.join(C.VERI, "test-sifre-{}.txt".format(kullanici)), "w") as f:
                f.write(ozet)
        C.log("Yönetici şifresi değiştirildi:", kullanici)
        return {"mesaj": "{} şifresi değiştirildi".format(kullanici)}

    def sifre_coz(self, p):
        import base64
        import hmac as _hmac
        nonce = base64.b64decode(p.get("n") or "")
        sifreli = base64.b64decode(p.get("s") or "")
        k = _hmac.new(self.a.anahtar.encode(), b"tys-sifre" + nonce, hashlib.sha256).digest()
        akis = bytearray()
        i = 0
        while len(akis) < len(sifreli):
            akis += _hmac.new(k, nonce + i.to_bytes(8, "big"), hashlib.sha256).digest()
            i += 1
        duz = bytes(a ^ b for a, b in zip(sifreli, akis))
        if not _hmac.compare_digest(_hmac.new(k, duz, hashlib.sha256).hexdigest()[:16], p.get("m") or ""):
            raise RuntimeError("Şifre paketi doğrulanamadı")
        return duz.decode("utf-8")

    # ── yeni dönem temizliği ───────────────────────────────────────────────
    def ev_koku(self):
        return "/home" if C.ROOT and not C.WINDOWS else os.path.join(C.VERI, "ev")

    def cop_koku(self):
        if C.WINDOWS:
            return os.path.join(C.WIN_PROGRAMDATA, "TahtaYonetim", "donem-cop") if C.ROOT else os.path.join(C.VERI, "donem-cop")
        return os.path.join(self.ev_koku(), ".tahta-donem-cop")

    WIN_KLASORLER = ("Desktop", "Downloads", "Documents", "Pictures", "Videos", "Music")

    def kullanici_bilgisi(self, ad):
        """→ {"ad", "ev", "uid", "gid", "yonetici"} ya da None"""
        if C.WINDOWS:
            ev = os.path.join(os.path.dirname(C.WIN_ORTAK_PROFIL), ad) if C.ROOT else os.path.join(C.VERI, "Kullanicilar", ad)
            return {"ad": ad, "ev": ev, "uid": None, "gid": None, "yonetici": False} if os.path.isdir(ev) else None
        if not C.ROOT:
            ev = os.path.join(self.ev_koku(), ad)
            return {"ad": ad, "ev": ev, "uid": os.getuid(), "gid": os.getgid(), "yonetici": ad == "etapadmin"} if os.path.isdir(ev) else None
        import pwd
        import grp
        try:
            p = pwd.getpwnam(ad)
        except KeyError:
            return None
        if p.pw_uid < 1000 or not p.pw_dir.startswith("/home/") or not os.path.isdir(p.pw_dir):
            return None
        yon = False
        for g in ("sudo", "admin", "wheel"):
            try:
                if ad in grp.getgrnam(g).gr_mem:
                    yon = True
            except KeyError:
                pass
        return {"ad": ad, "ev": p.pw_dir, "uid": p.pw_uid, "gid": p.pw_gid, "yonetici": yon}

    def oturum_acik_kullanicilar(self):
        if C.WINDOWS or not C.ROOT:
            o = C.oturum_bul()
            return {o["kullanici"]} if o else set()
        r = subprocess.run(["loginctl", "list-users", "--no-legend"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15)
        return {s.split()[1] for s in (r.stdout or b"").decode().splitlines() if len(s.split()) > 1}

    def temizlenecekler(self, k):
        if C.WINDOWS:
            return [os.path.join(k["ev"], x) for x in self.WIN_KLASORLER if os.path.isdir(os.path.join(k["ev"], x))]
        return [k["ev"]]

    @staticmethod
    def klasor_boyutu(yol, sinir=60.0):
        bas, top, adet = time.time(), 0, 0
        for kok, dizinler, dosyalar in os.walk(yol):
            for f in dosyalar:
                try:
                    top += os.lstat(os.path.join(kok, f)).st_size
                    adet += 1
                except OSError:
                    pass
            if time.time() - bas > sinir:
                break
        return top, adet

    def donem_onizle(self, v):
        acik = self.oturum_acik_kullanicilar()
        sonuc = []
        for ad in v.get("kullanicilar") or []:
            k = self.kullanici_bilgisi(ad)
            if not k:
                sonuc.append({"ad": ad, "var": False})
                continue
            top, adet = 0, 0
            for y in self.temizlenecekler(k):
                if C.WINDOWS:
                    b, a = self.klasor_boyutu(y)
                else:
                    b, a = 0, 0
                    for x in os.listdir(y):
                        bb, aa = self.klasor_boyutu(os.path.join(y, x)) if os.path.isdir(os.path.join(y, x)) and not os.path.islink(os.path.join(y, x)) else ((os.lstat(os.path.join(y, x)).st_size, 1))
                        b, a = b + bb, a + aa
                top, adet = top + b, adet + a
            sonuc.append({"ad": ad, "var": True, "boyut": top, "dosya": adet, "oturum": ad in acik, "yonetici": k["yonetici"]})
        bos = shutil.disk_usage(self.ev_koku() if os.path.isdir(self.ev_koku()) else C.VERI).free
        return {"mesaj": "{} kullanıcı incelendi".format(len(sonuc)), "veri": {"kullanicilar": sonuc, "bos": bos,
                "windows": bool(C.WINDOWS)}}

    def donem_temizle(self, v):
        acik = self.oturum_acik_kullanicilar()
        damga = time.strftime("%Y%m%d-%H%M%S")
        cop = os.path.join(self.cop_koku(), damga)
        os.makedirs(cop, exist_ok=True)
        os.chmod(self.cop_koku(), 0o700)
        yapilan, hatalar = [], []
        for ad in v.get("kullanicilar") or []:
            k = self.kullanici_bilgisi(ad)
            if not k:
                hatalar.append("{}: bu tahtada yok".format(ad))
                continue
            try:
                if ad in acik:
                    self.oturumu_kapat(ad)
                hedef = os.path.join(cop, ad)
                os.makedirs(hedef, exist_ok=True)
                if C.WINDOWS:
                    for y in self.temizlenecekler(k):
                        h = os.path.join(hedef, os.path.basename(y))
                        os.makedirs(h, exist_ok=True)
                        for x in os.listdir(y):
                            if x.lower() == "desktop.ini":
                                continue
                            shutil.move(os.path.join(y, x), os.path.join(h, x))
                else:
                    for x in os.listdir(k["ev"]):
                        shutil.move(os.path.join(k["ev"], x), os.path.join(hedef, x))
                    self.iskelet_kopyala(k)
                yapilan.append(ad)
            except Exception as e:
                hatalar.append("{}: {}".format(ad, str(e)[:160]))
        kayit = self.d.setdefault("donem_cop", [])
        kayit.append({"damga": damga, "zaman": time.time(), "kullanicilar": yapilan})
        self.kaydet()
        self.a.olay_gonder("sistem", "Yeni dönem temizliği: {}".format(", ".join(yapilan) or "-"))
        if not yapilan:
            raise RuntimeError("; ".join(hatalar) or "Temizlenecek kullanıcı yok")
        m = "Temizlendi: {} · {} gün içinde geri alınabilir".format(", ".join(yapilan), COP_GUN)
        if hatalar:
            m += " · Atlananlar: " + "; ".join(hatalar)
        return {"mesaj": m, "veri": {"temizlenen": yapilan, "hatalar": hatalar}}

    def oturumu_kapat(self, ad):
        if C.WINDOWS:
            o = C.oturum_bul()
            if o and (o.get("kullanici") or "").lower() == ad.lower() and o.get("oturum_id") is not None and C.ROOT:
                C.win_gizli(["logoff", str(o["oturum_id"])], 30)
                time.sleep(5)
            return
        if C.ROOT:
            subprocess.run(["loginctl", "terminate-user", ad], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
            for _ in range(20):
                if ad not in self.oturum_acik_kullanicilar():
                    break
                time.sleep(1)

    def iskelet_kopyala(self, k):
        """Ev klasörünü ilk günkü haline getirir: /etc/skel içeriği."""
        skel = "/etc/skel" if C.ROOT else os.path.join(C.VERI, "skel")
        if os.path.isdir(skel):
            for x in os.listdir(skel):
                kaynak, hedef = os.path.join(skel, x), os.path.join(k["ev"], x)
                if os.path.isdir(kaynak) and not os.path.islink(kaynak):
                    shutil.copytree(kaynak, hedef, symlinks=True)
                else:
                    shutil.copy2(kaynak, hedef, follow_symlinks=False)
        if C.ROOT:
            for kok, dizinler, dosyalar in os.walk(k["ev"]):
                for x in [kok] + [os.path.join(kok, d) for d in dizinler] + [os.path.join(kok, f) for f in dosyalar]:
                    try:
                        os.lchown(x, k["uid"], k["gid"])
                    except OSError:
                        pass

    def donem_geri_al(self):
        kayit = [c for c in self.d.get("donem_cop") or [] if time.time() - c.get("zaman", 0) < COP_GUN * 86400
                 and os.path.isdir(os.path.join(self.cop_koku(), c["damga"]))]
        if not kayit:
            raise RuntimeError("Geri alınacak temizlik yok (son {} gün içinde)".format(COP_GUN))
        c = kayit[-1]
        cop = os.path.join(self.cop_koku(), c["damga"])
        acik = self.oturum_acik_kullanicilar()
        geri = []
        for ad in c.get("kullanicilar") or []:
            k = self.kullanici_bilgisi(ad)
            kaynak = os.path.join(cop, ad)
            if not k or not os.path.isdir(kaynak):
                continue
            if ad in acik:
                self.oturumu_kapat(ad)
            if C.WINDOWS:
                for klasor in os.listdir(kaynak):
                    hedef_k = os.path.join(k["ev"], klasor)
                    os.makedirs(hedef_k, exist_ok=True)
                    for x in os.listdir(os.path.join(kaynak, klasor)):
                        self.tasi_cakisma(os.path.join(kaynak, klasor, x), os.path.join(hedef_k, x))
            else:
                for x in os.listdir(kaynak):
                    self.tasi_cakisma(os.path.join(kaynak, x), os.path.join(k["ev"], x))
            geri.append(ad)
        shutil.rmtree(cop, ignore_errors=True)
        self.d["donem_cop"] = [x for x in self.d.get("donem_cop") or [] if x["damga"] != c["damga"]]
        self.kaydet()
        self.a.olay_gonder("sistem", "Yeni dönem temizliği geri alındı: {}".format(", ".join(geri) or "-"))
        return {"mesaj": "Geri alındı: {}".format(", ".join(geri) or "-")}

    @staticmethod
    def tasi_cakisma(kaynak, hedef):
        """Geri alırken: temizlikten sonra oluşan aynı adlı öğe '(temizlik sonrası)' adıyla kenara alınır."""
        if os.path.lexists(hedef):
            if os.path.isdir(hedef) and not os.path.islink(hedef) and os.path.isdir(kaynak) and not os.path.islink(kaynak):
                for x in os.listdir(kaynak):
                    Okul.tasi_cakisma(os.path.join(kaynak, x), os.path.join(hedef, x))
                shutil.rmtree(kaynak, ignore_errors=True)
                return
            kok, uz = os.path.splitext(hedef)
            yeni = "{} (temizlik sonrası){}".format(kok, uz)
            i = 2
            while os.path.lexists(yeni):
                yeni = "{} (temizlik sonrası {}){}".format(kok, i, uz)
                i += 1
            shutil.move(hedef, yeni)
        shutil.move(kaynak, hedef)

    def cop_temizle(self):
        """7 günden eski temizlik yedeklerini siler."""
        kok = self.cop_koku()
        if not os.path.isdir(kok):
            return
        sinir = time.time() - COP_GUN * 86400
        degisti = False
        for c in list(self.d.get("donem_cop") or []):
            if c.get("zaman", 0) < sinir:
                shutil.rmtree(os.path.join(kok, c["damga"]), ignore_errors=True)
                self.d["donem_cop"].remove(c)
                degisti = True
        for x in os.listdir(kok):
            y = os.path.join(kok, x)
            try:
                if os.path.getmtime(y) < sinir - 86400 and not any(c["damga"] == x for c in self.d.get("donem_cop") or []):
                    shutil.rmtree(y, ignore_errors=True)
            except OSError:
                pass
        if degisti:
            self.kaydet()


def baslat(ajan):
    return Okul(ajan)


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--ciz":
        sys.exit(arkaplan_ciz(json.loads(sys.argv[2])) or 0)
