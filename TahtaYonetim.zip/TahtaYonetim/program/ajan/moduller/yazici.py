# -*- coding: utf-8 -*-
"""Yazıcı Merkezi: USB yazıcı algılama, uzaktan kurulum, varsayılan yapma, test sayfası, kilit.

Pardus/ETAP: CUPS (önce sürücüsüz IPP, sonra CUPS'un kendi eşleştirdiği sürücü, gerekirse Pardus deposundan
sürücü paketi, depoya yüklenmiş .deb / .ppd). Windows: depoya yüklenmiş INF paketi ya da sessiz kurulum
programı, Windows'un kendi sürücüleri. Tüm kurulumlar politika olarak gelir: kapalı tahta açılınca, yazıcısı
takılı olmayan tahta yazıcı takılınca tamamlar; geri alınınca kuyruk kaldırılır.
"""
SURUM = "4.3"
C = None

import os
import re
import glob
import json
import time
import shutil
import zipfile
import threading
import subprocess
from urllib.parse import unquote

TEST_SAYFASI = "/usr/share/cups/data/testprint"
POLKIT_KURAL = "/etc/polkit-1/rules.d/49-tahta-yonetim-yazici.rules"
POLKIT_PKLA = "/etc/polkit-1/localauthority/50-local.d/49-tahta-yonetim-yazici.pkla"
# Markaya göre Pardus/Debian deposundaki açık kaynak sürücü paketleri
MARKA_PAKET = {
    "hp": ["hplip", "printer-driver-hpcups", "printer-driver-foo2zjs"],
    "hewlett": ["hplip", "printer-driver-hpcups", "printer-driver-foo2zjs"],
    "samsung": ["printer-driver-splix", "printer-driver-foo2zjs"],
    "xerox": ["printer-driver-splix", "printer-driver-foo2zjs"],
    "dell": ["printer-driver-splix"],
    "brother": ["printer-driver-brlaser", "printer-driver-ptouch"],
    "epson": ["printer-driver-escpr", "printer-driver-gutenprint"],
    "canon": ["printer-driver-gutenprint"],
    "kyocera": ["printer-driver-gutenprint"],
    "lexmark": ["printer-driver-gutenprint"],
    "oki": ["printer-driver-oki", "printer-driver-gutenprint"],
    "ricoh": ["printer-driver-gutenprint"],
    "konica": ["printer-driver-foo2zjs"],
    "minolta": ["printer-driver-foo2zjs"],
}
# Modele göre açık kaynak sürücüler (sürücüsü Windows'a özel "host-based" yazıcılar)
MODEL_PAKET = [
    (r"laserjet\s*(p?10\d\d|p1[0-6]\d\d|m1[0-2]\d\d|pro\s*p1)", ["printer-driver-foo2zjs", "hplip"]),
    (r"(clp|clx|ml|scx|sl-m|sl-c)-?\d", ["printer-driver-splix", "printer-driver-foo2zjs"]),
    (r"(phaser|workcentre)\s*\d", ["printer-driver-splix"]),
    (r"(magicolor|minolta)", ["printer-driver-foo2zjs"]),
]
# Canon: eski "CAPT" modelleri açık kaynak captdriver ile çalışır; diğer LBP / MF / i-SENSYS modelleri Canon'un
# UFR II / UFR II LT Linux sürücüsünü ister (Pardus deposunda yoktur; Canon'un sitesinden .deb indirilip depoya yüklenir).
CANON_CAPT = re.compile(r"lbp\s*-?\s*(810|1120|1210|2900|3000|3010|3018|3050|3100|3108|3150|3200|3210|3250|3300|3310|3500|"
                        r"5000|5050|5100|5300|6000|6018|6020|6200|7010|7018|7200|9100)(?!\d)", re.I)
CANON_UFR = re.compile(r"(lbp|mf\s*\d|i-?sensys|imageclass|imagerunner|\bir\s*\d)", re.I)


def canon_turu(marka, model):
    """'capt' | 'ufr' | None"""
    if "canon" not in (marka or "").lower() and "canon" not in (model or "").lower():
        return None
    if CANON_CAPT.search(model or ""):
        return "capt"
    if CANON_UFR.search(model or ""):
        return "ufr"
    return None


# HP'nin "host-based" LaserJet'leri (1000, 1005, 1018, 1020, P1005, P1006 …) kendi belleğinde yazılım tutmaz:
# her açılışta bilgisayarın yazıcıya firmware göndermesi gerekir. Gönderilmezse kurulumdan sonra deneme sayfası
# basılır ama yazıcı kapatılıp açılınca bir daha basmaz.
HP_FIRMWARE = {"1000": ["sihp1000"], "1005": ["sihp1005"], "1018": ["sihp1018"], "1020": ["sihp1020", "sihp1018"],
               "P1005": ["sihpP1005"], "P1006": ["sihpP1006", "sihpP1005"], "P1007": ["sihpP1005"], "P1008": ["sihpP1006"],
               "P1505": ["sihpP1505"]}
FIRMWARE_DIZIN = "/var/lib/tahta-yonetim/firmware"
FIRMWARE_BETIK = "/usr/local/lib/tahta-yonetim/hp-firmware"
FIRMWARE_UDEV = "/etc/udev/rules.d/90-tahta-hp-firmware.rules"
FIRMWARE_BETIK_METIN = r'''#!/bin/sh
# Tahta Yönetim Asistanı — HP host-based LaserJet'e her açılışta firmware gönderir.
DEV="$1"
[ -c "$DEV" ] || exit 0
SYS=$(udevadm info -q path -n "$DEV" 2>/dev/null)
ID=$(cat "/sys$SYS/device/ieee1284_id" 2>/dev/null)
case "$ID" in *FWVER*) exit 0 ;; esac          # firmware zaten yüklü
MODEL=$(udevadm info -q property -n "$DEV" 2>/dev/null | sed -n 's/^ID_MODEL=//p')
[ -n "$MODEL" ] || MODEL=$(echo "$ID" | sed -n 's/.*MDL:\([^;]*\).*/\1/p')
NO=$(echo "$MODEL" | tr 'a-z' 'A-Z' | grep -oE 'P?1[0-9]{3}' | head -1)
[ -n "$NO" ] || exit 0
for AD in $(sed -n "s/^$NO //p" __DIZIN__/eslesme); do
  if [ -f "__DIZIN__/$AD.dl" ]; then
    cat "__DIZIN__/$AD.dl" > "$DEV" && logger -t tahta-yonetim "HP LaserJet $NO: firmware gönderildi ($AD)"
    exit 0
  fi
done
logger -t tahta-yonetim "HP LaserJet $NO: firmware dosyası yok; panelde Yazıcı Merkezi'ne yükleyin"
'''


def hp_firmware_model(model):
    """'HP LaserJet 1020' → '1020'; firmware istemeyen modellerde None."""
    m = re.search(r"(?<![\d])(P?1\d{3})(?![\d])", (model or "").upper())
    if m and m.group(1) in HP_FIRMWARE and re.search(r"laserjet|hp", (model or ""), re.I):
        return m.group(1)
    return None


def calistir(args, zaman=120, env=None):
    """(çıkış kodu, çıktı) — hiç hata fırlatmaz."""
    try:
        e = dict(os.environ, LC_ALL="C", LANG="C", DEBIAN_FRONTEND="noninteractive")
        if env:
            e.update(env)
        r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                           timeout=zaman, env=e)
        return r.returncode, (r.stdout or b"").decode("utf-8", "replace")
    except FileNotFoundError:
        return 127, "{} bulunamadı".format(args[0])
    except subprocess.TimeoutExpired:
        return 124, "{} zaman aşımı".format(args[0])


def ieee1284(metin):
    """'MFG:HP;MDL:LaserJet P1102;CMD:...' → sözlük (anahtarlar büyük harf)."""
    d = {}
    for p in (metin or "").split(";"):
        if ":" in p:
            k, v = p.split(":", 1)
            d[k.strip().upper()] = v.strip()
    return {"marka": d.get("MFG") or d.get("MANUFACTURER") or "", "model": d.get("MDL") or d.get("MODEL") or "",
            "komut": d.get("CMD") or d.get("COMMAND SET") or ""}


def kuyruk_adi(model):
    model = (model or "").translate(str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU"))
    ad = re.sub(r"[^A-Za-z0-9_\-]+", "_", model or "Yazici").strip("_")[:60]
    return ad or "Yazici"


def kelimeler(metin):
    return [k for k in re.split(r"[^a-z0-9]+", (metin or "").lower()) if len(k) > 1]


# ── Pardus / Linux ───────────────────────────────────────────────────────────
def oku(yol):
    try:
        with open(yol, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def linux_usb_yazicilar():
    sahte = os.environ.get("TYS_YAZICI_SAHTE")
    if sahte:
        try:
            return json.load(open(sahte, encoding="utf-8"))
        except (OSError, ValueError):
            return []
    sonuc = []
    for d in glob.glob("/sys/bus/usb/devices/*"):
        taban = os.path.basename(d)
        if ":" in taban or not os.path.exists(d + "/idVendor"):
            continue
        arayuzler = glob.glob(d + "/" + taban + ":*")
        if not any(oku(a + "/bInterfaceClass") == "07" for a in arayuzler):
            continue
        vid, pid, seri = oku(d + "/idVendor"), oku(d + "/idProduct"), oku(d + "/serial")
        aygit_id = ""
        for lp in glob.glob("/sys/class/usbmisc/lp*"):
            ara = os.path.realpath(lp + "/device")
            if os.path.dirname(ara) == os.path.realpath(d):
                aygit_id = oku(lp + "/device/ieee1284_id")
        i = ieee1284(aygit_id)
        sonuc.append({"anahtar": "usb:{}:{}:{}".format(vid, pid, seri or taban), "vidpid": vid + ":" + pid, "seri": seri,
                      "marka": i["marka"] or oku(d + "/manufacturer"), "model": i["model"] or oku(d + "/product"),
                      "aygit_id": aygit_id})
    return sonuc


def cups_kuyruklar():
    if not shutil.which("lpstat"):
        return []
    _, v = calistir(["lpstat", "-v"], 20)
    kuyruklar = {}
    for satir in v.splitlines():
        m = re.match(r"device for (\S+): (\S+)", satir)
        if m:
            kuyruklar[m.group(1)] = {"ad": m.group(1), "uri": m.group(2), "durum": "", "mesaj": "", "is": 0}
    _, p = calistir(["lpstat", "-p"], 20)
    son = None
    for satir in p.splitlines():
        m = re.match(r"printer (\S+) (?:is )?(idle|now printing|disabled)", satir)
        if m and m.group(1) in kuyruklar:
            son = m.group(1)
            kuyruklar[son]["durum"] = {"idle": "hazır", "now printing": "yazdırıyor", "disabled": "durduruldu"}[m.group(2)]
        elif son and satir.startswith(("\t", " ")) and satir.strip():
            kuyruklar[son]["mesaj"] = satir.strip()[:200]
    _, o = calistir(["lpstat", "-o"], 20)
    for satir in o.splitlines():
        ad = satir.split(" ", 1)[0].rsplit("-", 1)[0]
        if ad in kuyruklar:
            kuyruklar[ad]["is"] += 1
    _, d = calistir(["lpstat", "-d"], 10)
    m = re.search(r"destination: (\S+)", d)
    for k in kuyruklar.values():
        k["varsayilan"] = bool(m and m.group(1) == k["ad"])
    return list(kuyruklar.values())


def uri_eslesir(uri, y):
    u = unquote(uri or "").lower()
    if y.get("seri") and y["seri"].lower() in u:
        return True
    model = kelimeler(y.get("model"))
    return bool(model) and all(k in u for k in model[-2:])


# ── Windows ──────────────────────────────────────────────────────────────────
WIN_TARA = r"""
$port = @{}
Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceClasses\{28d78fad-5a12-11d1-ae5b-0000f803a8c2}' -ErrorAction SilentlyContinue | ForEach-Object {
  $p = Get-ItemProperty ($_.PSPath + '\#\Device Parameters') -ErrorAction SilentlyContinue
  if ($p -and $p.'Port Number') { $port[($_.PSChildName -replace '^##\?#','' -replace '#\{.*$','' -replace '#','\').ToUpper()] = ('{0}{1:000}' -f $p.'Base Name', $p.'Port Number') }
}
$yazicilar = @(Get-Printer -ErrorAction SilentlyContinue | Select-Object Name, PortName, DriverName, PrinterStatus, JobCount, Shared)
$sonuc = @()
Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -like 'USBPRINT\*' } | ForEach-Object {
  $ust = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName DEVPKEY_Device_Parent -ErrorAction SilentlyContinue).Data
  $hw = @((Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName DEVPKEY_Device_HardwareIds -ErrorAction SilentlyContinue).Data)
  $mfg = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName DEVPKEY_Device_Manufacturer -ErrorAction SilentlyContinue).Data
  $pt = if ($ust) { $port[$ust.ToUpper()] } else { $null }
  $kuyruk = ($yazicilar | Where-Object { $_.PortName -eq $pt } | Select-Object -First 1).Name
  $sonuc += [pscustomobject]@{ ornek = $_.InstanceId; ust = $ust; ad = $_.FriendlyName; marka = $mfg; hw = $hw; port = $pt; kuyruk = $kuyruk; durum = "$($_.Status)" }
}
[pscustomobject]@{ aygitlar = $sonuc; yazicilar = $yazicilar } | ConvertTo-Json -Depth 4 -Compress
"""


# Get-Printer PrinterStatus
WIN_DURUM = {0: "hazır", 1: "duraklatıldı", 2: "hata", 3: "siliniyor", 4: "kağıt sıkıştı", 5: "kağıt yok", 6: "elle besleme",
             7: "kağıt sorunu", 8: "çevrimdışı", 9: "çalışıyor", 10: "meşgul", 11: "yazdırıyor", 12: "çıkış tepsisi dolu",
             13: "kullanılamıyor", 14: "bekliyor", 15: "işleniyor", 16: "başlatılıyor", 17: "ısınıyor", 18: "toner azaldı",
             19: "toner yok", 20: "sayfa atlandı", 21: "müdahale gerekli", 22: "bellek yetersiz", 23: "kapak açık",
             24: "durum bilinmiyor", 25: "güç tasarrufu"}


def win_json(betik, zaman=90):
    kod, cikti = C.win_ps(betik, zaman)
    try:
        return json.loads(cikti.strip() or "null"), kod, cikti
    except ValueError:
        return None, kod, cikti


def win_usbprint_sayaci():
    """Takılı USB yazıcı sayısı değişti mi? (ucuz kontrol: usbprint hizmetinin canlı aygıt listesi)"""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\usbprint\Enum") as h:
            n = winreg.QueryValueEx(h, "Count")[0]
            return tuple(winreg.QueryValueEx(h, str(i))[0] for i in range(n))
    except OSError:
        return ()


def inf_surucu_adi(klasor, hw_kimlikleri, model=None):
    """INF dosyalarındaki [Models] satırlarından, yazıcının donanım kimliğine (ya da model adına) uyan sürücü adını bulur."""
    mk = kelimeler(model)[-2:] if model else []
    hw = {h.lower() for h in hw_kimlikleri or []}
    hw |= {h.split("\\", 1)[1] for h in hw if "\\" in h}
    aday = None
    for inf in glob.glob(os.path.join(klasor, "**", "*.inf"), recursive=True):
        try:
            ham = open(inf, "rb").read()
            metin = ham.decode("utf-16") if ham[:2] in (b"\xff\xfe", b"\xfe\xff") else ham.decode("cp1252", "replace")
        except OSError:
            continue
        for satir in metin.splitlines():
            m = re.match(r'\s*"([^"]+)"\s*=\s*[^,]+,\s*(.+)$', satir)
            if not m:
                continue
            kimlikler = {k.strip().lower() for k in m.group(2).split(",")}
            kimlikler |= {k.split("\\", 1)[1] for k in kimlikler if "\\" in k}
            if hw & kimlikler:
                return m.group(1)
            if aday is None and mk and all(k in m.group(1).lower() for k in mk):
                aday = m.group(1)
    return aday if mk else None


def win_depo_surucu(ajan, s):
    """Depodaki Windows sürücüsünü (INF içeren .zip / .inf ya da sessiz kurulum programı) kurar.
    (INF klasörü ya da None, adımlar)"""
    adimlar = []
    if s.get("tur") == "inf":
        dosya = ajan.modul("depo").indir(s["sha"])
        hedef = os.path.join(C.VERI, "yazici_surucu", s["sha"][:16])
        if not os.path.isdir(hedef):
            os.makedirs(hedef, exist_ok=True)
            if zipfile.is_zipfile(dosya):
                with zipfile.ZipFile(dosya) as z:
                    for ad in z.namelist():
                        if ".." in ad.replace("\\", "/").split("/") or ad.startswith(("/", "\\")):
                            raise RuntimeError("Sürücü arşivinde geçersiz yol: " + ad)
                    z.extractall(hedef)
            else:
                shutil.copy(dosya, os.path.join(hedef, os.path.basename(s.get("ad") or "surucu.inf")))
        k, c = C.win_gizli(["pnputil.exe", "/add-driver", os.path.join(hedef, "*.inf"), "/subdirs", "/install"], 600)
        adimlar.append("Sürücü paketi eklendi" if k in (0, 3010, 259) else "pnputil: " + c.strip()[-200:])
        return hedef, adimlar
    if s.get("tur") == "exe":
        dosya = ajan.modul("depo").indir(s["sha"])
        msi = (s.get("ad") or "").lower().endswith(".msi")
        exe = dosya + (".msi" if msi else ".exe")
        if not os.path.exists(exe):
            shutil.copy(dosya, exe)
        ek = [x for x in re.findall(r'"[^"]*"|\S+', s.get("parametre") or "")]
        args = (["msiexec.exe", "/i", exe] + (ek or ["/qn", "/norestart"])) if msi else [exe] + ek
        k, c = C.win_gizli([a.strip('"') for a in args], 1800)
        adimlar.append("Kurulum programı çalıştı (çıkış kodu {})".format(k))
    return None, adimlar


class Yazici:
    def __init__(self, ajan):
        self.a = ajan
        self.takili = {}
        self.kuyruklar = []
        self.son_rapor = 0
        self.kilit = threading.Lock()
        p = ajan.modul("politika")
        if p:
            p.kaydet("yazici.kur", Kurulum(self))
            p.kaydet("yazici.kilit", Kilit(self))

    def donguler(self):
        return [self.izle]

    # ── HP firmware (4.2) ────────────────────────────────────────────────────
    def ayar_degisti(self):
        if C.WINDOWS:
            return
        try:
            self.firmware_senkron()
        except Exception as e:
            C.log("Yazıcı firmware:", e)

    def firmware_modeller(self):
        """Tahtada firmware'i hazır olan modeller."""
        try:
            adlar = {os.path.splitext(x)[0] for x in os.listdir(FIRMWARE_DIZIN) if x.endswith(".dl")}
        except OSError:
            return set()
        return {m for m, liste in HP_FIRMWARE.items() if any(a in adlar for a in liste)}

    def firmware_senkron(self):
        """Paneldeki firmware dosyalarını indirir, .dl'ye çevirir; udev kuralını ve gönderme betiğini kurar."""
        liste = (self.a.ayar or {}).get("yazici_firmware") or []
        if not liste or not C.ROOT:
            return
        os.makedirs(FIRMWARE_DIZIN, exist_ok=True)
        depo = self.a.modul("depo")
        for f in liste:
            ad = re.sub(r"[^A-Za-z0-9]", "", re.sub(r"\.(dl|img|tar\.gz|tgz)$", "", f.get("ad") or "", flags=re.I))
            if not re.match(r"^sihpP?\d{4}$", ad) or os.path.exists(os.path.join(FIRMWARE_DIZIN, ad + ".dl")):
                continue
            kaynak = depo.indir(f["sha"])
            hedef = os.path.join(FIRMWARE_DIZIN, ad + ".dl")
            if (f.get("ad") or "").lower().endswith((".tar.gz", ".tgz")):
                import tarfile
                with tarfile.open(kaynak) as t:
                    uye = next((m for m in t.getmembers() if m.isfile() and m.name.lower().endswith((".img", ".dl"))), None)
                    if not uye:
                        continue
                    ic = t.extractfile(uye).read()
                gecici = hedef + (".img" if uye.name.lower().endswith(".img") else ".dl.yeni")
                open(gecici, "wb").write(ic)
                kaynak = gecici
            if kaynak.lower().endswith(".img") or (f.get("ad") or "").lower().endswith(".img"):
                if not shutil.which("arm2hpdl"):
                    calistir(["apt-get", "install", "-y", "--no-install-recommends", "printer-driver-foo2zjs"], 900)
                k, c = calistir(["sh", "-c", 'arm2hpdl "$0" > "$1"', kaynak, hedef + ".yeni"], 60)
                if k or not os.path.getsize(hedef + ".yeni"):
                    C.log("Firmware çevrilemedi:", ad, c[:200])
                    continue
                os.replace(hedef + ".yeni", hedef)
            else:
                shutil.copyfile(kaynak, hedef + ".yeni")
                os.replace(hedef + ".yeni", hedef)
            for g in glob.glob(hedef + ".img") + glob.glob(hedef + ".dl.yeni"):
                os.remove(g)
            C.log("HP firmware hazır:", ad)
        eslesme = "".join("{} {}\n".format(m, " ".join(l)) for m, l in HP_FIRMWARE.items())
        open(os.path.join(FIRMWARE_DIZIN, "eslesme"), "w").write(eslesme)
        os.makedirs(os.path.dirname(FIRMWARE_BETIK), exist_ok=True)
        metin = FIRMWARE_BETIK_METIN.replace("__DIZIN__", FIRMWARE_DIZIN)
        if oku(FIRMWARE_BETIK) != metin.strip():
            open(FIRMWARE_BETIK, "w").write(metin)
            os.chmod(FIRMWARE_BETIK, 0o755)
        kural = ('# Tahta Yönetim Asistanı — HP host-based LaserJet takılınca/açılınca firmware gönder\n'
                 'ACTION=="add", SUBSYSTEM=="usbmisc", KERNEL=="lp*", ATTRS{idVendor}=="03f0", '
                 'RUN+="/usr/bin/systemd-run --no-block --quiet %s $devnode"\n' % FIRMWARE_BETIK)
        if oku(FIRMWARE_UDEV) != kural.strip():
            open(FIRMWARE_UDEV, "w").write(kural)
            calistir(["udevadm", "control", "--reload-rules"], 30)
        self.firmware_gonder()

    def firmware_gonder(self):
        """Takılı HP yazıcılara firmware'i şimdi gönderir (kurulumda ve 'Basmıyor, onar'da)."""
        if C.WINDOWS or not os.path.exists(FIRMWARE_BETIK):
            return ""
        gonderilen = []
        for lp in glob.glob("/sys/class/usbmisc/lp*"):
            if oku(os.path.join(os.path.realpath(lp + "/device"), "..", "idVendor")) != "03f0":
                continue
            model = ieee1284(oku(lp + "/device/ieee1284_id")).get("model")
            if not hp_firmware_model(model):
                continue
            calistir([FIRMWARE_BETIK, "/dev/usb/" + os.path.basename(lp)], 60)
            gonderilen.append(model)
        return " · firmware gönderildi: " + ", ".join(gonderilen) if gonderilen else ""

    def durum(self):
        return {"yazicilar": [{"model": y.get("model"), "kurulu": y.get("kurulu")} for y in self.takili.values()]}

    # ── algılama ─────────────────────────────────────────────────────────────
    def tara(self):
        if C.WINDOWS:
            return self.win_tara()
        aygitlar = linux_usb_yazicilar()
        self.kuyruklar = cups_kuyruklar()
        for y in aygitlar:
            k = next((k for k in self.kuyruklar if k["uri"].startswith(("usb:", "ipp:", "ipps:", "hp:", "socket:"))
                      and not k["ad"].startswith("TYS_ham_")
                      and (k["uri"] == y.get("uri") or uri_eslesir(k["uri"], y))), None)
            y["kurulu"] = bool(k)
            y["kuyruk"] = k["ad"] if k else None
            y["durum"] = (k["durum"] + (" — " + k["mesaj"] if k.get("mesaj") else "")) if k else ""
        return {y["anahtar"]: y for y in aygitlar}

    def win_tara(self):
        veri, _, _ = win_json(WIN_TARA, 120)
        if not isinstance(veri, dict):
            return dict(self.takili)
        aygitlar = veri.get("aygitlar") or []
        if isinstance(aygitlar, dict):
            aygitlar = [aygitlar]
        yaz = veri.get("yazicilar") or []
        if isinstance(yaz, dict):
            yaz = [yaz]
        self.kuyruklar = [{"ad": x.get("Name"), "uri": x.get("PortName"), "surucu": x.get("DriverName"),
                           "durum": WIN_DURUM.get(x.get("PrinterStatus"), str(x.get("PrinterStatus") or "")),
                           "is": x.get("JobCount") or 0} for x in yaz]
        sonuc = {}
        for a in aygitlar:
            ust = a.get("ust") or a.get("ornek") or ""
            m = re.search(r"VID_([0-9A-F]{4})&PID_([0-9A-F]{4})\\([^\\]+)$", ust, re.I)
            vid, pid, seri = (m.group(1).lower(), m.group(2).lower(), m.group(3)) if m else ("", "", ust[-20:])
            hw = a.get("hw") or []
            if isinstance(hw, str):
                hw = [hw]
            sonuc["usb:{}:{}:{}".format(vid, pid, seri)] = {
                "anahtar": "usb:{}:{}:{}".format(vid, pid, seri), "vidpid": vid + ":" + pid, "seri": seri,
                "marka": a.get("marka") or "", "model": a.get("ad") or "", "aygit_id": ";".join(hw[:3]), "hw": hw,
                "port": a.get("port"), "kuyruk": a.get("kuyruk"), "kurulu": bool(a.get("kuyruk")), "durum": a.get("durum") or ""}
        return sonuc

    def izle(self):
        time.sleep(8)
        onceki_sayac = None
        son_tam = 0
        while True:
            try:
                if C.WINDOWS:
                    sayac = win_usbprint_sayaci()
                    if sayac != onceki_sayac or time.time() - son_tam > 600:
                        onceki_sayac = sayac
                        son_tam = time.time()
                        self.guncelle(self.tara())
                    time.sleep(3)
                else:
                    yeni = self.tara()
                    self.guncelle(yeni)
                    time.sleep(5)
            except Exception as e:
                C.log("Yazıcı tarama hatası:", e)
                time.sleep(30)

    def guncelle(self, yeni):
        eklenen = [k for k in yeni if k not in self.takili]
        degisti = eklenen or set(yeni) != set(self.takili) or \
            any(yeni[k].get("kurulu") != self.takili.get(k, {}).get("kurulu") for k in yeni)
        self.takili = yeni
        for k in eklenen:
            C.log("Yazıcı takıldı:", yeni[k].get("marka"), yeni[k].get("model"), "(kurulu)" if yeni[k].get("kurulu") else "(sürücü yok)")
        if eklenen:
            p = self.a.modul("politika")
            if p:
                p.tetikle()                         # bekleyen kurulum varsa hemen yapılsın
        if degisti or time.time() - self.son_rapor > 600:
            self.rapor()

    def rapor(self):
        self.son_rapor = time.time()
        try:
            c = self.a.istek("/api/a/yazici", {"id": self.a.id, "platform": "windows" if C.WINDOWS else "linux",
                                               "yazicilar": [{k: v for k, v in y.items() if k != "hw"} for y in self.takili.values()],
                                               "kuyruklar": self.kuyruklar[:30]}, zaman=20)
        except Exception:
            self.son_rapor = 0
            return
        for anahtar in (c or {}).get("bildir") or []:
            y = self.takili.get(anahtar)
            if y:
                self.tahtada_bildir("Yazıcınız algılandı", "{} {}\nYönetici panelden kuracak; bir şey yapmanıza gerek yok.".format(
                    y.get("marka") or "", y.get("model") or "").strip())

    def tahtada_bildir(self, baslik, metin):
        try:
            o = C.oturum_bul()
            if o and not self.a.kilitli and not self.a.tam_ekran:
                self.a.ui("bildirim", {"baslik": baslik, "metin": metin, "sure": 12, "okul_adi": ""}, o)
        except Exception:
            pass

    # ── test sayfası (panelden komut) ────────────────────────────────────────
    def komut(self, tur, v, kaynak):
        if tur == "yazici_firmware":
            self.firmware_senkron()
            return {"mesaj": self.firmware_gonder().strip(" ·") or "Firmware hazır"}
        if tur == "yazici_temizle":
            kuyruk = str(v.get("kuyruk") or "")
            if not kuyruk:
                raise RuntimeError("Kuyruk belirtilmedi")
            if C.WINDOWS:
                k, c = C.win_ps("Get-PrintJob -PrinterName '{}' | Remove-PrintJob".format(kuyruk.replace("'", "''")), 120)
            else:
                k, c = calistir(["cancel", "-a", kuyruk], 60)
            ps = self.a.modul("paylasim")
            if ps:
                ps.isleri_iptal(kuyruk)
            self.a.olay_gonder("sistem", "Yazıcı kuyruğu temizlendi ({}){}".format(kuyruk, "" if k == 0 else ": " + c.strip()[:150]))
            self.guncelle(self.tara())
            self.rapor()
            return True
        if tur != "yazici_test":
            return False
        kuyruk = v.get("kuyruk") or next((y.get("kuyruk") for y in self.takili.values() if y.get("kuyruk")), None)
        if not kuyruk:
            raise RuntimeError("Bu tahtada kurulu yazıcı yok")
        sonuc = self.test_sayfasi(kuyruk)
        self.a.olay_gonder("sistem", "Test sayfası ({}): {}".format(kuyruk, sonuc))
        return True

    def test_sayfasi(self, kuyruk, bekle=90):
        if C.WINDOWS:
            k, c = C.win_gizli(["rundll32.exe", "printui.dll,PrintUIEntry", "/k", "/n", kuyruk], 120)
            return "gönderildi" if k == 0 else "gönderilemedi: " + c[:200]
        dosya = TEST_SAYFASI if os.path.exists(TEST_SAYFASI) else None
        args = ["lp", "-d", kuyruk, "-t", "Tahta Yonetim test sayfasi"] + ([dosya] if dosya else [])
        try:
            r = subprocess.run(args, input=None if dosya else "Tahta Yonetim - test sayfasi\n".encode(),
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
            cikti = r.stdout.decode("utf-8", "replace")
        except Exception as e:
            return "gönderilemedi: {}".format(e)
        if r.returncode:
            return "gönderilemedi: " + cikti.strip()[:200]
        bitis = time.time() + bekle
        while time.time() < bitis:
            time.sleep(3)
            _, o = calistir(["lpstat", "-o", kuyruk], 20)
            _, p = calistir(["lpstat", "-p", kuyruk], 20)
            if "disabled" in p or "filter failed" in p.lower():
                return "hata: " + " ".join(p.split())[:200]
            if not o.strip():
                return "basıldı"
        return "kuyrukta bekliyor (yazıcı kapalı ya da kağıt yok olabilir)"


class Kurulum:
    """politika: yazici.kur — veri: anahtar, model, marka, aygit_id, surucu{tur, sha, ad, parametre}, varsayilan, test"""

    def __init__(self, y):
        self.y = y

    def uygula(self, p, kayit):
        v = p["veri"]
        aygit = self.y.takili.get(v.get("anahtar"))
        if not aygit:
            return {"durum": "bekliyor", "ayrinti": "Yazıcı şu an bu tahtaya takılı değil; takılınca kurulacak.", "kayit": kayit}
        if C.WINDOWS:
            return self.windows(v, aygit, kayit)
        return self.linux(v, aygit, kayit)

    def kaldir(self, kayit):
        kuyruk = (kayit or {}).get("kuyruk")
        if not kuyruk or not (kayit or {}).get("olusturduk", True):
            return
        if C.WINDOWS:
            k, c = C.win_ps("Remove-Printer -Name '{}'".format(kuyruk.replace("'", "''")), 120)
            if k and "No printer" not in c and "bulunamad" not in c:
                raise RuntimeError(c.strip()[:300])
        else:
            k, c = calistir(["lpadmin", "-x", kuyruk], 60)
            if k and "does not exist" not in c and "mevcut değil" not in c:
                raise RuntimeError(c.strip()[:300])
        C.log("Yazıcı kuyruğu kaldırıldı:", kuyruk)

    # ── Pardus / Linux ───────────────────────────────────────────────────────
    def linux(self, v, aygit, kayit):
        if not shutil.which("lpadmin"):
            return {"durum": "hata", "ayrinti": "Bu tahtada CUPS (yazdırma sistemi) kurulu değil."}
        s = v.get("surucu") or {"tur": "otomatik"}
        adimlar, ppd, kurulan = [], None, []
        if s.get("tur") in ("deb", "ppd"):
            dosya = self.y.a.modul("depo").indir(s["sha"])
            if s["tur"] == "deb":
                k, c = calistir(["dpkg", "-i", dosya], 600)
                calistir(["apt-get", "-f", "-y", "install"], 900)
                if k:
                    adimlar.append("dpkg uyarısı: " + c.strip().splitlines()[-1][:150] if c.strip() else "dpkg hatası")
                adimlar.append("Sürücü paketi kuruldu: " + s.get("ad", ""))
            else:
                ppd = dosya
        uri = aygit.get("uri") or self.uri_bul(aygit)
        if not uri:
            return {"durum": "hata", "ayrinti": "Yazıcının bağlantı adresi bulunamadı (CUPS yazıcıyı görmüyor). Kabloyu çıkarıp takın."}
        model_adi = "{} {}".format(aygit.get("marka") or "", aygit.get("model") or "").strip()
        surucu, yontem = None, None
        if ppd:
            yontem = "Depodaki PPD: " + s.get("ad", "")
        elif uri.startswith(("ipp://", "ipps://")):
            surucu, yontem = "everywhere", "Sürücüsüz (IPP Everywhere)"
        else:
            surucu, aciklama = self.cups_surucu(aygit)
            if not surucu and s.get("tur") == "otomatik" and shutil.which("apt-get"):
                paketler = self.aday_paketler(aygit)
                if paketler:
                    k, c = calistir(["apt-get", "install", "-y", "--no-install-recommends"] + paketler, 1200)
                    if k == 0:
                        kurulan = paketler
                        adimlar.append("Pardus deposundan kuruldu: " + ", ".join(paketler))
                    else:
                        adimlar.append("Depodan sürücü kurulamadı ({})".format(c.strip().splitlines()[-1][:120] if c.strip() else k))
                    surucu, aciklama = self.cups_surucu(aygit)
            if surucu:
                yontem = "CUPS sürücüsü: " + aciklama
        if not surucu and not ppd and canon_turu(aygit.get("marka"), aygit.get("model")) == "ufr":
            return {"durum": "hata", "ayrinti": " · ".join(adimlar + [
                "Bu Canon modeli Canon'un UFR II / UFR II LT Linux sürücüsünü ister (Pardus deposunda yoktur). Canon'un sitesinden "
                "\"UFR II/UFRII LT Printer Driver for Linux\" paketini indirin, içindeki 64 bit .deb dosyasını Yazıcı Merkezi › "
                "Sürücü yükle ile depoya ekleyin ve bu yazıcıyı o sürücüyle kurun."]),
                "sonuc": {"model": model_adi, "platform": "linux", "yontem": "sürücü yok (Canon UFR II)"}}
        if not surucu and not ppd:
            return {"durum": "hata", "ayrinti": " · ".join(adimlar + [
                "Bu model için Pardus sürücüsü bulunamadı. Seçenekler: üreticinin Linux sürücüsünü (.deb / .ppd) depoya "
                "yükleyip yeniden kurun; ya da 'Windows'ta işle, tahtada bas' ile bir Windows bilgisayardaki sürücüyü "
                "kullanın; o da olmazsa yazıcıyı bir Windows bilgisayara bağlayıp paylaşın."]),
                "sonuc": {"model": model_adi, "platform": "linux", "yontem": "sürücü yok"}}
        kuyruk = (kayit or {}).get("kuyruk")
        if not kuyruk:
            # Başkasının (öğretmenin elle eklediği, ağ yazıcısı vb.) kuyruğunun üzerine yazılmaz.
            taban = kuyruk_adi(aygit.get("model") or v.get("model"))
            mevcut = {k["ad"] for k in cups_kuyruklar()}
            kuyruk, n = taban, 2
            while kuyruk in mevcut:
                kuyruk, n = "{}_{}".format(taban, n), n + 1
        args = ["lpadmin", "-p", kuyruk, "-E", "-v", uri] + (["-P", ppd] if ppd else ["-m", surucu]) + \
               ["-o", "printer-is-shared=false", "-D", model_adi[:120], "-L", str(self.y.a.ayar.get("ad") or "")[:60]]
        k, c = calistir(args, 180)
        if k:
            return {"durum": "hata", "ayrinti": "Yazıcı eklenemedi: " + c.strip()[:300],
                    "sonuc": {"model": model_adi, "platform": "linux", "yontem": yontem}}
        calistir(["cupsenable", kuyruk], 30)
        calistir(["cupsaccept", kuyruk], 30)
        fw = hp_firmware_model(aygit.get("model") or v.get("model"))
        if fw:
            durum_fw = self.y.firmware_gonder()
            adimlar.append(durum_fw.strip(" ·") if durum_fw else "firmware: " + fw)
            if fw not in self.y.firmware_modeller():
                adimlar.append("UYARI: Bu yazıcı her açılışta firmware ister ama depoda {} firmware'i yok — yazıcı kapatılıp "
                               "açılınca basmaz. Yazıcı Merkezi › HP firmware bölümünden ekleyin.".format(fw))
        if v.get("varsayilan", True):
            calistir(["lpadmin", "-d", kuyruk], 30)
            adimlar.append("varsayılan yapıldı")
        test = "yok"
        if v.get("test", True):
            t = self.y.test_sayfasi(kuyruk)
            test = "basildi" if t == "basıldı" else ("hata" if t.startswith(("hata", "gönderilemedi")) else "bekliyor")
            adimlar.append("test sayfası: " + t)
        C.log("Yazıcı kuruldu:", kuyruk, yontem)
        self.y.guncelle(self.y.tara())
        return {"durum": "tamam", "ayrinti": " · ".join([yontem] + adimlar),
                "kayit": {"kuyruk": kuyruk, "platform": "linux", "olusturduk": True, "paketler": kurulan},
                "sonuc": {"model": model_adi, "platform": "linux", "yontem": yontem, "test": test}}

    def uri_bul(self, aygit):
        for args in (["lpinfo", "--include-schemes", "usb", "-v"], ["driverless"]):
            if not shutil.which(args[0]):
                continue
            _, c = calistir(args, 90)
            for satir in c.splitlines():
                parca = satir.split()
                uri = parca[-1] if parca else ""
                if uri.startswith(("usb://", "ipp://", "ipps://")) and uri_eslesir(uri, aygit):
                    return uri
        return None

    def cups_surucu(self, aygit):
        """CUPS'un kendi eşleştirmesi: aygıt kimliğine uyan sürücüler; 'recommended' olan öne alınır."""
        kimlik = aygit.get("aygit_id") or "MFG:{};MDL:{};".format(aygit.get("marka") or "", aygit.get("model") or "")
        _, c = calistir(["lpinfo", "--device-id", kimlik, "-m"], 120)
        adaylar = []
        for satir in c.splitlines():
            if " " not in satir or satir.startswith(("lpinfo:", "Unable")):
                continue
            uri, aciklama = satir.split(" ", 1)
            if uri in ("raw", "everywhere", "drv:///sample.drv/generic.ppd"):
                continue
            adaylar.append((0 if "recommended" in aciklama.lower() else 1, uri, aciklama.strip()))
        if not adaylar:
            model = kelimeler(aygit.get("model"))
            _, c = calistir(["lpinfo", "-m"], 120)
            for satir in c.splitlines():
                if " " in satir and model and all(k in satir.lower() for k in model[-2:]):
                    uri, aciklama = satir.split(" ", 1)
                    adaylar.append((2, uri, aciklama.strip()))
        if not adaylar:
            return None, None
        adaylar.sort()
        return adaylar[0][1], adaylar[0][2]

    def aday_paketler(self, aygit):
        marka = (aygit.get("marka") or "").lower()
        paketler = []
        model = (aygit.get("model") or "").lower()
        for desen, liste in MODEL_PAKET:
            if re.search(desen, model):
                paketler += liste
        ct = canon_turu(marka, model)
        if ct == "capt":
            paketler += ["printer-driver-captdriver"]
        elif ct == "ufr":
            return []                       # Pardus deposunda uygun sürücü yok
        for k, liste in MARKA_PAKET.items():
            if k in marka:
                paketler += liste
        paketler = paketler or ["printer-driver-gutenprint"]
        sonuc = []
        for p in dict.fromkeys(paketler):
            k, c = calistir(["dpkg-query", "-W", "-f=${Status}", p], 20)
            if "install ok installed" not in c:
                k2, c2 = calistir(["apt-cache", "show", p], 30)
                if k2 == 0 and c2.strip():
                    sonuc.append(p)
        return sonuc

    # ── Windows ──────────────────────────────────────────────────────────────
    def windows(self, v, aygit, kayit):
        s = v.get("surucu") or {"tur": "otomatik"}
        onceden = aygit.get("kuyruk")
        hedef, adimlar = win_depo_surucu(self.y.a, s)
        surucu_adi = inf_surucu_adi(hedef, aygit.get("hw")) if hedef else None
        kuyruk = self.port_kuyrugu(aygit)
        if not kuyruk:
            C.win_gizli(["pnputil.exe", "/scan-devices"], 120)
            for _ in range(12):
                time.sleep(5)
                kuyruk = self.port_kuyrugu(aygit)
                if kuyruk:
                    break
        yontem = "Windows sürücüsü" if not s.get("tur") or s["tur"] == "otomatik" else (
            "Depodaki INF: " if s["tur"] == "inf" else "Kurulum programı: ") + s.get("ad", "")
        if not kuyruk and aygit.get("port"):
            adlar = [surucu_adi] if surucu_adi else []
            adlar += [aygit.get("model")]
            for ad in [a for a in adlar if a]:
                k, c = C.win_ps("Add-PrinterDriver -Name '{0}'; Add-Printer -Name '{1}' -DriverName '{0}' -PortName '{2}'".format(
                    ad.replace("'", "''"), kuyruk_adi(aygit.get("model")).replace("_", " "), aygit["port"]), 300)
                if k == 0:
                    kuyruk = kuyruk_adi(aygit.get("model")).replace("_", " ")
                    yontem += " ({})".format(ad)
                    break
                adimlar.append("Sürücü eklenemedi ({}): {}".format(ad, c.strip()[-150:]))
        model_adi = aygit.get("model") or v.get("model")
        if not kuyruk:
            return {"durum": "hata", "ayrinti": " · ".join(adimlar + [
                "Windows bu yazıcı için sürücü bulamadı. Üreticinin sürücü paketini (INF içeren .zip) ya da sessiz "
                "kurulum programını depoya yükleyip yeniden kurun."]),
                "sonuc": {"model": model_adi, "platform": "windows", "yontem": "sürücü yok"}}
        if v.get("varsayilan", True):
            o = C.oturum_bul()
            if o:
                C.oturumda(["reg.exe", "add", r"HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows", "/v",
                            "LegacyDefaultPrinterMode", "/t", "REG_DWORD", "/d", "1", "/f"], o, yakala=True, zaman_asimi=20)
                C.oturumda(["rundll32.exe", "printui.dll,PrintUIEntry", "/y", "/n", kuyruk], o, yakala=True, zaman_asimi=30)
                adimlar.append("varsayılan yapıldı")
            else:
                adimlar.append("oturum açık değil: varsayılan yapılamadı")
        test = "yok"
        if v.get("test", True):
            t = self.y.test_sayfasi(kuyruk)
            test = "hata" if t.startswith("gönderilemedi") else "bekliyor"
            adimlar.append("test sayfası " + t)
        self.y.guncelle(self.y.tara())
        return {"durum": "tamam", "ayrinti": " · ".join([yontem] + adimlar),
                "kayit": {"kuyruk": kuyruk, "platform": "windows", "olusturduk": not onceden},
                "sonuc": {"model": model_adi, "platform": "windows", "yontem": yontem, "test": test}}

    def port_kuyrugu(self, aygit):
        if not aygit.get("port"):
            return None
        k, c = C.win_ps("(Get-Printer | Where-Object {{ $_.PortName -eq '{}' }} | Select-Object -First 1).Name".format(
            aygit["port"]), 60)
        return (c.strip() or None) if k == 0 else None


class Kilit:
    """politika: yazici.kilit — öğretmen yazıcı ekleyip silemez, sürücü kuramaz."""

    def __init__(self, y):
        self.y = y

    def uygula(self, p, kayit):
        if kayit:
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Yazıcı ayarları kilitli"}
        if C.WINDOWS:
            import winreg
            eski = {}
            for yol, ad in ((r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer", "NoAddPrinter"),
                            (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer", "NoDeletePrinter"),
                            (r"SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint", "RestrictDriverInstallationToAdministrators")):
                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as h:
                    try:
                        eski[yol + "|" + ad] = winreg.QueryValueEx(h, ad)[0]
                    except OSError:
                        eski[yol + "|" + ad] = None
                    winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, 1)
            return {"durum": "tamam", "ayrinti": "Yazıcı ekleme/silme ve sürücü kurulumu yöneticiye kilitlendi", "kayit": {"kayit": eski}}
        kural = ("// Tahta Yönetim: yazıcı yönetimi yalnızca yöneticide\npolkit.addRule(function(action, subject) {\n"
                 "  if (action.id.indexOf(\"org.opensuse.cupspkhelper.mechanism.\") == 0 && subject.user != \"root\") {\n"
                 "    return polkit.Result.NO;\n  }\n});\n")
        pkla = ("[Tahta Yonetim yazici kilidi]\nIdentity=unix-user:*\nAction=org.opensuse.cupspkhelper.mechanism.*\n"
                "ResultAny=no\nResultInactive=no\nResultActive=no\n")
        yazilan = []
        for yol, icerik in ((POLKIT_KURAL, kural), (POLKIT_PKLA, pkla)):
            if os.path.isdir(os.path.dirname(yol)):
                with open(yol, "w") as f:
                    f.write(icerik)
                os.chmod(yol, 0o644)
                yazilan.append(yol)
        cikarilan = []
        try:
            import grp
            for u in grp.getgrnam("lpadmin").gr_mem:
                if u != "root" and calistir(["gpasswd", "-d", u, "lpadmin"], 30)[0] == 0:
                    cikarilan.append(u)
        except KeyError:
            pass
        return {"durum": "tamam", "ayrinti": "Yazıcı ayarları yöneticiye kilitlendi" +
                (" (lpadmin grubundan çıkarılan: {})".format(", ".join(cikarilan)) if cikarilan else ""),
                "kayit": {"dosyalar": yazilan, "lpadmin": cikarilan}}

    def kaldir(self, kayit):
        if C.WINDOWS:
            import winreg
            for an, deger in (kayit.get("kayit") or {}).items():
                yol, ad = an.split("|", 1)
                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_SET_VALUE) as h:
                    if deger is None:
                        try:
                            winreg.DeleteValue(h, ad)
                        except OSError:
                            pass
                    else:
                        winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, deger)
            return
        for yol in kayit.get("dosyalar") or []:
            try:
                os.remove(yol)
            except OSError:
                pass
        for u in kayit.get("lpadmin") or []:
            calistir(["gpasswd", "-a", u, "lpadmin"], 30)


def baslat(ajan):
    return Yazici(ajan)
