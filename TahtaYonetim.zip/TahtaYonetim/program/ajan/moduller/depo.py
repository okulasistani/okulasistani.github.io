# -*- coding: utf-8 -*-
"""Dosya deposu istemcisi: sürücü ve kurulum dosyalarını yönetim bilgisayarından indirir.

Dosyalar içerik özetiyle (sha256) adlandırılır; indirme kaldığı yerden devam eder, özet doğrulanır,
cihazda önbelleğe alınır (internetsiz ve tekrar indirmeden çalışır).
"""
SURUM = "4.3"
C = None

import os
import time
import hashlib
import urllib.error

SINIR = 6 * 1024 ** 3                       # önbellek üst sınırı


class Depo:
    def __init__(self, ajan):
        self.a = ajan
        self.dizin = os.path.join(C.VERI, "depo")

    def yol(self, sha):
        return os.path.join(self.dizin, sha)

    def indir(self, sha, ilerleme=None, deneme=40):
        sha = "".join(c for c in (sha or "").lower() if c in "0123456789abcdef")
        if len(sha) != 64:
            raise ValueError("Geçersiz dosya kimliği")
        hedef = self.yol(sha)
        if os.path.isfile(hedef):
            os.utime(hedef, None)
            return hedef
        os.makedirs(self.dizin, exist_ok=True)
        parca = hedef + ".part"
        son_hata = None
        for _ in range(deneme):
            konum = os.path.getsize(parca) if os.path.exists(parca) else 0
            r = self.a._istek_nesnesi("/api/a/depo/" + sha)
            if konum:
                r.add_header("Range", "bytes={}-".format(konum))
            try:
                with self.a.acici.open(r, timeout=60) as y:
                    if konum and y.status != 206:
                        konum = 0
                    toplam = konum + int(y.headers.get("Content-Length") or 0)
                    with open(parca, "ab" if konum else "wb") as f:
                        while True:
                            b = y.read(256 * 1024)
                            if not b:
                                break
                            f.write(b)
                            konum += len(b)
                            if ilerleme:
                                ilerleme(konum, toplam)
                break
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    raise RuntimeError("Dosya yönetim bilgisayarının deposunda yok")
                son_hata = e
                time.sleep(int(e.headers.get("Retry-After") or 10) if e.code == 503 else 10)
            except Exception as e:
                son_hata = e
                time.sleep(10)
        else:
            raise RuntimeError("Dosya indirilemedi: {}".format(son_hata))
        h = hashlib.sha256()
        with open(parca, "rb") as f:
            for b in iter(lambda: f.read(1024 * 1024), b""):
                h.update(b)
        if h.hexdigest() != sha:
            os.remove(parca)
            raise RuntimeError("İndirilen dosya bozuk (özet tutmuyor)")
        os.replace(parca, hedef)
        self.temizle()
        return hedef

    def temizle(self):
        try:
            dosyalar = [(os.path.getatime(p), os.path.getsize(p), p) for p in
                        (os.path.join(self.dizin, x) for x in os.listdir(self.dizin)) if os.path.isfile(p)]
        except OSError:
            return
        toplam = sum(b for _, b, _ in dosyalar)
        for at, b, p in sorted(dosyalar):
            if toplam <= SINIR:
                break
            if time.time() - at > 7 * 86400:
                try:
                    os.remove(p)
                    toplam -= b
                except OSError:
                    pass


def baslat(ajan):
    return Depo(ajan)
