# -*- coding: utf-8 -*-
"""Politikalar (istenen durum): yönetim panelindeki her işlem bu cihaz için "olması gereken" bir kayıttır.

Ajan olması gerekenle olanı sürekli karşılaştırır; eksiği tamamlar, kaldırılan politikanın yalnızca kendi yaptığı
değişikliklerini geri alır ve her politika için durumu (bekliyor / uygulanıyor / tamam / hata) yönetime bildirir.
Cihaz kapalıyken verilen işler açıldığında kendiliğinden tamamlanır.
"""
SURUM = "4.1"
C = None                                   # çekirdek (tahta-ajan.py) — yükleyici tarafından verilir

import os
import time
import threading


class Politika:
    def __init__(self, ajan):
        self.a = ajan
        self.isleyiciler = {}
        self.yol = os.path.join(C.VERI, "politika.json")
        self.d = C.json_oku(self.yol, {}) or {}
        self.d.setdefault("durum", {})
        self.d.setdefault("rapor", [])
        self.olay = threading.Event()
        self.kilit = threading.RLock()
        self.rapor_kilit = threading.Lock()

    # ── modüllerin kullandığı arayüz ─────────────────────────────────────────
    def kaydet(self, anahtar, isleyici):
        """isleyici.uygula(politika, onceki_kayit) → {"durum", "ayrinti", "kayit", "sonuc"}; isleyici.kaldir(kayit)."""
        self.isleyiciler[anahtar] = isleyici

    def tetikle(self):
        self.olay.set()

    def ayar_degisti(self):
        self.olay.set()

    def donguler(self):
        return [self.dongu]

    def durum(self):
        say = {}
        for st in self.d["durum"].values():
            say[st.get("durum")] = say.get(st.get("durum"), 0) + 1
        return {"politika": say}

    # ── iç işler ─────────────────────────────────────────────────────────────
    def _yaz(self):
        try:
            C.json_yaz(self.yol, self.d)
        except Exception as e:
            C.log("Politika durumu yazılamadı:", e)

    def bildir(self, pid, durum, ayrinti="", sonuc=None, onceki=None):
        with self.rapor_kilit:
            self.d["rapor"] = [r for r in self.d["rapor"] if r.get("politika") != pid or r.get("durum") in ("tamam", "hata")]
            self.d["rapor"].append({"politika": pid, "durum": durum, "ayrinti": (ayrinti or "")[:2000], "sonuc": sonuc or {},
                                    "onceki": onceki, "zaman": time.time()})
            self.d["rapor"] = self.d["rapor"][-300:]
            self._yaz()

    def rapor_gonder(self):
        with self.rapor_kilit:
            liste = list(self.d["rapor"])
        if not liste:
            return
        try:
            self.a.istek("/api/a/politika", {"id": self.a.id, "durumlar": liste[:200]}, zaman=20)
        except Exception:
            return
        with self.rapor_kilit:
            gonderilen = {id(r) for r in liste[:200]}
            self.d["rapor"] = [r for r in self.d["rapor"] if id(r) not in gonderilen]
            self._yaz()

    def dongu(self):
        time.sleep(3)
        while True:
            self.olay.wait(60)
            self.olay.clear()
            try:
                self.uzlastir()
            except Exception as e:
                C.log("Politika hatası:", e)
            self.rapor_gonder()

    def uzlastir(self):
        ayar = self.a.ayar or {}
        if not isinstance(ayar.get("politikalar"), list):
            return                                  # sunucudan geçerli liste gelmeden hiçbir şey kaldırılmaz
        istenen = {p["id"]: p for p in ayar["politikalar"] if isinstance(p, dict) and p.get("id")}
        with self.kilit:
            durum = self.d["durum"]
            for pid, p in istenen.items():
                an = "{}.{}".format(p.get("modul"), p.get("tur"))
                st = durum.get(pid)
                h = self.isleyiciler.get(an)
                if h is None:
                    if not st or st.get("durum") != "desteklenmiyor":
                        durum[pid] = {"durum": "desteklenmiyor", "surum": p.get("surum"), "anahtar": an, "zaman": time.time()}
                        self._yaz()
                        self.bildir(pid, "desteklenmiyor", "Bu cihazda bu özellik kullanılamıyor")
                    continue
                ayni = st and st.get("surum") == p.get("surum")
                if ayni and st.get("durum") in ("tamam", "desteklenmiyor"):
                    continue
                if ayni and st.get("durum") == "hata":
                    bekle = min(3600, 300 * 2 ** min(st.get("deneme", 1) - 1, 4))
                    if time.time() - st.get("zaman", 0) < bekle:
                        continue
                onceki = st.get("durum") if st else None
                deneme = (st.get("deneme", 0) + 1) if ayni else 1
                if onceki != "bekliyor":
                    self.bildir(pid, "uygulaniyor", "", None, onceki)
                    self.rapor_gonder()
                kayit = st.get("kayit") if st else None
                try:
                    s = h.uygula(p, kayit) or {}
                except Exception as e:
                    C.log("Politika uygulanamadı:", an, e)
                    s = {"durum": "hata", "ayrinti": "{}: {}".format(type(e).__name__, e)}
                yeni = s.get("durum") or "tamam"
                durum[pid] = {"durum": yeni, "surum": p.get("surum"), "anahtar": an, "kayit": s.get("kayit", kayit),
                              "zaman": time.time(), "deneme": deneme, "ayrinti": (s.get("ayrinti") or "")[:500]}
                self._yaz()
                if yeni != "bekliyor" or onceki != "bekliyor" or (st and st.get("ayrinti") != s.get("ayrinti")):
                    self.bildir(pid, yeni, s.get("ayrinti") or "", s.get("sonuc"), onceki)
                C.log("Politika {}: {} → {}".format(an, pid, yeni))
            for pid in list(durum):
                if pid in istenen:
                    continue
                st = durum[pid]
                h = self.isleyiciler.get(st.get("anahtar"))
                if h is not None and st.get("kayit") is not None:
                    if time.time() - st.get("kaldir_zaman", 0) < 600 and st.get("kaldir_hata"):
                        continue
                    try:
                        h.kaldir(st["kayit"])
                    except Exception as e:
                        C.log("Politika geri alınamadı:", st.get("anahtar"), e)
                        st.update(kaldir_hata=str(e)[:300], kaldir_zaman=time.time())
                        self._yaz()
                        self.bildir(pid, "hata", "Geri alınamadı: {}".format(e))
                        continue
                del durum[pid]
                self._yaz()
                self.bildir(pid, "kaldirildi")
                C.log("Politika geri alındı:", st.get("anahtar"), pid)


def baslat(ajan):
    return Politika(ajan)
