# -*- coding: utf-8 -*-
"""Uzaktan Oturum Yönetimi: öğretmen oturumunu kapatma, belirli bir kullanıcıya geçiş, arka plan yönetimi
(masaüstü, sınıfa özel, özel günler, giriş ve kilit ekranı, değiştirme kilidi). Ajan root/SYSTEM olarak çalışır;
tahtada hiçbir şifre girilmez."""
SURUM = "4.0"
C = None

import os
import re
import sys
import time
import shutil
import threading

ARKAPLAN_LINUX = "/usr/share/backgrounds/tahta-yonetim"
DCONF_DOSYA = "/etc/dconf/db/local.d/50-tahta-yonetim"
DCONF_KILIT = "/etc/dconf/db/local.d/locks/50-tahta-yonetim"
DCONF_PROFIL = "/etc/dconf/profile/user"
GREETER = "/etc/lightdm/lightdm-gtk-greeter.conf.d/50-tahta-yonetim.conf"
PARDUS_GREETER_DIZIN = "/etc/pardus/greeter.conf.d"
PARDUS_GREETER = PARDUS_GREETER_DIZIN + "/90-tahta-asistani.conf"     # ETAP'ın 00-etap.conf'undan sonra okunur
OKUL_POLITIKA = {"id": "okul", "veri": {"kilitle": True}}             # yalnızca nöbet resmi (arka plan ayarı yokken)
SEMA_ANAHTAR = {"cinnamon": ("org.cinnamon.desktop.background", "picture-uri"),
                "gnome": ("org.gnome.desktop.background", "picture-uri"),
                "mate": ("org.mate.background", "picture-filename")}
KIOSKRC = "/etc/xdg/xfce4/kiosk/kioskrc"
LIGHTDM_GECIS = "/etc/lightdm/lightdm.conf.d/99-tahta-yonetim-gecis.conf"
CSP = r"SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP"


def Y():
    return sys.modules["tys_modul_yazici"]


def calistir(args, zaman=120, env=None):
    return Y().calistir(args, zaman, env)


def masaustu_turu(o=None):
    if C.WINDOWS:
        return "windows"
    o = o or C.oturum_bul()
    d = ((o or {}).get("env") or {}).get("XDG_CURRENT_DESKTOP", "").lower()
    for ad in ("cinnamon", "xfce", "mate", "gnome", "kde", "budgie"):
        if ad in d:
            return ad
    for ad, prog in (("cinnamon", "cinnamon-session"), ("xfce", "xfce4-session"), ("gnome", "gnome-shell"), ("mate", "mate-session")):
        if shutil.which(prog):
            return ad
    return ""


def giris_yoneticisi():
    try:
        hedef = os.path.basename(os.path.realpath("/etc/systemd/system/display-manager.service")).replace(".service", "")
    except OSError:
        hedef = ""
    if hedef:
        return hedef
    for ad in ("lightdm", "gdm3", "gdm", "sddm"):
        if shutil.which(ad):
            return ad
    return ""


def aktif_oturum_kimligi():
    for satir in calistir(["loginctl", "list-sessions", "--no-legend"], 15)[1].splitlines():
        p = satir.split()
        if not p:
            continue
        d = dict(x.split("=", 1) for x in calistir(["loginctl", "show-session", p[0], "-p", "Active", "-p", "Class",
                                                      "-p", "Type", "-p", "Name"], 15)[1].splitlines() if "=" in x)
        if d.get("Active") == "yes" and d.get("Class") == "user" and d.get("Type") in ("x11", "wayland"):
            return p[0], d.get("Name")
    return None, None


def bugun_icin(v, tid, bugun=None):
    """Bugün gösterilecek masaüstü resmi: özel gün > sınıfa özel > genel. → ({sha, ad}, açıklama) ya da (None, "")"""
    t = bugun or time.localtime()
    ay_gun, tam = time.strftime("%m-%d", t), time.strftime("%Y-%m-%d", t)
    for g in v.get("ozel_gunler") or []:
        bas, bit = g.get("tarih") or "", g.get("bitis") or g.get("tarih") or ""
        if not g.get("sha"):
            continue
        if len(bas) == 10:
            if bas <= tam <= (bit if len(bit) == 10 else bas):
                return g, g.get("ad") or "özel gün"
        elif len(bas) == 5:
            bit = bit[-5:] if bit else bas
            if (bas <= ay_gun <= bit) if bas <= bit else (ay_gun >= bas or ay_gun <= bit):
                return g, g.get("ad") or "özel gün"
    ozel = (v.get("tahtaya_ozel") or {}).get(tid)
    if ozel and ozel.get("sha"):
        return ozel, "sınıfa özel"
    m = v.get("masaustu") or {}
    return (m, "genel") if m.get("sha") else (None, "")


class Arkaplan:
    """politika: oturum.arkaplan — veri: masaustu{sha, ad}, tahtaya_ozel{tahta: {sha, ad}},
    ozel_gunler[{tarih, bitis, ad, sha}], giris{sha, ad}, kilit_ekrani{sha, ad}, kilitle"""

    def __init__(self, o):
        self.o = o

    def resim(self, r):
        if not r or not r.get("sha"):
            return None
        uzanti = os.path.splitext(r.get("dosya") or r.get("ad") or "")[1].lower()
        uzanti = uzanti if uzanti in (".png", ".jpg", ".jpeg", ".bmp", ".webp") else ".jpg"
        klasor = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), "TahtaYonetim", "arkaplan") if C.WINDOWS else ARKAPLAN_LINUX
        os.makedirs(klasor, exist_ok=True)
        hedef = os.path.join(klasor, r["sha"][:16] + uzanti)
        if not os.path.exists(hedef):
            shutil.copy(self.o.a.modul("depo").indir(r["sha"]), hedef)
            os.chmod(hedef, 0o644)
        return hedef

    def klasor(self):
        k = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), "TahtaYonetim", "arkaplan") if C.WINDOWS else ARKAPLAN_LINUX
        os.makedirs(k, exist_ok=True)
        return k

    def uygula(self, p, kayit):
        with self.o.kilit:
            v = p["veri"]
            secim, neden = bugun_icin(v, self.o.a.id)
            masaustu = self.resim(secim)
            okul = self.o.a.modul("okul")
            oi = okul.arkaplan_imza() if okul else ""
            if oi:
                birlesik = okul.arkaplan_birlestir(masaustu, self.klasor())
                if birlesik and birlesik != masaustu:
                    masaustu = birlesik
                    neden = (neden + " + nöbet" if neden else "nöbet çizelgesi")
                elif okul.son_ciz_hata:
                    neden = (neden or "değişmedi") + " (nöbet çizilemedi: {})".format(okul.son_ciz_hata)
            giris = self.resim(v.get("giris"))
            kilit = self.resim(v.get("kilit_ekrani")) or giris
            kayit = dict(kayit or {})
            if C.WINDOWS:
                adimlar = self.windows(masaustu, kilit, bool(v.get("kilitle")), kayit)
            else:
                logo = None
                if v.get("giris_logo") and okul:
                    l = (okul.ayar().get("logo") or {})
                    kaynak = okul.depo_dosyasi(l.get("sha"), l.get("dosya"))
                    if kaynak:
                        logo = os.path.join(self.klasor(), "logo-" + l["sha"][:16] + (os.path.splitext(kaynak)[1] or ".png"))
                        if not os.path.exists(logo):
                            shutil.copy(kaynak, logo)
                            os.chmod(logo, 0o644)
                self.o.greeter_pol = {"giris": giris, "logo": logo, "bulanik": bool(v.get("giris_bulanik"))}
                adimlar = self.linux(masaustu, giris, kilit, bool(v.get("kilitle")), kayit)
            kayit["uygulanan"] = (secim or {}).get("sha")
            self.o.durum_yaz(p["id"], kayit["uygulanan"], self.o.imza(p, secim, oi), kayit)
            return {"durum": "tamam", "kayit": kayit,
                    "ayrinti": " · ".join(["Masaüstü: " + (neden or "değişmedi")] + adimlar)}

    # ── Pardus ──────────────────────────────────────────────────────────────
    def linux(self, masaustu, giris, kilit, kilitle, kayit):
        adimlar = []
        os.makedirs(os.path.dirname(DCONF_KILIT), exist_ok=True)
        if not os.path.exists(DCONF_PROFIL):
            os.makedirs(os.path.dirname(DCONF_PROFIL), exist_ok=True)
            with open(DCONF_PROFIL, "w") as f:
                f.write("user-db:user\nsystem-db:local\n")
            kayit["profil"] = "olusturuldu"
        elif "system-db:local" not in open(DCONF_PROFIL).read():
            with open(DCONF_PROFIL, "a") as f:
                f.write("system-db:local\n")
            kayit["profil"] = "eklendi"
        bolumler, kilitler = [], []
        if masaustu:
            uri = "file://" + masaustu
            bolumler += ["[org/gnome/desktop/background]\npicture-uri='{0}'\npicture-uri-dark='{0}'\npicture-options='zoom'\n".format(uri),
                         "[org/cinnamon/desktop/background]\npicture-uri='{}'\npicture-options='zoom'\n".format(uri),
                         "[org/cinnamon/desktop/background/slideshow]\nslideshow-enabled=false\n",
                         "[org/mate/desktop/background]\npicture-filename='{}'\npicture-options='zoom'\n".format(masaustu)]
            kilitler += ["/org/gnome/desktop/background/picture-uri", "/org/gnome/desktop/background/picture-uri-dark",
                         "/org/gnome/desktop/background/picture-options", "/org/cinnamon/desktop/background/picture-uri",
                         "/org/cinnamon/desktop/background/picture-options",
                         "/org/cinnamon/desktop/background/slideshow/slideshow-enabled",
                         "/org/mate/desktop/background/picture-filename"]
        if kilit:
            bolumler.append("[org/gnome/desktop/screensaver]\npicture-uri='file://{}'\n".format(kilit))
            kilitler.append("/org/gnome/desktop/screensaver/picture-uri")
        if giris:
            bolumler.append("[x/dm/slick-greeter]\nbackground='{}'\n".format(giris))
        with open(DCONF_DOSYA, "w") as f:
            f.write("# Tahta Yönetim Asistanı — arka plan\n" + "\n".join(bolumler))
        if kilitle and kilitler:
            with open(DCONF_KILIT, "w") as f:
                f.write("\n".join(kilitler) + "\n")
        elif os.path.exists(DCONF_KILIT):
            os.remove(DCONF_KILIT)
        if shutil.which("dconf"):
            calistir(["dconf", "update"], 60)
        pardus = os.path.isdir("/etc/pardus")
        if giris and os.path.isdir("/etc/lightdm") and not pardus:
            os.makedirs(os.path.dirname(GREETER), exist_ok=True)
            with open(GREETER, "w") as f:
                f.write("[greeter]\nbackground={}\n".format(giris))
            adimlar.append("giriş ekranı")
        elif os.path.exists(GREETER):
            os.remove(GREETER)
        if self.o.greeter_yaz() and giris:
            adimlar.append("giriş ekranı (Pardus karşılayıcı)")
        o = C.oturum_bul()
        tur = masaustu_turu(o) if o else ""
        if kilit:
            adimlar.append("kilit ekranı" if tur != "cinnamon" else "kilit ekranı: Cinnamon masaüstü resmini gösterir")
        if kilitle:
            self.xfce_kilit(True, kayit)
            adimlar.append("değiştirme kilitli")
        else:
            self.xfce_kilit(False, kayit)
        if o and masaustu:
            self.oturuma_uygula(o, masaustu)
        if kilitle and masaustu:
            adimlar.append(self.kilit_testi(o))
        return adimlar

    def kilit_testi(self, o):
        """Kilidin gerçekten çalıştığını oturumdaki kullanıcı adına dener."""
        if not o:
            return "kilit testi: oturum açılınca yapılacak"
        tur = masaustu_turu(o)
        if tur == "xfce":
            return "kilit: XFCE kiosk ayarı"
        sema = SEMA_ANAHTAR.get(tur)
        if not sema or not shutil.which("gsettings"):
            return "kilit testi yapılamadı"
        try:
            r = C.oturumda(["gsettings", "writable", sema[0], sema[1]], o, yakala=True, zaman_asimi=15)
            cikti = (r.stdout or b"").decode().strip()
        except Exception:
            cikti = ""
        if cikti == "false":
            self.o.kilit_durum = "calisiyor"
            return "Kilit çalışıyor ✓"
        if cikti == "true":
            self.o.kilit_durum = "calismiyor"
            return "Kilit ÇALIŞMIYOR (dconf profili okunmuyor; tahtayı yeniden başlatın)"
        return "kilit testi yapılamadı"

    def oturuma_uygula(self, o, resim):
        tur = masaustu_turu(o)
        uri = "file://" + resim
        try:
            if tur == "xfce" and shutil.which("xfconf-query"):
                r = C.oturumda(["xfconf-query", "-c", "xfce4-desktop", "-l"], o, yakala=True, zaman_asimi=15)
                for ozellik in (r.stdout or b"").decode().split():
                    if ozellik.endswith("/last-image") or ozellik.endswith("/image-path"):
                        C.oturumda(["xfconf-query", "-c", "xfce4-desktop", "-p", ozellik, "-s", resim], o, yakala=True, zaman_asimi=15)
            elif shutil.which("gsettings"):
                semalar = {"gnome": [("org.gnome.desktop.background", "picture-uri"), ("org.gnome.desktop.background", "picture-uri-dark")],
                           "cinnamon": [("org.cinnamon.desktop.background", "picture-uri")],
                           "mate": [("org.mate.background", "picture-filename")]}.get(tur, [("org.gnome.desktop.background", "picture-uri")])
                for sema, anahtar in semalar:
                    C.oturumda(["gsettings", "set", sema, anahtar, resim if anahtar == "picture-filename" else uri], o, yakala=True, zaman_asimi=15)
        except Exception as e:
            C.log("Arka plan oturuma uygulanamadı:", e)

    def xfce_kilit(self, ac, kayit):
        if not os.path.isdir("/etc/xdg/xfce4") and not ac:
            return
        try:
            metin = open(KIOSKRC, encoding="utf-8").read() if os.path.exists(KIOSKRC) else ""
        except OSError:
            metin = ""
        temiz = re.sub(r"# TYS-BASLA\n.*?# TYS-BITIR\n", "", metin, flags=re.S)
        if ac and os.path.isdir("/etc/xdg/xfce4"):
            temiz = temiz.rstrip("\n") + ("\n" if temiz.strip() else "") + "# TYS-BASLA\n[xfdesktop]\nCustomizeBackdrop=root\n# TYS-BITIR\n"
        if temiz != metin:
            os.makedirs(os.path.dirname(KIOSKRC), exist_ok=True)
            if temiz.strip():
                with open(KIOSKRC, "w", encoding="utf-8") as f:
                    f.write(temiz)
            elif os.path.exists(KIOSKRC):
                os.remove(KIOSKRC)

    # ── Windows ─────────────────────────────────────────────────────────────
    def windows(self, masaustu, kilit, kilitle, kayit):
        import winreg
        adimlar = []
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, CSP, 0, winreg.KEY_ALL_ACCESS) as h:
            for on, yol in (("DesktopImage", masaustu), ("LockScreenImage", kilit)):
                if yol:
                    winreg.SetValueEx(h, on + "Path", 0, winreg.REG_SZ, yol)
                    winreg.SetValueEx(h, on + "Url", 0, winreg.REG_SZ, yol)
                    winreg.SetValueEx(h, on + "Status", 0, winreg.REG_DWORD, 1)
                else:
                    for s in ("Path", "Url", "Status"):
                        try:
                            winreg.DeleteValue(h, on + s)
                        except OSError:
                            pass
        if kilit:
            adimlar.append("kilit / giriş ekranı")
        yol = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop"
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_ALL_ACCESS) as h:
            if "eski_kilit" not in kayit:
                try:
                    kayit["eski_kilit"] = winreg.QueryValueEx(h, "NoChangingWallPaper")[0]
                except OSError:
                    kayit["eski_kilit"] = None
            if kilitle:
                winreg.SetValueEx(h, "NoChangingWallPaper", 0, winreg.REG_DWORD, 1)
                adimlar.append("değiştirme kilitli")
            elif kayit.get("eski_kilit") is None:
                try:
                    winreg.DeleteValue(h, "NoChangingWallPaper")
                except OSError:
                    pass
        o = C.oturum_bul()
        if o and masaustu:
            C.oturumda(["reg.exe", "add", r"HKCU\Control Panel\Desktop", "/v", "Wallpaper", "/t", "REG_SZ", "/d", masaustu, "/f"],
                       o, yakala=True, zaman_asimi=20)
            C.oturumda(["reg.exe", "add", r"HKCU\Control Panel\Desktop", "/v", "WallpaperStyle", "/t", "REG_SZ", "/d", "10", "/f"],
                       o, yakala=True, zaman_asimi=20)
            C.oturumda(["rundll32.exe", "user32.dll,UpdatePerUserSystemParameters", "1", "True"], o, yakala=True, zaman_asimi=20)
        return adimlar

    def kaldir(self, kayit):
        if C.WINDOWS:
            import winreg
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, CSP, 0, winreg.KEY_ALL_ACCESS) as h:
                    for ad in ("DesktopImagePath", "DesktopImageUrl", "DesktopImageStatus", "LockScreenImagePath",
                               "LockScreenImageUrl", "LockScreenImageStatus"):
                        try:
                            winreg.DeleteValue(h, ad)
                        except OSError:
                            pass
            except OSError:
                pass
            with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop",
                                    0, winreg.KEY_ALL_ACCESS) as h:
                if kayit.get("eski_kilit") is None:
                    try:
                        winreg.DeleteValue(h, "NoChangingWallPaper")
                    except OSError:
                        pass
                else:
                    winreg.SetValueEx(h, "NoChangingWallPaper", 0, winreg.REG_DWORD, kayit["eski_kilit"])
            return
        for yol in (DCONF_DOSYA, DCONF_KILIT, GREETER):
            if os.path.exists(yol):
                os.remove(yol)
        self.o.greeter_pol = {}
        self.o.greeter_yaz()
        if kayit.get("profil") == "olusturuldu" and os.path.exists(DCONF_PROFIL):
            os.remove(DCONF_PROFIL)
        if shutil.which("dconf"):
            calistir(["dconf", "update"], 60)
        self.xfce_kilit(False, kayit)


class Oturum:
    def __init__(self, ajan):
        self.a = ajan
        self.kilit = threading.RLock()
        self.arkaplan = Arkaplan(self)
        self.durum_yolu = os.path.join(C.VERI, "arkaplan.json")
        d = C.json_oku(self.durum_yolu, {}) or {}
        self.greeter_pol = d.get("greeter") or {}
        self.kilit_durum = None
        p = ajan.modul("politika")
        if p:
            p.kaydet("oturum.arkaplan", self.arkaplan)

    def durum_yaz(self, pid, sha, imza=None, kayit=None):
        C.json_yaz(self.durum_yolu, {"politika": pid, "sha": sha, "gun": time.strftime("%Y-%m-%d"), "imza": imza,
                                     "kayit": kayit or {}, "greeter": self.greeter_pol})

    @staticmethod
    def imza(p, secim, okul_imza):
        return "{}:{}:{}:{}".format(p.get("id"), p.get("surum"), (secim or {}).get("sha"), okul_imza or "")

    def politikalar(self):
        return [p for p in (self.a.ayar or {}).get("politikalar") or []
                if isinstance(p, dict) and p.get("modul") == "oturum" and p.get("tur") == "arkaplan"]

    def arkaplan_kontrol(self):
        """Gün değişince (özel gün, nöbet) ya da nöbet çizelgesi değişince masaüstü resmini yeniden üretir.
        Arka plan ayarı yoksa ve nöbet masaüstüne çizilecekse okul tasarımını uygular."""
        with self.kilit:
            d = C.json_oku(self.durum_yolu, {}) or {}
            okul = self.a.modul("okul")
            oi = okul.arkaplan_imza() if okul else ""
            pl = self.politikalar()
            if pl:
                p = pl[-1]
                if d.get("politika") != p["id"]:
                    return                      # ilk uygulamayı politika modülü yapar
                secim, _ = bugun_icin(p.get("veri") or {}, self.a.id)
                if d.get("imza") != self.imza(p, secim, oi):
                    C.log("Arka plan yeniden uygulanıyor (gün ya da nöbet değişti)")
                    self.arkaplan.uygula(p, d.get("kayit") or {})
            elif oi:
                if d.get("imza") != self.imza(OKUL_POLITIKA, None, oi):
                    C.log("Nöbet çizelgesi masaüstü resmine çiziliyor")
                    self.arkaplan.uygula(OKUL_POLITIKA, d.get("kayit") if d.get("politika") == "okul" else {})
            elif d.get("politika") == "okul":
                self.arkaplan.kaldir(d.get("kayit") or {})
                self.greeter_pol = {}
                C.json_yaz(self.durum_yolu, {})
            elif d.get("politika") and d.get("imza"):
                self.greeter_pol = {}
                C.json_yaz(self.durum_yolu, {})

    def greeter_yaz(self):
        """Pardus karşılayıcısı (giriş ekranı): arka plan, okul logosu, bulanıklık ve giriş ekranı notu.
        ETAP'ın kendi dosyasına dokunulmaz; 90- önekli ayrı dosya yazılır. → yazıldıysa True"""
        if C.WINDOWS or not os.path.isdir("/etc/pardus") or not C.ROOT:
            return False
        okul = self.a.modul("okul")
        not_yolu = okul.giris_notu_yolu() if okul else None
        g = self.greeter_pol or {}
        satir = []
        gw = []
        if g.get("giris") and os.path.exists(g["giris"]):
            gw.append("background=" + g["giris"])
        if g.get("bulanik"):
            gw += ["background-blur=true", "background-blur-level=15"]
        if g.get("logo") and os.path.exists(g["logo"]):
            gw.append("logo=" + g["logo"])
        if gw:
            satir += ["[gtkwindow]"] + gw + [""]
        if not_yolu:
            satir += ["[notes]", "enabled=true", "editable=false", "text-file=" + not_yolu, ""]
        if satir:
            metin = "# Tahta Yönetim Asistanı — giriş ekranı (kaldırınca ETAP'ın ayarları geri gelir)\n" + "\n".join(satir)
            os.makedirs(PARDUS_GREETER_DIZIN, exist_ok=True)
            eski = open(PARDUS_GREETER, encoding="utf-8").read() if os.path.exists(PARDUS_GREETER) else None
            if eski != metin:
                with open(PARDUS_GREETER + ".tmp", "w", encoding="utf-8") as f:
                    f.write(metin)
                os.chmod(PARDUS_GREETER + ".tmp", 0o644)
                os.replace(PARDUS_GREETER + ".tmp", PARDUS_GREETER)
            d = C.json_oku(self.durum_yolu, {}) or {}
            if d.get("greeter") != self.greeter_pol:
                d["greeter"] = self.greeter_pol
                C.json_yaz(self.durum_yolu, d)
            return True
        if os.path.exists(PARDUS_GREETER):
            os.remove(PARDUS_GREETER)
        return False

    def durum(self):
        return {"arkaplan_kilit": self.kilit_durum} if self.kilit_durum else {}

    def donguler(self):
        return [self.gun_dongu]

    def gun_dongu(self):
        """Yedek denetim: okul modülü çalışmasa da özel günlerde resmi değiştirir (10 dakikada bir)."""
        time.sleep(90)
        while True:
            try:
                self.arkaplan_kontrol()
            except Exception as e:
                C.log("Arka plan günlük kontrolü:", e)
            time.sleep(600)

    def komut(self, tur, v, kaynak):
        if tur == "oturum_kapat":
            self.oturum_kapat()
            return True
        if tur == "kullanici_gecis":
            self.gecis(str(v.get("kullanici") or ""))
            return True
        return False

    def oturum_kapat(self):
        if C.WINDOWS:
            o = C.oturum_bul()
            if not o or o.get("oturum_id") is None:
                raise RuntimeError("Açık oturum yok")
            C.win_gizli(["logoff", str(o["oturum_id"])], 30)
            self.a.olay_gonder("sistem", "Oturum kapatıldı ({})".format(o.get("kullanici")))
            return
        sid, ad = aktif_oturum_kimligi()
        if not sid:
            raise RuntimeError("Açık oturum yok")
        r, c = calistir(["loginctl", "terminate-session", sid], 30)
        if r:
            raise RuntimeError("Oturum kapatılamadı: " + c.strip()[:200])
        self.a.olay_gonder("sistem", "Oturum kapatıldı ({})".format(ad))

    def gecis(self, kullanici):
        if not re.match(r"^[a-z_][a-z0-9_.\-]{0,31}\$?$", kullanici, re.I):
            raise RuntimeError("Geçersiz kullanıcı adı")
        if C.WINDOWS:
            self.oturum_kapat()
            self.a.olay_gonder("sistem", "Windows'ta şifresiz kullanıcı geçişi yapılamaz; oturum kapatıldı, giriş ekranından '{}' seçilebilir".format(kullanici))
            return
        import pwd
        try:
            pwd.getpwnam(kullanici)
        except KeyError:
            raise RuntimeError("Bu tahtada '{}' kullanıcısı yok".format(kullanici))
        dm = giris_yoneticisi()
        if dm == "lightdm":
            os.makedirs(os.path.dirname(LIGHTDM_GECIS), exist_ok=True)
            with open(LIGHTDM_GECIS, "w") as f:
                f.write("[Seat:*]\nautologin-user={}\nautologin-user-timeout=0\n".format(kullanici))
            geri = lambda: os.path.exists(LIGHTDM_GECIS) and os.remove(LIGHTDM_GECIS)
        elif dm in ("gdm", "gdm3"):
            yol = "/etc/gdm3/daemon.conf" if os.path.exists("/etc/gdm3/daemon.conf") else "/etc/gdm/custom.conf"
            eski = open(yol, encoding="utf-8").read() if os.path.exists(yol) else ""
            yeni = re.sub(r"(?m)^\s*(AutomaticLoginEnable|AutomaticLogin)\s*=.*\n?", "", eski)
            yeni = re.sub(r"(?m)^\[daemon\]\s*$", "[daemon]\nAutomaticLoginEnable=true\nAutomaticLogin={}".format(kullanici), yeni, 1) \
                if "[daemon]" in yeni else yeni + "\n[daemon]\nAutomaticLoginEnable=true\nAutomaticLogin={}\n".format(kullanici)
            with open(yol, "w", encoding="utf-8") as f:
                f.write(yeni)

            def geri():
                with open(yol, "w", encoding="utf-8") as f:
                    f.write(eski)
        else:
            raise RuntimeError("Bu tahtanın giriş yöneticisi ({}) için kullanıcı geçişi desteklenmiyor".format(dm or "bilinmiyor"))
        sid, ad = aktif_oturum_kimligi()
        if sid:
            calistir(["loginctl", "terminate-session", sid], 30)
        else:
            calistir(["systemctl", "restart", "display-manager"], 60)

        def bekle():
            for _ in range(60):
                time.sleep(3)
                s, a = aktif_oturum_kimligi()
                if a == kullanici:
                    break
            try:
                geri()
            except Exception as e:
                C.log("Geçiş ayarı geri alınamadı:", e)
        threading.Thread(target=bekle, daemon=True).start()
        self.a.olay_gonder("sistem", "Kullanıcı geçişi: {} → {}".format(ad or "-", kullanici))


def baslat(ajan):
    return Oturum(ajan)
