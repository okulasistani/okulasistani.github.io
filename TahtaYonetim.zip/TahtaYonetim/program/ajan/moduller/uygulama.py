# -*- coding: utf-8 -*-
"""Uygulama Merkezi: uygulama kurma/kaldırma/güncelleme (Pardus: depo, .deb, Flatpak, Wine; Windows: winget,
.msi, .exe), kurulu uygulama listesi, öğretmenin uygulama kurmasını kilitleme, tarayıcı politikaları,
başlangıç yönetimi ve açılış süresi. Tüm işler politika olarak gelir; kaldırılınca yalnızca kendi yaptığı geri alınır.
"""
SURUM = "3.6"
C = None

import os
import re
import sys
import glob
import json
import time
import shutil
import fnmatch
import threading

WINE_KOK = "/opt/tahta-wine"
POLKIT_UYG = "/etc/polkit-1/rules.d/49-tahta-yonetim-uygulama.rules"
TARAYICI_LINUX = ["/etc/opt/chrome/policies/managed", "/etc/chromium/policies/managed", "/etc/chromium-browser/policies/managed",
                  "/etc/opt/edge/policies/managed", "/etc/brave/policies/managed"]
FIREFOX_LINUX = ["/etc/firefox/policies", "/etc/firefox-esr/policies"]
CHROME_GUNCELLEME = "https://clients2.google.com/service/update2/crx"


def Y():
    return sys.modules["tys_modul_yazici"]


def calistir(args, zaman=600, env=None):
    return Y().calistir(args, zaman, env)


def eslesir(ad, desenler):
    ad = (ad or "").lower()
    return any(fnmatch.fnmatch(ad, d.lower()) for d in desenler or [])


def oturum_masaustu_dizini(o):
    """Oturumdaki kullanıcının masaüstü klasörü (Masaüstü / Desktop)."""
    if not o or not o.get("home"):
        return None
    try:
        r = C.oturumda(["xdg-user-dir", "DESKTOP"], o, yakala=True, zaman_asimi=10)
        yol = (r.stdout or b"").decode().strip()
        if yol and os.path.isdir(yol) and yol != o["home"]:
            return yol
    except Exception:
        pass
    for ad in ("Masaüstü", "Desktop"):
        if os.path.isdir(os.path.join(o["home"], ad)):
            return os.path.join(o["home"], ad)
    return None


# ═════════════════════════════════════════════════════════════════════════════
# Windows yardımcıları
# ═════════════════════════════════════════════════════════════════════════════
def win_kurulu():
    """Programlar ve Özellikler listesi: {anahtar: {ad, surum, yayinci, kaldir, sessiz_kaldir, msi}}"""
    import winreg
    sonuc = {}
    for kok, yol in ((winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                     (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall")):
        try:
            h = winreg.OpenKey(kok, yol)
        except OSError:
            continue
        with h:
            i = 0
            while True:
                try:
                    alt = winreg.EnumKey(h, i)
                except OSError:
                    break
                i += 1
                try:
                    with winreg.OpenKey(h, alt) as a:
                        d = {}
                        for n in ("DisplayName", "DisplayVersion", "Publisher", "UninstallString", "QuietUninstallString",
                                  "SystemComponent", "WindowsInstaller", "ParentKeyName"):
                            try:
                                d[n] = winreg.QueryValueEx(a, n)[0]
                            except OSError:
                                pass
                except OSError:
                    continue
                if not d.get("DisplayName") or d.get("SystemComponent") == 1 or d.get("ParentKeyName"):
                    continue
                sonuc[yol + "\\" + alt] = {"ad": d["DisplayName"], "surum": str(d.get("DisplayVersion") or ""),
                                           "yayinci": str(d.get("Publisher") or ""), "kaldir": d.get("UninstallString"),
                                           "sessiz_kaldir": d.get("QuietUninstallString"),
                                           "msi": alt if d.get("WindowsInstaller") == 1 and alt.startswith("{") else None}
    return sonuc


def winget_yolu():
    yol = shutil.which("winget")
    if yol:
        return yol
    adaylar = sorted(glob.glob(os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "WindowsApps",
                                            "Microsoft.DesktopAppInstaller_*_x64__8wekyb3d8bbwe", "winget.exe")))
    return adaylar[-1] if adaylar else None


def win_tarayici_yolu(ad):
    for kok in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        for yol in {"chrome": [r"Google\Chrome\Application\chrome.exe"], "edge": [r"Microsoft\Edge\Application\msedge.exe"],
                    "firefox": [r"Mozilla Firefox\firefox.exe"]}[ad]:
            if os.path.exists(os.path.join(kok, yol)):
                return os.path.join(kok, yol)
    return None


def _reg_liste_yaz(winreg, kok, yol, ad, liste):
    try:
        winreg.DeleteKey(kok, yol + "\\" + ad)
    except OSError:
        pass
    if liste:
        with winreg.CreateKeyEx(kok, yol + "\\" + ad, 0, winreg.KEY_SET_VALUE) as h:
            for i, v in enumerate(liste, 1):
                winreg.SetValueEx(h, str(i), 0, winreg.REG_SZ, v)


# ═════════════════════════════════════════════════════════════════════════════
# Uygulama kurulumu
# ═════════════════════════════════════════════════════════════════════════════
class Kur:
    """politika: uygulama.kur — veri: kimlik, ad, kaynak{tur: apt|deb|flatpak|wine|winget|msi|exe, paket, sha, dosya_ad,
    parametre, parametre_kaldir, calistir}, guncelle (sayaç)"""

    def __init__(self, u):
        self.u = u

    def uygula(self, p, kayit):
        v = p["veri"]
        k = v.get("kaynak") or {}
        tur = k.get("tur")
        win_tur = tur in ("winget", "msi", "exe")
        if win_tur != bool(C.WINDOWS) and not (tur == "wine" and not C.WINDOWS):
            return {"durum": "desteklenmiyor", "ayrinti": "Bu uygulama {} için".format("Windows" if win_tur else "Pardus")}
        if kayit and kayit.get("sha", "") == (k.get("sha") or "") and kayit.get("guncelle") == v.get("guncelle"):
            return {"durum": "tamam", "kayit": kayit, "ayrinti": kayit.get("ayrinti") or "Kurulu"}
        guncelleme = bool(kayit)
        fonk = getattr(self, "k_" + str(tur), None)
        if not fonk:
            return {"durum": "hata", "ayrinti": "Bilinmeyen kaynak: {}".format(tur)}
        s = fonk(v, k, kayit or {}, guncelleme)
        if s.get("durum", "tamam") == "tamam":
            s.setdefault("kayit", {}).update(sha=k.get("sha") or "", guncelle=v.get("guncelle"), tur=tur,
                                             ayrinti=s.get("ayrinti"))
            self.u.envanter_tetikle()
        return s

    def kaldir(self, kayit):
        tur = kayit.get("tur")
        if kayit.get("onceden"):
            return                              # biz kurmadık: dokunulmaz
        fonk = getattr(self, "s_" + str(tur), None)
        if fonk:
            fonk(kayit)
        self.u.envanter_tetikle()

    # ── Pardus ──────────────────────────────────────────────────────────────
    def _paket_kurulu(self, ad):
        return "install ok installed" in calistir(["dpkg-query", "-W", "-f=${Status}", ad], 20)[1]

    def k_apt(self, v, k, kayit, guncelleme):
        paketler = [x for x in re.split(r"[\s,]+", k.get("paket") or "") if re.match(r"^[a-z0-9][a-z0-9+.\-]+$", x)]
        if not paketler:
            return {"durum": "hata", "ayrinti": "Paket adı geçersiz"}
        onceden = kayit.get("onceden") if guncelleme else all(self._paket_kurulu(x) for x in paketler)
        calistir(["apt-get", "update"], 600)
        args = ["apt-get", "install", "-y", "--no-install-recommends"] + (["--only-upgrade"] if guncelleme else []) + paketler
        r, c = calistir(args, 3600)
        if r:
            return {"durum": "hata", "ayrinti": "Kurulamadı: " + (c.strip().splitlines() or ["?"])[-1][:300]}
        return {"durum": "tamam", "ayrinti": ("Güncellendi: " if guncelleme else "Kuruldu: ") + ", ".join(paketler),
                "kayit": {"paketler": paketler, "onceden": onceden}}

    def s_apt(self, kayit):
        paketler = [x for x in kayit.get("paketler") or [] if not eslesir(x, self.u.koruma("linux_paketler"))]
        if paketler:
            calistir(["apt-get", "remove", "-y"] + paketler, 1800)

    def k_deb(self, v, k, kayit, guncelleme):
        dosya = self.u.a.modul("depo").indir(k["sha"])
        r, ad = calistir(["dpkg-deb", "-f", dosya, "Package"], 30)
        ad = ad.strip()
        if r or not ad:
            return {"durum": "hata", "ayrinti": "Geçersiz .deb dosyası"}
        onceden = kayit.get("onceden") if guncelleme else self._paket_kurulu(ad)
        r, c = calistir(["dpkg", "-i", dosya], 1800)
        if r:
            r2, c2 = calistir(["apt-get", "-f", "-y", "install"], 1800)
            if r2 or not self._paket_kurulu(ad):
                return {"durum": "hata", "ayrinti": "Kurulamadı: " + (c.strip().splitlines() or ["?"])[-1][:300]}
        return {"durum": "tamam", "ayrinti": "Kuruldu: " + ad, "kayit": {"paketler": [ad], "onceden": onceden}}

    s_deb = s_apt

    def k_flatpak(self, v, k, kayit, guncelleme):
        if not shutil.which("flatpak"):
            r, c = calistir(["apt-get", "install", "-y", "flatpak"], 1800)
            if r:
                return {"durum": "hata", "ayrinti": "Flatpak kurulamadı"}
        if k.get("sha"):
            dosya = self.u.a.modul("depo").indir(k["sha"])
            bicim = "--from" if (k.get("dosya_ad") or "").endswith(".flatpakref") else "--bundle"
            r, c = calistir(["flatpak", "install", "-y", "--noninteractive", "--system", bicim, dosya], 3600)
            m = re.search(r"([A-Za-z0-9_.\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)", k.get("paket") or "") or \
                re.search(r"Installing .*?([a-zA-Z][\w\-]*\.[\w\-]+\.[\w.\-]+)", c)
            kimlik = m.group(1) if m else ""
        else:
            kimlik = (k.get("paket") or "").strip()
            if not re.match(r"^[A-Za-z0-9_.\-]+$", kimlik):
                return {"durum": "hata", "ayrinti": "Flatpak kimliği geçersiz (ör. org.geogebra.GeoGebra)"}
            calistir(["flatpak", "remote-add", "--system", "--if-not-exists", "flathub",
                      "https://dl.flathub.org/repo/flathub.flatpakrepo"], 300)
            args = ["flatpak", "update", "-y", "--noninteractive", "--system", kimlik] if guncelleme else \
                ["flatpak", "install", "-y", "--noninteractive", "--system", "flathub", kimlik]
            r, c = calistir(args, 3600)
        if r:
            return {"durum": "hata", "ayrinti": "Kurulamadı: " + (c.strip().splitlines() or ["?"])[-1][:300]}
        return {"durum": "tamam", "ayrinti": "Kuruldu (Flatpak): " + kimlik, "kayit": {"flatpak": kimlik}}

    def s_flatpak(self, kayit):
        if kayit.get("flatpak"):
            calistir(["flatpak", "uninstall", "-y", "--noninteractive", "--system", kayit["flatpak"]], 1800)

    def k_wine(self, v, k, kayit, guncelleme):
        """Windows programı Pardus'ta Wine ile: sessiz kurulum, menü ve masaüstü kısayolu."""
        if not shutil.which("wine"):
            calistir(["dpkg", "--add-architecture", "i386"], 60)
            calistir(["apt-get", "update"], 900)
            r, c = calistir(["apt-get", "install", "-y", "wine"], 3600)
            if r or not shutil.which("wine"):
                return {"durum": "hata", "ayrinti": "Wine kurulamadı: " + (c.strip().splitlines() or ["?"])[-1][:200]}
        kimlik = re.sub(r"[^a-z0-9]", "", (v.get("kimlik") or "uyg").lower())[:24]
        onek = os.path.join(WINE_KOK, kimlik)
        os.makedirs(onek, exist_ok=True)
        env = {"WINEPREFIX": onek, "WINEDEBUG": "-all", "WINEDLLOVERRIDES": "mscoree,mshtml="}
        kip = ["xvfb-run", "-a"] if shutil.which("xvfb-run") else []
        calistir(kip + ["wineboot", "-i"], 600, env)
        once = set(glob.glob(os.path.join(onek, "drive_c", "**", "*.exe"), recursive=True))
        dosya = self.u.a.modul("depo").indir(k["sha"])
        uzanti = ".msi" if (k.get("dosya_ad") or "").lower().endswith(".msi") else ".exe"
        kurulum = os.path.join(onek, "kurulum" + uzanti)
        shutil.copy(dosya, kurulum)
        ek = re.findall(r'"[^"]*"|\S+', k.get("parametre") or "")
        args = (["wine", "msiexec", "/i", kurulum] + (ek or ["/qn"])) if uzanti == ".msi" else ["wine", kurulum] + ek
        r, c = calistir(kip + [a.strip('"') for a in args], 3600, env)
        calistir(kip + ["wineserver", "-w"], 600, env)
        os.remove(kurulum)
        hedef = k.get("calistir") or ""
        if hedef:
            yol = hedef
        else:
            yeni = [x for x in set(glob.glob(os.path.join(onek, "drive_c", "**", "*.exe"), recursive=True)) - once
                    if not re.search(r"(unins|setup|install|update|crash|helper|redist|vcredist)", os.path.basename(x), re.I)]
            if not yeni:
                return {"durum": "hata", "ayrinti": "Kurulum programı çalıştı (çıkış {}) ama program dosyası bulunamadı. "
                                                    "Sessiz kurulum parametresini ya da 'Çalıştırılacak dosya'yı kontrol edin.".format(r)}
            yeni.sort(key=lambda x: (-os.path.getsize(x), len(x)))
            yol = yeni[0]
        if os.path.isabs(yol) and yol.startswith(onek):
            winyol = "C:\\" + os.path.relpath(yol, os.path.join(onek, "drive_c")).replace("/", "\\")
        else:
            winyol = yol
        calistir(["chmod", "-R", "a+rwX", onek], 300)
        ad = v.get("ad") or kimlik
        masaustu = "[Desktop Entry]\nType=Application\nName={}\nExec=env WINEPREFIX={} WINEDEBUG=-all wine \"{}\"\n" \
                   "Icon=wine\nCategories=Education;Wine;\nComment=Wine ile çalışır (Tahta Yönetim Asistanı)\n".format(
                       ad, onek, winyol.replace("\\", "\\\\"))
        menu = "/usr/share/applications/tahta-wine-{}.desktop".format(kimlik)
        with open(menu, "w", encoding="utf-8") as f:
            f.write(masaustu)
        os.chmod(menu, 0o644)
        kisayollar = [menu]
        o = C.oturum_bul()
        md = oturum_masaustu_dizini(o)
        if md:
            k2 = os.path.join(md, "tahta-wine-{}.desktop".format(kimlik))
            with open(k2, "w", encoding="utf-8") as f:
                f.write(masaustu)
            os.chmod(k2, 0o755)
            try:
                os.chown(k2, o["uid"], o["gid"])
                C.oturumda(["gio", "set", k2, "metadata::trusted", "true"], o, yakala=True, zaman_asimi=10)
            except Exception:
                pass
            kisayollar.append(k2)
        return {"durum": "tamam", "ayrinti": "Wine ile kuruldu: {} · menü{} kısayolu eklendi".format(winyol, " ve masaüstü" if md else ""),
                "kayit": {"onek": onek, "kisayollar": kisayollar}, "sonuc": {"wine": "kuruldu", "calistir": winyol}}

    def s_wine(self, kayit):
        for yol in kayit.get("kisayollar") or []:
            try:
                os.remove(yol)
            except OSError:
                pass
        onek = kayit.get("onek") or ""
        if onek.startswith(WINE_KOK + "/") and os.path.isdir(onek):
            shutil.rmtree(onek, ignore_errors=True)

    # ── Windows ─────────────────────────────────────────────────────────────
    def k_winget(self, v, k, kayit, guncelleme):
        wg = winget_yolu()
        if not wg:
            return {"durum": "hata", "ayrinti": "Bu cihazda winget (Uygulama Yükleyici) yok"}
        kimlik = (k.get("paket") or "").strip()
        if not re.match(r"^[A-Za-z0-9_.\-+]+$", kimlik):
            return {"durum": "hata", "ayrinti": "winget kimliği geçersiz (ör. Google.Chrome)"}
        once = set(win_kurulu())
        args = [wg, "upgrade" if guncelleme else "install", "--id", kimlik, "-e", "--silent", "--accept-package-agreements",
                "--accept-source-agreements", "--disable-interactivity"] + ([] if guncelleme else ["--scope", "machine"])
        r, c = C.win_gizli(args, 3600)
        if r and not guncelleme and "--scope" in args:
            r, c = C.win_gizli([a for a in args if a not in ("--scope", "machine")], 3600)
        if r and not (guncelleme and r in (0x8A15002B,)) and "already installed" not in c.lower() and "zaten" not in c.lower():
            return {"durum": "hata", "ayrinti": "winget: " + (c.strip().splitlines() or ["?"])[-1][:300]}
        yeni = set(win_kurulu()) - once
        return {"durum": "tamam", "ayrinti": ("Güncellendi: " if guncelleme else "Kuruldu: ") + kimlik,
                "kayit": {"winget": kimlik, "onceden": kayit.get("onceden") if guncelleme else not yeni and r != 0}}

    def s_winget(self, kayit):
        wg = winget_yolu()
        if wg and kayit.get("winget"):
            C.win_gizli([wg, "uninstall", "--id", kayit["winget"], "-e", "--silent", "--accept-source-agreements",
                         "--disable-interactivity"], 1800)

    def _win_dosya(self, v, k, kayit, guncelleme, msi):
        dosya = self.u.a.modul("depo").indir(k["sha"])
        hedef = dosya + (".msi" if msi else ".exe")
        if not os.path.exists(hedef):
            shutil.copy(dosya, hedef)
        once = win_kurulu()
        ek = re.findall(r'"[^"]*"|\S+', k.get("parametre") or "")
        args = (["msiexec.exe", "/i", hedef] + (ek or ["/qn", "/norestart"])) if msi else [hedef] + ek
        r, c = C.win_gizli([a.strip('"') for a in args], 3600)
        sonra = win_kurulu()
        yeni = [sonra[x] for x in sonra if x not in once or sonra[x].get("surum") != once[x].get("surum")]
        if r not in (0, 3010, 1641) and not yeni:
            return {"durum": "hata", "ayrinti": "Kurulum programı hata verdi (çıkış kodu {}). Sessiz kurulum parametresini kontrol edin.".format(r)}
        kayit = dict(kayit) if guncelleme else {}
        if yeni:
            kayit["girdi"] = yeni[0]
        return {"durum": "tamam", "ayrinti": "Kuruldu: " + (yeni[0]["ad"] if yeni else v.get("ad") or "") +
                (" (yeniden başlatma gerekebilir)" if r in (3010, 1641) else ""), "kayit": kayit}

    def k_msi(self, v, k, kayit, guncelleme):
        return self._win_dosya(v, k, kayit, guncelleme, True)

    def k_exe(self, v, k, kayit, guncelleme):
        s = self._win_dosya(v, k, kayit, guncelleme, False)
        if s.get("durum") == "tamam":
            s["kayit"]["parametre_kaldir"] = k.get("parametre_kaldir") or ""
        return s

    def s_msi(self, kayit):
        g = kayit.get("girdi") or {}
        if eslesir(g.get("ad"), self.u.koruma("windows_uygulamalar")):
            return
        if g.get("msi"):
            C.win_gizli(["msiexec.exe", "/x", g["msi"], "/qn", "/norestart"], 1800)
        elif g.get("sessiz_kaldir"):
            C.win_gizli(["cmd.exe", "/c", g["sessiz_kaldir"]], 1800)
        elif g.get("kaldir"):
            ek = kayit.get("parametre_kaldir") or "/S"
            C.win_gizli(["cmd.exe", "/c", "{} {}".format(g["kaldir"], ek)], 1800)

    s_exe = s_msi


class UygulamaKilit:
    """politika: uygulama.kilit — öğretmen uygulama kurup kaldıramaz."""

    def __init__(self, u):
        self.u = u

    def uygula(self, p, kayit):
        if kayit:
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Uygulama kurma/kaldırma kilitli"}
        if C.WINDOWS:
            import winreg
            eski = {}
            for yol, ad in ((r"SOFTWARE\Policies\Microsoft\Windows\Installer", "DisableMSI"),
                            (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Programs", "NoProgramsCPL"),
                            (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Programs", "NoWindowsFeatures")):
                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as h:
                    try:
                        eski[yol + "|" + ad] = winreg.QueryValueEx(h, ad)[0]
                    except OSError:
                        eski[yol + "|" + ad] = None
                    winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, 1)
            return {"durum": "tamam", "ayrinti": "Uygulama kurma/kaldırma yöneticiye kilitlendi", "kayit": {"kayit": eski}}
        kural = ("// Tahta Yönetim Asistanı: uygulama kurma/kaldırma yalnızca yöneticide\npolkit.addRule(function(action, subject) {\n"
                 "  var y = [\"org.freedesktop.packagekit.\", \"org.freedesktop.Flatpak.\", \"tr.org.pardus.\", \"org.debian.apt.\",\n"
                 "           \"com.ubuntu.pkexec.synaptic\", \"org.gnome.software.\", \"org.mate.mate-software\"];\n"
                 "  for (var i = 0; i < y.length; i++) {\n"
                 "    if (action.id.indexOf(y[i]) == 0 && subject.user != \"root\") { return polkit.Result.NO; }\n  }\n});\n")
        if not os.path.isdir(os.path.dirname(POLKIT_UYG)):
            return {"durum": "hata", "ayrinti": "polkit kural klasörü yok"}
        with open(POLKIT_UYG, "w") as f:
            f.write(kural)
        os.chmod(POLKIT_UYG, 0o644)
        return {"durum": "tamam", "ayrinti": "Uygulama kurma/kaldırma yöneticiye kilitlendi", "kayit": {"dosya": POLKIT_UYG}}

    def kaldir(self, kayit):
        if C.WINDOWS:
            import winreg
            for an, deger in (kayit.get("kayit") or {}).items():
                yol, ad = an.split("|", 1)
                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_SET_VALUE) as h:
                    if deger is None:
                        try:
                            winreg.DeleteValue(h, ad)
                        except OSError:
                            pass
                    else:
                        winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, deger)
            return
        try:
            os.remove(kayit.get("dosya") or POLKIT_UYG)
        except OSError:
            pass


# ═════════════════════════════════════════════════════════════════════════════
# Tarayıcı politikaları (Chrome / Chromium / Edge / Firefox)
# ═════════════════════════════════════════════════════════════════════════════
class Tarayici:
    """politika: tarayici.ayar — veri: anasayfa, acilis[], yer_imleri[{ad, url}], klasor, uzanti_zorla[], uzanti_kaldir[],
    engelli[], yeniden_baslat. Aynı cihaza gelen birden çok tarayıcı ayarı birleştirilir."""

    def __init__(self, u):
        self.u = u

    def birlesik(self, haric=None):
        b = {"anasayfa": "", "acilis": [], "yer_imleri": [], "klasor": "Okul", "uzanti_zorla": [], "uzanti_kaldir": [], "engelli": []}
        for p in (self.u.a.ayar or {}).get("politikalar") or []:
            if not isinstance(p, dict) or p.get("modul") != "tarayici" or p.get("tur") != "ayar" or p.get("id") == haric:
                continue
            v = p.get("veri") or {}
            if v.get("anasayfa"):
                b["anasayfa"] = v["anasayfa"]
            if v.get("klasor"):
                b["klasor"] = v["klasor"]
            for k in ("acilis", "uzanti_zorla", "uzanti_kaldir", "engelli"):
                b[k] += [x for x in v.get(k) or [] if x not in b[k]]
            b["yer_imleri"] += [x for x in v.get("yer_imleri") or [] if x not in b["yer_imleri"]]
        return b

    def uygula(self, p, kayit):
        b = self.birlesik()
        yazilan = self.yaz(b)
        if (p.get("veri") or {}).get("yeniden_baslat"):
            self.yeniden_baslat()
        return {"durum": "tamam", "kayit": {"yazildi": True},
                "ayrinti": "Tarayıcı ayarları uygulandı ({})".format(", ".join(yazilan) or "tarayıcı bulunamadı; kurulunca geçerli olur")}

    def kaldir(self, kayit):
        self.yaz(self.birlesik())                 # bu politika artık listede yok: kalanlarla yeniden yazılır

    def chrome_json(self, b):
        d = {}
        if b["anasayfa"]:
            d.update(HomepageLocation=b["anasayfa"], HomepageIsNewTabPage=False, ShowHomeButton=True)
        if b["acilis"]:
            d.update(RestoreOnStartup=4, RestoreOnStartupURLs=b["acilis"])
        if b["yer_imleri"]:
            d["ManagedBookmarks"] = [{"toplevel_name": b["klasor"] or "Okul"}] + [{"name": x["ad"], "url": x["url"]} for x in b["yer_imleri"]]
            d["BookmarkBarEnabled"] = True
        if b["uzanti_zorla"]:
            d["ExtensionInstallForcelist"] = ["{};{}".format(x, CHROME_GUNCELLEME) for x in b["uzanti_zorla"]]
        if b["uzanti_kaldir"]:
            d["ExtensionInstallBlocklist"] = b["uzanti_kaldir"]
        if b["engelli"]:
            d["URLBlocklist"] = b["engelli"]
        return d

    def firefox_json(self, b):
        pol = {}
        if b["anasayfa"] or b["acilis"]:
            pol["Homepage"] = {"URL": b["anasayfa"] or b["acilis"][0], "Locked": True,
                               "Additional": b["acilis"] if b["anasayfa"] else b["acilis"][1:],
                               "StartPage": "homepage-locked"}
        if b["yer_imleri"]:
            pol["ManagedBookmarks"] = [{"toplevel_name": b["klasor"] or "Okul"}] + [{"name": x["ad"], "url": x["url"]} for x in b["yer_imleri"]]
        if b["engelli"]:
            pol["WebsiteFilter"] = {"Block": ["*://{}/*".format(x.strip("/").split("://")[-1]) for x in b["engelli"]] +
                                    ["*://*.{}/*".format(x.strip("/").split("://")[-1]) for x in b["engelli"] if "/" not in x.split("://")[-1]]}
        return {"policies": pol}

    def yaz(self, b):
        cd, fd = self.chrome_json(b), self.firefox_json(b)
        bos = not cd
        yazilan = []
        if C.WINDOWS:
            import winreg
            for marka, yol in (("Chrome", r"SOFTWARE\Policies\Google\Chrome"), ("Edge", r"SOFTWARE\Policies\Microsoft\Edge")):
                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, yol, 0, winreg.KEY_ALL_ACCESS) as h:
                    for ad in ("HomepageLocation", "HomepageIsNewTabPage", "ShowHomeButton", "RestoreOnStartup",
                               "ManagedBookmarks", "BookmarkBarEnabled"):
                        if ad not in cd:
                            try:
                                winreg.DeleteValue(h, ad)
                            except OSError:
                                pass
                    for ad, deger in cd.items():
                        if isinstance(deger, bool):
                            winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, int(deger))
                        elif isinstance(deger, int):
                            winreg.SetValueEx(h, ad, 0, winreg.REG_DWORD, deger)
                        elif ad == "ManagedBookmarks":
                            winreg.SetValueEx(h, ad, 0, winreg.REG_SZ, json.dumps(deger, ensure_ascii=False))
                        elif isinstance(deger, str):
                            winreg.SetValueEx(h, ad, 0, winreg.REG_SZ, deger)
                for ad in ("RestoreOnStartupURLs", "ExtensionInstallForcelist", "ExtensionInstallBlocklist", "URLBlocklist"):
                    liste = cd.get(ad) or []
                    if marka == "Edge" and ad == "ExtensionInstallForcelist":
                        liste = []                    # Chrome mağazası kimlikleri Edge'de geçerli değil
                    _reg_liste_yaz(winreg, winreg.HKEY_LOCAL_MACHINE, yol, ad, liste)
                yazilan.append(marka)
            ff = win_tarayici_yolu("firefox")
            if ff:
                d = os.path.join(os.path.dirname(ff), "distribution")
                os.makedirs(d, exist_ok=True)
                self._json_yaz(os.path.join(d, "policies.json"), None if not fd["policies"] else fd)
                yazilan.append("Firefox")
            return yazilan
        for d in TARAYICI_LINUX:
            hedef = os.path.join(d, "tahta-yonetim.json")
            if bos:
                if os.path.exists(hedef):
                    os.remove(hedef)
                continue
            if os.path.isdir(os.path.dirname(os.path.dirname(d))) or d.startswith("/etc/opt/chrome"):
                os.makedirs(d, exist_ok=True)
                self._json_yaz(hedef, cd)
                yazilan.append(d.split("/")[2] if d.split("/")[2] != "opt" else d.split("/")[3])
        for d in FIREFOX_LINUX + glob.glob("/usr/lib/firefox*/distribution"):
            if not os.path.isdir(os.path.dirname(d)):
                continue
            hedef = os.path.join(d, "policies.json")
            self._json_yaz(hedef, None if not fd["policies"] else fd)
            yazilan.append("Firefox")
        return sorted(set(yazilan))

    def _json_yaz(self, yol, veri):
        if veri is None:
            if os.path.exists(yol):
                try:
                    if json.load(open(yol, encoding="utf-8")).get("_tahta_yonetim"):
                        os.remove(yol)
                except (OSError, ValueError):
                    pass
            return
        if isinstance(veri, dict) and "policies" in veri:
            veri = dict(veri, _tahta_yonetim=True)
        os.makedirs(os.path.dirname(yol), exist_ok=True)
        with open(yol + ".yeni", "w", encoding="utf-8") as f:
            json.dump(veri, f, ensure_ascii=False, indent=1)
        os.chmod(yol + ".yeni", 0o644)
        os.replace(yol + ".yeni", yol)

    def tarayici_bul(self):
        if C.WINDOWS:
            for ad in ("chrome", "edge", "firefox"):
                y = win_tarayici_yolu(ad)
                if y:
                    return ad, y
            return None, None
        for ad in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "firefox-esr", "firefox"):
            y = shutil.which(ad)
            if y:
                return ("firefox" if "firefox" in ad else "chrome"), y
        return None, None

    def kapat_hepsi(self, o):
        if C.WINDOWS:
            for exe in ("chrome.exe", "msedge.exe", "firefox.exe"):
                C.win_gizli(["taskkill", "/F", "/IM", exe], 30)
        elif o:
            for ad in ("chrome", "chromium", "firefox"):
                calistir(["pkill", "-u", str(o["uid"]), "-f", ad], 10)
        time.sleep(1.5)

    def yeniden_baslat(self):
        o = C.oturum_bul()
        tur, yol = self.tarayici_bul()
        if not o or not yol:
            return
        self.kapat_hepsi(o)
        C.oturumda([yol] + (["--restore-last-session"] if tur == "chrome" else []), o)

    def kiosk(self, url, kapat=False):
        o = C.oturum_bul()
        if not o:
            raise RuntimeError("Tahtada açık oturum yok")
        tur, yol = self.tarayici_bul()
        if not yol:
            raise RuntimeError("Tahtada Chrome/Chromium/Firefox bulunamadı")
        self.kapat_hepsi(o)
        if kapat:
            return
        if not re.match(r"^https?://", url or "", re.I):
            raise RuntimeError("Geçersiz adres")
        args = [yol, "--kiosk", url] + (["--no-first-run", "--disable-session-crashed-bubble", "--incognito"] if tur == "chrome" else [])
        C.oturumda(args, o)


# ═════════════════════════════════════════════════════════════════════════════
# Başlangıç yönetimi
# ═════════════════════════════════════════════════════════════════════════════
class Baslangic:
    """politika: baslangic.kapat — veri: oge{tur, kimlik, ad}; baslangic.ekle — veri: kimlik, ad, komut"""

    def __init__(self, u, ekle=False):
        self.u, self.ekle = u, ekle

    def korumali(self, oge):
        k = self.u.koruma
        ad = oge.get("ad") or ""
        kim = oge.get("kimlik") or ""
        if oge.get("tur") == "servis":
            return eslesir(kim, k("windows_servisler" if C.WINDOWS else "linux_servisler"))
        if oge.get("tur") == "gorev":
            return eslesir(kim, k("windows_gorevler"))
        if oge.get("tur") == "autostart":
            return eslesir(os.path.basename(kim).replace(".desktop", ""), k("linux_otomatik_baslayanlar"))
        return "tahta" in ad.lower() and "yönetim" in ad.lower()

    def uygula(self, p, kayit):
        v = p["veri"]
        if self.ekle:
            return self.ekle_uygula(v, kayit)
        oge = v.get("oge") or {}
        if self.korumali(oge):
            return {"durum": "hata", "ayrinti": "Bu öğe korunuyor; kapatılamaz ({})".format(oge.get("ad"))}
        if kayit:
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Devre dışı: " + (oge.get("ad") or "")}
        fonk = getattr(self, ("w_" if C.WINDOWS else "l_") + str(oge.get("tur")), None)
        if not fonk:
            return {"durum": "desteklenmiyor", "ayrinti": "Bu cihazda bu öğe türü yok"}
        kayit = fonk(oge, True)
        if kayit is None:
            return {"durum": "bekliyor", "ayrinti": "Öğe bu cihazda bulunamadı: " + (oge.get("ad") or "")}
        self.u.envanter_tetikle()
        return {"durum": "tamam", "kayit": kayit, "ayrinti": "Devre dışı bırakıldı: " + (oge.get("ad") or "")}

    def kaldir(self, kayit):
        if kayit.get("ekle"):
            self.ekle_kaldir(kayit)
        else:
            fonk = getattr(self, ("w_" if C.WINDOWS else "l_") + str(kayit.get("tur")), None)
            if fonk:
                fonk(kayit, False)
        self.u.envanter_tetikle()

    # Pardus
    def l_autostart(self, oge, kapat):
        yol = oge.get("kimlik") or ""
        if not (yol.startswith("/etc/xdg/autostart/") or "/.config/autostart/" in yol) or not yol.endswith(".desktop"):
            return None
        if kapat:
            if not os.path.exists(yol):
                return None
            metin = open(yol, encoding="utf-8", errors="replace").read()
            yeni = re.sub(r"(?m)^(Hidden|X-GNOME-Autostart-enabled)=.*\n?", "", metin).rstrip("\n") + \
                "\nHidden=true\nX-GNOME-Autostart-enabled=false\n"
            with open(yol, "w", encoding="utf-8") as f:
                f.write(yeni)
            return {"tur": "autostart", "kimlik": yol, "eski": metin}
        if oge.get("eski") is not None:
            with open(yol, "w", encoding="utf-8") as f:
                f.write(oge["eski"])

    def l_servis(self, oge, kapat):
        ad = oge.get("kimlik") or ""
        if not re.match(r"^[\w@.\-]+$", ad):
            return None
        if kapat:
            durum = calistir(["systemctl", "is-enabled", ad], 20)[1].strip()
            if durum not in ("enabled", "enabled-runtime"):
                return None if durum in ("", "not-found") else {"tur": "servis", "kimlik": ad, "eski": durum}
            calistir(["systemctl", "disable", ad], 60)
            return {"tur": "servis", "kimlik": ad, "eski": durum}
        if oge.get("eski", "").startswith("enabled"):
            calistir(["systemctl", "enable", ad], 60)

    # Windows
    def _onay_yolu(self, oge):
        """Run ve Başlangıç klasörü öğeleri için Görev Yöneticisi'nin kullandığı StartupApproved değeri."""
        k = oge.get("kimlik") or ""
        kok, alt = k.split("|", 1) if "|" in k else ("", "")
        return kok, alt

    def w_run(self, oge, kapat):
        import winreg
        kok, deger = self._onay_yolu(oge)          # kök: "HKLM", "HKLM32" ya da "HKU\\<sid>"
        if not deger:
            return None
        h_kok = winreg.HKEY_LOCAL_MACHINE if kok.startswith("HKLM") else winreg.HKEY_USERS
        on = "" if kok.startswith("HKLM") else kok.split("\\", 1)[1] + "\\"
        yol = on + r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" + ("32" if kok == "HKLM32" else "")
        return self._onay_yaz(winreg, h_kok, yol, deger, kapat, oge)

    def w_klasor(self, oge, kapat):
        import winreg
        kok, dosya = self._onay_yolu(oge)
        if not dosya:
            return None
        h_kok = winreg.HKEY_LOCAL_MACHINE if kok.startswith("HKLM") else winreg.HKEY_USERS
        on = "" if kok.startswith("HKLM") else kok.split("\\", 1)[1] + "\\"
        return self._onay_yaz(winreg, h_kok, on + r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder",
                              dosya, kapat, oge)

    def _onay_yaz(self, winreg, kok, yol, ad, kapat, oge):
        if kapat:
            with winreg.CreateKeyEx(kok, yol, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as h:
                try:
                    eski = winreg.QueryValueEx(h, ad)[0].hex()
                except OSError:
                    eski = None
                winreg.SetValueEx(h, ad, 0, winreg.REG_BINARY, bytes([3, 0, 0, 0]) + bytes(8))
            return {"tur": oge["tur"], "kimlik": oge["kimlik"], "eski": eski}
        with winreg.CreateKeyEx(kok, yol, 0, winreg.KEY_SET_VALUE) as h:
            if oge.get("eski"):
                winreg.SetValueEx(h, ad, 0, winreg.REG_BINARY, bytes.fromhex(oge["eski"]))
            else:
                try:
                    winreg.DeleteValue(h, ad)
                except OSError:
                    pass

    def w_gorev(self, oge, kapat):
        ad = oge.get("kimlik") or ""
        r, c = C.win_gizli(["schtasks", "/Change", "/TN", ad, "/DISABLE" if kapat else "/ENABLE"], 60)
        if kapat and r:
            return None
        return {"tur": "gorev", "kimlik": ad} if kapat else None

    def w_servis(self, oge, kapat):
        ad = oge.get("kimlik") or ""
        if not re.match(r"^[\w.\- ]+$", ad):
            return None
        if kapat:
            r, c = C.win_ps("(Get-CimInstance Win32_Service -Filter \"Name='{}'\").StartMode".format(ad), 60)
            eski = c.strip()
            if r or not eski:
                return None
            C.win_gizli(["sc.exe", "config", ad, "start=", "disabled"], 60)
            return {"tur": "servis", "kimlik": ad, "eski": eski}
        tur = {"Auto": "auto", "Manual": "demand"}.get(oge.get("eski"), "auto")
        C.win_gizli(["sc.exe", "config", ad, "start=", tur], 60)

    # Yeni başlangıç öğesi
    def ekle_uygula(self, v, kayit):
        kimlik = re.sub(r"[^a-z0-9]", "", (v.get("kimlik") or "").lower())[:20] or "oge"
        komut = (v.get("komut") or "").strip()
        if not komut:
            return {"durum": "hata", "ayrinti": "Komut boş"}
        if C.WINDOWS:
            import winreg
            ad = "TahtaYonetim_" + kimlik
            with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as h:
                winreg.SetValueEx(h, ad, 0, winreg.REG_SZ, komut)
            return {"durum": "tamam", "kayit": {"ekle": True, "deger": ad}, "ayrinti": "Açılışta çalışacak: " + (v.get("ad") or komut)}
        yol = "/etc/xdg/autostart/tahta-yonetim-{}.desktop".format(kimlik)
        with open(yol, "w", encoding="utf-8") as f:
            f.write("[Desktop Entry]\nType=Application\nName={}\nExec={}\nX-GNOME-Autostart-enabled=true\n"
                    "Comment=Tahta Yönetim Asistanı\n".format(v.get("ad") or kimlik, komut))
        os.chmod(yol, 0o644)
        return {"durum": "tamam", "kayit": {"ekle": True, "dosya": yol}, "ayrinti": "Açılışta çalışacak: " + (v.get("ad") or komut)}

    def ekle_kaldir(self, kayit):
        if C.WINDOWS and kayit.get("deger"):
            import winreg
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as h:
                    winreg.DeleteValue(h, kayit["deger"])
            except OSError:
                pass
        elif kayit.get("dosya", "").startswith("/etc/xdg/autostart/tahta-yonetim-"):
            try:
                os.remove(kayit["dosya"])
            except OSError:
                pass


# ═════════════════════════════════════════════════════════════════════════════
# Envanter: kurulu uygulamalar, başlangıç öğeleri, kullanıcılar, açılış süresi
# ═════════════════════════════════════════════════════════════════════════════
WIN_ENVANTER = r"""
$g = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' -and ($_.Triggers | Where-Object { $_.CimClass.CimClassName -match 'Logon|Boot' }) } | ForEach-Object { [pscustomobject]@{ ad = $_.TaskPath + $_.TaskName; durum = "$($_.State)" } })
$s = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { ($_.StartMode -eq 'Auto' -or $_.StartMode -eq 'Disabled') -and $_.PathName -and $_.PathName -notmatch '(?i)\\windows\\' } | ForEach-Object { [pscustomobject]@{ ad = $_.Name; gorunen = $_.DisplayName; mod = $_.StartMode } })
$b = $null
try { $e = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Diagnostics-Performance/Operational'; Id=100} -MaxEvents 1 -ErrorAction Stop; $b = [int]$e.Properties[5].Value } catch {}
$k = @(Get-LocalUser -ErrorAction SilentlyContinue | Where-Object { $_.Enabled } | ForEach-Object { $_.Name })
[pscustomobject]@{ gorevler = $g; servisler = $s; acilis_ms = $b; kullanicilar = $k } | ConvertTo-Json -Depth 4 -Compress
"""


class Uygulama:
    def __init__(self, ajan):
        self.a = ajan
        self.olay = threading.Event()
        self.son = 0
        self.tarayici = Tarayici(self)
        p = ajan.modul("politika")
        if p:
            p.kaydet("uygulama.kur", Kur(self))
            p.kaydet("uygulama.kilit", UygulamaKilit(self))
            p.kaydet("tarayici.ayar", self.tarayici)
            p.kaydet("baslangic.kapat", Baslangic(self))
            p.kaydet("baslangic.ekle", Baslangic(self, ekle=True))

    def koruma(self, ad):
        return ((self.a.ayar or {}).get("koruma") or {}).get(ad) or []

    def donguler(self):
        return [self.envanter_dongu]

    def envanter_tetikle(self):
        self.olay.set()

    def komut(self, tur, v, kaynak):
        if tur == "envanter":
            self.olay.set()
            return True
        if tur == "kiosk":
            self.tarayici.kiosk(v.get("adres") or "", bool(v.get("kapat")))
            self.a.olay_gonder("sistem", "Kiosk modu {}".format("kapatıldı" if v.get("kapat") else "açıldı: " + (v.get("adres") or "")))
            return True
        return False

    def envanter_dongu(self):
        time.sleep(40)
        self.olay.set()                             # açılışta bir kez gönderilir
        while True:
            self.olay.wait(6 * 3600)
            tetik = self.olay.is_set()
            self.olay.clear()
            if tetik:
                time.sleep(5)
            try:
                e = self.envanter()
                self.a.istek("/api/a/envanter", {"id": self.a.id, "envanter": e}, zaman=30)
            except Exception as ex:
                C.log("Envanter gönderilemedi:", ex)

    def envanter(self):
        e = {"zaman": time.time(), "platform": "windows" if C.WINDOWS else "linux"}
        if C.WINDOWS:
            e["uygulamalar"] = sorted(({"ad": x["ad"], "surum": x["surum"], "kaynak": "windows", "yayinci": x["yayinci"]}
                                       for x in win_kurulu().values()), key=lambda x: x["ad"].lower())
            e["baslangic"] = self.win_baslangic()
            v, _, _ = Y().win_json(WIN_ENVANTER, 180)
            v = v if isinstance(v, dict) else {}
            liste = lambda x: x if isinstance(x, list) else ([x] if x else [])
            for g in liste(v.get("gorevler")):
                e["baslangic"].append({"tur": "gorev", "kimlik": g.get("ad"), "ad": g.get("ad"), "kaynak": "Zamanlanmış görev",
                                       "kapali": g.get("durum") == "Disabled"})
            for s in liste(v.get("servisler")):
                e["baslangic"].append({"tur": "servis", "kimlik": s.get("ad"), "ad": s.get("gorunen") or s.get("ad"),
                                       "kaynak": "Hizmet", "kapali": s.get("mod") == "Disabled"})
            e["acilis_sn"] = round(v["acilis_ms"] / 1000, 1) if v.get("acilis_ms") else None
            e["kullanicilar"] = liste(v.get("kullanicilar"))
            e["masaustu"] = "windows"
        else:
            e["uygulamalar"] = self.linux_uygulamalar()
            e["baslangic"] = self.linux_baslangic()
            _, c = calistir(["systemd-analyze"], 30)
            m = re.search(r"=\s*(?:(\d+)min\s*)?([\d.]+)s", c)
            e["acilis_sn"] = round(int(m.group(1) or 0) * 60 + float(m.group(2)), 1) if m else None
            e["kullanicilar"] = self.linux_kullanicilar()
            e["masaustu"] = sys.modules["tys_modul_oturum"].masaustu_turu() if "tys_modul_oturum" in sys.modules else ""
        for b in e["baslangic"]:
            b["korumali"] = Baslangic(self).korumali(b)
        return e

    def linux_uygulamalar(self):
        dosyalar = {}
        for yol in glob.glob("/usr/share/applications/*.desktop"):
            try:
                metin = open(yol, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            if re.search(r"(?m)^NoDisplay=true", metin):
                continue
            m = re.search(r"(?m)^Name\[tr\]=(.+)$", metin) or re.search(r"(?m)^Name=(.+)$", metin)
            dosyalar[yol] = m.group(1).strip() if m else os.path.basename(yol)
        paket_icin = {}
        if dosyalar and shutil.which("dpkg"):
            _, c = calistir(["dpkg", "-S"] + list(dosyalar), 60)
            for satir in c.splitlines():
                if ": " in satir:
                    pk, yol = satir.split(": ", 1)
                    paket_icin[yol.strip()] = pk.split(":")[0].split(",")[0].strip()
        surumler = {}
        if paket_icin:
            _, c = calistir(["dpkg-query", "-W", "-f=${Package}\t${Version}\n"] + sorted(set(paket_icin.values())), 60)
            surumler = dict(x.split("\t", 1) for x in c.splitlines() if "\t" in x)
        sonuc, gorulen = [], set()
        for yol, ad in dosyalar.items():
            pk = paket_icin.get(yol)
            if "tahta-wine-" in yol:
                sonuc.append({"ad": ad, "surum": "", "kaynak": "wine", "paket": os.path.basename(yol)})
                continue
            if pk and (pk, ad) not in gorulen:
                gorulen.add((pk, ad))
                sonuc.append({"ad": ad, "surum": surumler.get(pk, ""), "kaynak": "apt", "paket": pk})
        if shutil.which("flatpak"):
            _, c = calistir(["flatpak", "list", "--app", "--columns=application,name,version"], 60)
            for satir in c.splitlines():
                p = satir.split("\t")
                if len(p) >= 2 and "." in p[0]:
                    sonuc.append({"ad": p[1], "surum": p[2] if len(p) > 2 else "", "kaynak": "flatpak", "paket": p[0]})
        return sorted(sonuc, key=lambda x: x["ad"].lower())[:600]

    def linux_baslangic(self):
        liste = []
        yollar = glob.glob("/etc/xdg/autostart/*.desktop")
        o = C.oturum_bul()
        if o and o.get("home"):
            yollar += glob.glob(os.path.join(o["home"], ".config", "autostart", "*.desktop"))
        for yol in sorted(yollar):
            try:
                metin = open(yol, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            m = re.search(r"(?m)^Name\[tr\]=(.+)$", metin) or re.search(r"(?m)^Name=(.+)$", metin)
            ex = re.search(r"(?m)^Exec=(.+)$", metin)
            kapali = bool(re.search(r"(?m)^(Hidden=true|X-GNOME-Autostart-enabled=false)", metin))
            sadece = re.search(r"(?m)^OnlyShowIn=(.+)$", metin)
            liste.append({"tur": "autostart", "kimlik": yol, "ad": m.group(1).strip() if m else os.path.basename(yol),
                          "komut": ex.group(1).strip()[:200] if ex else "", "kaynak": "Oturum açılışı" + (
                              " (kullanıcı)" if "/.config/" in yol else "") + (" · yalnızca " + sadece.group(1) if sadece else ""),
                          "kapali": kapali})
        _, c = calistir(["systemctl", "list-unit-files", "--type=service", "--no-legend", "--no-pager"], 30)
        for satir in c.splitlines():
            p = satir.split()
            if len(p) >= 2 and p[1] in ("enabled", "disabled") and p[0].endswith(".service") and "@" not in p[0]:
                if p[1] == "disabled" and not any(x.get("kimlik") == p[0] for x in liste):
                    continue
                liste.append({"tur": "servis", "kimlik": p[0][:-8], "ad": p[0][:-8], "kaynak": "Hizmet", "kapali": p[1] == "disabled"})
        return liste

    def linux_kullanicilar(self):
        try:
            import pwd
            return sorted(p.pw_name for p in pwd.getpwall() if p.pw_uid >= 1000 and p.pw_uid < 60000
                          and not p.pw_shell.endswith(("nologin", "false")))
        except Exception:
            return []

    def win_baslangic(self):
        import winreg
        liste = []

        def onayli(kok, yol, ad):
            try:
                with winreg.OpenKey(kok, yol) as h:
                    return winreg.QueryValueEx(h, ad)[0][:1] not in (b"\x03", b"\x01")
            except OSError:
                return True
        kaynaklar = [("HKLM", winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "Run", ""),
                     ("HKLM32", winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "Run32", "")]
        try:
            with winreg.OpenKey(winreg.HKEY_USERS, "") as h:
                i = 0
                while True:
                    try:
                        sid = winreg.EnumKey(h, i)
                    except OSError:
                        break
                    i += 1
                    if sid.startswith("S-1-5-21-") and not sid.endswith("_Classes"):
                        kaynaklar.append(("HKU\\" + sid, winreg.HKEY_USERS, sid + r"\Software\Microsoft\Windows\CurrentVersion\Run", "Run", sid + "\\"))
        except OSError:
            pass
        for kok_ad, kok, yol, onay, on in kaynaklar:
            try:
                h = winreg.OpenKey(kok, yol)
            except OSError:
                continue
            with h:
                i = 0
                while True:
                    try:
                        ad, deger, _ = winreg.EnumValue(h, i)
                    except OSError:
                        break
                    i += 1
                    acik = onayli(kok, on + r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\\" + onay, ad)
                    liste.append({"tur": "run", "kimlik": kok_ad + "|" + ad, "ad": ad, "komut": str(deger)[:200],
                                  "kaynak": "Kayıt defteri ({})".format("tüm kullanıcılar" if kok_ad.startswith("HKLM") else "kullanıcı"),
                                  "kapali": not acik})
        ortak = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs\StartUp")
        for yol in glob.glob(os.path.join(ortak, "*")):
            ad = os.path.basename(yol)
            if ad.lower() == "desktop.ini":
                continue
            acik = onayli(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder", ad)
            liste.append({"tur": "klasor", "kimlik": "HKLM|" + ad, "ad": ad, "komut": yol, "kaynak": "Başlangıç klasörü", "kapali": not acik})
        return liste


def baslat(ajan):
    return Uygulama(ajan)
