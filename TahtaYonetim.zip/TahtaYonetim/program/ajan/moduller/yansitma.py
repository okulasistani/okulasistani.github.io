# -*- coding: utf-8 -*-
"""Ekran Yansıtma (4.3).

Telefon ekranını tahtaya yansıtır:
  • Android — "Okul Yansıtma" uygulaması (tr.okulasistani.yansitma). Uygulama telefonda kendi yayın sayfasını açar,
    tahtaya /ac çağrısıyla adresini bildirir; ajan o sayfayı öğretmen oturumunda tam ekran açar.
  • iPhone — UxPlay (AirPlay alıcısı), öğretmen oturumunda tahta adıyla sürekli çalışır.
  • Tahtanın kendi Wi-Fi'si (etkin nokta) — ajan ayarlarını kendiliğinden hazırlar (2.4 GHz, PMF kapalı, WPA2-PSK,
    dnsmasq-base, güvenlik duvarı); açıp kapatmak yöneticinin elindedir. Ad ve şifreye program kendiliğinden dokunmaz.

Tahtadaki HTTP uçları (port 8765):  /yansit  /yansit/apk  /ac?url=&cihaz=  /kapat
Masaüstündeki "Telefonu Yansıt" simgesi tam ekran QR penceresini açar.
"""
SURUM = "4.3"
C = None

import os
import re
import sys
import json
import time
import glob
import shutil
import signal
import socket
import threading
import ipaddress
import subprocess
from urllib.parse import urlparse, parse_qs, quote
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("TYS_YANSIT_PORT", "8765"))
PAKET = "tr.okulasistani.yansitma"
UXPLAY_TCP = (7000, 7001, 7100)
UXPLAY_UDP = (6000, 6001, 7011, 5353)
MENU_DOSYA = "/usr/share/applications/tahta-telefonu-yansit.desktop"


def durum_dosyasi():
    """QR penceresinin (kullanıcı süreci) okuduğu, herkesin okuyabildiği durum dosyası."""
    if os.environ.get("TYS_YANSIT_DURUM"):
        return os.environ["TYS_YANSIT_DURUM"]
    if os.name == "nt":
        return os.path.join(os.environ.get("ProgramData") or r"C:\ProgramData", "TahtaYonetim", "yansit.json")
    return "/run/tahta-yonetim/yansit.json"


# ═════════════════════════════════════════════════════════════════════════════
# QR kod üretici (bayt kipi, sürüm 1-25, hata düzeltme L/M/Q/H) — ek paket gerektirmez
# ═════════════════════════════════════════════════════════════════════════════
_ECC_KOD = {"L": 1, "M": 0, "Q": 3, "H": 2}
_ECC_BLOK_UZ = {
    "L": [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26],
    "M": [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28],
    "Q": [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30],
    "H": [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30]}
_ECC_BLOK_SAY = {
    "L": [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12],
    "M": [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21],
    "Q": [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29],
    "H": [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35]}


def _ham_modul(v):
    r = (16 * v + 128) * v + 64
    if v >= 2:
        n = v // 7 + 2
        r -= (25 * n - 10) * n - 55
        if v >= 7:
            r -= 36
    return r


def _veri_kelime(v, e):
    return _ham_modul(v) // 8 - _ECC_BLOK_UZ[e][v] * _ECC_BLOK_SAY[e][v]


def _gf_carp(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_bolen(derece):
    s = [0] * (derece - 1) + [1]
    kok = 1
    for _ in range(derece):
        for j in range(len(s)):
            s[j] = _gf_carp(s[j], kok)
            if j + 1 < len(s):
                s[j] ^= s[j + 1]
        kok = _gf_carp(kok, 0x02)
    return s


def _rs_kalan(veri, bolen):
    s = [0] * len(bolen)
    for b in veri:
        f = b ^ s.pop(0)
        s.append(0)
        for i, k in enumerate(bolen):
            s[i] ^= _gf_carp(k, f)
    return s


def _hizalama(v):
    if v == 1:
        return []
    n = v // 7 + 2
    adim = 26 if v == 32 else (v * 4 + n * 2 + 1) // (n * 2 - 2) * 2
    return list(reversed([v * 4 + 10 - i * adim for i in range(n - 1)] + [6]))


def qr_matris(metin, ecc="M"):
    """Metni QR matrisine çevirir: satır listesi (True = siyah)."""
    veri = metin.encode("utf-8")
    for v in range(1, 26):
        if 4 + (8 if v <= 9 else 16) + 8 * len(veri) <= _veri_kelime(v, ecc) * 8:
            break
    else:
        raise ValueError("QR için metin çok uzun")
    bitler = []

    def ekle(deger, uz):
        bitler.extend((deger >> i) & 1 for i in reversed(range(uz)))
    ekle(4, 4)
    ekle(len(veri), 8 if v <= 9 else 16)
    for b in veri:
        ekle(b, 8)
    kapasite = _veri_kelime(v, ecc) * 8
    ekle(0, min(4, kapasite - len(bitler)))
    ekle(0, (-len(bitler)) % 8)
    dolgu = 0xEC
    while len(bitler) < kapasite:
        ekle(dolgu, 8)
        dolgu ^= 0xEC ^ 0x11
    kelimeler = [int("".join(map(str, bitler[i:i + 8])), 2) for i in range(0, len(bitler), 8)]
    # hata düzeltme + harmanlama
    say, uz, ham = _ECC_BLOK_SAY[ecc][v], _ECC_BLOK_UZ[ecc][v], _ham_modul(v) // 8
    kisa_say, kisa_uz = say - ham % say, ham // say
    bolen = _rs_bolen(uz)
    bloklar, k = [], 0
    for i in range(say):
        d = kelimeler[k:k + kisa_uz - uz + (0 if i < kisa_say else 1)]
        k += len(d)
        e = _rs_kalan(d, bolen)
        if i < kisa_say:
            d.append(0)
        bloklar.append(d + e)
    son = []
    for i in range(len(bloklar[0])):
        for j, b in enumerate(bloklar):
            if i != kisa_uz - uz or j >= kisa_say:
                son.append(b[i])
    n = v * 4 + 17
    m = [[False] * n for _ in range(n)]
    f = [[False] * n for _ in range(n)]

    def koy(x, y, d):
        m[y][x] = bool(d)
        f[y][x] = True
    for i in range(n):
        koy(6, i, i % 2 == 0)
        koy(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < n and 0 <= y < n:
                    koy(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    h = _hizalama(v)
    for i, a in enumerate(h):
        for j, b in enumerate(h):
            if (i == 0 and j == 0) or (i == 0 and j == len(h) - 1) or (i == len(h) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    koy(a + dx, b + dy, max(abs(dx), abs(dy)) != 1)

    def bicim(maske):
        d = _ECC_KOD[ecc] << 3 | maske
        r = d
        for _ in range(10):
            r = (r << 1) ^ ((r >> 9) * 0x537)
        b = (d << 10 | r) ^ 0x5412
        bit = lambda i: (b >> i) & 1
        for i in range(6):
            koy(8, i, bit(i))
        koy(8, 7, bit(6))
        koy(8, 8, bit(7))
        koy(7, 8, bit(8))
        for i in range(9, 15):
            koy(14 - i, 8, bit(i))
        for i in range(8):
            koy(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            koy(8, n - 15 + i, bit(i))
        koy(8, n - 8, True)
    bicim(0)
    if v >= 7:
        r = v
        for _ in range(12):
            r = (r << 1) ^ ((r >> 11) * 0x1F25)
        b = v << 12 | r
        for i in range(18):
            bit = (b >> i) & 1
            a, c = n - 11 + i % 3, i // 3
            koy(a, c, bit)
            koy(c, a, bit)
    i = 0
    sag = n - 1
    while sag >= 1:
        if sag == 6:
            sag = 5
        for dik in range(n):
            for j in range(2):
                x = sag - j
                y = n - 1 - dik if ((sag + 1) & 2) == 0 else dik
                if not f[y][x] and i < len(son) * 8:
                    m[y][x] = bool((son[i >> 3] >> (7 - (i & 7))) & 1)
                    i += 1
        sag -= 2
    maskeler = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
                lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
                lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
                lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]

    def uygula(k):
        for y in range(n):
            for x in range(n):
                if not f[y][x] and maskeler[k](x, y):
                    m[y][x] = not m[y][x]

    def ceza():
        p = 0
        for satirlar in (m, [list(s) for s in zip(*m)]):
            for s in satirlar:
                seri, onceki = 0, None
                for d in s:
                    if d == onceki:
                        seri += 1
                    else:
                        if seri >= 5:
                            p += seri - 2
                        seri, onceki = 1, d
                if seri >= 5:
                    p += seri - 2
                for i_ in range(n - 10):
                    parca = s[i_:i_ + 11]
                    if parca in ([1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1]):
                        p += 40
        for y in range(n - 1):
            for x in range(n - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        siyah = sum(sum(s) for s in m)
        p += abs(siyah * 20 - n * n * 10) // (n * n) * 10
        return p
    en_iyi, en_ceza = 0, None
    for k in range(8):
        uygula(k)
        bicim(k)
        c = ceza()
        if en_ceza is None or c < en_ceza:
            en_iyi, en_ceza = k, c
        uygula(k)
    uygula(en_iyi)
    bicim(en_iyi)
    return m


def wifi_qr(ad, sifre):
    k = lambda s: re.sub(r'([\\;,:"])', r"\\\1", s or "")
    return "WIFI:S:{};T:WPA;P:{};;".format(k(ad), k(sifre))


def uygulama_qr(host, ad=None, sifre=None):
    q = "okulyansit://baglan?host={}&port={}".format(host, PORT)
    if ad:
        q += "&ag={}&sifre={}".format(quote(ad, safe=""), quote(sifre or "", safe=""))
    return q


# ═════════════════════════════════════════════════════════════════════════════
# Yardımcılar
# ═════════════════════════════════════════════════════════════════════════════

def calistir(args, zaman=60):
    try:
        r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, timeout=zaman,
                           env=dict(os.environ, LC_ALL="C", LANG="C", DEBIAN_FRONTEND="noninteractive"))
        return r.returncode, (r.stdout or b"").decode("utf-8", "replace")
    except FileNotFoundError:
        return 127, "{} bulunamadı".format(args[0])
    except subprocess.TimeoutExpired:
        return 124, "zaman aşımı"
    except Exception as e:
        return 1, str(e)


def iw_yolu():
    for p in ("/sbin/iw", "/usr/sbin/iw", shutil.which("iw") or ""):
        if p and os.path.exists(p):
            return p
    return None


def ap_destegi(cikti=None):
    """(AP destekleniyor mu, okul Wi-Fi'sine bağlıyken aynı anda yayın yapılabiliyor mu) — iw list çıktısından."""
    if cikti is None:
        iw = iw_yolu()
        if not iw:
            return None, None
        _, cikti = calistir([iw, "list"], 20)
    ap = False
    m = re.search(r"Supported interface modes:\n((?:\t\t \* .*\n)+)", cikti)
    if m and re.search(r"\* AP\s*$", m.group(1), re.M):
        ap = True
    es = False
    k = re.search(r"valid interface combinations:\n((?:\t\t .*\n)+)", cikti)
    if k:
        for blok in re.split(r"\n\t\t \* ", "\n" + k.group(1)):
            t = re.search(r"total <= (\d+)", blok)
            if t and int(t.group(1)) >= 2 and re.search(r"\bmanaged\b", blok) and re.search(r"\bAP\b", blok):
                es = True
    return ap, es


def ozel_ip(h):
    try:
        a = ipaddress.ip_address(h)
        return a.is_private and not a.is_loopback
    except ValueError:
        return False


def yerel_ipler():
    """[(arayüz, ip)] — Linux'ta ip komutundan; Windows'ta soket yöntemiyle."""
    sonuc = []
    if os.name != "nt":
        _, c = calistir(["ip", "-4", "-o", "addr", "show", "scope", "global"], 10)
        for m in re.finditer(r"^\d+:\s+(\S+)\s+inet (\d+\.\d+\.\d+\.\d+)/", c, re.M):
            sonuc.append((m.group(1), m.group(2)))
    if not sonuc:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            sonuc.append(("", s.getsockname()[0]))
            s.close()
        except OSError:
            pass
    return sonuc


def nm_alanlar(baglanti, alanlar, gizli=False):
    k, c = calistir(["nmcli"] + (["-s"] if gizli else []) + ["-g", ",".join(alanlar), "connection", "show", baglanti], 20)
    if k:
        return None
    satirlar = c.split("\n")
    return {a: (satirlar[i] if i < len(satirlar) else "").replace("\\:", ":") for i, a in enumerate(alanlar)}


def etkin_nokta_bul():
    """Tahtadaki etkin nokta (AP kipindeki Wi-Fi) bağlantısı: {uuid, ad, ssid, arayuz} ya da None."""
    if not shutil.which("nmcli"):
        return None
    _, c = calistir(["nmcli", "-t", "-f", "NAME,UUID,TYPE", "connection", "show"], 20)
    for satir in c.splitlines():
        p = re.split(r"(?<!\\):", satir)
        if len(p) < 3 or p[2] not in ("802-11-wireless", "wifi"):
            continue
        a = nm_alanlar(p[1], ["802-11-wireless.mode", "802-11-wireless.ssid", "connection.interface-name"])
        if a and a["802-11-wireless.mode"] == "ap":
            return {"uuid": p[1], "ad": p[0].replace("\\:", ":"), "ssid": a["802-11-wireless.ssid"],
                    "arayuz": a["connection.interface-name"]}
    return None


def wifi_arayuzu():
    for a in sorted(glob.glob("/sys/class/net/*/wireless")) + sorted(glob.glob("/sys/class/net/*/phy80211")):
        return a.split("/")[4]
    return None


ETKIN_NOKTA_AYAR = {"802-11-wireless.band": "bg", "802-11-wireless-security.pmf": "disable",
                    "802-11-wireless-security.key-mgmt": "wpa-psk", "802-11-wireless-security.proto": "rsn",
                    "802-11-wireless-security.pairwise": "ccmp", "802-11-wireless-security.group": "ccmp",
                    "ipv4.method": "shared"}


# ═════════════════════════════════════════════════════════════════════════════
# Ajan modülü
# ═════════════════════════════════════════════════════════════════════════════

class Yansitma:
    def __init__(self, ajan):
        self.a = ajan
        self.kilit = threading.RLock()
        self.tetik = threading.Event()
        self.sunucu = None
        self.izleyici = None            # {"proc", "ip", "cihaz", "url", "bas"}
        self.ux = None                  # {"proc", "kullanici", "ad"}
        self.ux_son_baslatma = 0.0
        self.ux_baglanti = None         # iPhone yansıtma başlangıcı
        self.ap = {}                    # etkin nokta durumu (panele)
        self.ux_durum = {}
        self.son_hazirlik = 0.0
        self.hazirlik_imza = None
        self.apk_yol = None
        self.apk_sha = None
        self.hata = ""

    # ── ayarlar ──────────────────────────────────────────────────────────────
    def ayar(self):
        y = (self.a.ayar or {}).get("yansitma") or {}
        return {"android": bool(y.get("android")), "iphone": bool(y.get("iphone")), "ag": y.get("ag") or {},
                "ayni_ip": y.get("ayni_ip", True) is not False, "tek": y.get("tek") or "degistir",
                "apk": y.get("apk") or {}, "tahta_adi": y.get("tahta_adi") or socket.gethostname()}

    def ayar_degisti(self):
        self.tetik.set()

    def donguler(self):
        return [self.dongu]

    def dongu(self):
        time.sleep(3)
        while True:
            try:
                self.uygula()
            except Exception as e:
                self.hata = str(e)[:200]
                C.log("Ekran yansıtma:", e)
            self.tetik.wait(15)
            self.tetik.clear()

    def uygula(self):
        a = self.ayar()
        acik = a["android"] or a["iphone"]
        self.sunucu_yonet(acik)
        if not C.WINDOWS and C.ROOT:
            imza = json.dumps([a["ag"], a["iphone"]], sort_keys=True)
            if imza != self.hazirlik_imza or time.time() - self.son_hazirlik > 600:
                self.etkin_nokta_hazirla(a)
                self.hazirlik_imza, self.son_hazirlik = imza, time.time()
            else:
                self.etkin_nokta_durum()
            self.menu_simgesi(acik)
        self.apk_hazirla(a)
        self.izleyici_kontrol()
        if not C.WINDOWS:
            self.uxplay_yonet(a)
        self.durum_yaz(a)

    def durum(self):
        a = self.ayar()
        iz = self.izleyici
        return {"yansitma": {
            "android": a["android"], "iphone": a["iphone"], "port": PORT if self.sunucu else None,
            "ap": {k: v for k, v in self.ap.items() if k != "sifre"}, "ap_sifre": self.ap.get("sifre"),
            "uxplay": self.ux_durum, "apk": bool(self.apk_yol), "hata": self.hata,
            "aktif": {"tur": "android", "cihaz": iz["cihaz"], "ip": iz["ip"], "bas": iz["bas"]} if iz else
                     ({"tur": "iphone", "bas": self.ux_baglanti} if self.ux_baglanti else None)}}

    def komut(self, tur, v, kaynak):
        if tur == "yansitma_kapat":
            kapandi = self.izleyici_kapat("yönetici")
            if self.ux and self.ux_baglanti:
                self.uxplay_durdur()
                kapandi = True
            return {"mesaj": "Yansıtma durduruldu" if kapandi else "Yansıtma yapılmıyordu"}
        if tur == "yansitma_hazirla":
            self.hazirlik_imza = None
            self.tetik.set()
            return {"mesaj": "Etkin nokta ayarları yeniden uygulanıyor"}
        return None

    # ── HTTP sunucusu (8765) ─────────────────────────────────────────────────
    def sunucu_yonet(self, acik):
        if acik and not self.sunucu:
            try:
                s = ThreadingHTTPServer(("0.0.0.0", PORT), self.isleyici())
                s.daemon_threads = True
                threading.Thread(target=s.serve_forever, daemon=True).start()
                self.sunucu = s
                if C.WINDOWS:
                    calistir(["netsh", "advfirewall", "firewall", "add", "rule", "name=Tahta Yansitma", "dir=in", "action=allow",
                              "protocol=TCP", "localport={}".format(PORT)], 30)
                C.log("Ekran yansıtma: {} portu dinleniyor".format(PORT))
            except OSError as e:
                self.hata = "{} portu açılamadı: {}".format(PORT, e)
        elif not acik and self.sunucu:
            self.izleyici_kapat("kapatıldı")
            s, self.sunucu = self.sunucu, None
            threading.Thread(target=s.shutdown, daemon=True).start()

    def isleyici(self):
        mod = self

        class H(BaseHTTPRequestHandler):
            server_version = "TahtaYansitma/" + SURUM

            def log_message(self, *a):
                pass

            def yanit(self, kod, govde, tur="application/json; charset=utf-8", ek=None):
                if isinstance(govde, (dict, list)):
                    govde = json.dumps(govde, ensure_ascii=False).encode("utf-8")
                elif isinstance(govde, str):
                    govde = govde.encode("utf-8")
                self.send_response(kod)
                self.send_header("Content-Type", tur)
                self.send_header("Content-Length", str(len(govde)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "*")
                for k, v in (ek or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(govde)

            def do_HEAD(self):
                self.do_GET()

            def do_GET(self):
                u = urlparse(self.path)
                q = {k: v[0] for k, v in parse_qs(u.query).items()}
                ip = self.client_address[0]
                host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]") or mod.ana_ip()
                try:
                    if u.path in ("/yansit", "/yansit/"):
                        return self.yanit(200, mod.sayfa(host, self.headers.get("User-Agent") or ""), "text/html; charset=utf-8")
                    if u.path == "/yansit/apk":
                        if not mod.apk_yol or not os.path.exists(mod.apk_yol):
                            return self.yanit(404, mod.mesaj_sayfa("Uygulama dosyası bu tahtada yok",
                                                                    "Okul yönetimi Okul Yansıtma uygulamasını panelden yüklemedi."), "text/html; charset=utf-8")
                        with open(mod.apk_yol, "rb") as f:
                            veri = f.read()
                        return self.yanit(200, veri, "application/vnd.android.package-archive",
                                          {"Content-Disposition": 'attachment; filename="OkulYansitma.apk"'})
                    if u.path == "/ac":
                        kod, r = mod.ac(ip, q.get("url") or "", q.get("cihaz") or "")
                        return self.yanit(kod, r)
                    if u.path == "/kapat":
                        return self.yanit(200, {"ok": True, "kapandi": mod.izleyici_kapat("telefon", ip)})
                    if u.path == "/durum":
                        a = mod.ayar()
                        return self.yanit(200, {"tahta": a["tahta_adi"], "android": a["android"], "iphone": a["iphone"],
                                                "yansitiliyor": bool(mod.izleyici)})
                    return self.yanit(404, {"ok": False, "hata": "Bulunamadı"})
                except Exception as e:
                    C.log("Yansıtma isteği:", e)
                    return self.yanit(500, {"ok": False, "hata": "Tahtada beklenmeyen hata"})
        return H

    def ana_ip(self):
        ap = self.ap.get("ip") if self.ap.get("acik") else None
        ipler = [ip for _, ip in yerel_ipler() if ip != ap]
        return ipler[0] if ipler else (ap or "127.0.0.1")

    # ── /ac ve /kapat ────────────────────────────────────────────────────────
    def ac(self, istemci, url, cihaz):
        a = self.ayar()
        if not a["android"]:
            return 403, {"ok": False, "hata": "Bu tahtada Android yansıtma kapalı"}
        p = urlparse(url)
        if p.scheme not in ("http", "https") or not p.hostname or not ozel_ip(p.hostname):
            return 400, {"ok": False, "hata": "Geçersiz yayın adresi"}
        if a["ayni_ip"] and p.hostname != istemci:
            return 403, {"ok": False, "hata": "Yalnızca isteği gönderen telefonun yayını açılabilir"}
        if self.a.kilitli:
            return 423, {"ok": False, "hata": "Tahta kilitli"}
        if self.a.tam_ekran == "sinav":
            return 423, {"ok": False, "hata": "Tahta sınav modunda"}
        o = C.oturum_bul()
        if not o:
            return 409, {"ok": False, "hata": "Tahtada oturum açık değil"}
        cihaz = re.sub(r"[^\w .,()+\-/]", "", cihaz or "")[:60] or "Android telefon"
        with self.kilit:
            iz = self.izleyici
            if iz and iz["proc"].poll() is None:
                if iz["ip"] != istemci and a["tek"] == "engelle":
                    return 409, {"ok": False, "hata": "Tahtaya şu an başka bir telefon yansıtıyor"}
                self.izleyici_kapat("yeni telefon bağlandı")
            proc = self.izleyici_baslat(url, o)
            if proc is None:
                return 500, {"ok": False, "hata": "Tahtada tarayıcı bulunamadı"}
            self.izleyici = {"proc": proc, "ip": istemci, "cihaz": cihaz, "url": url, "bas": time.time()}
        self.durum_yaz(a)
        self.a.olay_gonder("yansitma", "Telefon yansıtma başladı: {} (Android)".format(cihaz),
                           {"durum": "basladi", "tur": "android", "cihaz": cihaz, "ip": istemci})
        return 200, {"ok": True, "tahta": a["tahta_adi"]}

    def izleyici_baslat(self, url, o):
        if C.WINDOWS:
            for t in (r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
                      r"%ProgramFiles%\Google\Chrome\Application\chrome.exe", r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"):
                yol = os.path.expandvars(t)
                if os.path.exists(yol):
                    profil = os.path.join(os.environ.get("ProgramData") or r"C:\ProgramData", "TahtaYonetim", "yansit-profil")
                    return C.oturumda([yol, "--kiosk", url, "--edge-kiosk-type=fullscreen", "--no-first-run",
                                       "--user-data-dir=" + profil, "--autoplay-policy=no-user-gesture-required"], o)
            return None
        for t in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
            yol = shutil.which(t)
            if yol:
                profil = "/tmp/tahta-yansitma-{}".format(o.get("uid", 0))
                return C.oturumda([yol, "--kiosk", "--app=" + url, "--user-data-dir=" + profil, "--no-first-run",
                                   "--no-default-browser-check", "--noerrdialogs", "--disable-session-crashed-bubble",
                                   "--disable-infobars", "--disable-translate", "--autoplay-policy=no-user-gesture-required",
                                   "--password-store=basic", "--check-for-update-interval=31536000"], o)
        for t in ("firefox-esr", "firefox"):
            yol = shutil.which(t)
            if yol:
                return C.oturumda([yol, "--kiosk", "--new-window", url], o)
        return None

    def izleyici_kapat(self, neden, istemci=None):
        with self.kilit:
            iz = self.izleyici
            if not iz:
                return False
            if istemci and self.ayar()["ayni_ip"] and istemci != iz["ip"]:
                return False
            self.izleyici = None
        p = iz["proc"]
        try:
            if C.WINDOWS:
                calistir(["taskkill", "/F", "/T", "/PID", str(p.pid)], 20)
            else:
                try:
                    os.killpg(p.pid, signal.SIGTERM)
                except (ProcessLookupError, PermissionError):
                    pass
                C.proc_durdur(p)
        except Exception:
            pass
        self.bitti_bildir("android", iz["cihaz"], iz["ip"], iz["bas"], neden)
        self.durum_yaz(self.ayar())
        return True

    def izleyici_kontrol(self):
        iz = self.izleyici
        if iz and iz["proc"].poll() is not None:
            with self.kilit:
                if self.izleyici is iz:
                    self.izleyici = None
            self.bitti_bildir("android", iz["cihaz"], iz["ip"], iz["bas"], "pencere kapatıldı")
        if iz and not self.ayar()["android"]:
            self.izleyici_kapat("yansıtma kapatıldı")

    def bitti_bildir(self, tur, cihaz, ip, bas, neden):
        sure = int(time.time() - (bas or time.time()))
        self.a.olay_gonder("yansitma", "Telefon yansıtma bitti: {} ({} dk {} sn)".format(cihaz or tur, sure // 60, sure % 60),
                           {"durum": "bitti", "tur": tur, "cihaz": cihaz, "ip": ip, "sure": sure, "neden": neden})

    # ── telefonda açılan sayfa ───────────────────────────────────────────────
    def mesaj_sayfa(self, baslik, metin):
        return SAYFA.replace("__BASLIK__", baslik).replace("__ICERIK__", "<p>{}</p>".format(metin))

    def sayfa(self, host, ua):
        a = self.ayar()
        ad = a["tahta_adi"]
        esc = lambda s: (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        if re.search(r"iPhone|iPad|iPod", ua) or (re.search(r"Macintosh", ua) and "Mobile" in ua):
            if not a["iphone"]:
                return self.mesaj_sayfa("iPhone yansıtma kapalı", "Bu tahtada iPhone ile yansıtma açılmamış.")
            ap = self.ap if self.ap.get("acik") else None
            ic = ("<ol><li>{}</li><li>iPhone'da sağ üst köşeden aşağı kaydırıp <b>Denetim Merkezi</b>'ni açın.</li>"
                  "<li><b>Ekran Yansıtma</b>'ya dokunun ve listeden <b>{}</b> adlı tahtayı seçin.</li></ol>"
                  "<p class='k'>Görüntü tahtada tam ekran açılır. Bitirmek için yine Ekran Yansıtma › <b>Yansıtmayı Durdur</b>.</p>").format(
                "iPhone'un Wi-Fi'si tahtanın ağına (<b>{}</b>) bağlı olmalı: tahtadaki Wi-Fi karekodunu kamerayla okutun.".format(esc(ap.get("ssid")))
                if ap else "iPhone tahtayla aynı Wi-Fi ağına bağlı olmalı.", esc(ad))
            return SAYFA.replace("__BASLIK__", esc(ad) + " — iPhone ile yansıt").replace("__ICERIK__", ic)
        if not a["android"]:
            return self.mesaj_sayfa("Android yansıtma kapalı", "Bu tahtada Android ile yansıtma açılmamış.")
        apk = a["apk"].get("url") or ("http://{}:{}/yansit/apk".format(host, PORT) if self.apk_yol else "")
        intent = "intent://baglan?host={}&port={}#Intent;scheme=okulyansit;package={};{}end".format(
            host, PORT, PAKET, "S.browser_fallback_url={};".format(quote(apk, safe="")) if apk else "")
        ic = ("<a class='dugme' href='{}'>Yansıtmayı Başlat</a>"
              "<p class='k'>Okul Yansıtma uygulaması açılır ve telefonun ekranı tahtada (<b>{}</b>) görünür.</p>{}").format(
            esc(intent), esc(ad), "<p class='k'>Uygulama yüklü değilse: <a href='{}'>Okul Yansıtma'yı indir</a> "
            "(kurulumda \"bilinmeyen kaynaklara izin ver\" istenebilir).</p>".format(esc(apk)) if apk else
            "<p class='k'>Uygulama yüklü değilse okul yönetiminden Okul Yansıtma uygulamasını isteyin.</p>")
        return SAYFA.replace("__BASLIK__", esc(ad) + " — Telefonu yansıt").replace("__ICERIK__", ic)

    # ── APK ──────────────────────────────────────────────────────────────────
    def apk_hazirla(self, a):
        apk = a["apk"]
        if not apk.get("sha"):
            self.apk_yol = None
            return
        if apk["sha"] == self.apk_sha and self.apk_yol and os.path.exists(self.apk_yol):
            return
        depo = self.a.modul("depo")
        if not depo:
            return
        try:
            self.apk_yol = depo.indir(apk["sha"])
            self.apk_sha = apk["sha"]
        except Exception as e:
            self.hata = "Uygulama dosyası alınamadı: {}".format(e)[:200]

    # ── etkin nokta (Pardus) ─────────────────────────────────────────────────
    def etkin_nokta_hazirla(self, a):
        """Ayarları kendiliğinden hazırlar; açıp kapatmayı yönetici yapar."""
        ag = a["ag"]
        d = {"zaman": time.time(), "adimlar": []}
        adim = lambda ad, ok, ayr="": d["adimlar"].append({"ad": ad, "ok": ok, "ayrinti": ayr})
        if not shutil.which("nmcli"):
            self.ap = dict(d, var=False, hata="NetworkManager yok")
            return
        destek, es = ap_destegi()
        d["destek"], d["es_zamanli"] = destek, es
        adim("Kartın etkin nokta desteği (iw list)", bool(destek), "var" if destek else ("yok" if destek is False else "iw bulunamadı"))
        if not destek:
            self.ap = dict(d, var=False)
            return
        k, c = calistir(["dpkg-query", "-W", "-f", "${Status}", "dnsmasq-base"], 20)
        if "install ok installed" not in c:
            k, c = calistir(["apt-get", "install", "-y", "--no-install-recommends", "dnsmasq-base"], 900)
            adim("dnsmasq-base kurulumu", k == 0, "kuruldu" if k == 0 else c.strip()[-160:])
        else:
            adim("dnsmasq-base", True, "kurulu")
        b = etkin_nokta_bul()
        if not b and ag.get("olustur") and ag.get("ad") and len(ag.get("sifre") or "") >= 8:
            arayuz = wifi_arayuzu()
            k, c = calistir(["nmcli", "connection", "add", "type", "wifi", "ifname", arayuz or "*", "con-name", "Hotspot",
                             "autoconnect", "no", "ssid", ag["ad"], "802-11-wireless.mode", "ap", "ipv4.method", "shared",
                             "802-11-wireless-security.key-mgmt", "wpa-psk", "802-11-wireless-security.psk", ag["sifre"]], 30)
            adim("Etkin nokta oluşturma", k == 0, ag["ad"] if k == 0 else c.strip()[-160:])
            b = etkin_nokta_bul()
        if not b:
            self.ap = dict(d, var=True, tanimli=False)
            return
        d.update(var=True, tanimli=True, baglanti=b["ad"], uuid=b["uuid"])
        istenen = dict(ETKIN_NOKTA_AYAR)
        if ag.get("ad") and ag.get("degistir"):
            istenen["802-11-wireless.ssid"] = ag["ad"]
        if ag.get("sifre") and ag.get("degistir") and len(ag["sifre"]) >= 8:
            istenen["802-11-wireless-security.psk"] = ag["sifre"]
        simdiki = nm_alanlar(b["uuid"], list(istenen), gizli=True) or {}
        farkli = [x for x in istenen if not (simdiki.get(x) or "").lower().startswith(istenen[x].lower())
                  and not (x.endswith(".pmf") and (simdiki.get(x) or "") in ("1", "disable"))]
        if farkli:
            args = ["nmcli", "connection", "modify", b["uuid"]]
            for x in farkli:
                args += [x, istenen[x]]
            k, c = calistir(args, 30)
            adim("Ayarlar (2.4 GHz, PMF kapalı, WPA2-PSK)", k == 0, ", ".join(x.split(".")[-1] for x in farkli) if k == 0 else c.strip()[-160:])
        else:
            adim("Ayarlar (2.4 GHz, PMF kapalı, WPA2-PSK)", True, "zaten uygun")
        aktif = self.etkin_mi(b["uuid"])
        if farkli and aktif:
            calistir(["nmcli", "connection", "down", b["uuid"]], 30)
            k, c = calistir(["nmcli", "connection", "up", b["uuid"]], 60)
            adim("Etkin noktayı kapatıp açma", k == 0, "" if k == 0 else c.strip()[-160:])
            aktif = k == 0
        if ag.get("yonet"):
            if ag.get("acik") and not aktif:
                wifi_bagli = self.wifi_istemci_bagli()
                if wifi_bagli and es is False and not ag.get("zorla"):
                    adim("Etkin noktayı açma", False, "Kart, okul Wi-Fi'sine bağlıyken aynı anda yayın yapamıyor (panelde 'Yine de aç' ile zorlanabilir)")
                else:
                    k, c = calistir(["nmcli", "connection", "up", b["uuid"]], 60)
                    adim("Etkin noktayı açma", k == 0, "" if k == 0 else c.strip()[-160:])
            elif not ag.get("acik") and aktif:
                k, c = calistir(["nmcli", "connection", "down", b["uuid"]], 30)
                adim("Etkin noktayı kapatma", k == 0)
        self.ap = d
        self.etkin_nokta_durum()
        if self.ap.get("arayuz"):
            fw = self.guvenlik_duvari(self.ap["arayuz"], a["iphone"])
            self.ap["guvenlik_duvari"] = fw
            adim("Güvenlik duvarı (UDP 67, 53 · TCP {})".format(PORT), True, fw)
            self.internet_engeli(self.ap["arayuz"], not ag.get("internet"))
            adim("İnternet paylaşımı", True, "açık" if ag.get("internet") else "kapalı (telefonlar internete çıkamaz)")

    def etkin_mi(self, uuid):
        _, c = calistir(["nmcli", "-t", "-f", "UUID", "connection", "show", "--active"], 15)
        return uuid in c.split()

    def wifi_istemci_bagli(self):
        _, c = calistir(["nmcli", "-t", "-f", "UUID,TYPE", "connection", "show", "--active"], 15)
        for satir in c.splitlines():
            u, _, t = satir.partition(":")
            if t in ("802-11-wireless", "wifi") and u != self.ap.get("uuid"):
                a = nm_alanlar(u, ["802-11-wireless.mode"])
                if a and a["802-11-wireless.mode"] != "ap":
                    return True
        return False

    def etkin_nokta_durum(self):
        """Ad, şifre, açık mı, IP. Şifre yalnızca etkin nokta bağlantısının kendisinden okunur
        (nmcli dev wifi show-password o an etkin Wi-Fi'nin — örn. okulun — şifresini gösterebilir)."""
        if not self.ap.get("uuid"):
            return
        a = nm_alanlar(self.ap["uuid"], ["802-11-wireless.ssid", "802-11-wireless-security.psk", "connection.interface-name"], gizli=True)
        if not a:
            self.ap.update(tanimli=False)
            return
        self.ap.update(ssid=a["802-11-wireless.ssid"], sifre=a["802-11-wireless-security.psk"])
        acik = self.etkin_mi(self.ap["uuid"])
        self.ap["acik"] = acik
        arayuz, ip = a["connection.interface-name"] or None, None
        if acik:
            _, c = calistir(["nmcli", "-t", "-f", "UUID,DEVICE", "connection", "show", "--active"], 15)
            for satir in c.splitlines():
                u, _, dev = satir.partition(":")
                if u == self.ap["uuid"]:
                    arayuz = dev
            ip = next((i for ar, i in yerel_ipler() if ar == arayuz), None)
        self.ap.update(arayuz=arayuz, ip=ip)

    def guvenlik_duvari(self, arayuz, iphone):
        udp = [67, 53, 5353] + (list(UXPLAY_UDP) if iphone else [])
        tcp = [PORT] + (list(UXPLAY_TCP) if iphone else [])
        _, u = calistir(["ufw", "status"], 15) if shutil.which("ufw") else (1, "")
        if "Status: active" in u:
            for p in udp:
                calistir(["ufw", "allow", "in", "on", arayuz, "to", "any", "port", str(p), "proto", "udp"], 20)
            for p in tcp:
                calistir(["ufw", "allow", "in", "on", arayuz, "to", "any", "port", str(p), "proto", "tcp"], 20)
            if iphone:                                  # UxPlay okul ağında da çalışsın
                for p in UXPLAY_TCP:
                    calistir(["ufw", "allow", str(p) + "/tcp"], 20)
                for p in UXPLAY_UDP:
                    calistir(["ufw", "allow", str(p) + "/udp"], 20)
            return "ufw: kurallar eklendi"
        if shutil.which("iptables"):
            _, s = calistir(["iptables", "-S", "INPUT"], 15)
            if "-P INPUT DROP" in s or " -j REJECT" in s or " -j DROP" in s:
                for proto, liste in (("udp", udp), ("tcp", tcp)):
                    for p in liste:
                        kural = ["-i", arayuz, "-p", proto, "--dport", str(p), "-j", "ACCEPT"]
                        if calistir(["iptables", "-C", "INPUT"] + kural, 10)[0] != 0:
                            calistir(["iptables", "-I", "INPUT"] + kural, 10)
                return "iptables: kurallar eklendi"
        return "güvenlik duvarı kapalı (kural gerekmedi)"

    def internet_engeli(self, arayuz, engelle):
        """Etkin noktadan internete geçişi keser; okul ağına ve filtresine dokunmaz."""
        if shutil.which("nft"):
            calistir(["nft", "delete", "table", "inet", "tahta_yansitma"], 10)
            if engelle:
                betik = ("table inet tahta_yansitma {\n chain ileri {\n  type filter hook forward priority -10; policy accept;\n"
                         "  iifname \"%s\" drop\n  oifname \"%s\" ct state new drop\n }\n}\n" % (arayuz, arayuz))
                try:
                    subprocess.run(["nft", "-f", "-"], input=betik.encode(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
                except Exception:
                    pass
        elif shutil.which("iptables"):
            kural = ["-i", arayuz, "-j", "DROP"]
            var_ = calistir(["iptables", "-C", "FORWARD"] + kural, 10)[0] == 0
            if engelle and not var_:
                calistir(["iptables", "-I", "FORWARD"] + kural, 10)
            elif not engelle and var_:
                calistir(["iptables", "-D", "FORWARD"] + kural, 10)

    # ── iPhone: UxPlay ───────────────────────────────────────────────────────
    def uxplay_yonet(self, a):
        if not a["iphone"]:
            if self.ux:
                self.uxplay_durdur()
            self.ux_durum = {}
            return
        if C.ROOT and not self.ux_durum.get("kuruldu"):
            eksik = [p for p, komut in (("uxplay", "uxplay"),) if not shutil.which(komut)]
            if eksik:
                k, c = calistir(["apt-get", "install", "-y", "uxplay"], 1800)
                if k:
                    self.ux_durum = {"hata": "UxPlay kurulamadı (Pardus deposunda olmayabilir; .deb dosyasını Uygulama Merkezi'ne yükleyip kurun): " + c.strip()[-120:]}
                    return
            k, c = calistir(["systemctl", "is-active", "avahi-daemon"], 10)
            if c.strip() != "active":
                if not shutil.which("avahi-daemon"):
                    calistir(["apt-get", "install", "-y", "avahi-daemon"], 900)
                calistir(["systemctl", "enable", "--now", "avahi-daemon"], 60)
            self.ux_durum = {"kuruldu": True}
        if not shutil.which("uxplay"):
            self.ux_durum = {"hata": "UxPlay kurulu değil"}
            return
        o = C.oturum_bul()
        ad = a["tahta_adi"]
        if self.ux and (not o or self.ux["kullanici"] != o["kullanici"] or self.ux["ad"] != ad):
            self.uxplay_durdur()
        if not o:
            self.ux_durum = dict(self.ux_durum, calisiyor=False, not_="oturum yok")
            return
        if self.ux and self.ux["proc"].poll() is None:
            self.ux_durum = dict(self.ux_durum, calisiyor=True, ad=ad, hata=None)
            return
        if self.ux:
            self.ux_durum = dict(self.ux_durum, cokme=self.ux_durum.get("cokme", 0) + 1)
            self.ux = None
        if time.time() - self.ux_son_baslatma < 10:
            return
        self.ux_son_baslatma = time.time()
        p = self.uxplay_baslat(ad, o)
        if p:
            self.ux = {"proc": p, "kullanici": o["kullanici"], "ad": ad}
            self.ux_durum = dict(self.ux_durum, calisiyor=True, ad=ad, hata=None)
            threading.Thread(target=self.uxplay_izle, args=(self.ux,), daemon=True).start()

    def uxplay_baslat(self, ad, o):
        env = dict(o["env"])
        kw = dict(env=env, cwd=o.get("home") or "/", stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                  start_new_session=True, close_fds=True)
        if C.ROOT and o.get("uid") not in (None, 0):
            kw.update(user=o["uid"], group=o["gid"], extra_groups=o.get("gruplar") or [])
        try:
            return subprocess.Popen(["uxplay", "-n", ad, "-nh", "-fs", "-p"], **kw)
        except Exception as e:
            self.ux_durum = {"hata": "UxPlay başlatılamadı: {}".format(e)}
            return None

    def uxplay_izle(self, ux):
        """UxPlay çıktısından yansıtmanın başlayıp bittiğini anlar; bitince pencere kapansın diye yeniden başlatır."""
        p = ux["proc"]
        for ham in iter(p.stdout.readline, b""):
            satir = ham.decode("utf-8", "replace")
            if re.search(r"(connection request from|accepted ipv[46] client|begin streaming|raop_rtp_mirror)", satir, re.I) and not self.ux_baglanti:
                self.ux_baglanti = time.time()
                self.a.olay_gonder("yansitma", "Telefon yansıtma başladı: iPhone (AirPlay)", {"durum": "basladi", "tur": "iphone", "cihaz": "iPhone"})
            elif re.search(r"(connection closed|teardown|client disconnected|connection lost)", satir, re.I) and self.ux_baglanti:
                bas, self.ux_baglanti = self.ux_baglanti, None
                self.bitti_bildir("iphone", "iPhone", None, bas, "telefon bitirdi")
                if self.ux is ux:
                    self.uxplay_durdur(sessiz=True)     # pencere kapansın; döngü yeniden başlatır
                    self.tetik.set()
                break

    def uxplay_durdur(self, sessiz=False):
        ux, self.ux = self.ux, None
        if ux:
            try:
                os.killpg(ux["proc"].pid, signal.SIGTERM)
            except Exception:
                pass
            C.proc_durdur(ux["proc"])
        if self.ux_baglanti and not sessiz:
            bas, self.ux_baglanti = self.ux_baglanti, None
            self.bitti_bildir("iphone", "iPhone", None, bas, "durduruldu")

    # ── masaüstü/menü simgesi ve QR penceresinin okuduğu durum ───────────────
    def menu_simgesi(self, acik):
        try:
            if acik:
                icerik = yansit_desktop(sys.executable, C.AJAN_YOLU)
                if not os.path.exists(MENU_DOSYA) or open(MENU_DOSYA, encoding="utf-8").read() != icerik:
                    with open(MENU_DOSYA, "w", encoding="utf-8") as f:
                        f.write(icerik)
            elif os.path.exists(MENU_DOSYA):
                os.remove(MENU_DOSYA)
        except OSError:
            pass

    def durum_yaz(self, a):
        ap = self.ap if self.ap.get("acik") and self.ap.get("ip") else None
        d = {"tahta_adi": a["tahta_adi"], "port": PORT, "android": a["android"], "iphone": a["iphone"],
             "ip": self.ana_ip(), "ap": {"ssid": ap.get("ssid"), "sifre": ap.get("sifre"), "ip": ap.get("ip")} if ap else None,
             "aktif": ({"bas": self.izleyici["bas"], "cihaz": self.izleyici["cihaz"]} if self.izleyici else None),
             "apk": bool(self.apk_yol), "zaman": time.time()}
        yol = durum_dosyasi()
        try:
            os.makedirs(os.path.dirname(yol), exist_ok=True)
            if not C.WINDOWS:
                os.chmod(os.path.dirname(yol), 0o755)
            with open(yol + ".yeni", "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
            if not C.WINDOWS:
                os.chmod(yol + ".yeni", 0o644)
            os.replace(yol + ".yeni", yol)
        except OSError:
            pass


def yansit_desktop(python, ajan):
    return ("[Desktop Entry]\nType=Application\nName=Telefonu Yansıt\nComment=Telefonun ekranını tahtaya yansıtır\n"
            "Exec={} {} --arayuz yansit_qr\nIcon=video-display\nTerminal=false\nCategories=Utility;\n"
            "StartupNotify=false\n").format(python, ajan)


def baslat(ajan):
    return Yansitma(ajan)


SAYFA = """<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__BASLIK__</title><style>
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#0f172a;color:#e2e8f0;display:flex;min-height:100vh;align-items:center;justify-content:center}
main{max-width:460px;padding:28px 22px;text-align:center}h1{font-size:22px;margin:0 0 20px;color:#fff}
.dugme{display:block;background:#2563eb;color:#fff;text-decoration:none;font-size:22px;font-weight:700;padding:22px;border-radius:16px;margin:10px 0 18px}
.k{color:#94a3b8;font-size:15px;line-height:1.5}a{color:#93c5fd}ol{text-align:left;line-height:1.6;font-size:16px;padding-left:22px}p{line-height:1.5}
</style></head><body><main><h1>__BASLIK__</h1>__ICERIK__</main></body></html>"""


# ═════════════════════════════════════════════════════════════════════════════
# "Telefonu Yansıt" penceresi (öğretmen oturumunda, kullanıcı olarak çalışır)
# ═════════════════════════════════════════════════════════════════════════════

def pencere_icerigi(d):
    """Penceredeki karekodlar ve yazılar: [(başlık, qr metni|None, açıklama, büyük mü)]"""
    if not d or not (d.get("android") or d.get("iphone")):
        return [], "Bu tahtada ekran yansıtma kapalı. Okul yönetiminden açılmasını isteyin."
    ad = d.get("tahta_adi") or ""
    ap = d.get("ap")
    parcalar = []
    if d.get("android"):
        if ap:
            parcalar.append(("Okul Yansıtma ile okutun", uygulama_qr(ap["ip"], ap.get("ssid"), ap.get("sifre")),
                             "Telefon önce tahtanın ağına ({}) bağlanır, sonra ekranı tahtada görünür.".format(ap.get("ssid") or ""), True))
        else:
            parcalar.append(("Okul Yansıtma ile okutun", "http://{}:{}/yansit".format(d.get("ip"), d.get("port") or PORT),
                             "Telefon tahtayla aynı ağda olmalı. Uygulama yoksa telefonun kamerasıyla okutun.", True))
    if d.get("iphone"):
        if ap:
            parcalar.append(("iPhone için", wifi_qr(ap.get("ssid"), ap.get("sifre")),
                             "1. Kamerayla okutup tahtanın ağına bağlanın.\n2. Denetim Merkezi › Ekran Yansıtma › {}".format(ad), False))
        else:
            parcalar.append(("iPhone için", None, "iPhone'u tahtayla aynı Wi-Fi'ye bağlayın.\nDenetim Merkezi › Ekran Yansıtma › {}".format(ad), False))
    alt = ""
    if d.get("android"):
        alt = "Uygulama yüklü değilse telefonda http://{}:{}/yansit adresini açın.".format((ap or {}).get("ip") or d.get("ip"), d.get("port") or PORT)
    return parcalar, alt


def _durum_oku():
    try:
        with open(durum_dosyasi(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def arayuz(tur, arg):
    if tur != "yansit_qr":
        return 2
    if os.name == "nt":
        return arayuz_win(arg)
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk, GLib
    d = _durum_oku()
    acilis = time.time()
    parcalar, alt = pencere_icerigi(d)
    win = Gtk.Window(title="Telefonu Yansıt")
    win.set_keep_above(True)
    win.fullscreen()
    css = Gtk.CssProvider()
    css.load_from_data(b"window{background:#0f172a;} label{color:#e2e8f0;} .baslik{font-size:34px;font-weight:700;color:#fff;}"
                       b" .alt{font-size:20px;color:#94a3b8;} .kucuk{font-size:18px;color:#cbd5e1;} .qrb{font-size:24px;font-weight:700;color:#fff;}"
                       b" button{font-size:22px;padding:12px 48px;background-image:none;background-color:#2563eb;border:none;border-radius:12px;}"
                       b" button label{color:#ffffff;font-weight:700;}")
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    ekr = Gdk.Screen.get_default()
    H = ekr.get_height() if ekr else 1080
    win.set_default_size(ekr.get_width() if ekr else 1920, H)
    win.move(0, 0)
    kutu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
    kutu.set_halign(Gtk.Align.CENTER)
    kutu.set_valign(Gtk.Align.CENTER)
    b = Gtk.Label(label="Telefonu Yansıt — " + ((d or {}).get("tahta_adi") or ""))
    b.get_style_context().add_class("baslik")
    kutu.pack_start(b, False, False, 0)
    sira = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=60)
    sira.set_halign(Gtk.Align.CENTER)

    def qr_alani(metin, boyut):
        m = qr_matris(metin)
        n = len(m)
        alan = Gtk.DrawingArea()
        alan.set_size_request(boyut, boyut)

        def ciz(w, cr):
            cr.set_source_rgb(1, 1, 1)
            cr.rectangle(0, 0, boyut, boyut)
            cr.fill()
            h = boyut / (n + 8.0)
            cr.set_source_rgb(0, 0, 0)
            for y in range(n):
                for x in range(n):
                    if m[y][x]:
                        cr.rectangle((x + 4) * h, (y + 4) * h, h + 0.6, h + 0.6)
            cr.fill()
        alan.connect("draw", ciz)
        return alan
    for baslik, metin, aciklama, buyuk in parcalar:
        s = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        l = Gtk.Label(label=baslik)
        l.get_style_context().add_class("qrb")
        s.pack_start(l, False, False, 0)
        if metin:
            s.pack_start(qr_alani(metin, int(H * (0.52 if buyuk else 0.30))), False, False, 0)
        a_ = Gtk.Label(label=aciklama)
        a_.set_justify(Gtk.Justification.CENTER)
        a_.set_line_wrap(True)
        a_.set_max_width_chars(48)
        a_.get_style_context().add_class("kucuk")
        s.pack_start(a_, False, False, 0)
        sira.pack_start(s, False, False, 0)
    kutu.pack_start(sira, False, False, 0)
    if alt:
        al = Gtk.Label(label=alt)
        al.get_style_context().add_class("alt")
        kutu.pack_start(al, False, False, 0)
    kapat = Gtk.Button(label="Kapat")
    kapat.set_halign(Gtk.Align.CENTER)
    kapat.connect("clicked", lambda *_: Gtk.main_quit())
    kutu.pack_start(kapat, False, False, 10)
    win.add(kutu)
    win.connect("key-press-event", lambda w, e: Gtk.main_quit() if e.keyval == Gdk.KEY_Escape else None)
    win.connect("destroy", lambda *_: Gtk.main_quit())

    def denetle():
        y = _durum_oku() or {}
        if (y.get("aktif") or {}).get("bas", 0) > acilis or time.time() - acilis > 600:
            Gtk.main_quit()          # telefon bağlandı (ya da 10 dakika geçti): pencere kapanır
            return False
        return True
    GLib.timeout_add(1000, denetle)
    win.show_all()
    Gtk.main()
    return 0


def arayuz_win(arg):
    import tkinter as tk
    import ctypes
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
    d = _durum_oku()
    acilis = time.time()
    parcalar, alt = pencere_icerigi(d)
    kok = tk.Tk()
    kok.title("Telefonu Yansıt")
    kok.attributes("-fullscreen", True)
    kok.attributes("-topmost", True)
    kok.configure(bg="#0f172a")
    H = kok.winfo_screenheight()
    cer = tk.Frame(kok, bg="#0f172a")
    cer.place(relx=0.5, rely=0.5, anchor="center")
    tk.Label(cer, text="Telefonu Yansıt — " + ((d or {}).get("tahta_adi") or ""), fg="white", bg="#0f172a",
             font=("Segoe UI", 28, "bold")).pack(pady=(0, 16))
    sira = tk.Frame(cer, bg="#0f172a")
    sira.pack()
    for baslik, metin, aciklama, buyuk in parcalar:
        s = tk.Frame(sira, bg="#0f172a")
        s.pack(side="left", padx=40, anchor="n")
        tk.Label(s, text=baslik, fg="white", bg="#0f172a", font=("Segoe UI", 20, "bold")).pack(pady=6)
        if metin:
            m = qr_matris(metin)
            n = len(m)
            boyut = int(H * (0.52 if buyuk else 0.30))
            c = tk.Canvas(s, width=boyut, height=boyut, bg="white", highlightthickness=0)
            h = boyut / (n + 8.0)
            for y in range(n):
                for x in range(n):
                    if m[y][x]:
                        c.create_rectangle((x + 4) * h, (y + 4) * h, (x + 5) * h + 0.6, (y + 5) * h + 0.6, fill="black", width=0)
            c.pack()
        tk.Label(s, text=aciklama, fg="#cbd5e1", bg="#0f172a", font=("Segoe UI", 15), justify="center", wraplength=int(H * 0.5)).pack(pady=8)
    if alt:
        tk.Label(cer, text=alt, fg="#94a3b8", bg="#0f172a", font=("Segoe UI", 16)).pack(pady=8)
    tk.Button(cer, text="Kapat", font=("Segoe UI", 18), command=kok.destroy, padx=30, pady=6).pack(pady=12)
    kok.bind("<Escape>", lambda e: kok.destroy())

    def denetle():
        y = _durum_oku() or {}
        if (y.get("aktif") or {}).get("bas", 0) > acilis or time.time() - acilis > 600:
            kok.destroy()
            return
        kok.after(1000, denetle)
    kok.after(1000, denetle)
    kok.mainloop()
    return 0
