# -*- coding: utf-8 -*-
"""Yazıcı Merkezi (2. aşama): yazıcı paylaşımı ve izinler.

Yazıcının bağlı olduğu cihaz ("sunucu tahta"):
  • Pardus: CUPS paylaşımı açılır, yalnızca izinli cihazların adreslerine izin verilir (cupsd.conf).
  • Windows: ajan kendi yazdırma sunucusunu çalıştırır. Pardus cihazlar işi sürücüsüz (IPP Everywhere,
    PWG raster) gönderir, ajan Windows'taki sürücüyle basar.
  • Her ikisinde de Windows cihazlar için ham (RAW, 9100 tipi) bağlantı noktası açılır: Windows istemci işi
    kendi sürücüsüyle hazırlar, sunucu tahta olduğu gibi yazıcıya iletir.
İzin verilen cihazlar ("istemci"): yazıcı kendiliğinden eklenir; izin kaldırılınca silinir.
"""
SURUM = "3.6"
C = None

import os
import re
import sys
import gzip
import time
import uuid
import socket
import struct
import shutil
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote

IPP_PORT = 8631
CUPS_CONF = "/etc/cups/cupsd.conf"
EN_BUYUK_IS = 1024 * 1048576


def Y():
    return sys.modules["tys_modul_yazici"]


# ═════════════════════════════════════════════════════════════════════════════
# IPP kodlama / çözme (RFC 8010)
# ═════════════════════════════════════════════════════════════════════════════
G_OP, G_IS, G_SON, G_YAZICI, G_DESTEKSIZ = 0x01, 0x02, 0x03, 0x04, 0x05
T_INT, T_BOOL, T_ENUM = 0x21, 0x22, 0x23
T_OCTET, T_TARIH, T_COZUNURLUK, T_ARALIK, T_KOLEKSIYON_BAS = 0x30, 0x31, 0x32, 0x33, 0x34
T_KOLEKSIYON_SON, T_METIN, T_AD, T_ANAHTAR, T_URI = 0x37, 0x41, 0x42, 0x44, 0x45
T_CHARSET, T_DIL, T_MIME, T_UYE = 0x47, 0x48, 0x49, 0x4A
T_YOK = 0x13

OP_ADI = {0x02: "Print-Job", 0x04: "Validate-Job", 0x08: "Cancel-Job", 0x09: "Get-Job-Attributes",
          0x0A: "Get-Jobs", 0x0B: "Get-Printer-Attributes"}


def _deger_coz(tip, b):
    if tip in (T_INT, T_ENUM):
        return struct.unpack(">i", b)[0] if len(b) == 4 else 0
    if tip == T_BOOL:
        return bool(b and b[0])
    if tip == T_COZUNURLUK and len(b) == 9:
        return struct.unpack(">iib", b)
    if tip == T_ARALIK and len(b) == 8:
        return struct.unpack(">ii", b)
    if tip in (0x35, 0x36) and len(b) >= 4:          # textWithLanguage / nameWithLanguage
        n = struct.unpack(">H", b[:2])[0]
        m = struct.unpack(">H", b[2 + n:4 + n])[0]
        return b[4 + n:4 + n + m].decode("utf-8", "replace")
    if 0x40 <= tip <= 0x5F:
        return b.decode("utf-8", "replace")
    return b


def ipp_coz(veri):
    """→ (sürüm, işlem/durum, istek no, [(grup, {ad: [değerler]})], belge başlangıcı)"""
    if len(veri) < 9:
        raise ValueError("kısa IPP iletisi")
    surum = (veri[0], veri[1])
    islem, istek = struct.unpack(">Hi", veri[2:8])
    i, gruplar, grup, son_ad, bitti = 8, [], None, None, False
    yigin = []                                        # koleksiyonlar: [(sözlük, üye adı)]
    while i < len(veri):
        tip = veri[i]
        i += 1
        if tip <= 0x0F:
            if tip == G_SON:
                bitti = True
                break
            grup = {}
            gruplar.append((tip, grup))
            son_ad = None
            continue
        n = struct.unpack(">H", veri[i:i + 2])[0]
        ad = veri[i + 2:i + 2 + n].decode("utf-8", "replace")
        i += 2 + n
        m = struct.unpack(">H", veri[i:i + 2])[0]
        b = veri[i + 2:i + 2 + m]
        i += 2 + m
        if i > len(veri):
            raise ValueError("IPP iletisi yarım")
        if grup is None:
            raise ValueError("grup etiketi yok")
        if yigin:
            kol, uye = yigin[-1]
            if tip == T_UYE:
                yigin[-1] = (kol, b.decode("utf-8", "replace"))
            elif tip == T_KOLEKSIYON_SON:
                yigin.pop()
            elif tip == T_KOLEKSIYON_BAS:
                yeni = {}
                kol.setdefault(uye, []).append(yeni)
                yigin.append((yeni, None))
            else:
                kol.setdefault(uye, []).append(_deger_coz(tip, b))
            continue
        if ad:
            son_ad = ad
            grup[ad] = []
        if son_ad is None:
            continue
        if tip == T_KOLEKSIYON_BAS:
            yeni = {}
            grup[son_ad].append(yeni)
            yigin.append((yeni, None))
        else:
            grup[son_ad].append(_deger_coz(tip, b))
    if not bitti:
        raise ValueError("IPP iletisi yarım")
    return surum, islem, istek, gruplar, i


def _deger_kodla(tip, v):
    if tip in (T_INT, T_ENUM):
        return struct.pack(">i", int(v))
    if tip == T_BOOL:
        return b"\x01" if v else b"\x00"
    if tip == T_COZUNURLUK:
        return struct.pack(">iib", v[0], v[1], 3)
    if tip == T_ARALIK:
        return struct.pack(">ii", v[0], v[1])
    if tip == T_YOK:
        return b""
    return v if isinstance(v, bytes) else str(v).encode("utf-8")


def _oz_kodla(ad, tip, degerler):
    out = bytearray()
    if not isinstance(degerler, (list, tuple)) or tip in (T_COZUNURLUK, T_ARALIK) and degerler and \
            isinstance(degerler[0], int):
        degerler = [degerler]
    for j, v in enumerate(degerler):
        a = ad.encode() if j == 0 else b""
        if tip == T_KOLEKSIYON_BAS:
            out += bytes([T_KOLEKSIYON_BAS]) + struct.pack(">H", len(a)) + a + b"\x00\x00"
            for uad, utip, udeger in v:
                ub = uad.encode()
                out += bytes([T_UYE]) + b"\x00\x00" + struct.pack(">H", len(ub)) + ub
                k = _oz_kodla("", utip, udeger)
                out += k
            out += bytes([T_KOLEKSIYON_SON]) + b"\x00\x00\x00\x00"
            continue
        b = _deger_kodla(tip, v)
        out += bytes([tip]) + struct.pack(">H", len(a)) + a + struct.pack(">H", len(b)) + b
    return bytes(out)


def ipp_kodla(durum, istek, gruplar, surum=(2, 0)):
    """gruplar: [(grup, [(ad, tip, değer(ler))])]"""
    out = bytearray(bytes(surum) + struct.pack(">Hi", durum, istek))
    for g, oznitelikler in gruplar:
        out.append(g)
        for ad, tip, deger in oznitelikler:
            out += _oz_kodla(ad, tip, deger)
    out.append(G_SON)
    return bytes(out)


ipp_kodla_ = ipp_kodla


def ilk(gruplar, ad, varsayilan=None, grup=None):
    for g, d in gruplar:
        if (grup is None or g == grup) and d.get(ad):
            return d[ad][0]
    return varsayilan


# ═════════════════════════════════════════════════════════════════════════════
# PWG raster (PWG 5102.4) çözücü
# ═════════════════════════════════════════════════════════════════════════════
class Sayfa:
    def __init__(self, bas):
        u = lambda o: struct.unpack(">I", bas[o:o + 4])[0]
        self.dpi = (u(276), u(280))
        self.genislik, self.yukseklik = u(372), u(376)
        self.renk_biti, self.piksel_biti, self.satir_bayt = u(384), u(388), u(392)
        self.renk_uzayi = u(400)
        self.kopya = max(1, u(264))
        if (self.piksel_biti, self.renk_biti) not in ((8, 8), (24, 8), (1, 1)) or not self.genislik or not self.yukseklik \
                or self.genislik > 20000 or self.yukseklik > 30000:
            raise ValueError("desteklenmeyen raster ({} bit, {}x{})".format(self.piksel_biti, self.genislik, self.yukseklik))
        self.ham_bpp = max(1, self.piksel_biti // 8)       # sıkıştırmadaki "piksel" boyu
        self.tek_bit = self.piksel_biti == 1
        self.bpp = 1 if self.tek_bit else self.piksel_biti // 8
        self.siyah_beyaz = self.bpp == 1
        self.ham_satir = self.satir_bayt
        if self.tek_bit:
            # 1 bit → 8 bit gri. PWG "black" (3): 1 = siyah; sgray (18): 1 = beyaz
            siyah1 = self.renk_uzayi in (3, 6)
            self.tablo = [bytes(((0 if siyah1 else 255) if (b >> (7 - k)) & 1 else (255 if siyah1 else 0)) for k in range(8))
                          for b in range(256)]
            self.satir_bayt = self.genislik


def raster_sayfalar(f):
    """Dosyadan (sayfa, şerit üreteci) çiftleri: her şerit (ilk satır, bytes — satır_bayt × n)."""
    if f.read(4) != b"RaS2":
        raise ValueError("PWG raster değil")
    while True:
        bas = f.read(1796)
        if len(bas) < 1796:
            return
        s = Sayfa(bas)
        yield s, _seritler(f, s)


def _seritler(f, s, serit=128):
    bpp, satir_bayt, ham_satir = s.ham_bpp, s.satir_bayt, s.ham_satir
    beyaz = (b"\x00" if s.tek_bit and s.renk_uzayi in (3, 6) else b"\xff") * ham_satir
    y, tampon, bas = 0, bytearray(), 0
    oku = f.read
    while y < s.yukseklik:
        tekrar = oku(1)
        if not tekrar:
            raise ValueError("raster yarıda bitti")
        tekrar = tekrar[0] + 1
        satir = bytearray()
        while len(satir) < ham_satir:
            c = oku(1)
            if not c:
                raise ValueError("raster yarıda bitti")
            c = c[0]
            if c == 128:
                satir += beyaz[len(satir):]
            elif c < 128:
                satir += oku(bpp) * (c + 1)
            else:
                satir += oku((257 - c) * bpp)
        satir = bytes(satir[:ham_satir])
        if s.tek_bit:
            t = s.tablo
            satir = b"".join(t[b] for b in satir)[:satir_bayt]
        for _ in range(min(tekrar, s.yukseklik - y)):
            if not tampon:
                bas = y
            tampon += satir
            y += 1
            if len(tampon) >= serit * satir_bayt:
                yield bas, bytes(tampon)
                tampon = bytearray()
    if tampon:
        yield bas, bytes(tampon)


# ═════════════════════════════════════════════════════════════════════════════
# Basıcılar: Windows (GDI ve RAW), test (dosyaya)
# ═════════════════════════════════════════════════════════════════════════════
def win_raster_bas(kuyruk, dosya, belge, kopya=1, iptal=None, cikti=None):
    import ctypes
    from ctypes import wintypes as w
    gdi, k32 = ctypes.WinDLL("gdi32"), ctypes.WinDLL("kernel32")

    class DOCINFOW(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_int), ("lpszDocName", w.LPCWSTR), ("lpszOutput", w.LPCWSTR),
                    ("lpszDatatype", w.LPCWSTR), ("fwType", w.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("biSize", w.DWORD), ("biWidth", w.LONG), ("biHeight", w.LONG), ("biPlanes", w.WORD),
                    ("biBitCount", w.WORD), ("biCompression", w.DWORD), ("biSizeImage", w.DWORD),
                    ("biXPelsPerMeter", w.LONG), ("biYPelsPerMeter", w.LONG), ("biClrUsed", w.DWORD),
                    ("biClrImportant", w.DWORD), ("renkler", w.DWORD * 256)]

    gdi.CreateDCW.restype = w.HDC
    gdi.CreateDCW.argtypes = [w.LPCWSTR, w.LPCWSTR, w.LPCWSTR, ctypes.c_void_p]
    gdi.StretchDIBits.argtypes = [w.HDC] + [ctypes.c_int] * 8 + [ctypes.c_void_p, ctypes.c_void_p, w.UINT, w.DWORD]
    for ad in ("StartPage", "EndPage", "EndDoc", "DeleteDC", "AbortDoc"):
        getattr(gdi, ad).argtypes = [w.HDC]
    gdi.GetDeviceCaps.argtypes = [w.HDC, ctypes.c_int]
    gdi.StartDocW.argtypes = [w.HDC, ctypes.POINTER(DOCINFOW)]
    gdi.SetStretchBltMode.argtypes = [w.HDC, ctypes.c_int]
    gdi.SetBrushOrgEx.argtypes = [w.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    with open(dosya, "rb") as f:                 # bozuk veriyi sürücüye hiç vermeden ele
        bas = f.read(4 + 1796)
    if len(bas) < 1800 or bas[:4] != b"RaS2":
        raise RuntimeError("Gelen iş geçerli bir PWG raster değil")
    Sayfa(bas[4:])
    try:
        hdc = gdi.CreateDCW("WINSPOOL", kuyruk, None, _win_devmode(kuyruk, dosya))
    except OSError:
        hdc = None
    if not hdc:                                  # kağıt ayarı kabul edilmezse yazıcının kendi ayarıyla
        hdc = gdi.CreateDCW("WINSPOOL", kuyruk, None, None)
    if not hdc:
        raise RuntimeError("Yazıcı açılamadı ({}), hata {}".format(kuyruk, k32.GetLastError()))
    sayfa_sayisi = 0
    try:
        di = DOCINFOW(ctypes.sizeof(DOCINFOW), belge[:200] or "Belge", cikti, None, 0)   # cikti: sürücü verisi dosyaya
        if gdi.StartDocW(hdc, ctypes.byref(di)) <= 0:
            raise RuntimeError("Yazdırma başlatılamadı, hata {}".format(k32.GetLastError()))
        dpx, dpy = gdi.GetDeviceCaps(hdc, 88), gdi.GetDeviceCaps(hdc, 90)
        ox, oy = gdi.GetDeviceCaps(hdc, 112), gdi.GetDeviceCaps(hdc, 113)
        gdi.SetStretchBltMode(hdc, 4)                  # HALFTONE
        gdi.SetBrushOrgEx(hdc, 0, 0, None)
        for _ in range(max(1, kopya)):
            with open(dosya, "rb") as f:
                for s, seritler in raster_sayfalar(f):
                    if gdi.StartPage(hdc) <= 0:
                        raise RuntimeError("Sayfa başlatılamadı")
                    bmi = BITMAPINFO()
                    bmi.biSize, bmi.biWidth, bmi.biPlanes = 40, s.genislik, 1
                    bmi.biBitCount = 8 if s.siyah_beyaz else 24
                    if s.siyah_beyaz:
                        bmi.biClrUsed = 256
                        for i in range(256):
                            bmi.renkler[i] = i | (i << 8) | (i << 16)
                    adim = (s.genislik * s.bpp + 3) & ~3
                    dolgu = b"\x00" * (adim - s.genislik * s.bpp)
                    rx, ry = s.dpi
                    for y0, ham in seritler:
                        if iptal and iptal():
                            gdi.AbortDoc(hdc)
                            raise RuntimeError("iptal edildi")
                        n = len(ham) // s.satir_bayt
                        if ham.count(b"\xff") == len(ham):
                            continue                    # boş (beyaz) şerit: çizmeye gerek yok
                        b = bytearray(ham)
                        if not s.siyah_beyaz:
                            b[0::3], b[2::3] = b[2::3], b[0::3]       # RGB → BGR
                        if dolgu:
                            sb = s.genislik * s.bpp
                            b = b"".join(bytes(b[i * sb:(i + 1) * sb]) + dolgu for i in range(n))
                        bmi.biHeight = -n
                        dy0 = round(y0 * dpy / ry) - oy
                        dy1 = round((y0 + n) * dpy / ry) - oy
                        gdi.StretchDIBits(hdc, -ox, dy0, round(s.genislik * dpx / rx), dy1 - dy0,
                                          0, 0, s.genislik, n, ctypes.c_char_p(bytes(b)), ctypes.byref(bmi), 0, 0x00CC0020)
                    gdi.EndPage(hdc)
                    sayfa_sayisi += 1
        gdi.EndDoc(hdc)
    finally:
        gdi.DeleteDC(hdc)
    return sayfa_sayisi


KAGIT = {9: (595, 842), 1: (612, 792), 11: (420, 595), 5: (612, 1008), 8: (842, 1191)}   # DMPAPER_* → nokta


def _win_devmode(kuyruk, dosya):
    """Yazıcının varsayılan ayarları + belgedeki kağıt boyu (A4/Letter/A5...) ve dikey yön. Olmazsa None."""
    import ctypes
    from ctypes import wintypes as w
    try:
        with open(dosya, "rb") as f:
            bas = f.read(4 + 1796)
        gen, yuk = struct.unpack(">II", bas[4 + 352:4 + 360])
        kod = min(KAGIT, key=lambda k: abs(KAGIT[k][0] - gen) + abs(KAGIT[k][1] - yuk))
        if abs(KAGIT[kod][0] - gen) + abs(KAGIT[kod][1] - yuk) > 40:
            return None
        ws = ctypes.WinDLL("winspool.drv")
        ws.DocumentPropertiesW.argtypes = [w.HWND, w.HANDLE, w.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, w.DWORD]
        h = w.HANDLE()
        if not ws.OpenPrinterW(kuyruk, ctypes.byref(h), None):
            return None
        try:
            n = ws.DocumentPropertiesW(None, h, kuyruk, None, None, 0)
            if n <= 0:
                return None
            dm = ctypes.create_string_buffer(n)
            if ws.DocumentPropertiesW(None, h, kuyruk, dm, None, 2) < 0:
                return None
            alanlar = struct.unpack_from("<I", dm, 72)[0] | 0x1 | 0x2          # DM_ORIENTATION | DM_PAPERSIZE
            struct.pack_into("<I", dm, 72, alanlar)
            struct.pack_into("<hh", dm, 76, 1, kod)
            ws.DocumentPropertiesW(None, h, kuyruk, dm, dm, 2 | 8)             # DM_OUT_BUFFER | DM_IN_BUFFER
            return dm
        finally:
            ws.ClosePrinter(h)
    except Exception:
        return None


def win_ayri_surecte(j, kopya, cikti=None):
    """Sürücü (GDI) işini ayrı bir Python sürecinde yaptırır: sürücü çökerse ajan etkilenmez."""
    import subprocess
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe") and os.path.exists(exe[:-5] + ".exe"):
        exe = exe[:-5] + ".exe"
    args = [exe, os.path.abspath(__file__), "--bas", j.kuyruk, j.dosya, j.ad[:200] or "Belge", str(kopya)] + ([cikti] if cikti else [])
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                         creationflags=0x08000000)
    while p.poll() is None:
        if j.iptal:
            p.kill()
            raise RuntimeError("iptal edildi")
        time.sleep(0.5)
    cikis = (p.stdout.read() or b"").decode("utf-8", "replace").strip()
    m = re.search(r"SAYFA=(\d+)", cikis)
    if p.returncode or not m:
        raise RuntimeError((cikis.splitlines() or ["sürücü süreci hata verdi ({})".format(p.returncode)])[-1][:300])
    return int(m.group(1))


def win_ham_bas(kuyruk, dosya, belge):
    import ctypes
    from ctypes import wintypes as w
    ws = ctypes.WinDLL("winspool.drv")

    class DOC_INFO_1W(ctypes.Structure):
        _fields_ = [("pDocName", w.LPWSTR), ("pOutputFile", w.LPWSTR), ("pDatatype", w.LPWSTR)]

    h = w.HANDLE()
    if not ws.OpenPrinterW(kuyruk, ctypes.byref(h), None):
        raise RuntimeError("Yazıcı açılamadı: " + kuyruk)
    try:
        di = DOC_INFO_1W(belge[:200] or "Belge", None, "RAW")
        if not ws.StartDocPrinterW(h, 1, ctypes.byref(di)):
            raise RuntimeError("Yazdırma başlatılamadı")
        ws.StartPagePrinter(h)
        yazilan = w.DWORD()
        with open(dosya, "rb") as f:
            while True:
                parca = f.read(65536)
                if not parca:
                    break
                if not ws.WritePrinter(h, parca, len(parca), ctypes.byref(yazilan)):
                    ws.EndDocPrinter(h)
                    raise RuntimeError("Yazıcıya gönderilemedi")
        ws.EndPagePrinter(h)
        ws.EndDocPrinter(h)
    finally:
        ws.ClosePrinter(h)


def test_raster_bas(klasor, kuyruk, dosya, belge, kopya=1, iptal=None):
    """TYS_YAZDIR_TEST: sayfaları PGM/PPM olarak yazar (Linux'ta denemek için)."""
    os.makedirs(klasor, exist_ok=True)
    n = 0
    with open(dosya, "rb") as f:
        for s, seritler in raster_sayfalar(f):
            n += 1
            ad = os.path.join(klasor, "{}-{}-{}.{}".format(kuyruk, int(time.time() * 1000), n, "pgm" if s.siyah_beyaz else "ppm"))
            with open(ad, "wb") as o:
                o.write("{}\n{} {}\n255\n".format("P5" if s.siyah_beyaz else "P6", s.genislik, s.yukseklik).encode())
                for _, ham in seritler:
                    o.write(ham)
    return n


# ═════════════════════════════════════════════════════════════════════════════
# Yazdırma sunucusu (sunucu tahtada)
# ═════════════════════════════════════════════════════════════════════════════
class Is:
    def __init__(self, no, pid, kuyruk, ad, kullanici, ip, yontem):
        self.no, self.pid, self.kuyruk, self.ad, self.kullanici, self.ip = no, pid, kuyruk, ad, kullanici, ip
        self.yontem = yontem
        self.durum = 3                       # 3 bekliyor, 5 işleniyor, 7 iptal, 8 iptal (hata), 9 tamam
        self.neden = "none"
        self.sayfa, self.boyut, self.hata = 0, 0, ""
        self.olusma, self.bitis = time.time(), None
        self.iptal = False


class IppIstek(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "TahtaYonetim-IPP/1.0"
    sunucu = None                                     # PaylasimSunucu

    def log_message(self, *a):
        pass

    def _govde_oku(self, sinir):
        if "chunked" in (self.headers.get("Transfer-Encoding") or "").lower():
            while True:
                satir = self.rfile.readline(1024)
                n = int(satir.split(b";")[0].strip() or b"0", 16)
                if n == 0:
                    while self.rfile.readline(1024) not in (b"\r\n", b"\n", b""):
                        pass
                    return
                kalan = n
                while kalan:
                    b = self.rfile.read(min(kalan, 65536))
                    if not b:
                        raise ConnectionError("bağlantı koptu")
                    kalan -= len(b)
                    yield b
                self.rfile.readline(8)
                sinir -= n
                if sinir < 0:
                    raise ValueError("iş çok büyük")
        else:
            kalan = int(self.headers.get("Content-Length") or 0)
            if kalan > sinir:
                raise ValueError("iş çok büyük")
            while kalan:
                b = self.rfile.read(min(kalan, 65536))
                if not b:
                    raise ConnectionError("bağlantı koptu")
                kalan -= len(b)
                yield b

    def _yanit(self, kod, govde, tur="application/ipp"):
        self.send_response(kod)
        self.send_header("Content-Type", tur)
        self.send_header("Content-Length", str(len(govde)))
        self.end_headers()
        self.wfile.write(govde)

    def do_GET(self):
        if not self.sunucu.izinli_mi(self.client_address[0]):
            return self._yanit(403, b"Yasak", "text/plain")
        self._yanit(200, "Tahta Yönetim Asistanı yazdırma sunucusu\n".encode(), "text/plain; charset=utf-8")

    def do_POST(self):
        ip = self.client_address[0]
        if not self.sunucu.izinli_mi(ip):
            return self._yanit(403, b"Yasak", "text/plain")
        m = re.match(r"^/ipp/print/([0-9a-f]{6,32})/?$", self.path)
        pay = self.sunucu.paylasimlar.get(m.group(1)) if m else None
        if pay is not None and not self.sunucu.izinli_mi(ip, pay):
            return self._yanit(403, b"Yasak", "text/plain")
        gecici, bas = None, bytearray()
        try:
            parcalar = self._govde_oku(EN_BUYUK_IS)
            for b in parcalar:                         # IPP öznitelikleri (genelde ilk birkaç KB)
                bas += b
                try:
                    surum, islem, istek, gruplar, belge_bas = ipp_coz(bytes(bas))
                    break
                except (ValueError, struct.error, IndexError):
                    if len(bas) > 1048576:
                        raise ValueError("IPP öznitelikleri okunamadı")
            else:
                surum, islem, istek, gruplar, belge_bas = ipp_coz(bytes(bas))
            if pay is None:
                for _ in parcalar:
                    pass
                return self._yanit(200, ipp_kodla(0x0406, istek, [(G_OP, self.sunucu.op_oz())], surum))
            if islem == 0x02:                          # Print-Job: belgeyi diske al
                fd, gecici = tempfile.mkstemp(prefix="tys-is-", dir=self.sunucu.spool)
                with os.fdopen(fd, "wb") as f:
                    f.write(bas[belge_bas:])
                    for b in parcalar:
                        f.write(b)
            else:
                for _ in parcalar:
                    pass
            govde = self.sunucu.ipp_isle(pay, islem, istek, gruplar, gecici, ip, surum)
            gecici = None                              # sahipliği işe geçti
            self._yanit(200, govde)
        except Exception as e:
            C.log("IPP isteği işlenemedi ({}): {}".format(ip, e))
            try:
                self._yanit(400, b"Hatali istek", "text/plain")
            except Exception:
                pass
        finally:
            if gecici:
                try:
                    os.remove(gecici)
                except OSError:
                    pass


class PaylasimSunucu:
    """Sunucu tahtada paylaşılan yazıcılar: IPP (Windows) ve RAW (iki platformda) dinleyicileri, iş kuyruğu."""

    def __init__(self, ps):
        self.ps = ps
        self.paylasimlar = {}           # pid → {kuyruk, ad, model, raw_port, izinli, kayit}
        self.isler = {}                 # iş no → Is
        self.sira = 0
        self.kilit = threading.RLock()
        self.ipp = None
        self.raw = {}                   # port → (soket, pid)
        self.kuyruk_olay = threading.Event()
        self.bekleyen = []
        self.spool = os.path.join(C.VERI, "yazdirma")
        os.makedirs(self.spool, exist_ok=True)
        for ad in os.listdir(self.spool):
            try:
                os.remove(os.path.join(self.spool, ad))
            except OSError:
                pass
        # Yazıcı sürücüleri (GDI) küçük iş parçacığı yığınında çökebiliyor: yazdırma işçisine geniş yığın
        eski = threading.stack_size()
        try:
            threading.stack_size(32 * 1024 * 1024)
        except (ValueError, RuntimeError):
            pass
        threading.Thread(target=self.isci, daemon=True).start()
        try:
            threading.stack_size(eski)
        except (ValueError, RuntimeError):
            pass

    def izinli_mi(self, ip, pay=None):
        """Yalnızca o yazıcıya izin verilen cihazlar (pay verilmezse herhangi bir paylaşıma izinli olanlar)."""
        if ip in ("127.0.0.1", "::1"):
            return True
        ip = ip[7:] if ip.startswith("::ffff:") else ip
        if pay is not None:
            return ip in pay["izinli"]
        return any(ip in p["izinli"] for p in self.paylasimlar.values())

    # ── dinleyicileri isteğe göre aç/kapat ──────────────────────────────────
    def ayarla(self, yeni):
        with self.kilit:
            self.paylasimlar = yeni
            ipp_gerek = bool(yeni) and (C.WINDOWS or os.environ.get("TYS_IPP_SUNUCU"))
            if ipp_gerek and not self.ipp:
                try:
                    IppIstek.sunucu = self
                    port = int(os.environ.get("TYS_IPP_PORT") or IPP_PORT)
                    self.ipp = ThreadingHTTPServer(("0.0.0.0", port), IppIstek)
                    self.ipp.daemon_threads = True
                    threading.Thread(target=self.ipp.serve_forever, daemon=True).start()
                    C.log("Yazdırma sunucusu açıldı (IPP, port {})".format(port))
                except OSError as e:
                    C.log("Yazdırma sunucusu açılamadı:", e)
                    self.ipp = None
            elif not ipp_gerek and self.ipp:
                self.ipp.shutdown()
                self.ipp.server_close()
                self.ipp = None
                C.log("Yazdırma sunucusu kapatıldı")
            isteneler = {p["raw_port"]: pid for pid, p in yeni.items() if p.get("raw_port")}
            for port in list(self.raw):
                if port not in isteneler:
                    try:
                        self.raw.pop(port)[0].close()
                    except OSError:
                        pass
            for port, pid in isteneler.items():
                if port in self.raw:
                    self.raw[port] = (self.raw[port][0], pid)
                    continue
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.bind(("0.0.0.0", port))
                    s.listen(8)
                    self.raw[port] = (s, pid)
                    threading.Thread(target=self.raw_dinle, args=(port, s), daemon=True).start()
                except OSError as e:
                    C.log("Ham yazdırma noktası açılamadı ({}): {}".format(port, e))

    def raw_dinle(self, port, s):
        while True:
            try:
                b, adres = s.accept()
            except OSError:
                return
            threading.Thread(target=self.raw_al, args=(port, b, adres[0]), daemon=True).start()

    def raw_al(self, port, b, ip):
        with b:
            pid = (self.raw.get(port) or (None, None))[1]
            pay = self.paylasimlar.get(pid)
            if not pay or not self.izinli_mi(ip, pay):
                C.log("Ham yazdırma reddedildi:", ip)
                return
            b.settimeout(300)
            fd, gecici = tempfile.mkstemp(prefix="tys-raw-", dir=self.spool)
            boyut = 0
            try:
                with os.fdopen(fd, "wb") as f:
                    while True:
                        parca = b.recv(65536)
                        if not parca:
                            break
                        boyut += len(parca)
                        if boyut > EN_BUYUK_IS:
                            raise ValueError("iş çok büyük")
                        f.write(parca)
            except Exception as e:
                C.log("Ham yazdırma alınamadı ({}): {}".format(ip, e))
                os.remove(gecici)
                return
            if boyut == 0:
                os.remove(gecici)
                return
            self.is_ekle(pid, pay, "Ağdan yazdırma", "", ip, "raw", gecici, {})

    # ── IPP ─────────────────────────────────────────────────────────────────
    def op_oz(self):
        return [("attributes-charset", T_CHARSET, "utf-8"), ("attributes-natural-language", T_DIL, "en")]

    def yazici_oz(self, pid, pay, istenen=None):
        ip = self.yerel_ip()
        renkli = bool(pay.get("renkli", True))
        boyutlar = {"iso_a4_210x297mm": (21000, 29700), "iso_a5_148x210mm": (14800, 21000),
                    "na_letter_8.5x11in": (21590, 27940), "na_legal_8.5x14in": (21590, 35560)}
        kenar = 423

        def mcol(x, y):
            return [("media-size", T_KOLEKSIYON_BAS, [[("x-dimension", T_INT, x), ("y-dimension", T_INT, y)]]),
                    ("media-bottom-margin", T_INT, kenar), ("media-left-margin", T_INT, kenar),
                    ("media-right-margin", T_INT, kenar), ("media-top-margin", T_INT, kenar)]
        with self.kilit:
            is_sayisi = sum(1 for j in self.isler.values() if j.pid == pid and j.durum in (3, 5))
        oz = [
            ("printer-uri-supported", T_URI, "ipp://{}:{}/ipp/print/{}".format(ip, IPP_PORT, pid)),
            ("uri-security-supported", T_ANAHTAR, "none"), ("uri-authentication-supported", T_ANAHTAR, "none"),
            ("printer-name", T_AD, pay.get("kod") or pid), ("printer-info", T_METIN, pay.get("ad") or pay["kuyruk"]),
            ("printer-make-and-model", T_METIN, (pay.get("model") or pay["kuyruk"])[:120]),
            ("printer-location", T_METIN, pay.get("konum") or ""),
            ("printer-more-info", T_URI, "http://{}:{}/".format(ip, IPP_PORT)),
            ("printer-device-id", T_METIN, "MFG:Tahta Yonetim;MDL:{};CMD:PWGRaster;".format(
                re.sub(r"[;:]", " ", pay.get("model") or pay["kuyruk"])[:80])),
            ("printer-uuid", T_URI, "urn:uuid:" + str(uuid.uuid5(uuid.NAMESPACE_URL, "tys:" + pid))),
            ("printer-state", T_ENUM, 4 if is_sayisi else 3),
            ("printer-state-reasons", T_ANAHTAR, "none"), ("printer-is-accepting-jobs", T_BOOL, True),
            ("printer-up-time", T_INT, int(time.time() - self.ps.baslangic) + 1),
            ("queued-job-count", T_INT, is_sayisi),
            ("ipp-versions-supported", T_ANAHTAR, ["1.1", "2.0"]),
            ("operations-supported", T_ENUM, sorted(OP_ADI)),
            ("charset-configured", T_CHARSET, "utf-8"), ("charset-supported", T_CHARSET, ["utf-8"]),
            ("natural-language-configured", T_DIL, "en"), ("generated-natural-language-supported", T_DIL, ["en"]),
            ("document-format-default", T_MIME, "image/pwg-raster"),
            ("document-format-supported", T_MIME, ["image/pwg-raster"]),
            ("compression-supported", T_ANAHTAR, ["none", "gzip"]),
            ("pdl-override-supported", T_ANAHTAR, "attempted"),
            ("multiple-document-jobs-supported", T_BOOL, False),
            ("color-supported", T_BOOL, renkli),
            ("print-color-mode-supported", T_ANAHTAR, ["monochrome", "color"] if renkli else ["monochrome"]),
            ("print-color-mode-default", T_ANAHTAR, "color" if renkli else "monochrome"),
            ("pwg-raster-document-resolution-supported", T_COZUNURLUK, [(300, 300)]),
            ("pwg-raster-document-type-supported", T_ANAHTAR, ["sgray_8", "srgb_8"] if renkli else ["sgray_8"]),
            ("pwg-raster-document-sheet-back", T_ANAHTAR, "normal"),
            ("printer-resolution-supported", T_COZUNURLUK, [(300, 300)]),
            ("printer-resolution-default", T_COZUNURLUK, (300, 300)),
            ("media-supported", T_ANAHTAR, list(boyutlar)), ("media-default", T_ANAHTAR, "iso_a4_210x297mm"),
            ("media-ready", T_ANAHTAR, ["iso_a4_210x297mm"]),
            ("media-col-supported", T_ANAHTAR, ["media-size", "media-bottom-margin", "media-left-margin",
                                                 "media-right-margin", "media-top-margin"]),
            ("media-col-database", T_KOLEKSIYON_BAS, [mcol(*v) for v in boyutlar.values()]),
            ("media-col-default", T_KOLEKSIYON_BAS, [mcol(21000, 29700)]),
            ("media-col-ready", T_KOLEKSIYON_BAS, [mcol(21000, 29700)]),
            ("media-size-supported", T_KOLEKSIYON_BAS, [[("x-dimension", T_INT, x), ("y-dimension", T_INT, y)]
                                                          for x, y in boyutlar.values()]),
            ("media-bottom-margin-supported", T_INT, [kenar]), ("media-left-margin-supported", T_INT, [kenar]),
            ("media-right-margin-supported", T_INT, [kenar]), ("media-top-margin-supported", T_INT, [kenar]),
            ("sides-supported", T_ANAHTAR, ["one-sided"]), ("sides-default", T_ANAHTAR, "one-sided"),
            ("copies-supported", T_ARALIK, (1, 99)), ("copies-default", T_INT, 1),
            ("finishings-supported", T_ENUM, [3]), ("finishings-default", T_ENUM, 3),
            ("orientation-requested-supported", T_ENUM, [3, 4, 5, 6]), ("orientation-requested-default", T_ENUM, 3),
            ("print-quality-supported", T_ENUM, [4]), ("print-quality-default", T_ENUM, 4),
            ("job-creation-attributes-supported", T_ANAHTAR, ["copies", "media", "media-col", "print-color-mode",
                                                              "sides", "orientation-requested", "print-quality"]),
            ("which-jobs-supported", T_ANAHTAR, ["completed", "not-completed"]),
            ("printer-kind", T_ANAHTAR, ["document"]),
            ("output-bin-supported", T_ANAHTAR, ["face-down"]), ("output-bin-default", T_ANAHTAR, "face-down"),
            ("pages-per-minute", T_INT, 20),
        ] + ([("pages-per-minute-color", T_INT, 10)] if renkli else []) + [
        ]
        if istenen and "all" not in istenen:
            gruplar = {"printer-description", "job-template", "media-col-database"}
            if not (gruplar & set(istenen)):
                oz = [o for o in oz if o[0] in istenen]
        return oz

    def is_oz(self, j, pay_pid=None):
        ip = self.yerel_ip()
        return [("job-id", T_INT, j.no), ("job-uri", T_URI, "ipp://{}:{}/ipp/print/{}/{}".format(ip, IPP_PORT, j.pid, j.no)),
                ("job-printer-uri", T_URI, "ipp://{}:{}/ipp/print/{}".format(ip, IPP_PORT, j.pid)),
                ("job-name", T_AD, j.ad or "Belge"), ("job-originating-user-name", T_AD, j.kullanici or "anonim"),
                ("job-state", T_ENUM, j.durum), ("job-state-reasons", T_ANAHTAR, j.neden),
                ("job-impressions-completed", T_INT, j.sayfa), ("job-media-sheets-completed", T_INT, j.sayfa),
                ("time-at-creation", T_INT, int(j.olusma - self.ps.baslangic) + 1),
                ("time-at-completed", T_INT, int((j.bitis or j.olusma) - self.ps.baslangic) + 1) if j.bitis else
                ("time-at-completed", T_YOK, b"")]

    def ipp_isle(self, pay, islem, istek, gruplar, belge, ip, surum=(2, 0)):
        def ipp_kodla(d, i, g):
            return ipp_kodla_(d, i, g, surum if surum in ((1, 0), (1, 1), (2, 0), (2, 1), (2, 2)) else (2, 0))
        pid = next(k for k, v in self.paylasimlar.items() if v is pay)
        if istek == 0:
            return ipp_kodla(0x0400, istek, [(G_OP, self.op_oz())])
        if islem == 0x0B:                                              # Get-Printer-Attributes
            istenen = [str(x) for x in (dict(gruplar[0][1]).get("requested-attributes") or [])] if gruplar else []
            return ipp_kodla(0, istek, [(G_OP, self.op_oz()), (G_YAZICI, self.yazici_oz(pid, pay, istenen))])
        if islem == 0x04:                                              # Validate-Job
            bicim = ilk(gruplar, "document-format", "image/pwg-raster")
            if bicim not in ("image/pwg-raster", "application/octet-stream"):
                return ipp_kodla(0x040A, istek, [(G_OP, self.op_oz())])
            return ipp_kodla(0, istek, [(G_OP, self.op_oz())])
        if islem == 0x02:                                              # Print-Job
            bicim = ilk(gruplar, "document-format", "image/pwg-raster")
            if bicim not in ("image/pwg-raster", "application/octet-stream"):
                os.remove(belge)
                return ipp_kodla(0x040A, istek, [(G_OP, self.op_oz())])
            if (ilk(gruplar, "compression", "none") or "none") == "gzip":
                acik = belge + ".acik"
                with gzip.open(belge, "rb") as g, open(acik, "wb") as o:
                    shutil.copyfileobj(g, o)
                os.replace(acik, belge)
            secenek = {"kopya": int(ilk(gruplar, "copies", 1, G_IS) or 1)}
            j = self.is_ekle(pid, pay, str(ilk(gruplar, "job-name", "Belge") or "Belge"),
                             str(ilk(gruplar, "requesting-user-name", "") or ""), ip, "ipp", belge, secenek)
            return ipp_kodla(0, istek, [(G_OP, self.op_oz()), (G_IS, self.is_oz(j))])
        if islem in (0x09, 0x08):                                      # Get-Job-Attributes / Cancel-Job
            no = int(ilk(gruplar, "job-id", 0) or 0)
            if not no:
                uri = str(ilk(gruplar, "job-uri", "") or "")
                no = int(uri.rsplit("/", 1)[-1]) if uri.rsplit("/", 1)[-1].isdigit() else 0
            j = self.isler.get(no)
            if not j or j.pid != pid:
                return ipp_kodla(0x0406, istek, [(G_OP, self.op_oz())])
            if islem == 0x08:
                if j.durum in (7, 8, 9):
                    return ipp_kodla(0x040C, istek, [(G_OP, self.op_oz())])
                j.iptal = True
                if j.durum == 3:
                    j.durum, j.neden, j.bitis = 7, "job-canceled-by-user", time.time()
                return ipp_kodla(0, istek, [(G_OP, self.op_oz())])
            return ipp_kodla(0, istek, [(G_OP, self.op_oz()), (G_IS, self.is_oz(j))])
        if islem == 0x0A:                                              # Get-Jobs
            hangi = str(ilk(gruplar, "which-jobs", "not-completed") or "not-completed")
            with self.kilit:
                liste = [j for j in self.isler.values() if j.pid == pid and
                         ((j.durum in (7, 8, 9)) == (hangi == "completed"))][-100:]
            return ipp_kodla(0, istek, [(G_OP, self.op_oz())] + [(G_IS, self.is_oz(j)) for j in liste])
        return ipp_kodla(0x0501, istek, [(G_OP, self.op_oz())])

    def yerel_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except OSError:
            return "127.0.0.1"

    # ── iş kuyruğu ──────────────────────────────────────────────────────────
    def is_ekle(self, pid, pay, ad, kullanici, ip, yontem, dosya, secenek):
        with self.kilit:
            self.sira += 1
            j = Is(self.sira, pid, pay["kuyruk"], ad[:200], kullanici[:100], ip, yontem)
            j.boyut = os.path.getsize(dosya)
            j.dosya, j.secenek = dosya, secenek
            self.isler[j.no] = j
            for eski in sorted(self.isler)[:-300]:
                self.isler.pop(eski, None)
            self.bekleyen.append(j)
        self.kuyruk_olay.set()
        return j

    def isci(self):
        while True:
            self.kuyruk_olay.wait(30)
            self.kuyruk_olay.clear()
            while True:
                with self.kilit:
                    j = self.bekleyen.pop(0) if self.bekleyen else None
                if not j:
                    break
                if j.iptal:
                    self.bitir(j, 7, "job-canceled-by-user")
                    continue
                j.durum = 5
                j.neden = "job-printing"
                try:
                    if j.yontem == "raw":
                        self.ham_bas(j)
                    else:
                        j.sayfa = self.raster_bas(j)
                    self.bitir(j, 9, "job-completed-successfully")
                except Exception as e:
                    j.hata = str(e)[:300]
                    C.log("Yazdırma işi basılamadı ({} → {}): {}".format(j.ip, j.kuyruk, e))
                    if os.environ.get("TYS_AJAN_TEST") or os.environ.get("TYS_HATA_AYRINTI"):
                        import traceback
                        C.log(traceback.format_exc()[-1500:])
                    self.bitir(j, 7 if j.iptal else 8, "job-canceled-by-user" if j.iptal else "aborted-by-system")

    def bitir(self, j, durum, neden):
        j.durum, j.neden, j.bitis = durum, neden, time.time()
        try:
            os.remove(j.dosya)
        except OSError:
            pass
        self.ps.is_kaydi({"zaman": j.bitis, "kuyruk": j.kuyruk, "paylasim": j.pid, "ip": j.ip, "ad": j.ad,
                          "kullanici": j.kullanici, "sayfa": j.sayfa, "boyut": j.boyut, "yontem": j.yontem,
                          "sonuc": {9: "basildi", 7: "iptal"}.get(durum, "hata"), "hata": j.hata})

    def raster_bas(self, j):
        test = os.environ.get("TYS_YAZDIR_TEST")
        kopya = max(1, min(99, j.secenek.get("kopya", 1)))
        pay = self.paylasimlar.get(j.pid) or {}
        if pay.get("isle"):
            return self.isle_gonder(j, pay, kopya)
        if test:
            return test_raster_bas(test, j.kuyruk, j.dosya, j.ad, kopya, lambda: j.iptal)
        if C.WINDOWS:
            return win_ayri_surecte(j, kopya)
        k, c = Y().calistir(["lp", "-d", j.kuyruk, "-n", str(kopya), "-t", j.ad[:100], "-o",
                             "document-format=image/pwg-raster", j.dosya], 300)
        if k:
            raise RuntimeError(c.strip()[:200])
        return 0

    def isle_gonder(self, j, pay, kopya):
        """"Windows'ta işle, tahtada bas": sayfaları Windows sürücüsüyle yazıcının kendi diline çevirir,
        çıkan veriyi yazıcının takılı olduğu Pardus tahtaya (ham uç) gönderir."""
        hedef = pay["isle"]
        if not hedef.get("ip"):
            raise RuntimeError("Yazıcının takılı olduğu tahtanın adresi bilinmiyor")
        cikti = j.dosya + ".prn"
        try:
            if C.WINDOWS:
                n = win_ayri_surecte(j, kopya, cikti)
            else:                                          # yalnızca deneme ortamı
                n = test_raster_bas(os.environ.get("TYS_YAZDIR_TEST") or self.spool, j.kuyruk, j.dosya, j.ad)
                with open(cikti, "wb") as f:
                    f.write(b"%!PS\n%%Title: " + j.ad.encode("utf-8", "replace") + b"\nshowpage\n")
            if not os.path.exists(cikti) or not os.path.getsize(cikti):
                raise RuntimeError("Sürücü çıktı üretmedi")
            with socket.create_connection((hedef["ip"], int(hedef["port"])), timeout=20) as b, open(cikti, "rb") as f:
                b.settimeout(300)
                while True:
                    parca = f.read(65536)
                    if not parca:
                        break
                    b.sendall(parca)
            return n
        finally:
            try:
                os.remove(cikti)
            except OSError:
                pass

    def ham_bas(self, j):
        test = os.environ.get("TYS_YAZDIR_TEST")
        if test:
            os.makedirs(test, exist_ok=True)
            shutil.copy(j.dosya, os.path.join(test, "{}-{}.raw".format(j.kuyruk, int(time.time() * 1000))))
            return
        if C.WINDOWS:
            return win_ham_bas(j.kuyruk, j.dosya, j.ad)
        k, c = Y().calistir(["lp", "-d", j.kuyruk, "-o", "raw", "-t", "Ag uzerinden ({})".format(j.ip), j.dosya], 300)
        if k:
            raise RuntimeError(c.strip()[:200])

    def iptal_et(self, kuyruk):
        with self.kilit:
            for j in self.isler.values():
                if j.kuyruk == kuyruk and j.durum in (3, 5):
                    j.iptal = True
                    if j.durum == 3:
                        self.bekleyen = [b for b in self.bekleyen if b is not j]
                        self.bitir(j, 7, "job-canceled-by-user")


# ═════════════════════════════════════════════════════════════════════════════
# Politikalar
# ═════════════════════════════════════════════════════════════════════════════
def _cups_yeniden():
    for args in (["systemctl", "restart", "cups"], ["service", "cups", "restart"]):
        if shutil.which(args[0]) and Y().calistir(args, 60)[0] == 0:
            return True
    k, _ = Y().calistir(["pkill", "-HUP", "-x", "cupsd"], 10)
    time.sleep(2)
    return k == 0


def cups_konum_yaz(kuyruk, izinli):
    """cupsd.conf'ta bu kuyruk için yalnızca izinli adreslere açık <Location> bloğu (None → bloğu kaldır)."""
    try:
        metin = open(CUPS_CONF, encoding="utf-8").read()
    except OSError:
        return False
    bas, son = "# TYS-YAZICI-BASLA {}\n".format(kuyruk), "# TYS-YAZICI-BITIR {}\n".format(kuyruk)
    temiz = re.sub(re.escape(bas) + r".*?" + re.escape(son), "", metin, flags=re.S)
    if izinli is not None:
        blok = bas + "<Location /printers/{}>\n  Order deny,allow\n  Deny from all\n  Allow from 127.0.0.1\n  Allow from ::1\n".format(
            quote(kuyruk)) + "".join("  Allow from {}\n".format(ip) for ip in izinli) + "</Location>\n" + son
        temiz = temiz.rstrip("\n") + "\n" + blok
    if temiz == metin:
        return False
    with open(CUPS_CONF + ".tys-yeni", "w", encoding="utf-8") as f:
        f.write(temiz)
    os.chmod(CUPS_CONF + ".tys-yeni", 0o640)
    os.replace(CUPS_CONF + ".tys-yeni", CUPS_CONF)
    return True


def ufw_etkin():
    return bool(shutil.which("ufw")) and "Status: active" in Y().calistir(["ufw", "status"], 20)[1]


def baglanti_var(ip, port, zaman=4):
    try:
        with socket.create_connection((ip, int(port)), timeout=zaman):
            return True
    except OSError:
        return False


class Paylas:
    """politika: yazici.paylas (sunucu tahta) — veri: kuyruk, ad, raw_port, izinli[], ipp_port"""

    def __init__(self, ps):
        self.ps = ps

    def uygula(self, p, kayit):
        v = p["veri"]
        kuyruk = v.get("kuyruk") or ""
        kayit = dict(kayit or {}, kuyruk=kuyruk, platform="windows" if C.WINDOWS else "linux")
        mevcut = {k.get("ad") for k in (self.ps.yazici().kuyruklar or [])}
        if C.WINDOWS:
            if kuyruk not in mevcut and self.ps.yazici().kuyruklar:
                return {"durum": "hata", "ayrinti": "Bu cihazda '{}' yazıcısı yok".format(kuyruk), "kayit": kayit}
            ad = "Tahta Yonetim Yazici {}".format(p["id"])
            C.win_gizli(["netsh", "advfirewall", "firewall", "delete", "rule", "name=" + ad], 60)
            if v.get("izinli"):
                k, c = C.win_gizli(["netsh", "advfirewall", "firewall", "add", "rule", "name=" + ad, "dir=in", "action=allow",
                                    "protocol=TCP", "localport={},{}".format(IPP_PORT, v.get("raw_port")),
                                    "remoteip=" + ",".join(v["izinli"])], 60)
                if k:
                    return {"durum": "hata", "ayrinti": "Güvenlik duvarı kuralı eklenemedi: " + c.strip()[:200], "kayit": kayit}
            kayit["kural"] = ad
            self.ps.ayar_degisti()
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Paylaşıldı: {} cihaz kullanabilir".format(len(v.get("izinli") or []))}
        if not shutil.which("lpadmin"):
            return {"durum": "hata", "ayrinti": "Bu cihazda CUPS kurulu değil", "kayit": kayit}
        if kuyruk not in {k["ad"] for k in Y().cups_kuyruklar()}:
            return {"durum": "hata", "ayrinti": "Bu cihazda '{}' yazıcısı yok".format(kuyruk), "kayit": kayit}
        k, c = Y().calistir(["lpadmin", "-p", kuyruk, "-o", "printer-is-shared=true"], 60)
        if k:
            return {"durum": "hata", "ayrinti": "Paylaşım açılamadı: " + c.strip()[:200], "kayit": kayit}
        _, ayar = Y().calistir(["cupsctl"], 30)
        if "_share_printers=1" not in ayar:
            Y().calistir(["cupsctl", "--share-printers"], 60)
            kayit["cupsctl"] = True
        degisti = cups_konum_yaz(kuyruk, v.get("izinli") or [])
        if ufw_etkin():
            for kural in ("631/tcp", "{}/tcp".format(v.get("raw_port"))):
                if kural not in kayit.setdefault("ufw", []):
                    if Y().calistir(["ufw", "allow", kural], 30)[0] == 0:
                        kayit["ufw"].append(kural)
        if degisti:
            _cups_yeniden()
        self.ps.ayar_degisti()
        return {"durum": "tamam", "kayit": kayit,
                "ayrinti": "Paylaşıldı: {} cihaz kullanabilir".format(len(v.get("izinli") or []))}

    def kaldir(self, kayit):
        kuyruk = kayit.get("kuyruk")
        if C.WINDOWS:
            if kayit.get("kural"):
                C.win_gizli(["netsh", "advfirewall", "firewall", "delete", "rule", "name=" + kayit["kural"]], 60)
            self.ps.ayar_degisti()
            return
        if kuyruk:
            Y().calistir(["lpadmin", "-p", kuyruk, "-o", "printer-is-shared=false"], 60)
            if cups_konum_yaz(kuyruk, None):
                _cups_yeniden()
        for kural in kayit.get("ufw") or []:
            Y().calistir(["ufw", "delete", "allow", kural], 30)
        if kayit.get("cupsctl"):
            hala = any(st.get("anahtar") == "yazici.paylas" and st.get("kayit", {}).get("kuyruk") != kuyruk
                       for st in self.ps.politika_durumlari())
            if not hala:
                Y().calistir(["cupsctl", "--no-share-printers"], 60)
        self.ps.ayar_degisti()


class Baglan:
    """politika: yazici.baglan (izin verilen cihaz) — veri: ad, host_ad, host_ip, host_platform, kuyruk, paylasim,
    raw_port, ipp_uri, surucu_adi, windows_surucu{tur, sha, ad, parametre}, model, varsayilan"""

    def __init__(self, ps):
        self.ps = ps

    def uygula(self, p, kayit):
        v = p["veri"]
        ip = v.get("host_ip")
        if not ip:
            return {"durum": "bekliyor", "ayrinti": "Yazıcının bağlı olduğu cihazın ({}) adresi henüz bilinmiyor; "
                                                    "cihaz açılınca kurulacak.".format(v.get("host_ad") or "?"), "kayit": kayit}
        if C.WINDOWS:
            return self.windows(v, ip, kayit)
        return self.linux(v, ip, kayit)

    def kapali(self, v, kayit):
        return {"durum": "bekliyor", "kayit": kayit,
                "ayrinti": "Yazıcının bağlı olduğu cihaz ({}) kapalı ya da ağda görünmüyor; açılınca kurulacak.".format(
                    v.get("host_ad") or v.get("host_ip"))}

    def linux(self, v, ip, kayit):
        if not shutil.which("lpadmin"):
            return {"durum": "hata", "ayrinti": "Bu cihazda CUPS kurulu değil"}
        if v.get("host_platform") == "windows":
            uri, port = "ipp://{}:{}/ipp/print/{}".format(ip, IPP_PORT, v["paylasim"]), IPP_PORT
        else:
            uri, port = "ipp://{}:631/printers/{}".format(ip, quote(v.get("kuyruk") or "")), 631
        mevcut = {k["ad"]: k for k in Y().cups_kuyruklar()}
        ad = (kayit or {}).get("kuyruk")
        if ad and ad in mevcut:
            if mevcut[ad]["uri"] != uri:
                Y().calistir(["lpadmin", "-p", ad, "-v", uri], 60)
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Kurulu ({})".format(ad)}
        if not baglanti_var(ip, port):
            return self.kapali(v, kayit)
        taban = Y().kuyruk_adi(v.get("ad") or v.get("kuyruk"))
        ad, n = taban, 2
        while ad in mevcut:
            ad, n = "{}_{}".format(taban, n), n + 1
        k, c = Y().calistir(["lpadmin", "-p", ad, "-E", "-v", uri, "-m", "everywhere", "-o", "printer-is-shared=false",
                             "-D", (v.get("ad") or "")[:120], "-L", "Paylaşılan: " + (v.get("host_ad") or "")[:60]], 180)
        if k:
            if not baglanti_var(ip, port):
                return self.kapali(v, kayit)
            return {"durum": "hata", "ayrinti": "Yazıcı eklenemedi: " + c.strip()[:300], "kayit": kayit}
        Y().calistir(["cupsenable", ad], 30)
        Y().calistir(["cupsaccept", ad], 30)
        adimlar = ["Eklendi: " + ad]
        if v.get("varsayilan"):
            Y().calistir(["lpadmin", "-d", ad], 30)
            adimlar.append("varsayılan yapıldı")
        self.ps.yazici_yenile()
        return {"durum": "tamam", "kayit": {"kuyruk": ad, "platform": "linux"}, "ayrinti": " · ".join(adimlar)}

    def windows(self, v, ip, kayit):
        port_adi = "TYS_{}_{}".format(ip, v.get("raw_port"))
        ad = (kayit or {}).get("kuyruk") or (v.get("ad") or v.get("kuyruk") or "Yazici")[:100]
        k, c = C.win_ps("(Get-Printer -Name '{}' -ErrorAction SilentlyContinue).PortName".format(ad.replace("'", "''")), 60)
        var_olan = c.strip() if k == 0 else ""
        if kayit and var_olan:
            if var_olan != port_adi:                     # sunucu tahtanın adresi değişmiş
                C.win_ps("Add-PrinterPort -Name '{0}' -PrinterHostAddress '{1}' -PortNumber {2} -ErrorAction SilentlyContinue; "
                         "Set-Printer -Name '{3}' -PortName '{0}'; Remove-PrinterPort -Name '{4}' -ErrorAction SilentlyContinue".format(
                             port_adi, ip, int(v.get("raw_port")), ad.replace("'", "''"), var_olan), 120)
                kayit = dict(kayit, port=port_adi)
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Kurulu ({})".format(ad)}
        if not baglanti_var(ip, v.get("raw_port")):
            return self.kapali(v, kayit)
        klasor, adimlar = Y().win_depo_surucu(self.ps.a, v.get("windows_surucu") or {})
        adaylar = []
        if klasor:
            adaylar.append(Y().inf_surucu_adi(klasor, [], v.get("model")))
        adaylar += [v.get("surucu_adi"), v.get("model")]
        surucu = None
        for d in [a for a in dict.fromkeys(adaylar) if a]:
            k, c = C.win_ps("Add-PrinterDriver -Name '{}'".format(d.replace("'", "''")), 300)
            if k == 0:
                surucu = d
                break
            adimlar.append("Sürücü yok: " + d)
        if not surucu:
            return {"durum": "hata", "kayit": kayit, "ayrinti": " · ".join(adimlar + [
                "Bu yazıcının Windows sürücüsü bu cihazda yok. Sürücüyü (INF içeren .zip) depoya yükleyip paylaşımda "
                "'Windows cihazlar için sürücü' olarak seçin."])}
        k, c = C.win_ps("Add-PrinterPort -Name '{0}' -PrinterHostAddress '{1}' -PortNumber {2} -ErrorAction SilentlyContinue; "
                        "Add-Printer -Name '{3}' -DriverName '{4}' -PortName '{0}'".format(
                            port_adi, ip, int(v.get("raw_port")), ad.replace("'", "''"), surucu.replace("'", "''")), 300)
        if k:
            return {"durum": "hata", "kayit": kayit, "ayrinti": "Yazıcı eklenemedi: " + c.strip()[-300:]}
        adimlar.append("Eklendi: {} ({})".format(ad, surucu))
        if v.get("varsayilan"):
            o = C.oturum_bul()
            if o:
                C.oturumda(["reg.exe", "add", r"HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows", "/v",
                            "LegacyDefaultPrinterMode", "/t", "REG_DWORD", "/d", "1", "/f"], o, yakala=True, zaman_asimi=20)
                C.oturumda(["rundll32.exe", "printui.dll,PrintUIEntry", "/y", "/n", ad], o, yakala=True, zaman_asimi=30)
                adimlar.append("varsayılan yapıldı")
        self.ps.yazici_yenile()
        return {"durum": "tamam", "kayit": {"kuyruk": ad, "port": port_adi, "platform": "windows"}, "ayrinti": " · ".join(adimlar)}

    def kaldir(self, kayit):
        ad = kayit.get("kuyruk")
        if not ad:
            return
        if C.WINDOWS:
            k, c = C.win_ps("Remove-Printer -Name '{}' -ErrorAction SilentlyContinue; Remove-PrinterPort -Name '{}' "
                            "-ErrorAction SilentlyContinue".format(ad.replace("'", "''"), kayit.get("port") or ""), 120)
        else:
            k, c = Y().calistir(["lpadmin", "-x", ad], 60)
            if k and "does not exist" not in c:
                raise RuntimeError(c.strip()[:300])
        C.log("Paylaşılan yazıcı kaldırıldı:", ad)
        self.ps.yazici_yenile()


def isle_kuyruk_adi(pid):
    return "TYS Isleme " + pid[:8]


def uzak_ham_adi(pid):
    return "TYS_ham_" + pid[:8]


class Isle:
    """politika: yazici.isle (Windows) — sürücüsü yalnızca Windows'ta olan yazıcı için işleme kuyruğu.
    veri: model, windows_surucu{tur, sha, ad, parametre}, hedef_ip, raw_port"""

    def __init__(self, ps):
        self.ps = ps

    def uygula(self, p, kayit):
        if not C.WINDOWS:
            return {"durum": "desteklenmiyor", "ayrinti": "Yalnızca Windows cihazlarda"}
        v = p["veri"]
        ad = isle_kuyruk_adi(p["id"])
        if os.environ.get("TYS_ISLE_KUYRUK"):
            self.ps.ayar_degisti()
            return {"durum": "tamam", "kayit": {"kuyruk": None}, "ayrinti": "Deneme kuyruğu"}
        k, c = C.win_ps("(Get-Printer -Name '{}' -ErrorAction SilentlyContinue).DriverName".format(ad), 60)
        if k == 0 and c.strip():
            self.ps.ayar_degisti()
            return {"durum": "tamam", "kayit": kayit or {"kuyruk": ad}, "ayrinti": "İşleme kuyruğu hazır ({})".format(c.strip())}
        klasor, adimlar = Y().win_depo_surucu(self.ps.a, v.get("windows_surucu") or {})
        adaylar = ([Y().inf_surucu_adi(klasor, [], v.get("model"))] if klasor else []) + [v.get("surucu_adi"), v.get("model")]
        surucu = None
        for d in [a for a in dict.fromkeys(adaylar) if a]:
            if C.win_ps("Add-PrinterDriver -Name '{}'".format(d.replace("'", "''")), 300)[0] == 0:
                surucu = d
                break
            adimlar.append("Sürücü yok: " + d)
        if not surucu:
            return {"durum": "hata", "ayrinti": " · ".join(adimlar + [
                "Bu yazıcının Windows sürücüsü bulunamadı. Sürücü paketini (INF içeren .zip) depoya yükleyip seçin."])}
        k, c = C.win_ps("Add-Printer -Name '{}' -DriverName '{}' -PortName 'FILE:'".format(ad, surucu.replace("'", "''")), 300)
        if k:
            return {"durum": "hata", "ayrinti": "İşleme kuyruğu eklenemedi: " + c.strip()[-300:]}
        self.ps.ayar_degisti()
        return {"durum": "tamam", "kayit": {"kuyruk": ad}, "ayrinti": " · ".join(adimlar + ["İşleme kuyruğu hazır ({})".format(surucu)])}

    def kaldir(self, kayit):
        if C.WINDOWS and kayit.get("kuyruk"):
            C.win_ps("Remove-Printer -Name '{}' -ErrorAction SilentlyContinue".format(kayit["kuyruk"]), 120)
        self.ps.ayar_degisti()


class Uzak:
    """politika: yazici.uzak (Pardus) — USB yazıcı Pardus tahtada, sürücüsü Windows'ta.
    Tahtada iki kuyruk: yazıcının adıyla sürücüsüz kuyruk (işi Windows'a gönderir) ve Windows'tan gelen hazır
    veriyi USB'ye olduğu gibi ileten ham kuyruk. veri: anahtar, model, isleyici_ip, isle_id, raw_port, varsayilan, test"""

    def __init__(self, ps):
        self.ps = ps

    def uygula(self, p, kayit):
        v = p["veri"]
        y = self.ps.yazici()
        aygit = y.takili.get(v.get("anahtar")) if y else None
        if not aygit:
            return {"durum": "bekliyor", "kayit": kayit, "ayrinti": "Yazıcı şu an bu tahtaya takılı değil; takılınca kurulacak."}
        if not shutil.which("lpadmin"):
            return {"durum": "hata", "ayrinti": "Bu tahtada CUPS kurulu değil"}
        ip = v.get("isleyici_ip")
        mevcut = {k["ad"]: k for k in Y().cups_kuyruklar()}
        kayit = dict(kayit or {})
        ham = uzak_ham_adi(p["id"])
        if ham not in mevcut:
            uri = aygit.get("uri") or Y().Kurulum(y).uri_bul(aygit)
            if not uri:
                return {"durum": "hata", "ayrinti": "Yazıcının bağlantı adresi bulunamadı. Kabloyu çıkarıp takın."}
            k, c = Y().calistir(["lpadmin", "-p", ham, "-E", "-v", uri, "-m", "raw", "-o", "printer-is-shared=false",
                                 "-D", "Tahta Yönetim ham çıkış (silmeyin)"], 120)
            if k:
                return {"durum": "hata", "ayrinti": "Ham kuyruk eklenemedi: " + c.strip()[:300]}
            Y().calistir(["cupsenable", ham], 30)
            Y().calistir(["cupsaccept", ham], 30)
            kayit["ham"] = ham
        self.ps.ayar_degisti()
        uri = "ipp://{}:{}/ipp/print/{}".format(ip, IPP_PORT, v.get("isle_id"))
        ad = kayit.get("kuyruk")
        if ad and ad in mevcut:
            if mevcut[ad]["uri"] != uri and ip:
                Y().calistir(["lpadmin", "-p", ad, "-v", uri], 60)
            return {"durum": "tamam", "kayit": kayit, "ayrinti": "Kurulu (Windows'ta işleniyor)"}
        if not ip or not baglanti_var(ip, IPP_PORT):
            return {"durum": "bekliyor", "kayit": kayit,
                    "ayrinti": "İşi hazırlayacak Windows cihaz ({}) kapalı ya da ağda görünmüyor; açılınca kurulacak.".format(v.get("isleyici_ad") or ip or "?")}
        taban = Y().kuyruk_adi(v.get("model"))
        ad, n = taban, 2
        while ad in mevcut:
            ad, n = "{}_{}".format(taban, n), n + 1
        k, c = Y().calistir(["lpadmin", "-p", ad, "-E", "-v", uri, "-m", "everywhere", "-o", "printer-is-shared=false",
                             "-D", (v.get("model") or "")[:120], "-L", "Windows'ta işlenir: " + (v.get("isleyici_ad") or "")], 180)
        if k:
            return {"durum": "hata", "kayit": kayit, "ayrinti": "Yazıcı eklenemedi: " + c.strip()[:300]}
        Y().calistir(["cupsenable", ad], 30)
        Y().calistir(["cupsaccept", ad], 30)
        kayit.update(kuyruk=ad, platform="linux", olusturduk=True)
        adimlar = ["Windows'ta işle, tahtada bas: " + ad]
        if v.get("varsayilan", True):
            Y().calistir(["lpadmin", "-d", ad], 30)
            adimlar.append("varsayılan yapıldı")
        test = "yok"
        if v.get("test", True):
            t = y.test_sayfasi(ad, 150)
            test = "basildi" if t == "basıldı" else ("hata" if t.startswith(("hata", "gönderilemedi")) else "bekliyor")
            adimlar.append("test sayfası: " + t)
        self.ps.yazici_yenile()
        model = "{} {}".format(aygit.get("marka") or "", aygit.get("model") or "").strip()
        return {"durum": "tamam", "kayit": kayit, "ayrinti": " · ".join(adimlar),
                "sonuc": {"model": model, "platform": "linux", "yontem": "Windows'ta işle, tahtada bas", "test": test}}

    def kaldir(self, kayit):
        for ad in (kayit.get("kuyruk"), kayit.get("ham")):
            if ad:
                Y().calistir(["lpadmin", "-x", ad], 60)
        self.ps.ayar_degisti()
        self.ps.yazici_yenile()


# ═════════════════════════════════════════════════════════════════════════════
# Modül
# ═════════════════════════════════════════════════════════════════════════════
class Paylasim:
    def __init__(self, ajan):
        self.a = ajan
        self.baslangic = time.time()
        self.sunucu = PaylasimSunucu(self)
        self.kayitlar = []
        self.kayit_kilit = threading.Lock()
        self.cups_gorulen = set()
        p = ajan.modul("politika")
        if p:
            p.kaydet("yazici.paylas", Paylas(self))
            p.kaydet("yazici.baglan", Baglan(self))
            p.kaydet("yazici.isle", Isle(self))
            p.kaydet("yazici.uzak", Uzak(self))

    def yazici(self):
        return self.a.modul("yazici")

    def yazici_yenile(self):
        y = self.yazici()
        if y:
            try:
                y.guncelle(y.tara())
                y.rapor()
            except Exception:
                pass

    def politika_durumlari(self):
        p = self.a.modul("politika")
        return list((p.d.get("durum") or {}).values()) if p else []

    def donguler(self):
        return [self.kayit_dongu]

    def ayar_degisti(self):
        """Çalışan dinleyicileri sunucudan gelen paylaşım listesine göre ayarlar."""
        politikalar = (self.a.ayar or {}).get("politikalar")
        if not isinstance(politikalar, list):
            return
        yeni = {}
        for p in politikalar:
            if isinstance(p, dict) and p.get("modul") == "yazici" and p.get("tur") == "isle":
                v = p.get("veri") or {}
                yeni[p["id"]] = {"kuyruk": os.environ.get("TYS_ISLE_KUYRUK") or isle_kuyruk_adi(p["id"]),
                                 "ad": v.get("ad"), "model": v.get("model"), "raw_port": None,
                                 "izinli": set([v["hedef_ip"]] if v.get("hedef_ip") else []), "kayit": False,
                                 "renkli": v.get("renkli", False), "konum": v.get("konum") or "",
                                 "isle": {"ip": v.get("hedef_ip"), "port": v.get("raw_port")}}
            elif isinstance(p, dict) and p.get("modul") == "yazici" and p.get("tur") == "uzak":
                v = p.get("veri") or {}
                yeni[p["id"]] = {"kuyruk": uzak_ham_adi(p["id"]), "ad": v.get("model"), "model": v.get("model"),
                                 "raw_port": int(v.get("raw_port") or 0) or None,
                                 "izinli": set([v["isleyici_ip"]] if v.get("isleyici_ip") else []), "kayit": False}
            elif isinstance(p, dict) and p.get("modul") == "yazici" and p.get("tur") == "paylas":
                v = p.get("veri") or {}
                yeni[p["id"]] = {"kuyruk": v.get("kuyruk"), "ad": v.get("ad"), "model": v.get("model"),
                                 "raw_port": int(v.get("raw_port") or 0) or None, "izinli": set(v.get("izinli") or []),
                                 "kayit": bool(v.get("kayit")), "renkli": v.get("renkli", True),
                                 "konum": v.get("konum") or ""}
        self.sunucu.ayarla(yeni)

    def isleri_iptal(self, kuyruk):
        self.sunucu.iptal_et(kuyruk)

    def durum(self):
        with self.sunucu.kilit:
            bekleyen = sum(1 for j in self.sunucu.isler.values() if j.durum in (3, 5))
        return {"paylasim": {"sayi": len(self.sunucu.paylasimlar), "bekleyen_is": bekleyen}} if self.sunucu.paylasimlar else {}

    # ── çıktı kaydı ─────────────────────────────────────────────────────────
    def is_kaydi(self, k):
        pay = next((p for pid, p in self.sunucu.paylasimlar.items() if pid == k.get("paylasim")), None)
        if not pay or not pay.get("kayit"):
            return
        with self.kayit_kilit:
            self.kayitlar.append(k)
            self.kayitlar = self.kayitlar[-500:]

    def cups_isleri(self):
        """Pardus sunucu tahta: paylaşılan kuyruklarda başka cihazlardan gelen, biten işler (CUPS iş kayıtları)."""
        kuyruklar = {p["kuyruk"]: pid for pid, p in self.sunucu.paylasimlar.items() if p.get("kayit")}
        if C.WINDOWS or not kuyruklar or not os.path.isdir("/var/spool/cups"):
            return
        for yol in sorted(os.listdir("/var/spool/cups")):
            if not re.match(r"^c\d+$", yol) or yol in self.cups_gorulen:
                continue
            try:
                veri = open(os.path.join("/var/spool/cups", yol), "rb").read()
                _, _, _, gruplar, _ = ipp_coz(veri)
            except Exception:
                continue
            d = {}
            for _, g in gruplar:
                d.update(g)
            durum = (d.get("job-state") or [0])[0]
            if durum < 7:
                continue
            self.cups_gorulen.add(yol)
            uri = str((d.get("job-printer-uri") or [""])[0])
            kuyruk = uri.rsplit("/", 1)[-1]
            ip = str((d.get("job-originating-host-name") or [""])[0])
            if kuyruk not in kuyruklar or ip in ("localhost", "127.0.0.1", "::1", ""):
                continue
            bitis = (d.get("time-at-completed") or [0])[0]
            self.is_kaydi({"zaman": bitis if isinstance(bitis, int) and bitis > 1e9 else time.time(), "kuyruk": kuyruk,
                           "paylasim": kuyruklar[kuyruk], "ip": ip, "ad": str((d.get("job-name") or [""])[0])[:200],
                           "kullanici": str((d.get("job-originating-user-name") or [""])[0])[:100],
                           "sayfa": (d.get("job-impressions-completed") or [0])[0] or 0,
                           "boyut": 0, "yontem": "cups", "sonuc": "basildi" if durum == 9 else "iptal" if durum == 7 else "hata",
                           "hata": ""})

    def kayit_dongu(self):
        time.sleep(20)
        ilk_tur = True
        while True:
            try:
                if ilk_tur and not C.WINDOWS and os.path.isdir("/var/spool/cups"):
                    self.cups_gorulen = {y for y in os.listdir("/var/spool/cups") if re.match(r"^c\d+$", y)}
                ilk_tur = False
                self.cups_isleri()
                with self.kayit_kilit:
                    liste = list(self.kayitlar)
                if liste:
                    self.a.istek("/api/a/yazici-is", {"id": self.a.id, "isler": liste[:200]}, zaman=20)
                    with self.kayit_kilit:
                        self.kayitlar = self.kayitlar[len(liste[:200]):]
            except Exception as e:
                C.log("Çıktı kaydı gönderilemedi:", e)
            time.sleep(30)


def baslat(ajan):
    m = Paylasim(ajan)
    return m


if __name__ == "__main__" and len(sys.argv) >= 7 and sys.argv[1] == "--bas":
    # ayrı süreç: python paylasim.py --bas <kuyruk> <raster> <belge adı> <kopya> [çıktı dosyası]
    import types
    C = types.SimpleNamespace(WINDOWS=True, log=lambda *a: None)
    try:
        n = win_raster_bas(sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5]), None, sys.argv[6] if len(sys.argv) > 6 else None)
        print("SAYFA=%d" % n)
    except Exception as e:
        print("HATA: %s" % e)
        sys.exit(1)
