# -*- coding: utf-8 -*-
"""Tanıla ve onar (4.2).

Tahtanın genel sorunlarını bulur ve onarır: ağ kartı ve sürücüsü, kablo/port, IP (DHCP), elle girilmiş yanlış
ayarlar, IP çakışması, DNS, internete çıkış, vekil sunucu, okul ağı (MEB) güvenlik sertifikası, kablosuz güç
tasarrufu, yönetim bilgisayarına erişim, saat, paket sistemi, disk, bellek, çöken hizmetler, ses, dokunmatik,
ekran çözünürlüğü, yazıcı, kamera/mikrofon, tahta programı ve kimlik çakışması.

İki yerde çalışır:
  • Ajan modülü olarak — panelde Tahta Sağlığı › "Tanıla" / "Onar" komutları.
  • Tek başına — Tahta Onarım Belleği'nden:  python3 onarim.py --bellek <klasör>
Yalnızca Python standart kütüphanesini kullanır. Önce tanılar; onarım ayrı adımdır. Değiştirilen her ayarın
yedeği alınır ve "geri al" ile eski hâline döner. Kişisel dosyalara hiç dokunulmaz.
"""
SURUM = "4.3"
C = None

import os
import re
import sys
import ssl
import glob
import json
import time
import shutil
import socket
import tempfile
import threading
import subprocess
import urllib.request

YEDEK_KOK = os.environ.get("TYS_ONARIM_YEDEK") or "/var/lib/tahta-onarim"
KOK = os.environ.get("TYS_ONARIM_KOK", "")        # testlerde yazılacak sistem dosyalarının önüne eklenir
SAHTE = bool(os.environ.get("TYS_ONARIM_SAHTE"))  # testlerde sistemi değiştiren komutlar çalıştırılmaz
SAHTE_KOMUTLAR = []
SERTIFIKA_YOL = "/usr/local/share/ca-certificates/tahta-okul-agi.crt"
SERTIFIKA_AD = "Okul Ağı Sertifikası (Tahta Yönetim)"
WIFI_CONF = "/etc/NetworkManager/conf.d/90-tahta-wifi-tasarruf.conf"
DENEME_SITELER = ("www.meb.gov.tr", "www.google.com")
GRUPLAR = ["Ağ ve internet", "Yönetim bilgisayarı", "Sistem", "Ses, görüntü ve dokunmatik", "Yazıcı ve aygıtlar", "Tahta programı"]
ONAR_YAZI = {
    "ag_yenile": "Ağ bağlantısını yeniden başlat",
    "dhcp": "Elle girilmiş ağ ayarını otomatiğe (DHCP) çevir",
    "proxy": "Vekil sunucu (proxy) ayarını kaldır",
    "wifi_tasarruf": "Kablosuz güç tasarrufunu kapat",
    "sertifika": "Okul ağı sertifikasını kur",
    "saat": "Saati düzelt",
    "paket": "Yarım kalmış paket işlemlerini tamamla",
    "disk": "Geçici dosyaları ve önbellekleri temizle",
    "hizmet": "Çöken hizmetleri yeniden başlat",
    "ses": "Sesi aç ve ses sistemini yeniden başlat",
    "kalibrasyon": "Dokunmatik kalibrasyonunu sıfırla",
    "ekran": "Ekranı önerilen çözünürlüğe al",
    "yazici": "Yazdırma sistemini onar (kuyruk, durdurulmuş yazıcı)",
    "r8168": "Realtek ağ kartı için uygun sürücüyü kur",
    "kimlik": "Tahtaya yeni kimlik ver (aynı imajdan kurulmuş tahtalar)",
    "ajan_baslat": "Tahta programını yeniden başlat",
}


# ═════════════════════════════════════════════════════════════════════════════
# Yardımcılar
# ═════════════════════════════════════════════════════════════════════════════

def calistir(args, zaman=40, env=None, girdi=None):
    """(çıkış kodu, çıktı) — hiç hata fırlatmaz."""
    try:
        e = dict(os.environ, LC_ALL="C", LANG="C", DEBIAN_FRONTEND="noninteractive")
        if env:
            e.update(env)
        r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           stdin=subprocess.PIPE if girdi is not None else subprocess.DEVNULL,
                           input=girdi.encode() if girdi is not None else None, timeout=zaman, env=e)
        return r.returncode, (r.stdout or b"").decode("utf-8", "replace")
    except FileNotFoundError:
        return 127, "{} bulunamadı".format(args[0])
    except subprocess.TimeoutExpired:
        return 124, "{} zaman aşımı".format(args[0])
    except Exception as e:
        return 1, str(e)


def degistir(args, zaman=300, env=None, girdi=None):
    """Sistemi değiştiren komut (testte yalnızca kaydedilir)."""
    if SAHTE:
        SAHTE_KOMUTLAR.append(list(args))
        return 0, ""
    return calistir(args, zaman, env, girdi)


def oku(yol, varsayilan=""):
    try:
        with open(yol, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return varsayilan


def var(komut):
    return shutil.which(komut) is not None


def tcp(host, port, sure=5.0):
    try:
        socket.create_connection((host, port), timeout=sure).close()
        return True
    except OSError:
        return False


def coz(ad, sure=6.0):
    """Alan adını çözer (zaman sınırlı); IP ya da None."""
    sonuc = []

    def is_():
        try:
            sonuc.append(socket.getaddrinfo(ad, 443, socket.AF_INET)[0][4][0])
        except Exception:
            pass
    t = threading.Thread(target=is_, daemon=True)
    t.start()
    t.join(sure)
    return sonuc[0] if sonuc else None


def acici():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def http_tarih(adres, sure=8):
    """Sunucunun saatini (HTTP Date) epoch olarak döner."""
    from email.utils import parsedate_to_datetime
    try:
        r = urllib.request.Request(adres, method="GET")
        with acici().open(r, timeout=sure) as y:
            d = y.headers.get("Date")
    except urllib.error.HTTPError as e:
        d = e.headers.get("Date") if e.headers else None
    except Exception:
        return None
    try:
        return parsedate_to_datetime(d).timestamp() if d else None
    except Exception:
        return None


def ayir(adres):
    m = re.match(r"^https?://([^/:]+)(?::(\d+))?", adres or "")
    return (m.group(1), int(m.group(2) or 8765)) if m else (None, None)


def B(id_, grup, baslik, durum, mesaj, onar=None, **ek):
    d = {"id": id_, "grup": grup, "baslik": baslik, "durum": durum, "mesaj": mesaj}
    if onar:
        d["onar"] = onar
        d["onar_yazi"] = ONAR_YAZI.get(onar, onar)
    d.update(ek)
    return d


def yol(p):
    return KOK + p if KOK else p


# ── masaüstü oturumu (ses, ekran ve kullanıcı ayarları için) ────────────────
def oturum_bul():
    """Etkin grafik oturumun kullanıcısı ve ortam değişkenleri (tek başına çalışırken)."""
    uid = None
    for satir in calistir(["loginctl", "list-sessions", "--no-legend"], 10)[1].splitlines():
        p = satir.split()
        if not p:
            continue
        _, b = calistir(["loginctl", "show-session", p[0], "-p", "Active", "-p", "Type", "-p", "Class", "-p", "User"], 10)
        d = dict(x.split("=", 1) for x in b.splitlines() if "=" in x)
        if d.get("Active") == "yes" and d.get("Class") == "user" and d.get("Type") in ("x11", "wayland"):
            try:
                uid = int(d.get("User"))
                break
            except (TypeError, ValueError):
                pass
    if uid is None:
        return None
    try:
        import pwd
        pw = pwd.getpwuid(uid)
    except Exception:
        return None
    env = {"HOME": pw.pw_dir, "USER": pw.pw_name, "LOGNAME": pw.pw_name, "XDG_RUNTIME_DIR": "/run/user/%d" % uid,
           "DBUS_SESSION_BUS_ADDRESS": "unix:path=/run/user/%d/bus" % uid, "DISPLAY": ":0",
           "PATH": "/usr/local/bin:/usr/bin:/bin"}
    # DISPLAY ve XAUTHORITY'yi oturumdaki bir süreçten al
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            if os.stat("/proc/" + pid).st_uid != uid:
                continue
            ham = open("/proc/%s/environ" % pid, "rb").read()
        except OSError:
            continue
        ev = dict(kv.split(b"=", 1) for kv in ham.split(b"\0") if b"=" in kv)
        if b"DISPLAY" in ev:
            env["DISPLAY"] = ev[b"DISPLAY"].decode("utf-8", "replace")
            if b"XAUTHORITY" in ev:
                env["XAUTHORITY"] = ev[b"XAUTHORITY"].decode("utf-8", "replace")
            break
    return {"uid": uid, "kullanici": pw.pw_name, "home": pw.pw_dir, "env": env}


def kullanici_olarak(args, oturum, zaman=20):
    if not oturum:
        return 1, "oturum yok"
    env = dict(oturum.get("env") or {})
    if os.geteuid() == 0 and oturum.get("uid") != 0:
        return calistir(["runuser", "-u", oturum["kullanici"], "--", "env"] +
                        ["{}={}".format(k, v) for k, v in env.items()] + list(args), zaman)
    return calistir(list(args), zaman, env=env)


def kullanici_degistir(args, oturum, zaman=60):
    if SAHTE:
        SAHTE_KOMUTLAR.append(["(kullanıcı)"] + list(args))
        return 0, ""
    return kullanici_olarak(args, oturum, zaman)


# ═════════════════════════════════════════════════════════════════════════════
# Yedek ve geri alma
# ═════════════════════════════════════════════════════════════════════════════

class Yedek:
    """Onarımın değiştirdiği her şeyi kaydeder; geri_al() aynı sırayla tersine çevirir."""

    def __init__(self, kok=None):
        self.kok = kok or YEDEK_KOK
        self.dizin = os.path.join(self.kok, "yedek", time.strftime("%Y%m%d-%H%M%S"))
        self.kayit = []

    def dosya(self, p):
        if any(k.get("yol") == p for k in self.kayit):
            return
        os.makedirs(os.path.join(self.dizin, "dosyalar"), exist_ok=True)
        if os.path.lexists(p):
            hedef = os.path.join(self.dizin, "dosyalar", "%02d-" % len(self.kayit) + os.path.basename(p))
            shutil.copy2(p, hedef, follow_symlinks=False)
            self.kayit.append({"tur": "dosya", "yol": p, "yedek": hedef})
        else:
            self.kayit.append({"tur": "dosya", "yol": p, "yedek": None})

    def ekle(self, **k):
        self.kayit.append(k)

    def kaydet(self, aciklama):
        if not self.kayit:
            return None
        os.makedirs(self.dizin, exist_ok=True)
        with open(os.path.join(self.dizin, "kayit.json"), "w", encoding="utf-8") as f:
            json.dump({"zaman": time.time(), "aciklama": aciklama, "kayit": self.kayit}, f, ensure_ascii=False, indent=1)
        return self.dizin


def son_yedek(kok=None):
    adaylar = sorted(glob.glob(os.path.join(kok or YEDEK_KOK, "yedek", "*", "kayit.json")))
    for p in reversed(adaylar):
        if not os.path.exists(os.path.join(os.path.dirname(p), "geri-alindi")):
            return p
    return None


def geri_al(oturum=None, kok=None):
    """Son onarımın değiştirdiklerini eski hâline getirir."""
    p = son_yedek(kok)
    if not p:
        return {"ok": False, "mesaj": "Geri alınacak onarım yok"}
    k = json.load(open(p, encoding="utf-8"))
    yapilan, nm_degisti = [], False
    for x in reversed(k.get("kayit") or []):
        try:
            if x["tur"] == "dosya":
                if x.get("yedek"):
                    os.makedirs(os.path.dirname(x["yol"]), exist_ok=True)
                    shutil.copy2(x["yedek"], x["yol"], follow_symlinks=False)
                elif os.path.lexists(x["yol"]):
                    os.remove(x["yol"])
                yapilan.append(os.path.basename(x["yol"]))
                if x["yol"].startswith(yol("/usr/local/share/ca-certificates")):
                    degistir(["update-ca-certificates", "--fresh"], 120)
                if "NetworkManager" in x["yol"]:
                    nm_degisti = True
            elif x["tur"] == "nm":
                args = ["nmcli", "connection", "modify", x["ad"]]
                for a, v in x["alanlar"].items():
                    args += [a, v if v not in ("--", None) else ""]
                degistir(args, 30)
                degistir(["nmcli", "connection", "up", x["ad"]], 60)
                yapilan.append("ağ ayarı: " + x["ad"])
            elif x["tur"] == "ses":
                kullanici_degistir(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if x.get("sessiz") else "0"], oturum)
                if x.get("seviye") is not None:
                    kullanici_degistir(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % x["seviye"]], oturum)
                yapilan.append("ses düzeyi")
            elif x["tur"] == "ekran":
                kullanici_degistir(["xrandr", "--output", x["cikis"], "--mode", x["mod"]], oturum)
                yapilan.append("ekran çözünürlüğü")
            elif x["tur"] == "gsettings":
                kullanici_degistir(["gsettings", "set", x["sema"], x["anahtar"], x["deger"]], oturum)
                yapilan.append("vekil sunucu (kullanıcı)")
            elif x["tur"] == "sertifika_nss":
                kullanici_degistir(["certutil", "-D", "-n", SERTIFIKA_AD, "-d", "sql:" + x["db"]], {"uid": x["uid"], "kullanici": x["kullanici"], "env": {}})
                yapilan.append("tarayıcı sertifikası")
        except Exception as e:
            yapilan.append("hata: {}".format(e))
    if nm_degisti:
        degistir(["systemctl", "reload-or-restart", "NetworkManager"], 60)
    open(os.path.join(os.path.dirname(p), "geri-alindi"), "w").write(str(time.time()))
    return {"ok": True, "mesaj": "Geri alındı: " + ", ".join(yapilan) if yapilan else "Değişiklik yoktu", "yapilan": yapilan}


# ═════════════════════════════════════════════════════════════════════════════
# Tanılama (Pardus / Linux)
# ═════════════════════════════════════════════════════════════════════════════

def arayuzler():
    sonuc = []
    for a in sorted(os.listdir(yol("/sys/class/net")) if os.path.isdir(yol("/sys/class/net")) else []):
        k = yol("/sys/class/net/" + a)
        if a == "lo" or not os.path.exists(k + "/device"):
            continue                                  # sanal arayüzler (docker, köprü, vpn) atlanır
        surucu = os.path.basename(os.path.realpath(k + "/device/driver")) if os.path.exists(k + "/device/driver") else ""
        sonuc.append({"ad": a, "kablosuz": os.path.exists(k + "/wireless") or os.path.exists(k + "/phy80211"),
                      "surucu": surucu, "tasiyici": oku(k + "/carrier") == "1", "durum": oku(k + "/operstate"),
                      "mac": oku(k + "/address").lower(), "vendor": oku(k + "/device/vendor").lower(),
                      "aygit": oku(k + "/device/device").lower()})
    return sonuc


def ipv4_adresler():
    _, c = calistir(["ip", "-4", "-o", "addr", "show", "scope", "global"], 10)
    return [(m.group(1), m.group(2), int(m.group(3))) for m in re.finditer(r"^\d+:\s+(\S+)\s+inet (\d+\.\d+\.\d+\.\d+)/(\d+)", c, re.M)]


def varsayilan_yol():
    _, c = calistir(["ip", "-4", "route", "show", "default"], 10)
    m = re.search(r"default via (\d+\.\d+\.\d+\.\d+) dev (\S+)", c)
    return (m.group(1), m.group(2)) if m else (None, None)


def ping(ip, n=2):
    k, _ = calistir(["ping", "-c", str(n), "-W", "2", ip], 15)
    return k == 0


def ayni_ag(ip, gw, onek):
    import ipaddress
    try:
        return ipaddress.ip_address(gw) in ipaddress.ip_interface("%s/%d" % (ip, onek)).network
    except ValueError:
        return True


def nm_baglantilar():
    """Etkin NetworkManager bağlantıları: ad, tür, aygıt, ipv4 yöntemi ve elle girilmiş ayarlar."""
    if not var("nmcli"):
        return []
    _, c = calistir(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"], 15)
    sonuc = []
    for satir in c.splitlines():
        p = re.split(r"(?<!\\):", satir)
        if len(p) < 3 or p[1] not in ("802-3-ethernet", "802-11-wireless", "ethernet", "wifi"):
            continue
        ad = p[0].replace("\\:", ":")
        _, a = calistir(["nmcli", "-g", "ipv4.method,ipv4.addresses,ipv4.gateway,ipv4.dns", "connection", "show", ad], 15)
        s = (a.splitlines() + ["", "", "", ""])[:4]
        sonuc.append({"ad": ad, "tur": p[1], "aygit": p[2], "yontem": s[0], "adres": s[1], "gw": s[2], "dns": s[3]})
    return sonuc


def proxy_var():
    bulunan = []
    for satir in oku(yol("/etc/environment")).splitlines():
        if re.match(r"\s*(export\s+)?(https?|ftp|all)_proxy\s*=", satir, re.I):
            bulunan.append("/etc/environment")
            break
    for p in glob.glob(yol("/etc/apt/apt.conf.d/*")):
        if re.search(r"Acquire::(https?)::Proxy", oku(p), re.I):
            bulunan.append(p)
    return bulunan


def tls_dene(host, sure=8):
    """("ok"|"dogrulanamadi"|"saat"|"baglanti", ayrıntı)"""
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, 443), timeout=sure) as s:
            with ctx.wrap_socket(s, server_hostname=host):
                return "ok", ""
    except ssl.SSLCertVerificationError as e:
        neden = (getattr(e, "verify_message", "") or str(e)).lower()
        if "expired" in neden or "not yet valid" in neden:
            return "saat", neden
        return "dogrulanamadi", veren_al(host) or neden
    except (OSError, ssl.SSLError) as e:
        return "baglanti", str(e)


def veren_al(host):
    """Sitenin sunduğu sertifikayı kimin verdiği (MEB ağı araya girdiyse onu gösterir)."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, 443), timeout=8) as s:
            with ctx.wrap_socket(s, server_hostname=host) as t:
                der = t.getpeercert(binary_form=True)
        return sertifika_bilgi(ssl.DER_cert_to_PEM_cert(der)).get("veren")
    except Exception:
        return None


def sertifika_bilgi(pem):
    """PEM sertifikanın konu, veren ve bitiş tarihi."""
    with tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False) as f:
        f.write(pem)
        p = f.name
    try:
        d = ssl._ssl._test_decode_cert(p)
    finally:
        os.remove(p)

    def ad(alan):
        x = dict(i[0] for i in d.get(alan) or [] if i)
        return x.get("commonName") or x.get("organizationName") or ""
    return {"konu": ad("subject"), "veren": ad("issuer"), "bitis": d.get("notAfter"), "seri": d.get("serialNumber")}


def dokunmatik_aygitlar():
    bulunan = []
    for ev in sorted(glob.glob("/dev/input/event*"))[:48]:
        _, c = calistir(["udevadm", "info", "-q", "property", "-n", ev], 5)
        if "ID_INPUT_TOUCHSCREEN=1" in c:
            m = re.search(r"^ID_MODEL=(.*)$", c, re.M)
            bulunan.append((m.group(1) if m else os.path.basename(ev)).replace("_", " "))
    if not bulunan:
        blok = oku("/proc/bus/input/devices")
        for m in re.finditer(r'N: Name="([^"]+)"', blok):
            if re.search(r"touch|dokun|ilitek|egalax|goodix|elan.*tp|multi-?touch", m.group(1), re.I):
                bulunan.append(m.group(1))
    return list(dict.fromkeys(bulunan))


class Tanilayici:
    """ortam: sunucu, sunucular, mod ('ajan' | 'bellek'), sertifika (PEM), oturum, kimlik_cakisma, ajan_surum"""

    def __init__(self, ortam=None):
        self.o = dict(ortam or {})
        self.bulgular = []
        self.bilgi = {}
        if "oturum" not in self.o:
            try:
                self.o["oturum"] = oturum_bul()
            except Exception:
                self.o["oturum"] = None

    def ekle(self, b):
        self.bulgular.append(b)

    def calistir(self):
        for f in (self.ag, self.yonetim, self.saat_kontrol, self.sertifika_kontrol, self.sistem, self.ses_goruntu,
                  self.aygitlar, self.program):
            try:
                f()
            except Exception as e:
                self.ekle(B(f.__name__, "Sistem", "Kontrol: " + f.__name__, "bilgi", "Kontrol yapılamadı: {}".format(e)))
        self.bilgi.update(cihaz_bilgisi())
        return self.bulgular

    # ── ağ ───────────────────────────────────────────────────────────────────
    def ag(self):
        G = GRUPLAR[0]
        kartlar = arayuzler()
        kablolu = [k for k in kartlar if not k["kablosuz"]]
        kablosuz = [k for k in kartlar if k["kablosuz"]]
        self.bilgi["kartlar"] = kartlar
        if not kartlar:
            return self.ekle(B("ag_kart", G, "Ağ kartı", "hata", "Tahta hiçbir ağ kartı görmüyor. Kartın sürücüsü yüklenmemiş "
                               "ya da kart arızalı olabilir; tahtayı tamamen kapatıp açın, düzelmezse teknik servise bildirin."))
        self.ekle(B("ag_kart", G, "Ağ kartı", "ok", " · ".join("{} {} ({})".format("Kablosuz" if k["kablosuz"] else "Kablolu", k["ad"],
                                                                                     k["surucu"] or "sürücü ?") for k in kartlar)))
        adresler = ipv4_adresler()
        self.bilgi["adresler"] = adresler
        wifi_bagli = any(a for a, _, _ in adresler if a in [k["ad"] for k in kablosuz])
        realtek = [k for k in kablolu if k["vendor"] == "0x10ec" and k["aygit"] in ("0x8168", "0x8111", "0x8161") and k["surucu"] == "r8169"]
        for k in kablolu:
            if k["tasiyici"]:
                self.ekle(B("kablo_" + k["ad"], G, "Kablo bağlantısı", "ok", "Kablo takılı, bağlantı ışığı yanıyor ({}).".format(k["ad"])))
            elif wifi_bagli:
                self.ekle(B("kablo_" + k["ad"], G, "Kablo bağlantısı", "bilgi", "Kablo takılı değil; tahta kablosuz ağı kullanıyor."))
            else:
                ek = ""
                onar = None
                if k in realtek:
                    ek = (" Bu tahtadaki Realtek kart, Linux'un varsayılan sürücüsüyle bazen bağlantı kuramıyor. Kablo ve port "
                          "sağlamsa (başka cihazda çalışıyorsa) uygun sürücü kurulabilir — kurulum için internet gerekir.")
                    onar = "r8168"
                self.ekle(B("kablo_" + k["ad"], G, "Kablo bağlantısı", "hata",
                            "Ağ kartı çalışıyor ama bağlantı ışığı yok: kablo takılı değil, kablo kopuk ya da switch portu kapalı. "
                            "Kabloyu başka bir cihazda ya da başka bir portta deneyin." + ek, onar))
        if not adresler:
            kendinden = [a for a in kartlar if a["tasiyici"] or a["kablosuz"]]
            return self.ekle(B("ip", G, "IP adresi", "hata", "Tahta ağdan adres alamadı." +
                               (" Kablo bağlı olduğu hâlde adres gelmiyorsa modemin adres dağıtımı (DHCP) çalışmıyor olabilir."
                                if kendinden else ""), "ag_yenile"))
        ip, kart, onek = adresler[0]
        if ip.startswith("169.254."):
            return self.ekle(B("ip", G, "IP adresi", "hata", "Modemden adres alınamadı ({}): modem ya da adres dağıtımı (DHCP) yanıt vermiyor.".format(ip), "ag_yenile"))
        baglantilar = nm_baglantilar()
        elle = [b for b in baglantilar if b["yontem"] == "manual"]
        self.ekle(B("ip", G, "IP adresi", "ok", "{} ({}, {})".format(ip, kart, "elle girilmiş" if elle else "otomatik")))
        gw, gw_kart = varsayilan_yol()
        self.bilgi["ag_gecidi"] = gw
        if elle:
            b = elle[0]
            yanlis = (not gw) or (b["gw"] and not ayni_ag(ip, b["gw"], onek))
            if yanlis or (gw and not ping(gw)):
                self.ekle(B("elle", G, "Elle girilmiş ağ ayarı", "hata",
                            "Bu tahtada IP, ağ geçidi ve DNS elle yazılmış ve çalışmıyor ({}). Otomatiğe çevrilince modem doğru ayarı verir.".format(
                                ", ".join(x for x in (b["adres"], b["gw"], b["dns"]) if x) or b["ad"]), "dhcp", baglanti=b["ad"]))
            else:
                self.ekle(B("elle", G, "Elle girilmiş ağ ayarı", "bilgi", "Ağ ayarı elle girilmiş ve çalışıyor ({}).".format(b["adres"] or ip)))
        if not gw:
            self.ekle(B("gw", G, "Ağ geçidi (modem)", "hata", "Tahtada ağ geçidi (modem adresi) tanımlı değil.", "ag_yenile"))
        elif ping(gw):
            self.ekle(B("gw", G, "Ağ geçidi (modem)", "ok", "Modeme ulaşılıyor ({}).".format(gw)))
        else:
            self.ekle(B("gw", G, "Ağ geçidi (modem)", "uyari", "Modem ({}) ping'e yanıt vermiyor. Bazı modemler ping'i kapatır; "
                        "internet çalışıyorsa sorun yoktur.".format(gw)))
        if var("arping") and os.geteuid() == 0:
            k, c = calistir(["arping", "-D", "-c", "2", "-w", "3", "-I", kart, ip], 10)
            if k == 1 and re.search(r"reply from", c, re.I):
                m = re.search(r"\[([0-9a-f:]{17})\]", c, re.I)
                self.ekle(B("cakisma", G, "IP çakışması", "hata", "Bu IP adresini ({}) ağda başka bir cihaz da kullanıyor{}. "
                            "İki cihaz da zaman zaman bağlantı kaybeder.".format(ip, " (" + m.group(1) + ")" if m else ""),
                            "dhcp" if elle else "ag_yenile", baglanti=elle[0]["ad"] if elle else None))
            elif k == 0:
                self.ekle(B("cakisma", G, "IP çakışması", "ok", "Ağda bu adresi kullanan başka cihaz yok."))
        dns = coz(DENEME_SITELER[0])
        if dns:
            self.ekle(B("dns", G, "Alan adı çözümleme (DNS)", "ok", "Site adları çözülüyor."))
        else:
            self.ekle(B("dns", G, "Alan adı çözümleme (DNS)", "hata", "Site adları IP adresine çevrilemiyor (DNS çalışmıyor)." +
                        (" DNS elle girilmiş ({}).".format(elle[0]["dns"]) if elle and elle[0]["dns"] else ""),
                        "dhcp" if elle else "ag_yenile", baglanti=elle[0]["ad"] if elle else None))
        internet = tcp(dns or "1.1.1.1", 443, 6) or tcp("1.1.1.1", 443, 6) or tcp("8.8.8.8", 53, 6)
        self.o["internet"] = internet
        if internet:
            self.ekle(B("internet", G, "İnternet", "ok", "İnternete çıkılıyor."))
        else:
            self.ekle(B("internet", G, "İnternet", "hata", "İnternete çıkılamıyor. Tahta modeme ulaşıyorsa sorun tahtada değil, "
                        "okul ağındadır (modem, internet hattı ya da ağ filtresi)." if gw and ping(gw, 1) else
                        "İnternete çıkılamıyor; önce yukarıdaki ağ sorunları çözülmeli.", sorun_ag=True))
        p = proxy_var()
        gs_mod = ""
        if self.o.get("oturum"):
            _, gs_mod = kullanici_olarak(["gsettings", "get", "org.gnome.system.proxy", "mode"], self.o["oturum"], 10)
            gs_mod = gs_mod.strip().strip("'")
        if p or gs_mod == "manual":
            self.ekle(B("proxy", G, "Vekil sunucu (proxy)", "uyari" if internet else "hata",
                        "Tahtada vekil sunucu ayarı var ({}). Okul ağında gerekmiyorsa sitelerin açılmamasına yol açar.".format(
                            ", ".join(p + (["masaüstü ayarı"] if gs_mod == "manual" else []))), "proxy"))
        if kablosuz:
            self.kablosuz(kablosuz, adresler, G)

    def kablosuz(self, kartlar, adresler, G):
        bagli = [k for k in kartlar if k["ad"] in [a for a, _, _ in adresler]]
        tasarruf_kapali = False
        for p in glob.glob(yol("/etc/NetworkManager/conf.d/*.conf")):
            if re.search(r"^\s*wifi\.powersave\s*=\s*2", oku(p), re.M):
                tasarruf_kapali = True
        sinyal = None
        if var("nmcli"):
            _, c = calistir(["nmcli", "-t", "-f", "IN-USE,SIGNAL,SSID", "device", "wifi", "list", "--rescan", "no"], 15)
            for satir in c.splitlines():
                if satir.startswith("*"):
                    p = satir.split(":")
                    try:
                        sinyal = int(p[1])
                    except (IndexError, ValueError):
                        pass
        kopma = 0
        if var("journalctl"):
            _, j = calistir(["journalctl", "-u", "NetworkManager", "--since", "-24h", "-o", "cat", "--no-pager"], 20)
            kopma = len(re.findall(r"\(\S*wl\S*\): state change: activated -> (?:disconnected|deactivating|failed)", j))
        self.bilgi["kablosuz"] = {"sinyal": sinyal, "kopma_24s": kopma}
        if not bagli:
            return
        if not tasarruf_kapali:
            self.ekle(B("wifi_tasarruf", G, "Kablosuz güç tasarrufu", "uyari" if kopma < 3 else "hata",
                        "Kablosuz kartın güç tasarrufu açık. Bağlantı birkaç dakikada bir kopuyorsa en sık neden budur." +
                        (" Son 24 saatte {} kez koptu.".format(kopma) if kopma else ""), "wifi_tasarruf"))
        elif kopma >= 3:
            self.ekle(B("wifi_kopma", G, "Kablosuz bağlantı", "uyari", "Son 24 saatte {} kez koptu (güç tasarrufu zaten kapalı). "
                        "Sinyal zayıf ya da kanal kalabalık olabilir; mümkünse kablo kullanın.".format(kopma)))
        if sinyal is not None:
            self.ekle(B("wifi_sinyal", G, "Kablosuz sinyal gücü", "ok" if sinyal >= 50 else "uyari",
                        "Sinyal %{}{}".format(sinyal, "" if sinyal >= 50 else " — zayıf; erişim noktası uzak ya da arada engel var.")))

    # ── yönetim bilgisayarı ──────────────────────────────────────────────────
    def yonetim(self):
        G = GRUPLAR[1]
        adresler = [a for a in [self.o.get("sunucu")] + list(self.o.get("sunucular") or []) if a]
        if not adresler:
            return
        for adres in dict.fromkeys(adresler):
            h, p = ayir(adres)
            if not h:
                continue
            if not tcp(h, p, 6) and not tcp(h, p, 10):
                continue
            try:
                with acici().open(adres.rstrip("/") + "/api/saglik", timeout=10) as y:
                    if b"TahtaYonetim" in y.read(4096):
                        self.o["calisan_sunucu"] = adres.rstrip("/")
                        return self.ekle(B("yonetim", G, "Yönetim bilgisayarı", "ok", "Yönetim bilgisayarına ulaşılıyor ({}).".format(h)))
            except Exception:
                pass
        h, p = ayir(adresler[0])
        gw = self.bilgi.get("ag_gecidi")
        if not self.bilgi.get("adresler"):
            mesaj = "Tahtanın ağ bağlantısı olmadığı için yönetim bilgisayarına ulaşılamıyor."
        elif h and ping(h, 1):
            mesaj = ("Yönetim bilgisayarı ({}) açık ama program yanıt vermiyor: program kapalı ya da güvenlik duvarı engelliyor. "
                     "Yönetim bilgisayarında KUR.bat'ı yeniden çalıştırın.".format(h))
        else:
            mesaj = ("Yönetim bilgisayarına ({}) ulaşılamıyor: bilgisayar kapalı, adresi değişmiş ya da tahta farklı bir ağda.".format(h) +
                     (" Tahtanın ağ geçidi: {}.".format(gw) if gw else ""))
        self.ekle(B("yonetim", G, "Yönetim bilgisayarı", "hata", mesaj))

    # ── saat ─────────────────────────────────────────────────────────────────
    def saat_kontrol(self):
        G = GRUPLAR[2]
        ref, kaynak = None, ""
        if self.o.get("calisan_sunucu"):
            ref, kaynak = http_tarih(self.o["calisan_sunucu"] + "/api/saglik"), "yönetim bilgisayarı"
        if ref is None and self.o.get("internet"):
            for s in DENEME_SITELER:
                ref = http_tarih("http://" + s + "/")
                if ref:
                    kaynak = s
                    break
        if ref is None:
            return self.ekle(B("saat", G, "Saat ve tarih", "bilgi", "Karşılaştırılacak doğru saat bulunamadı (ağ yok)."))
        fark = time.time() - ref
        self.o["ref_zaman"], self.o["ref_olcum"] = ref, time.time()
        if abs(fark) > 120:
            self.ekle(B("saat", G, "Saat ve tarih", "hata", "Tahtanın saati {} {} ({} göre). Saat yanlışken siteler "
                        "\"güvenli değil\" hatası verir. Saat her açılışta bozuluyorsa anakart pili bitmiş olabilir.".format(
                            sure_yazi(abs(fark)), "ileri" if fark > 0 else "geri", kaynak + "'na" if kaynak == "yönetim bilgisayarı" else kaynak + "'a"),
                        "saat", ref=ref, olcum=time.time()))
        else:
            self.ekle(B("saat", G, "Saat ve tarih", "ok", "Saat doğru."))

    # ── güvenlik sertifikası ─────────────────────────────────────────────────
    def sertifika_kontrol(self):
        G = GRUPLAR[0]
        if not self.o.get("internet"):
            return
        sonuc, ayrinti = "baglanti", ""
        for s in DENEME_SITELER:
            sonuc, ayrinti = tls_dene(s)
            if sonuc != "baglanti":
                break
        if sonuc == "ok":
            return self.ekle(B("sertifika", G, "Güvenlik sertifikası", "ok", "Güvenli (https) siteler sorunsuz açılıyor."))
        if sonuc == "saat":
            return self.ekle(B("sertifika", G, "Güvenlik sertifikası", "hata", "Siteler \"güvenli değil\" hatası veriyor; neden tahtanın saati."))
        if sonuc == "baglanti":
            return self.ekle(B("sertifika", G, "Güvenlik sertifikası", "uyari", "Güvenli bağlantı kurulamadı: {}".format(ayrinti[:150])))
        kurulu = os.path.exists(yol(SERTIFIKA_YOL))
        if self.o.get("sertifika"):
            self.ekle(B("sertifika", G, "Güvenlik sertifikası", "hata",
                        "Siteler \"güvenli değil\" hatası veriyor: okul ağı araya kendi sertifikasını koyuyor ({}) ama bu tahtada o sertifika "
                        "{}. Panele yüklenen okul ağı sertifikası kurulunca düzelir.".format(ayrinti or "?", "eski/yanlış" if kurulu else "kurulu değil"),
                        "sertifika"))
        else:
            self.ekle(B("sertifika", G, "Güvenlik sertifikası", "hata",
                        "Siteler \"güvenli değil\" hatası veriyor: okul ağı araya kendi sertifikasını koyuyor ({}). Sertifikayı panelde "
                        "Raporlar › Tahta sağlığı › Okul ağı sertifikası bölümüne bir kez yükleyin; tüm tahtalara kurulur.".format(ayrinti or "?")))

    # ── sistem ───────────────────────────────────────────────────────────────
    def sistem(self):
        G = GRUPLAR[2]
        if var("dpkg"):
            _, c = calistir(["dpkg", "--audit"], 60)
            if c.strip():
                self.ekle(B("paket", G, "Paket sistemi", "hata", "Yarım kalmış bir güncelleme ya da kurulum var; yeni uygulama ve güncelleme kurulamaz.", "paket"))
            else:
                self.ekle(B("paket", G, "Paket sistemi", "ok", "Paket sistemi sağlam."))
            if self.o.get("internet"):
                if tcp("depo.pardus.org.tr", 80, 6) or tcp("depo.pardus.org.tr", 443, 6):
                    self.ekle(B("depo", G, "Pardus deposu", "ok", "Güncelleme sunucusuna ulaşılıyor."))
                else:
                    self.ekle(B("depo", G, "Pardus deposu", "uyari", "Pardus deposuna ulaşılamıyor; güncelleme ve uygulama kurulumu çalışmaz "
                                "(okul ağı filtresi engelliyor olabilir)."))
        try:
            d = shutil.disk_usage("/")
            yuzde = 100.0 * d.used / d.total
            bos = d.free / 1024 ** 3
            durum = "hata" if yuzde >= 97 or bos < 1 else "uyari" if yuzde >= 90 or bos < 3 else "ok"
            self.ekle(B("disk", G, "Disk", durum, "%{:.0f} dolu, {:.1f} GB boş.{}".format(yuzde, bos, "" if durum == "ok" else
                        " Disk dolunca tahta yavaşlar, güncelleme yapılamaz, oturum açılmayabilir."), "disk" if durum != "ok" else None))
        except OSError:
            pass
        m = dict(re.findall(r"^(\w+):\s+(\d+)", oku("/proc/meminfo"), re.M))
        if m.get("MemTotal") and m.get("MemAvailable"):
            oran = int(m["MemAvailable"]) / int(m["MemTotal"])
            if oran < 0.10:
                _, ps = calistir(["ps", "-eo", "comm,%mem", "--sort=-%mem", "--no-headers"], 10)
                ilk = ", ".join("{} (%{})".format(*x.split()[:2]) for x in ps.splitlines()[:3] if len(x.split()) >= 2)
                self.ekle(B("bellek", G, "Bellek (RAM)", "uyari", "Bellek neredeyse dolu (%{:.0f} boş). En çok kullananlar: {}. "
                            "Tahtayı yeniden başlatmak rahatlatır.".format(oran * 100, ilk)))
            else:
                self.ekle(B("bellek", G, "Bellek (RAM)", "ok", "%{:.0f} boş.".format(oran * 100)))
        if var("systemctl"):
            _, c = calistir(["systemctl", "--failed", "--plain", "--no-legend", "--no-pager"], 20)
            cokenler = [s.split()[0] for s in c.splitlines() if s.strip() and s.split()[0].endswith((".service", ".socket"))]
            self.bilgi["coken_hizmetler"] = cokenler
            if cokenler:
                self.ekle(B("hizmet", G, "Sistem hizmetleri", "uyari", "Çalışmayan hizmet: " + ", ".join(cokenler[:8]), "hizmet", hizmetler=cokenler[:12]))
            else:
                self.ekle(B("hizmet", G, "Sistem hizmetleri", "ok", "Tüm hizmetler çalışıyor."))

    # ── ses, ekran, dokunmatik ───────────────────────────────────────────────
    def ses_goruntu(self):
        G = GRUPLAR[3]
        o = self.o.get("oturum")
        dok = dokunmatik_aygitlar()
        self.ekle(B("dokunmatik", G, "Dokunmatik", "ok" if dok else "hata", ", ".join(dok) if dok else
                    "Dokunmatik çerçeve algılanmıyor. Dokunmatik USB kablosu çıkmış ya da çerçeve arızalı olabilir; tahtayı kapatıp "
                    "açın, düzelmezse teknik servise bildirin."))
        kal = [p for p in glob.glob(yol("/etc/X11/xorg.conf.d/*.conf")) if re.search(r"calibrat|kalibr", os.path.basename(p), re.I)
               or re.search(r'Option\s+"Calibration"|TransformationMatrix', oku(p))]
        if kal and dok:
            self.ekle(B("kalibrasyon", G, "Dokunmatik kalibrasyonu", "bilgi", "Elle yapılmış bir kalibrasyon ayarı var ({}). Dokunduğunuz yer "
                        "ile işaretçi kayıksa sıfırlanabilir (oturum yeniden açılınca geçerli olur).".format(", ".join(os.path.basename(x) for x in kal)),
                        "kalibrasyon", dosyalar=kal))
        if not o:
            return self.ekle(B("oturum", G, "Ses ve ekran", "bilgi", "Tahtada açık masaüstü oturumu yok; ses ve ekran kontrol edilemedi."))
        if var("pactl"):
            _, sinks = kullanici_olarak(["pactl", "list", "short", "sinks"], o)
            if not [s for s in sinks.splitlines() if s.strip() and "auto_null" not in s]:
                self.ekle(B("ses", G, "Ses", "hata", "Ses çıkışı bulunamadı; ses sistemi çökmüş ya da ses kartı görünmüyor.", "ses"))
            else:
                _, ms = kullanici_olarak(["pactl", "get-sink-mute", "@DEFAULT_SINK@"], o)
                _, vs = kullanici_olarak(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], o)
                sessiz = "yes" in ms.lower()
                m = re.search(r"(\d+)%", vs)
                seviye = int(m.group(1)) if m else None
                self.bilgi["ses"] = {"sessiz": sessiz, "seviye": seviye}
                if sessiz or (seviye is not None and seviye < 10):
                    self.ekle(B("ses", G, "Ses", "uyari", "Ses {}.".format("kapalı (sessize alınmış)" if sessiz else "çok kısık (%{})".format(seviye)), "ses",
                                sessiz=sessiz, seviye=seviye))
                else:
                    self.ekle(B("ses", G, "Ses", "ok", "Ses açık (%{}).".format(seviye) if seviye is not None else "Ses açık."))
        env = o.get("env") or {}
        if var("xrandr") and env.get("DISPLAY") and not env.get("WAYLAND_DISPLAY"):
            _, x = kullanici_olarak(["xrandr", "--query"], o)
            cikis, simdiki, onerilen = None, None, None
            for satir in x.splitlines():
                m = re.match(r"^(\S+) connected", satir)
                if m:
                    if cikis and simdiki:
                        break
                    cikis, simdiki, onerilen = m.group(1), None, None
                    continue
                m = re.match(r"^\s+(\d+x\d+)\S*\s+(.*)$", satir)
                if m and cikis:
                    if "*" in m.group(2):
                        simdiki = m.group(1)
                    if "+" in m.group(2):
                        onerilen = onerilen or m.group(1)
            if cikis and simdiki:
                self.bilgi["ekran"] = {"cikis": cikis, "cozunurluk": simdiki, "onerilen": onerilen}
                if onerilen and simdiki != onerilen:
                    self.ekle(B("ekran", G, "Ekran çözünürlüğü", "uyari", "Ekran {} çözünürlükte; tahtanın önerilen çözünürlüğü {}. "
                                "Görüntü bulanık ya da taşmış görünebilir.".format(simdiki, onerilen), "ekran", cikis=cikis, mod=onerilen, eski=simdiki))
                else:
                    self.ekle(B("ekran", G, "Ekran çözünürlüğü", "ok", "{} ({})".format(simdiki, cikis)))

    # ── yazıcı ve aygıtlar ───────────────────────────────────────────────────
    def aygitlar(self):
        G = GRUPLAR[4]
        if var("lpstat"):
            k, r = calistir(["lpstat", "-r"], 10)
            if "not running" in r or k != 0:
                self.ekle(B("yazici", G, "Yazdırma sistemi", "hata", "Yazdırma sistemi (CUPS) çalışmıyor; hiçbir yazıcı basmaz.", "yazici"))
            else:
                _, p = calistir(["lpstat", "-p"], 15)
                _, o = calistir(["lpstat", "-o"], 15)
                durmus = re.findall(r"^printer (\S+) disabled", p, re.M)
                isler = len([s for s in o.splitlines() if s.strip()])
                if durmus:
                    self.ekle(B("yazici", G, "Yazıcı", "hata", "Durdurulmuş yazıcı: {}. Bir baskı hatasından sonra CUPS yazıcıyı durdurmuş; "
                                "yeniden etkinleştirilmeden basmaz.".format(", ".join(durmus)), "yazici"))
                elif isler:
                    self.ekle(B("yazici", G, "Yazıcı", "uyari", "Kuyrukta {} iş bekliyor. Yazıcı kapalı, kağıt bitmiş ya da kuyruk takılmış olabilir.".format(isler), "yazici"))
                elif re.search(r"^printer ", p, re.M):
                    self.ekle(B("yazici", G, "Yazıcı", "ok", "Yazıcı hazır, bekleyen iş yok."))
        kamera = glob.glob("/dev/video*")
        _, mik = calistir(["arecord", "-l"], 10) if var("arecord") else (1, "")
        mikrofon = len(re.findall(r"^card \d+", mik, re.M))
        usb = len([d for d in glob.glob("/sys/bus/usb/devices/*") if re.match(r"^\d+-[\d.]+$", os.path.basename(d))])
        self.ekle(B("aygitlar", G, "Kamera, mikrofon, USB", "bilgi", "Kamera: {} · Mikrofon: {} · Takılı USB aygıt: {}".format(
            "var" if kamera else "yok", "var" if mikrofon else "yok", usb)))

    # ── tahta programı ───────────────────────────────────────────────────────
    def program(self):
        G = GRUPLAR[5]
        if self.o.get("kimlik_cakisma"):
            self.ekle(B("kimlik", G, "Tahta kimliği", "hata", "Bu tahtanın kimliği başka bir tahtayla aynı (aynı imajdan kurulmuşlar). "
                        "Panelde iki tahta tek tahta gibi görünür. Yeni kimlik verilince tahta panele ayrı tahta olarak gelir.", "kimlik"))
        if self.o.get("mod") != "bellek" or os.name == "nt":
            return
        ajan = yol("/opt/tahta-ajan/tahta-ajan.py")
        if not os.path.exists(ajan):
            self.o["ajan_gerekli"] = "kur"
            return self.ekle(B("ajan", G, "Tahta programı", "hata", "Tahta programı kurulu değil."))
        m = re.search(r'^SURUM\s*=\s*"([^"]+)"', oku(ajan), re.M)
        surum = m.group(1) if m else "?"
        _, aktif = calistir(["systemctl", "is-active", "tahta-ajan"], 10)
        try:
            b = json.load(open(yol("/var/lib/tahta-ajan/baglanti.json"), encoding="utf-8"))
        except Exception:
            b = None
        if b is None:
            self.o["ajan_gerekli"] = "onar"
            return self.ekle(B("ajan", G, "Tahta programı", "hata", "Tahta programının bağlantı ayarı bozuk ya da silinmiş (sürüm {}).".format(surum)))
        if aktif.strip() != "active":
            self.o["ajan_gerekli"] = "onar"
            return self.ekle(B("ajan", G, "Tahta programı", "hata", "Tahta programı kurulu (sürüm {}) ama çalışmıyor.".format(surum), "ajan_baslat"))
        bilinen = [a.rstrip("/") for a in [self.o.get("sunucu")] + list(self.o.get("sunucular") or []) if a]
        if bilinen and b.get("sunucu", "").rstrip("/") not in bilinen:
            self.o["ajan_gerekli"] = "onar"
            return self.ekle(B("ajan", G, "Tahta programı", "hata", "Tahta programı eski bir yönetim bilgisayarı adresine bağlanmaya çalışıyor ({}).".format(b.get("sunucu"))))
        if self.o.get("ajan_surum") and surum != self.o["ajan_surum"]:
            self.o["ajan_gerekli"] = "onar"
            return self.ekle(B("ajan", G, "Tahta programı", "uyari", "Tahta programı eski sürüm ({}; güncel: {}).".format(surum, self.o["ajan_surum"])))
        self.ekle(B("ajan", G, "Tahta programı", "ok", "Kurulu ve çalışıyor (sürüm {}).".format(surum)))


def sure_yazi(sn):
    sn = int(sn)
    if sn >= 86400:
        return "{} gün".format(sn // 86400)
    if sn >= 3600:
        return "{} saat".format(sn // 3600)
    return "{} dakika".format(max(1, sn // 60))


def makine_kimligi():
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        k = oku(yol(p))
        if len(k) >= 16:
            return k
    return ""


def cihaz_bilgisi():
    rel = dict(re.findall(r'^(\w+)="?([^"\n]*)"?', oku("/etc/os-release"), re.M))
    return {"hostname": socket.gethostname(), "os": rel.get("PRETTY_NAME") or "", "kimlik": makine_kimligi(),
            "macler": [k["mac"] for k in arayuzler() if k["mac"]], "ip": [a[1] for a in ipv4_adresler()]}


def tanila(ortam=None):
    t = Tanilayici(ortam)
    b = t.calistir()
    return {"bulgular": b, "bilgi": t.bilgi, "zaman": time.time(), "platform": "linux", "surum": SURUM}


def ozet(bulgular):
    h = sum(1 for b in bulgular if b["durum"] == "hata")
    u = sum(1 for b in bulgular if b["durum"] == "uyari")
    if not h and not u:
        return "Sorun bulunmadı"
    return ", ".join(x for x in ("{} sorun".format(h) if h else "", "{} uyarı".format(u) if u else "") if x)


# ═════════════════════════════════════════════════════════════════════════════
# Onarım (Pardus / Linux)
# ═════════════════════════════════════════════════════════════════════════════

def nm_yenile():
    if var("nmcli"):
        degistir(["systemctl", "restart", "NetworkManager"], 60)
    elif var("systemctl"):
        degistir(["systemctl", "restart", "networking"], 90)
    if not SAHTE:
        for _ in range(20):
            time.sleep(1.5)
            if ipv4_adresler() and varsayilan_yol()[0]:
                break


def onar(islemler, ortam=None, bulgular=None):
    """islemler: onar kimlikleri. bulgular: son tanılamanın bulguları (ayrıntı için). → [{id, ok, mesaj}]"""
    ortam = dict(ortam or {})
    if "oturum" not in ortam:
        try:
            ortam["oturum"] = oturum_bul()
        except Exception:
            ortam["oturum"] = None
    o = ortam["oturum"]
    bul = {}
    for b in bulgular or []:
        if b.get("onar"):
            bul.setdefault(b["onar"], b)
    y = Yedek()
    sonuc = []
    sira = ["saat", "proxy", "dhcp", "wifi_tasarruf", "ag_yenile", "sertifika", "paket", "r8168", "disk", "hizmet",
            "ses", "ekran", "kalibrasyon", "yazici", "ajan_baslat", "kimlik"]
    istenen = [i for i in sira if i in set(islemler)]
    ag_yenilenecek = False
    for i in istenen:
        try:
            r = ONARICI[i](bul.get(i) or {}, ortam, y, o)
            if r is None:
                r = (True, "Yapıldı")
            if r == "ag":
                ag_yenilenecek, r = True, (True, "Ağ bağlantısı yeniden başlatılacak")
            sonuc.append({"id": i, "baslik": ONAR_YAZI.get(i, i), "ok": bool(r[0]), "mesaj": r[1]})
        except Exception as e:
            sonuc.append({"id": i, "baslik": ONAR_YAZI.get(i, i), "ok": False, "mesaj": str(e)[:300]})
    if ag_yenilenecek or "ag_yenile" in istenen:
        nm_yenile()
    y.kaydet("Onarım: " + ", ".join(istenen))
    return sonuc


def o_ag_yenile(b, ortam, y, o):
    return "ag"


def o_dhcp(b, ortam, y, o):
    if not var("nmcli"):
        return False, "NetworkManager yok; ağ ayarı elle düzeltilmeli"
    hedefler = [b["baglanti"]] if b.get("baglanti") else [x["ad"] for x in nm_baglantilar() if x["yontem"] == "manual"]
    if not hedefler:
        return True, "Elle girilmiş ayar bulunamadı (zaten otomatik)"
    for ad in hedefler:
        _, a = calistir(["nmcli", "-g", "ipv4.method,ipv4.addresses,ipv4.gateway,ipv4.dns", "connection", "show", ad], 15)
        s = (a.splitlines() + ["", "", "", ""])[:4]
        y.ekle(tur="nm", ad=ad, alanlar={"ipv4.method": s[0] or "auto", "ipv4.addresses": s[1], "ipv4.gateway": s[2], "ipv4.dns": s[3]})
        k, c = degistir(["nmcli", "connection", "modify", ad, "ipv4.method", "auto", "ipv4.addresses", "", "ipv4.gateway", "",
                         "ipv4.dns", ""], 30)
        if k:
            return False, "Ayar değiştirilemedi: " + c.strip()[:200]
        degistir(["nmcli", "connection", "up", ad], 60)
    return True, "Otomatik ayara (DHCP) çevrildi: " + ", ".join(hedefler)


def o_proxy(b, ortam, y, o):
    yapilan = []
    p = yol("/etc/environment")
    satirlar = oku(p).splitlines()
    yeni = [s for s in satirlar if not re.match(r"\s*(export\s+)?(https?|ftp|all|no)_proxy\s*=", s, re.I)]
    if len(yeni) != len(satirlar):
        y.dosya(p)
        open(p, "w", encoding="utf-8").write("\n".join(yeni) + "\n")
        yapilan.append("/etc/environment")
    for f in glob.glob(yol("/etc/apt/apt.conf.d/*")):
        if re.search(r"Acquire::(https?)::Proxy", oku(f), re.I):
            y.dosya(f)
            os.remove(f)
            yapilan.append(os.path.basename(f))
    if o:
        _, mod = kullanici_olarak(["gsettings", "get", "org.gnome.system.proxy", "mode"], o, 10)
        mod = mod.strip()
        if mod.strip("'") == "manual":
            y.ekle(tur="gsettings", sema="org.gnome.system.proxy", anahtar="mode", deger=mod.strip("'"))
            kullanici_degistir(["gsettings", "set", "org.gnome.system.proxy", "mode", "none"], o)
            yapilan.append("masaüstü vekil ayarı")
    return True, ("Kaldırıldı: " + ", ".join(yapilan)) if yapilan else "Vekil sunucu ayarı bulunamadı"


def o_wifi_tasarruf(b, ortam, y, o):
    p = yol(WIFI_CONF)
    y.dosya(p)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write("# Tahta Yönetim Asistanı — kablosuz güç tasarrufu kapalı (bağlantı kopmasın)\n[connection]\nwifi.powersave = 2\n")
    return "ag"


def o_sertifika(b, ortam, y, o):
    pem = (ortam.get("sertifika") or "").strip()
    if "BEGIN CERTIFICATE" not in pem:
        return False, "Panelde okul ağı sertifikası yüklü değil"
    p = yol(SERTIFIKA_YOL)
    y.dosya(p)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write(pem + "\n")
    k, c = degistir(["update-ca-certificates"], 120)
    if k:
        return False, "Sistem sertifikaları güncellenemedi: " + c.strip()[-200:]
    tarayici = sertifika_tarayicilara(p, y)
    return True, "Sertifika sisteme kuruldu" + (" · tarayıcılar: " + tarayici if tarayici else "")


def sertifika_tarayicilara(p, y):
    """Chrome/Chromium (~/.pki/nssdb) ve Firefox profillerine (cert9.db) ekler — certutil varsa."""
    if not var("certutil"):
        if var("apt-get") and not SAHTE:
            calistir(["apt-get", "install", "-y", "--no-install-recommends", "libnss3-tools"], 600)
        if not var("certutil"):
            return "certutil yok (Firefox kendi deposunu kullanır; sistem deposu Chrome için yeterli)"
    import pwd
    eklenen = 0
    for kul in pwd.getpwall():
        if kul.pw_uid < 1000 or not os.path.isdir(kul.pw_dir) or kul.pw_shell.endswith(("nologin", "false")):
            continue
        dblar = [os.path.join(kul.pw_dir, ".pki", "nssdb")] + [os.path.dirname(x) for x in glob.glob(
            os.path.join(kul.pw_dir, ".mozilla", "firefox", "*", "cert9.db"))]
        for db in dblar:
            if not os.path.exists(os.path.join(db, "cert9.db")):
                continue
            o = {"uid": kul.pw_uid, "kullanici": kul.pw_name, "env": {"HOME": kul.pw_dir}}
            k, _ = kullanici_degistir(["certutil", "-A", "-n", SERTIFIKA_AD, "-t", "C,,", "-i", p, "-d", "sql:" + db], o)
            if k == 0:
                y.ekle(tur="sertifika_nss", db=db, uid=kul.pw_uid, kullanici=kul.pw_name)
                eklenen += 1
    return "{} tarayıcı profili".format(eklenen) if eklenen else ""


def o_saat(b, ortam, y, o):
    ref = b.get("ref") or ortam.get("ref_zaman")
    olcum = b.get("olcum") or ortam.get("ref_olcum") or time.time()
    if var("timedatectl"):
        degistir(["timedatectl", "set-ntp", "true"], 30)
    if not ref:
        return True, "Saat eşitlemesi (NTP) açıldı"
    ref = ref + (time.time() - olcum)
    k, c = degistir(["date", "-u", "-s", "@%d" % int(ref)], 20)
    if var("hwclock"):
        degistir(["hwclock", "-w"], 30)
    return (k == 0), ("Saat düzeltildi" if k == 0 else "Saat ayarlanamadı: " + c.strip()[:150])


def o_paket(b, ortam, y, o):
    k1, c1 = degistir(["dpkg", "--configure", "-a"], 1800)
    k2, c2 = degistir(["apt-get", "-f", "-y", "install"], 1800)
    _, kalan = calistir(["dpkg", "--audit"], 60)
    if kalan.strip() and not SAHTE:
        return False, "Bir kısmı tamamlanamadı: " + kalan.strip().splitlines()[0][:200]
    return True, "Yarım kalan paket işlemleri tamamlandı"


def o_r8168(b, ortam, y, o):
    if not ortam.get("internet") and not SAHTE:
        return False, "İnternet gerekli (sürücü Pardus deposundan indirilir). Tahtayı geçici olarak kablosuz ağa bağlayıp yeniden deneyin."
    _, cek = calistir(["uname", "-r"], 10)
    k, c = degistir(["apt-get", "install", "-y", "r8168-dkms", "linux-headers-" + cek.strip()], 1800)
    if k:
        return False, "Sürücü kurulamadı (depoda olmayabilir): " + c.strip().splitlines()[-1][:200] if c.strip() else "Sürücü kurulamadı"
    y.ekle(tur="paket", paket="r8168-dkms")
    return True, "Realtek sürücüsü kuruldu; tahtayı yeniden başlatın"


def o_disk(b, ortam, y, o):
    once = shutil.disk_usage("/").free
    if var("apt-get"):
        degistir(["apt-get", "clean"], 300)
    if var("journalctl"):
        degistir(["journalctl", "--vacuum-size=100M"], 120)
    sinir = time.time() - 7 * 86400
    if not SAHTE:
        for kok in ("/tmp", "/var/tmp"):
            for k, dizinler, dosyalar in os.walk(kok):
                for d in dosyalar:
                    p = os.path.join(k, d)
                    try:
                        st = os.lstat(p)
                        if st.st_mtime < sinir and os.path.isfile(p) and not os.path.islink(p):
                            os.remove(p)
                    except OSError:
                        pass
        for d in glob.glob("/home/*/.cache/thumbnails") + glob.glob("/root/.cache/thumbnails"):
            shutil.rmtree(d, ignore_errors=True)
    kazanc = max(0, shutil.disk_usage("/").free - once) / 1024 ** 2
    return True, "{:.0f} MB yer açıldı (indirilmiş paket arşivleri, sistem günlükleri, geçici dosyalar, küçük resim önbelleği). Kişisel dosyalara dokunulmadı.".format(kazanc)


def o_hizmet(b, ortam, y, o):
    hizmetler = b.get("hizmetler")
    if not hizmetler:
        _, c = calistir(["systemctl", "--failed", "--plain", "--no-legend", "--no-pager"], 20)
        hizmetler = [s.split()[0] for s in c.splitlines() if s.strip()]
    duzelen, kalan = [], []
    for h in hizmetler[:12]:
        degistir(["systemctl", "reset-failed", h], 20)
        k, _ = degistir(["systemctl", "restart", h], 90)
        time.sleep(0 if SAHTE else 2)
        _, d = calistir(["systemctl", "is-active", h], 10)
        (duzelen if k == 0 and (SAHTE or d.strip() == "active") else kalan).append(h)
    if kalan:
        return False, "Yeniden başladı: {} · başlamadı: {}".format(", ".join(duzelen) or "—", ", ".join(kalan))
    return True, "Yeniden başlatıldı: " + (", ".join(duzelen) or "—")


def o_ses(b, ortam, y, o):
    if not o:
        return False, "Tahtada açık oturum yok"
    _, sinks = kullanici_olarak(["pactl", "list", "short", "sinks"], o)
    if not [s for s in sinks.splitlines() if s.strip() and "auto_null" not in s]:
        k, _ = kullanici_degistir(["systemctl", "--user", "restart", "pipewire", "pipewire-pulse", "wireplumber"], o)
        if k:
            kullanici_degistir(["pulseaudio", "-k"], o)
        if not SAHTE:
            time.sleep(3)
    y.ekle(tur="ses", sessiz=bool(b.get("sessiz")), seviye=b.get("seviye"))
    kullanici_degistir(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"], o)
    if b.get("seviye") is None or b.get("seviye") < 30:
        kullanici_degistir(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "60%"], o)
    return True, "Ses açıldı" + ("" if b.get("seviye") is not None and b["seviye"] >= 30 else " (%60)")


def o_ekran(b, ortam, y, o):
    if not (o and b.get("cikis") and b.get("mod")):
        return False, "Ekran bilgisi yok"
    y.ekle(tur="ekran", cikis=b["cikis"], mod=b.get("eski") or b["mod"])
    k, c = kullanici_degistir(["xrandr", "--output", b["cikis"], "--mode", b["mod"]], o)
    return (k == 0), ("Ekran {} yapıldı".format(b["mod"]) if k == 0 else "Ayarlanamadı: " + c.strip()[:150])


def o_kalibrasyon(b, ortam, y, o):
    dosyalar = b.get("dosyalar") or []
    for p in dosyalar:
        if os.path.exists(p):
            y.dosya(p)
            os.remove(p)
    return True, "Kalibrasyon ayarı kaldırıldı ({}); oturumu kapatıp açınca geçerli olur".format(", ".join(os.path.basename(p) for p in dosyalar))


def o_yazici(b, ortam, y, o):
    if not var("lpstat"):
        return False, "Bu tahtada yazdırma sistemi (CUPS) yok"
    return yazici_onar()


def yazici_onar(firmware=None):
    """Takılan kuyruğu temizler, CUPS'ı yeniden başlatır, durdurulmuş yazıcıları etkinleştirir."""
    degistir(["cancel", "-a", "-x"], 60)
    degistir(["systemctl", "restart", "cups"], 90)
    if not SAHTE:
        time.sleep(3)
    _, p = calistir(["lpstat", "-p"], 20)
    kuyruklar = re.findall(r"^printer (\S+)", p, re.M)
    for q in kuyruklar:
        degistir(["cupsenable", q], 30)
        degistir(["cupsaccept", q], 30)
    ek = ""
    if firmware:
        try:
            ek = firmware()
        except Exception as e:
            ek = " · firmware gönderilemedi: {}".format(e)
    return True, "Kuyruk temizlendi, yazdırma sistemi yeniden başlatıldı{}{}".format(
        ", yazıcılar etkinleştirildi (" + ", ".join(kuyruklar) + ")" if kuyruklar else "", ek or "")


def o_ajan_baslat(b, ortam, y, o):
    degistir(["systemctl", "enable", "tahta-ajan"], 30)
    k, c = degistir(["systemctl", "restart", "tahta-ajan"], 60)
    return (k == 0), ("Tahta programı yeniden başlatıldı" if k == 0 else c.strip()[:200])


def o_kimlik(b, ortam, y, o):
    p = yol("/etc/machine-id")
    y.dosya(p)
    dbus = yol("/var/lib/dbus/machine-id")
    if os.path.exists(dbus) and not os.path.islink(dbus):
        y.dosya(dbus)
    if SAHTE:
        SAHTE_KOMUTLAR.append(["machine-id yenile"])
        return True, "Yeni kimlik verildi"
    os.remove(p)
    k, c = calistir(["systemd-machine-id-setup"], 30)
    if k:
        return False, c.strip()[:200]
    if os.path.exists(dbus) and not os.path.islink(dbus):
        shutil.copy2(p, dbus)
    return True, "Yeni kimlik verildi; tahta yeniden başlayınca panele ayrı tahta olarak gelir (adını panelden verin)"


ONARICI = {"ag_yenile": o_ag_yenile, "dhcp": o_dhcp, "proxy": o_proxy, "wifi_tasarruf": o_wifi_tasarruf,
           "sertifika": o_sertifika, "saat": o_saat, "paket": o_paket, "r8168": o_r8168, "disk": o_disk,
           "hizmet": o_hizmet, "ses": o_ses, "ekran": o_ekran, "kalibrasyon": o_kalibrasyon, "yazici": o_yazici,
           "ajan_baslat": o_ajan_baslat, "kimlik": o_kimlik}


# ═════════════════════════════════════════════════════════════════════════════
# Windows tahtalar (PowerShell)
# ═════════════════════════════════════════════════════════════════════════════
# Tanılama ve onarım betiği. Ajan SYSTEM olarak çalıştırır; Onarım Belleği aynı motoru kullanır.
# Çıktı: tek satır JSON (bulgular ya da onarım sonuçları).
WIN_MOTOR = r'''
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$script:B = New-Object System.Collections.ArrayList
$GA = 'Ağ ve internet'; $GY = 'Yönetim bilgisayarı'; $GS = 'Sistem'; $GG = 'Ses, görüntü ve dokunmatik'; $GC = 'Yazıcı ve aygıtlar'
$OY = @{ ag_yenile='Ağ bağlantısını yeniden başlat'; sertifika='Okul ağı sertifikasını kur'; saat='Saati düzelt';
         disk='Geçici dosyaları temizle'; hizmet='Durmuş Windows hizmetlerini başlat'; yazici='Yazdırma sistemini onar (kuyruk, durdurulmuş yazıcı)'; proxy='Vekil sunucu (proxy) ayarını kaldır' }
function Ekle($id, $grup, $baslik, $durum, $mesaj, $onar) {
  $o = [ordered]@{ id=$id; grup=$grup; baslik=$baslik; durum=$durum; mesaj=$mesaj }
  if ($onar) { $o.onar = $onar; $o.onar_yazi = $OY[$onar] }
  [void]$script:B.Add($o)
}
function Tcp($h, $p, $ms) {
  try { $c = New-Object Net.Sockets.TcpClient; $a = $c.BeginConnect($h, $p, $null, $null)
        $ok = $a.AsyncWaitHandle.WaitOne($ms); if ($ok) { $c.EndConnect($a) }; $c.Close(); return $ok } catch { return $false }
}
function HttpTarih($u) {
  try { $r = [Net.WebRequest]::Create($u); $r.Timeout = 8000; $r.Method = 'GET'; $y = $r.GetResponse(); $d = $y.Headers['Date']; $y.Close()
        if ($d) { return [DateTimeOffset]::Parse($d).ToUnixTimeSeconds() } } catch [Net.WebException] {
        if ($_.Exception.Response) { $d = $_.Exception.Response.Headers['Date']; if ($d) { return [DateTimeOffset]::Parse($d).ToUnixTimeSeconds() } } } catch {}
  return $null
}
function Tanila($Sunucular, $Sertifika, $Kimlik) {
  # ── ağ
  $kart = @(Get-NetAdapter -Physical | Where-Object { $_.Status -ne 'Disabled' })
  if (-not $kart) { Ekle 'ag_kart' $GA 'Ağ kartı' 'hata' 'Tahta hiçbir ağ kartı görmüyor (sürücü yok ya da kart arızalı).' }
  else { Ekle 'ag_kart' $GA 'Ağ kartı' 'ok' (($kart | ForEach-Object { "$($_.Name) ($($_.InterfaceDescription))" }) -join ' · ') }
  $bagli = @($kart | Where-Object { $_.Status -eq 'Up' })
  foreach ($k in $kart) {
    if ($k.MediaType -match '802.3' -and $k.Status -ne 'Up') {
      if ($bagli) { Ekle ("kablo_" + $k.ifIndex) $GA 'Kablo bağlantısı' 'bilgi' 'Kablo takılı değil; tahta kablosuz ağı kullanıyor.' }
      else { Ekle ("kablo_" + $k.ifIndex) $GA 'Kablo bağlantısı' 'hata' 'Ağ kartı çalışıyor ama bağlantı yok: kablo takılı değil, kopuk ya da switch portu kapalı.' }
    } elseif ($k.MediaType -match '802.3') { Ekle ("kablo_" + $k.ifIndex) $GA 'Kablo bağlantısı' 'ok' 'Kablo takılı, bağlantı var.' }
  }
  $ip = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch 'Loopback|vEthernet|VirtualBox|VMware' -and $_.IPAddress -ne '127.0.0.1' })
  $gecerli = @($ip | Where-Object { $_.IPAddress -notlike '169.254.*' })
  $script:internet = $false
  if (-not $gecerli) {
    if ($ip) { Ekle 'ip' $GA 'IP adresi' 'hata' 'Modemden adres alınamadı (DHCP yanıt vermiyor).' 'ag_yenile' }
    else { Ekle 'ip' $GA 'IP adresi' 'hata' 'Tahta ağdan adres alamadı.' 'ag_yenile' }
  } else {
    $elle = ($gecerli[0].PrefixOrigin -eq 'Manual')
    Ekle 'ip' $GA 'IP adresi' 'ok' ("$($gecerli[0].IPAddress) ($($gecerli[0].InterfaceAlias), " + $(if ($elle) { 'elle girilmiş' } else { 'otomatik' }) + ')')
    $gw = (Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object RouteMetric | Select-Object -First 1).NextHop
    if (-not $gw) { Ekle 'gw' $GA 'Ağ geçidi (modem)' 'hata' 'Ağ geçidi (modem adresi) tanımlı değil.' 'ag_yenile' }
    elseif (Test-Connection -ComputerName $gw -Count 2 -Quiet) { Ekle 'gw' $GA 'Ağ geçidi (modem)' 'ok' "Modeme ulaşılıyor ($gw)." }
    else { Ekle 'gw' $GA 'Ağ geçidi (modem)' 'uyari' "Modem ($gw) ping'e yanıt vermiyor. İnternet çalışıyorsa sorun yoktur." }
    $dns = $null; try { $dns = (Resolve-DnsName www.meb.gov.tr -Type A -QuickTimeout -ErrorAction Stop | Where-Object { $_.IPAddress } | Select-Object -First 1).IPAddress } catch {}
    if ($dns) { Ekle 'dns' $GA 'Alan adı çözümleme (DNS)' 'ok' 'Site adları çözülüyor.' }
    else { Ekle 'dns' $GA 'Alan adı çözümleme (DNS)' 'hata' 'Site adları IP adresine çevrilemiyor (DNS çalışmıyor).' 'ag_yenile' }
    $script:internet = (Tcp $(if ($dns) { $dns } else { '1.1.1.1' }) 443 6000) -or (Tcp '1.1.1.1' 443 6000)
    if ($script:internet) { Ekle 'internet' $GA 'İnternet' 'ok' 'İnternete çıkılıyor.' }
    else { Ekle 'internet' $GA 'İnternet' 'hata' 'İnternete çıkılamıyor. Tahta modeme ulaşıyorsa sorun okul ağındadır (modem, hat, ağ filtresi).' }
  }
  $wp = (netsh winhttp show proxy) -join ' '
  if ($wp -match 'Proxy Server\(s\)\s*:\s*\S') { Ekle 'proxy' $GA 'Vekil sunucu (proxy)' 'uyari' 'Sistemde vekil sunucu ayarı var; okul ağında gerekmiyorsa sitelerin açılmamasına yol açar.' 'proxy' }
  if ($script:internet) {
    $hata = $null
    try { $r = [Net.WebRequest]::Create('https://www.google.com/'); $r.Timeout = 10000; $y = $r.GetResponse(); $y.Close() }
    catch [Net.WebException] { if ($_.Exception.Status -eq 'TrustFailure' -or $_.Exception.Status -eq 'SecureChannelFailure') { $hata = $_.Exception.Message } }
    catch {}
    if ($hata) {
      if ($Sertifika) { Ekle 'sertifika' $GA 'Güvenlik sertifikası' 'hata' 'Siteler "güvenli değil" hatası veriyor: okul ağının sertifikası bu tahtada kurulu değil.' 'sertifika' }
      else { Ekle 'sertifika' $GA 'Güvenlik sertifikası' 'hata' 'Siteler "güvenli değil" hatası veriyor. Okul ağı sertifikasını panelde Tahta sağlığı › Okul ağı sertifikası bölümüne yükleyin.' }
    } else { Ekle 'sertifika' $GA 'Güvenlik sertifikası' 'ok' 'Güvenli (https) siteler sorunsuz açılıyor.' }
  }
  # ── yönetim bilgisayarı ve saat
  $calisan = $null
  foreach ($s in $Sunucular) {
    if (-not $s) { continue }
    try { $u = [Uri]$s; if (Tcp $u.Host $u.Port 6000) {
      $w = New-Object Net.WebClient; $t = $w.DownloadString($s.TrimEnd('/') + '/api/saglik')
      if ($t -match 'TahtaYonetim') { $calisan = $s.TrimEnd('/'); break } } } catch {}
  }
  if ($Sunucular -and @($Sunucular | Where-Object { $_ }).Count) {
    if ($calisan) { Ekle 'yonetim' $GY 'Yönetim bilgisayarı' 'ok' ("Yönetim bilgisayarına ulaşılıyor (" + ([Uri]$calisan).Host + ").") }
    else { Ekle 'yonetim' $GY 'Yönetim bilgisayarı' 'hata' 'Yönetim bilgisayarına ulaşılamıyor: bilgisayar kapalı, program çalışmıyor ya da güvenlik duvarı engelliyor (yönetim bilgisayarında KUR.bat''ı yeniden çalıştırın).' }
  }
  $script:calisan = $calisan
  $ref = $null
  if ($calisan) { $ref = HttpTarih ($calisan + '/api/saglik') }
  if (-not $ref -and $script:internet) { $ref = HttpTarih 'http://www.meb.gov.tr/' }
  if ($ref) {
    $fark = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $ref
    $script:ref = $ref
    if ([Math]::Abs($fark) -gt 120) { Ekle 'saat' $GS 'Saat ve tarih' 'hata' ("Tahtanın saati " + [int]([Math]::Abs($fark) / 60) + " dakika " + $(if ($fark -gt 0) { 'ileri' } else { 'geri' }) + ". Saat yanlışken siteler ""güvenli değil"" hatası verir.") 'saat' }
    else { Ekle 'saat' $GS 'Saat ve tarih' 'ok' 'Saat doğru.' }
  }
  # ── sistem
  $c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
  if ($c) { $yz = [Math]::Round(100 - 100 * $c.FreeSpace / $c.Size); $gb = [Math]::Round($c.FreeSpace / 1GB, 1)
    $d = $(if ($yz -ge 97 -or $gb -lt 1) { 'hata' } elseif ($yz -ge 90 -or $gb -lt 3) { 'uyari' } else { 'ok' })
    Ekle 'disk' $GS 'Disk' $d "%$yz dolu, $gb GB boş." $(if ($d -ne 'ok') { 'disk' }) }
  $os = Get-CimInstance Win32_OperatingSystem
  if ($os) { $bos = [Math]::Round(100 * $os.FreePhysicalMemory / $os.TotalVisibleMemorySize)
    if ($bos -lt 10) { Ekle 'bellek' $GS 'Bellek (RAM)' 'uyari' "Bellek neredeyse dolu (%$bos boş). Tahtayı yeniden başlatmak rahatlatır." } else { Ekle 'bellek' $GS 'Bellek (RAM)' 'ok' "%$bos boş." } }
  $durmus = @(Get-Service Audiosrv, AudioEndpointBuilder, Spooler, Dhcp, Dnscache, W32Time | Where-Object { $_.StartType -ne 'Disabled' -and $_.Status -ne 'Running' } | ForEach-Object { $_.Name })
  if ($durmus) { Ekle 'hizmet' $GS 'Windows hizmetleri' 'uyari' ("Çalışmayan hizmet: " + ($durmus -join ', ')) 'hizmet' } else { Ekle 'hizmet' $GS 'Windows hizmetleri' 'ok' 'Temel hizmetler çalışıyor.' }
  # ── ses, dokunmatik
  $ses = @(Get-PnpDevice -Class AudioEndpoint -Status OK | Where-Object { $_.FriendlyName -notmatch 'Mikrofon|Microphone|Line In|Hat Girişi' })
  if ($ses) { Ekle 'ses' $GG 'Ses' 'ok' ("Ses çıkışı: " + ($ses[0].FriendlyName)) } else { Ekle 'ses' $GG 'Ses' 'hata' 'Ses çıkışı bulunamadı; ses kartı sürücüsü ya da ses hizmeti çalışmıyor.' 'hizmet' }
  $dok = @(Get-PnpDevice -Class HIDClass -Status OK | Where-Object { $_.FriendlyName -match 'touch|dokunma' })
  if ($dok) { Ekle 'dokunmatik' $GG 'Dokunmatik' 'ok' (($dok | Select-Object -First 2 | ForEach-Object { $_.FriendlyName }) -join ', ') }
  else { Ekle 'dokunmatik' $GG 'Dokunmatik' 'hata' 'Dokunmatik çerçeve algılanmıyor. Dokunmatik USB kablosu çıkmış ya da çerçeve arızalı olabilir.' }
  # ── yazıcı ve aygıtlar
  $yz = @(Get-Printer | Where-Object { $_.Type -eq 'Local' -and $_.PortName -notmatch 'PORTPROMPT|nul:|SHRFAX|XPS|PDF|OneNote' })
  $sorun = @($yz | Where-Object { $_.PrinterStatus -in 'Error', 'Offline', 'Paused', 'PaperJam', 'PaperOut', 'UserIntervention' })
  $isler = @($yz | ForEach-Object { Get-PrintJob -PrinterName $_.Name })
  if ($sorun) { Ekle 'yazici' $GC 'Yazıcı' 'hata' ("Sorunlu yazıcı: " + (($sorun | ForEach-Object { "$($_.Name) ($($_.PrinterStatus))" }) -join ', ')) 'yazici' }
  elseif ($isler.Count) { Ekle 'yazici' $GC 'Yazıcı' 'uyari' "Kuyrukta $($isler.Count) iş bekliyor." 'yazici' }
  elseif ($yz) { Ekle 'yazici' $GC 'Yazıcı' 'ok' 'Yazıcı hazır, bekleyen iş yok.' }
  $kam = @(Get-PnpDevice -Class Camera, Image -Status OK).Count; $mik = @(Get-PnpDevice -Class AudioEndpoint -Status OK | Where-Object { $_.FriendlyName -match 'Mikrofon|Microphone' }).Count
  Ekle 'aygitlar' $GC 'Kamera, mikrofon' 'bilgi' ("Kamera: " + $(if ($kam) { 'var' } else { 'yok' }) + " · Mikrofon: " + $(if ($mik) { 'var' } else { 'yok' }))
  if ($Kimlik) { Ekle 'kimlik' 'Tahta programı' 'Tahta kimliği' 'hata' 'Bu tahtanın kimliği başka bir tahtayla aynı (aynı imajdan kurulmuş). Windows''u Sysprep ile hazırlamadan çoğaltılmış tahtalarda görülür; teknik servise bildirin.' }
  return $script:B
}
function YedekDizin() { $d = Join-Path $env:ProgramData ('TahtaYonetim\onarim\' + (Get-Date -Format 'yyyyMMdd-HHmmss')); New-Item -ItemType Directory -Force -Path $d | Out-Null; return $d }
function Onar($Islemler, $SertifikaYol, $Ref) {
  $S = New-Object System.Collections.ArrayList
  $kayit = New-Object System.Collections.ArrayList
  foreach ($i in $Islemler) {
    $ok = $true; $m = 'Yapıldı'
    try {
      switch ($i) {
        'ag_yenile' { ipconfig /release | Out-Null; ipconfig /renew | Out-Null; ipconfig /flushdns | Out-Null
                      Get-NetAdapter -Physical | Where-Object { $_.Status -ne 'Disabled' } | Restart-NetAdapter -Confirm:$false
                      Start-Sleep 8; $m = 'Ağ bağlantısı yeniden başlatıldı, adres yenilendi, DNS önbelleği temizlendi' }
        'proxy' { netsh winhttp reset proxy | Out-Null; $m = 'Sistem vekil sunucu ayarı kaldırıldı' }
        'sertifika' { if (-not $SertifikaYol -or -not (Test-Path $SertifikaYol)) { $ok = $false; $m = 'Panelde okul ağı sertifikası yüklü değil' }
                      else { $c = Import-Certificate -FilePath $SertifikaYol -CertStoreLocation Cert:\LocalMachine\Root
                             [void]$kayit.Add(@{ tur='sertifika'; parmak=$c.Thumbprint }); $m = 'Sertifika Windows''a kuruldu (Chrome ve Edge bunu kullanır)' } }
        'saat' { Set-Service W32Time -StartupType Automatic; Start-Service W32Time; w32tm /resync /force | Out-Null
                 if ($Ref) { $f = [Math]::Abs([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $Ref); if ($f -gt 120) { Set-Date ([DateTimeOffset]::FromUnixTimeSeconds($Ref).LocalDateTime) | Out-Null } }
                 $m = 'Saat düzeltildi' }
        'disk' { $once = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'").FreeSpace; $sinir = (Get-Date).AddDays(-7)
                 foreach ($t in @("$env:windir\Temp") + @(Get-ChildItem 'C:\Users' -Directory | ForEach-Object { Join-Path $_.FullName 'AppData\Local\Temp' })) {
                   Get-ChildItem $t -Recurse -Force -File | Where-Object { $_.LastWriteTime -lt $sinir } | Remove-Item -Force }
                 Remove-Item "$env:windir\SoftwareDistribution\Download\*" -Recurse -Force
                 $mb = [Math]::Round(((Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'").FreeSpace - $once) / 1MB)
                 $m = "$mb MB yer açıldı (geçici dosyalar, indirilmiş güncelleme dosyaları). Kişisel dosyalara dokunulmadı." }
        'hizmet' { $b = @(); foreach ($h in 'AudioEndpointBuilder', 'Audiosrv', 'Spooler', 'Dhcp', 'Dnscache', 'W32Time') { $s = Get-Service $h
                     if ($s -and $s.StartType -ne 'Disabled' -and $s.Status -ne 'Running') { Start-Service $h; $b += $h } }
                   $m = $(if ($b) { 'Başlatıldı: ' + ($b -join ', ') } else { 'Durmuş hizmet yoktu' }) }
        'yazici' { Stop-Service Spooler -Force; Start-Sleep 2; Remove-Item "$env:windir\System32\spool\PRINTERS\*" -Force; Start-Service Spooler
                   Get-CimInstance Win32_Printer | Where-Object { $_.WorkOffline } | ForEach-Object { Set-CimInstance -InputObject $_ -Property @{ WorkOffline = $false } }
                   $m = 'Kuyruk temizlendi, yazdırma hizmeti yeniden başlatıldı' }
        default { $ok = $false; $m = 'Bu onarım Windows tahtalarda yok' }
      }
    } catch { $ok = $false; $m = $_.Exception.Message }
    [void]$S.Add([ordered]@{ id=$i; baslik=$(if ($OY[$i]) { $OY[$i] } else { $i }); ok=$ok; mesaj=$m })
  }
  if ($kayit.Count) { $d = YedekDizin; ($kayit | ConvertTo-Json -Depth 3 -Compress) | Set-Content -Encoding UTF8 (Join-Path $d 'kayit.json') }
  return $S
}
function GeriAl() {
  $s = Get-ChildItem (Join-Path $env:ProgramData 'TahtaYonetim\onarim') -Directory | Where-Object { -not (Test-Path (Join-Path $_.FullName 'geri-alindi')) } | Sort-Object Name | Select-Object -Last 1
  if (-not $s) { return [ordered]@{ ok=$false; mesaj='Geri alınacak onarım yok' } }
  $k = @(Get-Content (Join-Path $s.FullName 'kayit.json') -Raw | ConvertFrom-Json)
  foreach ($x in $k) { if ($x.tur -eq 'sertifika') { Remove-Item ("Cert:\LocalMachine\Root\" + $x.parmak) -Force } }
  Set-Content (Join-Path $s.FullName 'geri-alindi') (Get-Date).ToString()
  return [ordered]@{ ok=$true; mesaj='Okul ağı sertifikası kaldırıldı' }
}
'''

# Ajanın çalıştırdığı kısım: girdi JSON (stdin) → çıktı JSON
WIN_AJAN = r'''
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
''' + WIN_MOTOR + r'''
$g = [Console]::In.ReadToEnd() | ConvertFrom-Json
$sertYol = $null
if ($g.sertifika) { $sertYol = Join-Path $env:TEMP 'tahta-okul-agi.cer'; [IO.File]::WriteAllText($sertYol, $g.sertifika) }
if ($g.islem -eq 'tanila') { $b = Tanila @($g.sunucular) $g.sertifika $g.kimlik_cakisma; @{ bulgular=@($b); ref=$script:ref } | ConvertTo-Json -Depth 5 -Compress }
elseif ($g.islem -eq 'onar') { $null = Tanila @($g.sunucular) $g.sertifika $false; $s = Onar @($g.islemler) $sertYol $script:ref; $script:B.Clear(); $b = Tanila @($g.sunucular) $g.sertifika $false
  @{ sonuclar=@($s); bulgular=@($b) } | ConvertTo-Json -Depth 5 -Compress }
elseif ($g.islem -eq 'geri') { GeriAl | ConvertTo-Json -Compress }
'''


# Onarım Belleği'nden çalışan Windows betiği (TahtaOnar.bat yönetici olarak başlatır)
WIN_BELLEK_BAS = r"""param([string]$Bellek)
[Console]::OutputEncoding = [Text.Encoding]::UTF8
"""
WIN_BELLEK = r"""
function Yaz($m, $r) { if ($r) { Write-Host $m -ForegroundColor $r } else { Write-Host $m } }
function Goster($liste) {
  foreach ($g in @($GA, $GY, $GS, $GG, $GC, 'Tahta programı')) {
    $bs = @($liste | Where-Object { $_.grup -eq $g }); if (-not $bs) { continue }
    Yaz "`n  $g" White
    foreach ($b in $bs) { $r = @{ ok='Green'; uyari='Yellow'; hata='Red'; bilgi='Cyan' }[$b.durum]; $s = @{ ok='✓'; uyari='!'; hata='✗'; bilgi='·' }[$b.durum]
      Write-Host ("  $s ") -ForegroundColor $r -NoNewline; Write-Host ("$($b.baslik): $($b.mesaj)") }
  }
}
$ayar = Get-Content (Join-Path $Bellek 'ayar.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Yaz "`n  ══ Tahta Yönetim Asistanı — Tahta Onarım Belleği ══" Cyan
$simdi = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$doldu = $simdi -gt [double]$ayar.bitis
Yaz ("  Okul: " + $ayar.okul_adi + " · Bellek " + ([DateTimeOffset]::FromUnixTimeSeconds([int64]$ayar.bitis).LocalDateTime.ToString('dd.MM.yyyy')) + " tarihine kadar geçerli")
if ($doldu) { Yaz "  Bu belleğin süresi dolmuş: yalnızca tanılama yapılır, program kurulmaz. Panelden yeni bellek hazırlayın." Yellow }
$sertYol = $null
if ($ayar.sertifika) { $sertYol = Join-Path $env:TEMP 'tahta-okul-agi.cer'; [IO.File]::WriteAllText($sertYol, $ayar.sertifika) }
Yaz "`n  Tahta inceleniyor (yaklaşık 30 saniye)…"
$b = @(Tanila @($ayar.sunucular) $ayar.sertifika $false)
$ajan = Join-Path $env:ProgramFiles 'TahtaYonetim\ajan\tahta-ajan.py'
$gorev = Get-ScheduledTask -TaskName 'Tahta Yonetim Ajani'
$ajanGerekli = $null
if (-not (Test-Path $ajan) -or -not $gorev) { $ajanGerekli = 'kur'; Ekle 'ajan' 'Tahta programı' 'Tahta programı' 'hata' 'Tahta programı kurulu değil.'; $b = @($script:B) }
elseif ($gorev.State -ne 'Running') { $ajanGerekli = 'onar'; Ekle 'ajan' 'Tahta programı' 'Tahta programı' 'hata' 'Tahta programı kurulu ama çalışmıyor.'; $b = @($script:B) }
else { Ekle 'ajan' 'Tahta programı' 'Tahta programı' 'ok' 'Kurulu ve çalışıyor.'; $b = @($script:B) }
Goster $b
$calisan = $script:calisan
$s = @()
$onar = @($b | Where-Object { $_.onar -and ($_.durum -eq 'hata' -or $_.durum -eq 'uyari') } | ForEach-Object { $_.onar } | Select-Object -Unique)
if ($onar.Count) {
  Yaz "`n  Onarılabilecekler:" White
  foreach ($i in $onar) { Yaz ("    • " + $OY[$i]) }
  $c = Read-Host "  Bunlar onarılsın mı? (Kişisel dosyalara dokunulmaz.) [E/h]"
  if ($c -eq '' -or $c -match '^[eEyY]') {
    $s = @(Onar $onar $sertYol $script:ref)
    foreach ($x in $s) { if ($x.ok) { Write-Host '  ✓ ' -ForegroundColor Green -NoNewline } else { Write-Host '  ✗ ' -ForegroundColor Red -NoNewline }; Write-Host "$($x.baslik): $($x.mesaj)" }
    Yaz "`n  Yeniden kontrol ediliyor…"
    $script:B.Clear(); $b = @(Tanila @($ayar.sunucular) $ayar.sertifika $false); $calisan = $script:calisan
    Goster @($b | Where-Object { $_.durum -ne 'ok' })
  }
}
$kurulum = $null
if ($ajanGerekli -and -not $doldu) {
  if (-not $calisan) { Yaz "`n  Tahta programı kurulamıyor: yönetim bilgisayarına ulaşılamıyor (yukarıdaki ağ sorunlarına bakın)." Yellow }
  else {
    $c = Read-Host ("`n  Tahta programı " + $(if ($ajanGerekli -eq 'kur') { 'kurulsun' } else { 'yeniden kurulsun' }) + " mu? [E/h]")
    if ($c -eq '' -or $c -match '^[eEyY]') {
      try { $bat = Join-Path $env:TEMP 'TahtaKurulum-onarim.bat'
            (New-Object Net.WebClient).DownloadFile("$calisan/onarim/w?b=$($ayar.belirtec)", $bat)
            Start-Process -FilePath $bat -Wait; $kurulum = @{ ok=$true; mesaj='Kurulum çalıştırıldı' } }
      catch { Yaz ("  Kurulum dosyası alınamadı: " + $_.Exception.Message) Red; $kurulum = @{ ok=$false; mesaj=$_.Exception.Message } }
    }
  }
}
$guid = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography').MachineGuid
$cihaz = [ordered]@{ hostname=$env:COMPUTERNAME; os=(Get-CimInstance Win32_OperatingSystem).Caption; kimlik="pc-$guid"
  macler=@(Get-NetAdapter -Physical | ForEach-Object { $_.MacAddress.Replace('-', ':').ToLower() })
  ip=@(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $_.IPAddress }) }
$rapor = [ordered]@{ surum='4.2'; zaman=$simdi; kaynak='bellek'; bellek=$ayar.id; platform='windows'; cihaz=$cihaz; bulgular=@($b); onarimlar=@($s); kurulum=$kurulum }
$json = $rapor | ConvertTo-Json -Depth 6
$rd = Join-Path $Bellek 'raporlar'; New-Item -ItemType Directory -Force -Path $rd | Out-Null
$ad = ($env:COMPUTERNAME -replace '[^\w.\-]', '_') + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
[IO.File]::WriteAllText((Join-Path $rd "$ad.json"), $json, (New-Object Text.UTF8Encoding $false))
Yaz "  Rapor belleğe kaydedildi: raporlar\$ad.json"
if ($calisan -and -not $doldu) {
  try { $w = New-Object Net.WebClient; $w.Headers['Content-Type'] = 'application/json; charset=utf-8'; $w.Encoding = [Text.Encoding]::UTF8
        [void]$w.UploadString("$calisan/onarim/rapor?b=$($ayar.belirtec)", $json); Yaz "  Rapor yönetim bilgisayarına gönderildi." }
  catch { Yaz "  Rapor gönderilemedi; belleği yönetim bilgisayarına takıp panelden içe alın." }
}
Yaz "`n  Bitti. Belleği çıkarabilirsiniz.`n" Green
"""


def win_bellek_betigi():
    return WIN_BELLEK_BAS + WIN_MOTOR + WIN_BELLEK


# ═════════════════════════════════════════════════════════════════════════════
# Ajan modülü
# ═════════════════════════════════════════════════════════════════════════════

class Onarim:
    def __init__(self, ajan):
        self.a = ajan
        self.kilit = threading.Lock()
        self.son = {}

    def durum(self):
        return {}

    def komut(self, tur, v, kaynak):
        if tur not in ("tanila", "onar", "onar_geri", "yazici_onar"):
            return None
        if tur == "yazici_onar":
            self.a.arkada(self.yazici, tur, v)
            return C.ARKADA
        self.a.arkada(self.calis, tur, tur, v)
        return C.ARKADA

    def ortam(self, v):
        o = {"mod": "ajan", "sunucu": self.a.sunucu, "sunucular": list(getattr(self.a, "sunucular", []) or []),
             "sertifika": v.get("sertifika") or "", "kimlik_cakisma": bool(v.get("kimlik_cakisma"))}
        try:
            o["oturum"] = C.oturum_bul()
        except Exception:
            o["oturum"] = None
        return o

    def calis(self, tur, v):
        if not self.kilit.acquire(timeout=5):
            raise RuntimeError("Bu tahtada tanılama/onarım zaten sürüyor")
        try:
            ortam = self.ortam(v)
            if C.WINDOWS:
                return self.windows(tur, v, ortam)
            if tur == "tanila":
                r = tanila(ortam)
                self.son = r
                return {"mesaj": ozet(r["bulgular"]), "veri": dict(r, tur="tanila")}
            if tur == "onar":
                islemler = [str(x) for x in (v.get("islemler") or []) if str(x) in ONARICI]
                if not islemler:
                    raise RuntimeError("Onarılacak bir şey seçilmedi")
                once = self.son if self.son and time.time() - self.son.get("zaman", 0) < 600 else tanila(ortam)
                ortam["internet"] = any(b["id"] == "internet" and b["durum"] == "ok" for b in once["bulgular"])
                sonuclar = onar(islemler, ortam, once["bulgular"])
                if "yazici" in islemler:
                    y = self.a.modul("yazici")
                    if y and hasattr(y, "firmware_gonder"):
                        try:
                            y.firmware_gonder()
                        except Exception:
                            pass
                sonra = tanila(self.ortam(v))
                self.son = sonra
                basarili = sum(1 for s in sonuclar if s["ok"])
                return {"mesaj": "{}/{} onarım yapıldı · şimdi: {}".format(basarili, len(sonuclar), ozet(sonra["bulgular"])),
                        "veri": dict(sonra, tur="onar", sonuclar=sonuclar)}
            r = geri_al(ortam.get("oturum"))
            if not r["ok"]:
                raise RuntimeError(r["mesaj"])
            return {"mesaj": r["mesaj"], "veri": {"tur": "onar_geri"}}
        finally:
            self.kilit.release()

    def windows(self, tur, v, ortam):
        g = {"islem": {"tanila": "tanila", "onar": "onar", "onar_geri": "geri"}[tur], "sunucular": [ortam["sunucu"]] + ortam["sunucular"],
             "sertifika": v.get("sertifika") or "", "kimlik_cakisma": bool(v.get("kimlik_cakisma")),
             "islemler": [str(x) for x in (v.get("islemler") or [])]}
        r = win_calistir(WIN_AJAN, g)
        if tur == "tanila":
            b = r.get("bulgular") or []
            return {"mesaj": ozet(b), "veri": {"tur": "tanila", "bulgular": b, "zaman": time.time(), "platform": "windows", "surum": SURUM}}
        if tur == "onar":
            s, b = r.get("sonuclar") or [], r.get("bulgular") or []
            return {"mesaj": "{}/{} onarım yapıldı · şimdi: {}".format(sum(1 for x in s if x.get("ok")), len(s), ozet(b)),
                    "veri": {"tur": "onar", "sonuclar": s, "bulgular": b, "zaman": time.time(), "platform": "windows", "surum": SURUM}}
        if not r.get("ok"):
            raise RuntimeError(r.get("mesaj") or "Geri alınamadı")
        return {"mesaj": r.get("mesaj"), "veri": {"tur": "onar_geri"}}

    def yazici(self, v):
        if C.WINDOWS:
            r = win_calistir(WIN_AJAN, {"islem": "onar", "islemler": ["yazici"], "sunucular": []})
            s = (r.get("sonuclar") or [{}])[0]
            if not s.get("ok"):
                raise RuntimeError(s.get("mesaj") or "Onarılamadı")
            return {"mesaj": s.get("mesaj")}
        if not var("lpstat"):
            raise RuntimeError("Bu tahtada yazdırma sistemi (CUPS) yok")
        y = self.a.modul("yazici")
        ok, mesaj = yazici_onar(getattr(y, "firmware_gonder", None) if y else None)
        if y:
            try:
                y.guncelle(y.tara())
                y.rapor()
            except Exception:
                pass
        return {"mesaj": mesaj}


def win_calistir(betik, girdi, zaman=600):
    """PowerShell motorunu çalıştırır; JSON çıktıyı döner."""
    if not C or not C.WINDOWS:
        raise RuntimeError("Windows değil")
    # Betik komut satırı sınırını aştığı için dosyaya yazılır (UTF-8 BOM: Windows PowerShell 5.1 Türkçe karakterleri doğru okusun)
    yol_ = os.path.join(C.VERI, "onarim.ps1")
    with open(yol_, "w", encoding="utf-8-sig") as f:
        f.write(betik)
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", yol_],
                           input=json.dumps(girdi, ensure_ascii=False).encode("utf-8"), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=zaman, creationflags=getattr(C, "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        raise RuntimeError("Tanılama zaman aşımına uğradı")
    cikti = (r.stdout or b"").decode("utf-8", "replace").strip().splitlines()
    for satir in reversed(cikti):
        satir = satir.strip()
        if satir.startswith("{"):
            try:
                return json.loads(satir)
            except ValueError:
                break
    raise RuntimeError("Tanılama çalışmadı: " + ((r.stderr or b"").decode("utf-8", "replace").strip()[:200] or "çıktı yok"))


def baslat(ajan):
    return Onarim(ajan)


# ═════════════════════════════════════════════════════════════════════════════
# Tahta Onarım Belleği (tek başına çalışma)
# ═════════════════════════════════════════════════════════════════════════════
R, Y, S, M, K, N = "\033[1;31m", "\033[1;32m", "\033[1;33m", "\033[1;36m", "\033[1m", "\033[0m"
SIMGE = {"ok": Y + "  ✓" + N, "uyari": S + "  !" + N, "hata": R + "  ✗" + N, "bilgi": M + "  ·" + N}


def yaz(m=""):
    sys.stdout.write(m + "\n")
    sys.stdout.flush()


def sor(soru, evet=False):
    if evet:
        return True
    try:
        return input(K + "  " + soru + " [E/h] " + N).strip().lower() in ("", "e", "evet", "y", "yes")
    except EOFError:
        return False


def bulgu_yaz(bulgular):
    gruplar = GRUPLAR + [g for g in dict.fromkeys(b["grup"] for b in bulgular) if g not in GRUPLAR]
    for g in gruplar:
        bs = [b for b in bulgular if b["grup"] == g]
        if not bs:
            continue
        yaz("\n" + K + "  " + g + N)
        for b in bs:
            yaz("{} {}: {}".format(SIMGE.get(b["durum"], "  ·"), b["baslik"], b["mesaj"]))


def sunucu_istek(ayar, calisan, yol_, veri=None, zaman=30):
    adres = (calisan or "").rstrip("/") + yol_ + ("&" if "?" in yol_ else "?") + "b=" + ayar["belirtec"]
    r = urllib.request.Request(adres, data=json.dumps(veri, ensure_ascii=False).encode("utf-8") if veri is not None else None,
                               headers={"Content-Type": "application/json"} if veri is not None else {})
    with acici().open(r, timeout=zaman) as y:
        return y.read()


def bellek_calis(dizin, evet=False):
    yaz("\n" + M + "  ══ Tahta Yönetim Asistanı — Tahta Onarım Belleği ══" + N)
    if os.geteuid() != 0:
        yaz(R + "\n  Yönetici yetkisi gerekli. tahta-onar.sh ile başlatın (etapadmin şifresi sorulur)." + N)
        return 1
    try:
        ayar = json.load(open(os.path.join(dizin, "ayar.json"), encoding="utf-8"))
    except Exception as e:
        yaz(R + "  Bellekteki ayar dosyası okunamadı: {}".format(e) + N)
        return 1
    suresi_doldu = time.time() > float(ayar.get("bitis") or 0)
    yaz("  Okul: {} · Bellek {} tarihine kadar geçerli".format(ayar.get("okul_adi") or "?", time.strftime("%d.%m.%Y", time.localtime(ayar.get("bitis") or 0))))
    if suresi_doldu:
        yaz(S + "  Bu belleğin süresi dolmuş: yalnızca tanılama yapılır, program kurulmaz. Panelden yeni bellek hazırlayın." + N)
    ortam = {"mod": "bellek", "sunucular": ayar.get("sunucular") or [], "sertifika": ayar.get("sertifika") or "",
             "ajan_surum": ayar.get("ajan_surum")}
    yaz("\n  Tahta inceleniyor (yaklaşık 30 saniye)…")
    t = Tanilayici(ortam)
    bulgular = t.calistir()
    calisan = t.o.get("calisan_sunucu")
    # aynı imajdan kurulmuş tahta: yönetim bilgisayarına sor
    if calisan and not suresi_doldu:
        try:
            c = json.loads(sunucu_istek(ayar, calisan, "/onarim/kimlik?id={}&mac={}".format(makine_kimligi(), ",".join(cihaz_bilgisi()["macler"]))).decode())
            if c.get("cakisma"):
                t.o["kimlik_cakisma"] = True
                bulgular.insert(0, B("kimlik", GRUPLAR[5], "Tahta kimliği", "hata", "Bu tahtanın kimliği panelde başka bir tahtayla aynı "
                                     "(aynı imajdan kurulmuş). Yeni kimlik verilince panele ayrı tahta olarak gelir.", "kimlik"))
        except Exception:
            pass
    bulgu_yaz(bulgular)
    rapor = {"surum": SURUM, "zaman": time.time(), "kaynak": "bellek", "bellek": ayar.get("id"), "cihaz": cihaz_bilgisi(),
             "bulgular": bulgular, "onarimlar": [], "kurulum": None}
    onarilacak = list(dict.fromkeys(b["onar"] for b in bulgular if b.get("onar") and b["durum"] in ("hata", "uyari")))
    if onarilacak:
        yaz("\n" + K + "  Onarılabilecekler:" + N)
        for i in onarilacak:
            yaz("    • " + ONAR_YAZI.get(i, i))
        if sor("Bunlar onarılsın mı? (Değişikliklerin yedeği alınır, kişisel dosyalara dokunulmaz.)", evet):
            ortam["ref_zaman"], ortam["ref_olcum"] = t.o.get("ref_zaman"), t.o.get("ref_olcum")
            ortam["internet"], ortam["oturum"] = t.o.get("internet"), t.o.get("oturum")
            sonuc = onar(onarilacak, ortam, bulgular)
            rapor["onarimlar"] = sonuc
            for s in sonuc:
                yaz("{} {}: {}".format(SIMGE["ok" if s["ok"] else "hata"], s["baslik"], s["mesaj"]))
            yaz("\n  Yeniden kontrol ediliyor…")
            t = Tanilayici(ortam)
            bulgular = t.calistir()
            calisan = t.o.get("calisan_sunucu")
            rapor["bulgular_sonra"] = bulgular
            bulgu_yaz([b for b in bulgular if b["durum"] != "ok"] or [B("tamam", GRUPLAR[2], "Sonuç", "ok", "Sorun kalmadı.")])
    gerek = t.o.get("ajan_gerekli")
    if gerek and not suresi_doldu:
        if not calisan:
            yaz(S + "\n  Tahta programı kurulamıyor: yönetim bilgisayarına ulaşılamıyor (yukarıdaki ağ sorunlarına bakın)." + N)
        elif sor("Tahta programı {} edilsin mi?".format("kurulsun" if gerek == "kur" else "onarılsın (yeniden kurulsun)"), evet):
            rapor["kurulum"] = ajan_kur(ayar, calisan)
    if not gerek and not t.o.get("ajan_gerekli") and any(b["id"] == "ajan" and b["durum"] == "ok" for b in bulgular):
        yaz(Y + "\n  Tahta programı kurulu ve çalışıyor." + N)
    kaydet_rapor(dizin, rapor)
    if calisan and not suresi_doldu:
        try:
            sunucu_istek(ayar, calisan, "/onarim/rapor", rapor)
            yaz("  Rapor yönetim bilgisayarına gönderildi.")
        except Exception:
            yaz("  Rapor yönetim bilgisayarına gönderilemedi; belleği yönetim bilgisayarına takıp panelden içe alın.")
    yaz(Y + "\n  Bitti. Belleği çıkarabilirsiniz." + N + "\n")
    return 0


def ajan_kur(ayar, calisan):
    yaz("\n  Kurulum betiği yönetim bilgisayarından alınıyor…")
    son = None
    for i in range(4):
        try:
            betik = sunucu_istek(ayar, calisan, "/onarim/k?ad=", zaman=30 + i * 10).decode("utf-8")
            break
        except Exception as e:
            son = e
            time.sleep(2)
    else:
        yaz(R + "  Alınamadı: {}".format(son) + N)
        return {"ok": False, "mesaj": "Kurulum betiği alınamadı: {}".format(son)}
    if SAHTE:
        SAHTE_KOMUTLAR.append(["bash", "(kurulum betiği)"])
        return {"ok": True, "mesaj": "kuruldu (test)"}
    r = subprocess.run(["bash", "-s"], input=betik.encode("utf-8"))
    ok = r.returncode == 0
    return {"ok": ok, "mesaj": "Tahta programı kuruldu" if ok else "Kurulum hata verdi (çıkış kodu {})".format(r.returncode)}


def kaydet_rapor(dizin, rapor):
    try:
        d = os.path.join(dizin, "raporlar")
        os.makedirs(d, exist_ok=True)
        ad = "{}-{}".format(re.sub(r"[^\w.\-]+", "_", rapor["cihaz"].get("hostname") or "tahta")[:40], time.strftime("%Y%m%d-%H%M%S"))
        with open(os.path.join(d, ad + ".json"), "w", encoding="utf-8") as f:
            json.dump(rapor, f, ensure_ascii=False, indent=1)
        with open(os.path.join(d, ad + ".txt"), "w", encoding="utf-8") as f:
            f.write("Tahta onarım raporu — {} — {}\n\n".format(rapor["cihaz"].get("hostname"), time.strftime("%d.%m.%Y %H:%M")))
            for b in rapor.get("bulgular_sonra") or rapor["bulgular"]:
                f.write("[{}] {} — {}: {}\n".format({"ok": "TAMAM", "uyari": "UYARI", "hata": "SORUN", "bilgi": "BİLGİ"}.get(b["durum"]),
                                                    b["grup"], b["baslik"], b["mesaj"]))
            for s in rapor["onarimlar"]:
                f.write("Onarım: {} — {}\n".format(s["baslik"], s["mesaj"]))
        if hasattr(os, "sync"):
            os.sync()
        yaz("  Rapor belleğe kaydedildi: raporlar/{}.txt".format(ad))
    except Exception as e:
        yaz(S + "  Rapor belleğe yazılamadı: {}".format(e) + N)


def main(argv):
    if "--bellek" in argv:
        i = argv.index("--bellek")
        dizin = argv[i + 1] if len(argv) > i + 1 else os.path.dirname(os.path.abspath(__file__))
        try:
            kod = bellek_calis(dizin, evet="--evet" in argv)
        except KeyboardInterrupt:
            kod = 130
        if "--bekleme" not in argv and sys.stdin.isatty():
            try:
                input("  Pencereyi kapatmak için Enter'a basın…")
            except EOFError:
                pass
        return kod
    if "--json" in argv:
        sys.stdout.write(json.dumps(tanila({"mod": "bellek"}), ensure_ascii=False) + "\n")
        return 0
    yaz("Kullanım: onarim.py --bellek <klasör>   |   onarim.py --json")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
