﻿# ─────────────────────────────────────────────────────────────────────────────
#  Tahta Yönetim Sistemi — Windows kurulumu
#  KUR.bat veya Ortak Klasör kurulum dosyası tarafından çalıştırılır.
#    (parametresiz)             Kurulum türünü sorar
#    -Istemci -Sunucu -Anahtar  Öğretmen bilgisayarı (yalnızca Ortak Klasör)
#    -Tahta [-Sunucu -Anahtar -Kimlik -Ad]  Windows akıllı tahta (tahta programı)
#    -Kaldir [-Istemci | -Tahta]  Kaldırma
# ─────────────────────────────────────────────────────────────────────────────
param([switch]$Kaldir, [switch]$Istemci, [switch]$Tahta, [string]$Sunucu = '', [string]$Anahtar = '',
      [string]$Kimlik = '', [string]$Ad = '', [switch]$Bekle)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$Kaynak  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Kok     = Join-Path $env:LOCALAPPDATA 'TahtaYonetim'
$Hedef   = Join-Path $Kok 'program'
$IKok    = Join-Path $Kok 'istemci'
$Port    = 8765
$KuralAd = 'Tahta Yonetim Sistemi'
$OrtakAd = 'Ortak Klasör'
$OrtakYol = Join-Path $env:USERPROFILE $OrtakAd
$KayitAnahtari = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TahtaYonetimOrtak'

function Baslik($m) { Write-Host ""; Write-Host "  $m" -ForegroundColor Cyan }
function Tamam($m)  { Write-Host "   [OK] $m" -ForegroundColor Green }
function Uyari($m)  { Write-Host "   [!]  $m" -ForegroundColor Yellow }
function Hata($m)   {
    Write-Host ""; Write-Host "   [X]  $m" -ForegroundColor Red; Write-Host ""
    if ($Bekle) { Read-Host "   Kapatmak için Enter'a basın" | Out-Null }
    exit 1
}

function Dosya-Yaz($yol, $metin) {
    [IO.File]::WriteAllText($yol, $metin, (New-Object Text.UTF8Encoding $false))
}

# ── Güvenlik duvarı (yönetici onayıyla ayrı çalışır) ─────────────────────────
$script:YetkiliEk = New-Object System.Collections.Generic.List[string]

function Guvenlik-Duvari($pythonw) {
    $komut = @"
netsh advfirewall firewall delete rule name="$KuralAd" | Out-Null
netsh advfirewall firewall delete rule name="$KuralAd (Python)" | Out-Null
netsh advfirewall firewall add rule name="$KuralAd" dir=in action=allow protocol=TCP localport=$Port profile=any | Out-Null
netsh advfirewall firewall add rule name="$KuralAd (Python)" dir=in action=allow program="$pythonw" enable=yes profile=any | Out-Null
"@
    foreach ($e in $script:YetkiliEk) { $komut += "`n$e | Out-Null" }
    $kodlu = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($komut))
    try {
        $p = Start-Process powershell -Verb RunAs -WindowStyle Hidden -Wait -PassThru `
             -ArgumentList "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $kodlu"
        return ($p.ExitCode -eq 0)
    } catch { return $false }
}

function Guvenlik-Kaldir {
    $komut = @"
netsh advfirewall firewall delete rule name="$KuralAd" | Out-Null
netsh advfirewall firewall delete rule name="$KuralAd (Python)" | Out-Null
"@
    $kodlu = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($komut))
    try { Start-Process powershell -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $kodlu" } catch {}
}

# ── Güç ayarı: uyku kapatılmaz, prize takılıyken 30 dakikadan kısaysa 30 dakikaya çıkarılır ──
$UykuDk = 30

function Guc-Deger($ayar) {
    $ErrorActionPreference = 'Continue'
    try {
        $c = (& powercfg /query SCHEME_CURRENT SUB_SLEEP $ayar 2>$null) -join "`n"
        $m = [regex]::Match($c, '\bAC\b[^:\r\n]*:\s*(0x[0-9a-fA-F]+)')
        if ($m.Success) { return [Convert]::ToInt64($m.Groups[1].Value, 16) }
    } catch {}
    return $null
}

function Dk-Yaz($sn) { if ($sn -eq 0) { 'kapalı' } else { "$([math]::Round($sn / 60)) dakika" } }

function Uyku-Ayarla {
    $ErrorActionPreference = 'Continue'
    $ayarlar = @(
        @{ Ad = 'STANDBYIDLE';   Komut = 'standby-timeout-ac';   Isim = 'Uyku' },
        @{ Ad = 'HIBERNATEIDLE'; Komut = 'hibernate-timeout-ac'; Isim = 'Hazırda bekletme' })
    $sonuc = New-Object System.Collections.Generic.List[string]
    foreach ($a in $ayarlar) {
        $v = Guc-Deger $a.Ad
        if ($v -eq $null) { continue }
        if ($v -gt 0 -and $v -lt ($UykuDk * 60)) {
            try { & powercfg /change $a.Komut $UykuDk 2>$null | Out-Null } catch {}
            $y = Guc-Deger $a.Ad
            if ($y -eq 0 -or $y -ge ($UykuDk * 60)) {
                $sonuc.Add("$($a.Isim) süresi $(Dk-Yaz $v)dan $UykuDk dakikaya çıkarıldı")
            } else {
                $script:YetkiliEk.Add("powercfg /change $($a.Komut) $UykuDk")
                $sonuc.Add("$($a.Isim) süresi $(Dk-Yaz $v); onay penceresinden sonra $UykuDk dakikaya çıkarılacak")
            }
        } elseif ($a.Ad -eq 'STANDBYIDLE') {
            $sonuc.Add("Uyku ayarı uygun ($(Dk-Yaz $v))")
        }
    }
    return $sonuc
}

# ── Ağ: tahtaların kullanacağı adres ─────────────────────────────────────────
function Ag-Baglantilari {
    $ErrorActionPreference = 'Continue'
    $liste = @()
    try {
        $liste = @(Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4Address -and $_.NetAdapter.Status -eq 'Up' } | ForEach-Object {
            $adr = $_.IPv4Address | Select-Object -First 1
            [pscustomobject]@{
                Ad    = $_.InterfaceAlias
                Ip    = $adr.IPAddress
                Gecit = [bool]$_.IPv4DefaultGateway
                Dhcp  = ($adr.PrefixOrigin -eq 'Dhcp')
                Sanal = (("$($_.InterfaceDescription) $($_.InterfaceAlias)") -match 'Hyper-V|vEthernet|VirtualBox|VMware|TAP-|WireGuard|Wintun|Loopback|Bluetooth|Npcap|ZeroTier|Tailscale|Docker|WSL')
            }
        })
    } catch {}
    return @($liste | Where-Object { $_.Ip -and $_.Ip -notlike '169.254.*' -and $_.Ip -notlike '127.*' })
}

# ── Python bulma / kurma ─────────────────────────────────────────────────────
# Python'un yazdığı yol okunmaz; aday dosyanın kendisi denenir. (Windows'ta Python çıktısı
# Türkçe kod sayfasıyla gelir; kullanıcı adında ö, ü, ı gibi harf varsa yol bozuluyordu.)
$script:PyDenenen = New-Object System.Collections.Generic.List[string]

function Python-Dene($yol) {
    $ErrorActionPreference = 'Continue'
    if (-not $yol) { return $null }
    $yol = $yol.Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $yol -PathType Leaf)) { return $null }
    try {
        & $yol -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 3)" 2>$null | Out-Null
        $kod = $LASTEXITCODE
        if ($kod -eq 0) { return (Get-Item -LiteralPath $yol).FullName }
        if ($kod -eq 3) { $script:PyDenenen.Add("$yol  (sürümü 3.8'den eski)") }
        else { $script:PyDenenen.Add("$yol  (çalışmadı, kod $kod)") }
    } catch {
        $script:PyDenenen.Add("$yol  ($($_.Exception.Message))")
    }
    return $null
}

function Python-Bul {
    $ErrorActionPreference = 'Continue'
    $script:PyDenenen.Clear()
    $adaylar = New-Object System.Collections.Generic.List[string]
    # 1) Windows kayıt defteri (python.org kurulumları buraya yazılır)
    foreach ($kok in @('HKCU:\Software\Python\PythonCore', 'HKLM:\Software\Python\PythonCore', 'HKLM:\Software\WOW6432Node\Python\PythonCore')) {
        Get-ChildItem $kok -ErrorAction SilentlyContinue | Sort-Object PSChildName -Descending | ForEach-Object {
            $ip = Get-ItemProperty -LiteralPath (Join-Path $_.PSPath 'InstallPath') -ErrorAction SilentlyContinue
            if ($ip) {
                if ($ip.ExecutablePath) { $adaylar.Add([string]$ip.ExecutablePath) }
                if ($ip.'(default)') { $adaylar.Add((Join-Path ([string]$ip.'(default)') 'python.exe')) }
            }
        }
    }
    # 2) Bilinen klasörler
    foreach ($kalip in @("$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe",
                         "$env:LOCALAPPDATA\Python\pythoncore-3*\python.exe",
                         "$env:ProgramFiles\Python3*\python.exe",
                         "${env:ProgramFiles(x86)}\Python3*\python.exe",
                         "$env:SystemDrive\Python3*\python.exe")) {
        Get-ChildItem $kalip -ErrorAction SilentlyContinue | Sort-Object FullName -Descending |
            ForEach-Object { $adaylar.Add($_.FullName) }
    }
    # 3) PATH'teki python (Microsoft Store kısayolu hariç)
    $pc = Get-Command python -ErrorAction SilentlyContinue
    if ($pc -and $pc.Source -notlike '*WindowsApps*') { $adaylar.Add($pc.Source) }
    foreach ($a in ($adaylar | Select-Object -Unique)) {
        $s = Python-Dene $a
        if ($s) { return $s }
    }
    # 4) py başlatıcısı: yolu UTF-8 olarak yazdır
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        $eskiKod = $env:PYTHONIOENCODING
        try {
            $env:PYTHONIOENCODING = 'utf-8'
            $c = & $py.Source -3 -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $c) {
                $s = Python-Dene ([string]($c | Select-Object -Last 1))
                if ($s) { return $s }
            }
        } catch {} finally { $env:PYTHONIOENCODING = $eskiKod }
    }
    return $null
}

function Python-Teshis {
    if ($script:PyDenenen.Count) {
        Write-Host "   Denenen Python dosyaları:" -ForegroundColor Gray
        $script:PyDenenen | Select-Object -First 8 | ForEach-Object { Write-Host "     $_" -ForegroundColor Gray }
    } else {
        Write-Host "   Bilgisayarda Python dosyası bulunamadı." -ForegroundColor Gray
    }
}

function Python-Kur {
    $ErrorActionPreference = 'Continue'
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "   Python indiriliyor ve kuruluyor (winget)... Bu birkaç dakika sürebilir." -ForegroundColor Gray
        try {
            & $winget.Source install -e --id Python.Python.3.12 --scope user --silent `
                --accept-package-agreements --accept-source-agreements | Out-Null
        } catch {}
        $p = Python-Bul
        if ($p) { return $p }
    }
    Write-Host "   Python python.org adresinden indiriliyor... Bu birkaç dakika sürebilir." -ForegroundColor Gray
    $adres = if ([Environment]::Is64BitOperatingSystem) { 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' } else { 'https://www.python.org/ftp/python/3.12.8/python-3.12.8.exe' }
    $dosya = Join-Path $env:TEMP 'python-kurulum.exe'
    try {
        Invoke-WebRequest -Uri $adres -OutFile $dosya -UseBasicParsing
        Start-Process $dosya -Wait -ArgumentList '/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0 Include_doc=0' | Out-Null
        Remove-Item $dosya -ErrorAction SilentlyContinue
    } catch {
        return $null
    }
    return Python-Bul
}

function Python-Hazirla {
    $python = Python-Bul
    if ($python) {
        Tamam "Python bulundu: $python"
    } else {
        Uyari "Python bulunamadı, otomatik kuruluyor"
        $python = Python-Kur
        if (-not $python) {
            Python-Teshis
            Start-Process 'https://www.python.org/downloads/windows/'
            Hata "Python kurulamadı. Açılan sayfadan Python'u indirip kurun ('Add Python to PATH' kutusunu işaretleyin), sonra kurulumu yeniden çalıştırın."
        }
        Tamam "Python kuruldu: $python"
    }
    return $python
}

# ── Kısayol, Ortak Klasör ────────────────────────────────────────────────────
function Kisayol($yol, $hedef, $arg, $calisma, $ikon, $aciklama) {
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($yol)
    $s.TargetPath = $hedef
    if ($arg) { $s.Arguments = $arg }
    if ($calisma) { $s.WorkingDirectory = $calisma }
    if ($ikon) { $s.IconLocation = $ikon }
    $s.Description = $aciklama
    $s.Save()
}

function Ortak-Klasor-Hazirla {
    New-Item -ItemType Directory -Force -Path $OrtakYol | Out-Null
    Kisayol (Join-Path $Masaustu "$OrtakAd.lnk") $OrtakYol '' '' "$env:SystemRoot\System32\imageres.dll,-1023" 'Okulun ortak dosyaları (tahtalarla eşitlenir)'
    try {
        $sh = New-Object -ComObject Shell.Application
        $sh.Namespace($OrtakYol).Self.InvokeVerb('pintohome')
    } catch {}
}

function Surec-Durdur($desen) {
    try {
        Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -like $desen } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {}
    Start-Sleep -Milliseconds 800
}

function Sunucu-Istegi($adres, $yol, $govde, $anahtar) {
    $wc = New-Object Net.WebClient
    $wc.Proxy = $null
    $wc.Encoding = [Text.Encoding]::UTF8
    $wc.Headers['Content-Type'] = 'application/json'
    if ($anahtar) { $wc.Headers['X-Anahtar'] = $anahtar }
    if ($govde -ne $null) { return $wc.UploadString("$adres$yol", 'POST', $govde) }
    return $wc.DownloadString("$adres$yol")
}

$Masaustu  = [Environment]::GetFolderPath('Desktop')
$Baslangic = [Environment]::GetFolderPath('Startup')
$Menu      = Join-Path ([Environment]::GetFolderPath('Programs')) 'Tahta Yönetim'
$KisaPanel = Join-Path $Masaustu 'Tahta Yönetim Paneli.lnk'
$KisaOto   = Join-Path $Baslangic 'Tahta Yönetim Sunucusu.lnk'
$KisaIOto  = Join-Path $Baslangic 'Ortak Klasör eşitleme.lnk'
$YonetimKurulu = Test-Path (Join-Path $Hedef 'tys.py')
$IstemciKurulu = Test-Path (Join-Path $IKok 'tahta-ajan.py')

Write-Host ""
Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Cyan
if ($Kaldir) {
    Write-Host "     TAHTA YÖNETİM SİSTEMİ — KALDIRMA" -ForegroundColor White
} elseif ($Tahta) {
    Write-Host "     TAHTA YÖNETİM — WINDOWS TAHTA KURULUMU" -ForegroundColor White
} elseif ($Istemci) {
    Write-Host "     ORTAK KLASÖR — ÖĞRETMEN BİLGİSAYARI KURULUMU" -ForegroundColor White
} else {
    Write-Host "     TAHTA YÖNETİM SİSTEMİ — KURULUM" -ForegroundColor White
}
Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Cyan


# ═════════════════════════ WINDOWS AKILLI TAHTA ══════════════════════════════
# Tahta programı SYSTEM hesabıyla Görev Zamanlayıcı görevi olarak çalışır; kilit ekranı,
# duyuru ve sınav pencerelerini oturum açan kullanıcının masaüstünde açar.
$TKok   = Join-Path $env:ProgramFiles 'TahtaYonetim'
$TAjanD = Join-Path $TKok 'ajan'
$TAjan  = Join-Path $TAjanD 'tahta-ajan.py'
$TVeriK = Join-Path $env:ProgramData 'TahtaYonetim'
$TVeri  = Join-Path $TVeriK 'tahta'
$TPay   = Join-Path $TVeriK 'paylasim'
$TGorev = 'Tahta Yonetim Ajani'
$TKural = 'Tahta Yonetim Ajani'
$TKayit = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TahtaYonetimTahta'
$TMenu  = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Tahta Yönetim'
$TOrtak = Join-Path $env:PUBLIC $OrtakAd
$TahtaKurulu = Test-Path $TAjan

function Yonetici-Mi {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Yetki-Al {
    if (Yonetici-Mi) { return }
    Write-Host ""
    Write-Host "   Yönetici izni gerekiyor. Açılan pencerede 'Evet'e tıklayın." -ForegroundColor Yellow
    $a = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Tahta -Bekle"
    if ($Kaldir)  { $a += ' -Kaldir' }
    if ($Sunucu)  { $a += " -Sunucu `"$Sunucu`"" }
    if ($Anahtar) { $a += " -Anahtar `"$Anahtar`"" }
    if ($Kimlik)  { $a += " -Kimlik `"$Kimlik`"" }
    if ($Ad)      { $a += " -Ad `"$Ad`"" }
    try {
        $p = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList $a
        exit $p.ExitCode
    } catch {
        Hata "Yönetici izni verilmedi. Kurulum dosyasını yeniden çalıştırıp 'Evet'e tıklayın."
    }
}

function Bekle-Cik($kod) {
    if ($Bekle) { Write-Host ""; Read-Host "   Kapatmak için Enter'a basın" | Out-Null }
    exit $kod
}

function Tk-Var($py) {
    $ErrorActionPreference = 'Continue'
    try { & $py -c "import tkinter; tkinter.Tcl()" 2>$null | Out-Null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}

# Pencereler her kullanıcının oturumunda açıldığı için Python tüm kullanıcıların erişebileceği
# bir yerde olmalı (Program Files). Kullanıcı klasörüne kurulmuş Python başka hesaplardan okunamaz.
function Python-Herkes {
    $ErrorActionPreference = 'Continue'
    $adaylar = New-Object System.Collections.Generic.List[string]
    foreach ($kok in @('HKLM:\Software\Python\PythonCore', 'HKLM:\Software\WOW6432Node\Python\PythonCore')) {
        Get-ChildItem $kok -ErrorAction SilentlyContinue | Sort-Object PSChildName -Descending | ForEach-Object {
            $ip = Get-ItemProperty -LiteralPath (Join-Path $_.PSPath 'InstallPath') -ErrorAction SilentlyContinue
            if ($ip -and $ip.ExecutablePath) { $adaylar.Add([string]$ip.ExecutablePath) }
            if ($ip -and $ip.'(default)') { $adaylar.Add((Join-Path ([string]$ip.'(default)') 'python.exe')) }
        }
    }
    foreach ($kalip in @("$env:ProgramFiles\Python3*\python.exe", "$env:SystemDrive\Python3*\python.exe")) {
        Get-ChildItem $kalip -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object { $adaylar.Add($_.FullName) }
    }
    foreach ($a in ($adaylar | Select-Object -Unique)) {
        $s = Python-Dene $a
        if ($s -and ($s -notlike "$env:SystemDrive\Users\*") -and (Tk-Var $s)) { return $s }
    }
    return $null
}

function Python-Herkes-Kur {
    $ErrorActionPreference = 'Continue'
    Write-Host "   Python tüm kullanıcılar için kuruluyor... Bu birkaç dakika sürebilir." -ForegroundColor Gray
    $adres = if ([Environment]::Is64BitOperatingSystem) { 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' } else { 'https://www.python.org/ftp/python/3.12.8/python-3.12.8.exe' }
    $dosya = Join-Path $env:TEMP 'python-kurulum.exe'
    try {
        Invoke-WebRequest -Uri $adres -OutFile $dosya -UseBasicParsing
        Start-Process $dosya -Wait -ArgumentList '/quiet InstallAllUsers=1 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_test=0 Include_doc=0' | Out-Null
        Remove-Item $dosya -ErrorAction SilentlyContinue
    } catch {
        $wg = Get-Command winget -ErrorAction SilentlyContinue
        if ($wg) {
            try { & $wg.Source install -e --id Python.Python.3.12 --scope machine --silent --accept-package-agreements --accept-source-agreements | Out-Null } catch {}
        }
    }
    return (Python-Herkes)
}

function Tahta-Durdur {
    $ErrorActionPreference = 'Continue'
    try { Stop-ScheduledTask -TaskName $TGorev -ErrorAction SilentlyContinue } catch {}
    try {
        Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -and $_.CommandLine -like "*$TAjanD*" } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {}
    Start-Sleep -Milliseconds 800
}

function Klasor-Herkese($yol) {
    New-Item -ItemType Directory -Force -Path $yol | Out-Null
    & icacls $yol /grant '*S-1-5-32-545:(OI)(CI)M' /Q 2>$null | Out-Null
}

if ($Kaldir -and -not $Tahta -and -not $Istemci -and $TahtaKurulu -and -not $YonetimKurulu -and -not $IstemciKurulu) { $Tahta = $true }
if ($Tahta -and $Kaldir) {
    Yetki-Al
    Baslik "1/3  Tahta programı durduruluyor"
    $pyw = $null
    try { $pyw = (Get-ScheduledTask -TaskName $TGorev -ErrorAction Stop).Actions[0].Execute } catch {}
    Tahta-Durdur
    if ($pyw -and (Test-Path $pyw) -and (Test-Path $TAjan)) {
        $py = Join-Path (Split-Path $pyw) 'python.exe'
        if (-not (Test-Path $py)) { $py = $pyw }
        try { & $py $TAjan --temizle 2>$null | Out-Null } catch {}
    }
    try { Unregister-ScheduledTask -TaskName $TGorev -Confirm:$false -ErrorAction SilentlyContinue } catch {}
    & netsh advfirewall firewall delete rule name="$TKural" 2>$null | Out-Null
    Tamam "Durduruldu; site engeli ve masaüstü kısayolları geri alındı"
    Baslik "2/3  Program dosyaları siliniyor"
    Remove-Item $TKok, $TVeriK, $TMenu -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $TKayit -Recurse -Force -ErrorAction SilentlyContinue
    Tamam "Kaldırıldı"
    Baslik "3/3  Ortak Klasör"
    Write-Host "   '$TOrtak' klasöründeki dosyalar silinmedi; artık eşitlenmez." -ForegroundColor Gray
    Write-Host "   Tahta, panelde 'kapalı' olarak kalır; listeden silmek için panelde tahtaya tıklayıp 'Yalnızca listeden sil'." -ForegroundColor Gray
    Bekle-Cik 0
}

# ═════════════════════════════ KALDIRMA ══════════════════════════════════════
if ($Kaldir) {
    if ($Istemci -or (-not $YonetimKurulu -and $IstemciKurulu)) {
        Baslik "1/2  Ortak Klasör eşitlemesi durduruluyor"
        Surec-Durdur '*tahta-ajan.py*--istemci*'
        Remove-Item $KisaIOto, (Join-Path $Masaustu "$OrtakAd.lnk") -ErrorAction SilentlyContinue
        Remove-Item (Join-Path $Menu "Ortak Klasör'ü kaldır.lnk") -ErrorAction SilentlyContinue
        if (-not (Get-ChildItem $Menu -ErrorAction SilentlyContinue)) { Remove-Item $Menu -Recurse -ErrorAction SilentlyContinue }
        Remove-Item $KayitAnahtari -Recurse -ErrorAction SilentlyContinue
        Tamam "Durduruldu"
        Baslik "2/2  Program dosyaları siliniyor"
        Remove-Item $IKok -Recurse -Force -ErrorAction SilentlyContinue
        if (-not (Get-ChildItem $Kok -ErrorAction SilentlyContinue)) { Remove-Item $Kok -Recurse -ErrorAction SilentlyContinue }
        Tamam "Kaldırıldı"
        Write-Host ""
        Write-Host "  '$OrtakYol' klasöründeki dosyalarınız silinmedi; artık eşitlenmez." -ForegroundColor Gray
        Write-Host ""
        exit 0
    }
    Baslik "1/3  Sunucu durduruluyor"
    Surec-Durdur '*TahtaYonetim*sunucu.pyw*'
    Tamam "Durduruldu"
    Baslik "2/3  Kısayollar ve güvenlik duvarı izni kaldırılıyor"
    Remove-Item $KisaPanel, $KisaOto, (Join-Path $Masaustu "$OrtakAd.lnk") -ErrorAction SilentlyContinue
    Remove-Item $Menu -Recurse -ErrorAction SilentlyContinue
    Guvenlik-Kaldir
    Tamam "Kaldırıldı"
    Baslik "3/3  Program dosyaları"
    Remove-Item $Hedef -Recurse -Force -ErrorAction SilentlyContinue
    $cevap = Read-Host "   Tahta listesi, ayarlar ve kayıtlar da silinsin mi? (E/H)"
    if ($cevap -match '^[eEyY]') {
        Remove-Item $Kok -Recurse -Force -ErrorAction SilentlyContinue
        Tamam "Tüm veriler silindi"
    } else {
        Tamam "Veriler korundu: $Kok\veri"
    }
    Write-Host ""
    Write-Host "  '$OrtakYol' klasöründeki dosyalar silinmedi." -ForegroundColor Gray
    Write-Host "  Not: Tahtalardaki programı kaldırmak için, kaldırmadan ÖNCE panelden" -ForegroundColor Gray
    Write-Host "  her tahta için 'Programı tahtadan kaldır' kullanılmalıydı." -ForegroundColor Gray
    Write-Host ""
    exit 0
}

# ═════════════════════════════ KURULUM TÜRÜ ══════════════════════════════════
if (-not $Istemci -and -not $Tahta) {
    if (-not $YonetimKurulu) {
        Write-Host ""
        Write-Host "   Bu bilgisayar hangisi?" -ForegroundColor White
        Write-Host "     1) Yönetim bilgisayarı   — tahtaları yöneteceğiniz ana bilgisayar (okulda bir tane)"
        Write-Host "     2) Öğretmen bilgisayarı  — yalnızca Ortak Klasör (diğer bilgisayarlar)"
        Write-Host "     3) Windows akıllı tahta  — tahtayı panelden yönetmek için (kilit, duyuru, sınav...)"
        $vars = if ($TahtaKurulu) { '3' } elseif ($IstemciKurulu) { '2' } else { '1' }
        $secim = Read-Host "   Seçiminiz (1, 2 veya 3) [$vars]"
        if (-not $secim) { $secim = $vars }
        if ($secim.Trim() -eq '2') { $Istemci = $true }
        if ($secim.Trim() -eq '3') { $Tahta = $true }
    }
}

if ($Tahta) {
    Yetki-Al
    if ($YonetimKurulu) { Hata "Bu bilgisayar yönetim bilgisayarı; tahta programı buraya kurulamaz." }

    if (-not $Sunucu -or -not $Anahtar) {
        Baslik "1/5  Yönetim bilgisayarına bağlanılıyor"
        $eski = $null
        try { $eski = Get-Content (Join-Path $TVeri 'baglanti.json') -Raw -ErrorAction Stop | ConvertFrom-Json } catch {}
        while ($true) {
            $vars = if ($eski) { ($eski.sunucu -replace '^http://', '') } else { '' }
            $adres = Read-Host "   Yönetim bilgisayarının adresi (paneldeki Tahta Ekle sayfasında yazar, ör. 192.168.1.10)$(if ($vars) { " [$vars]" })"
            if (-not $adres) { $adres = $vars }
            $adres = $adres.Trim() -replace '^https?://', '' -replace '/.*$', ''
            if (-not $adres) { continue }
            if ($adres -notmatch ':\d+$') { $adres = "${adres}:$Port" }
            $Sunucu = "http://$adres"
            try {
                $s = Sunucu-Istegi $Sunucu '/api/saglik' $null $null
                if ($s -like '*TahtaYonetim*') { Tamam "Bulundu: $Sunucu"; break }
            } catch {}
            Uyari "$Sunucu adresine ulaşılamadı. Yönetim bilgisayarı açık ve aynı ağda mı?"
        }
        while ($true) {
            $sifre = Read-Host "   Panel yönetici şifresi" -AsSecureString
            $duz = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sifre))
            try {
                $c = Sunucu-Istegi $Sunucu '/api/o/tahta-anahtar' (@{sifre = $duz} | ConvertTo-Json -Compress) $null | ConvertFrom-Json
                $Anahtar = $c.anahtar; $Kimlik = $c.kimlik
                Tamam "Şifre doğru"
                break
            } catch {
                if ($_.Exception.Message -like '*429*') { Hata "Çok fazla hatalı deneme. 5 dakika sonra yeniden deneyin." }
                Uyari "Şifre hatalı, tekrar deneyin."
            }
        }
        if (-not $Ad) {
            $Ad = (Read-Host "   Tahtanın adı (ör. 9-A, Fizik Lab.) [Enter: $env:COMPUTERNAME]").Trim()
        }
    } else {
        Baslik "1/5  Yönetim bilgisayarı: $Sunucu"
        try {
            $s = Sunucu-Istegi $Sunucu '/api/saglik' $null $null
            if ($s -like '*TahtaYonetim*') { Tamam "Bağlantı var" } else { throw 'yanıt' }
        } catch {
            Hata "Yönetim bilgisayarına ulaşılamadı ($Sunucu). Bilgisayar açık ve tahtayla aynı ağda mı? Panelden yeni kurulum dosyası indirip tekrar deneyin."
        }
    }
    if ($Ad) { Tamam "Tahta adı: $Ad" }

    Baslik "2/5  Python kontrol ediliyor (tüm kullanıcılar için)"
    $python = Python-Herkes
    if ($python) { Tamam "Python bulundu: $python" }
    else {
        $python = Python-Herkes-Kur
        if (-not $python) {
            $kisisel = Python-Bul
            if ($kisisel -and (Tk-Var $kisisel)) {
                $python = $kisisel
                Uyari "Python yalnızca bu kullanıcı için kurulu ($python). Başka hesaplarla oturum açılınca pencereler açılmayabilir."
            } else {
                Start-Process 'https://www.python.org/downloads/windows/'
                Hata "Python kurulamadı. Açılan sayfadan Python'u indirin; kurulumda 'Customize installation' › 'Install Python for all users' ve 'tcl/tk' seçili olsun. Sonra kurulumu yeniden çalıştırın."
            }
        } else { Tamam "Python kuruldu: $python" }
    }
    $pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
    if (-not (Test-Path $pythonw)) { $pythonw = $python }

    Baslik "3/5  Tahta programı kuruluyor"
    Tahta-Durdur
    if ($IstemciKurulu) {
        Surec-Durdur '*tahta-ajan.py*--istemci*'
        Remove-Item $KisaIOto -ErrorAction SilentlyContinue
        Remove-Item $IKok -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item $KayitAnahtari -Recurse -ErrorAction SilentlyContinue
        Tamam "Öğretmen bilgisayarı eşitlemesi kaldırıldı (tahta programı Ortak Klasör'ü kendisi eşitler)"
    }
    New-Item -ItemType Directory -Force -Path $TAjanD | Out-Null
    $yerel = Join-Path $Kaynak 'ajan\tahta-ajan.py'
    if (Test-Path $yerel) {
        Copy-Item $yerel $TAjan -Force
    } else {
        try {
            $wc = New-Object Net.WebClient; $wc.Proxy = $null; $wc.Headers['X-Anahtar'] = $Anahtar
            $wc.DownloadFile("$Sunucu/api/a/kod", $TAjan)
        } catch { Hata "Program yönetim bilgisayarından indirilemedi: $($_.Exception.Message)" }
    }
    Copy-Item $PSCommandPath (Join-Path $TKok 'kur.ps1') -Force -ErrorAction SilentlyContinue
    Get-ChildItem $TKok -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
    # Bağlantı anahtarının bulunduğu klasöre yalnızca SYSTEM ve yöneticiler erişebilir
    New-Item -ItemType Directory -Force -Path $TVeri | Out-Null
    & icacls $TVeri /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' /Q 2>$null | Out-Null
    Dosya-Yaz (Join-Path $TVeri 'baglanti.json') (@{sunucu = $Sunucu; anahtar = $Anahtar; kimlik = $Kimlik; ad_istek = $Ad} | ConvertTo-Json -Compress)
    foreach ($d in @('gecici', 'gunluk', 'sesler')) { Klasor-Herkese (Join-Path $TPay $d) }
    Klasor-Herkese $TOrtak
    Tamam "Kuruldu: $TAjanD"

    Baslik "4/5  Otomatik başlatma, güvenlik duvarı ve uzaktan açma ayarları"
    try {
        $eylem = New-ScheduledTaskAction -Execute $pythonw -Argument "`"$TAjan`"" -WorkingDirectory $TAjanD
        $tetik = @((New-ScheduledTaskTrigger -AtStartup),
                   (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)))
        $ayar = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
                -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
        $kim = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        Register-ScheduledTask -TaskName $TGorev -Action $eylem -Trigger $tetik -Settings $ayar -Principal $kim -Force | Out-Null
        Tamam "Tahta her açıldığında program kendiliğinden başlar"
    } catch { Hata "Görev Zamanlayıcı kaydı yapılamadı: $($_.Exception.Message)" }
    & netsh advfirewall firewall delete rule name="$TKural" 2>$null | Out-Null
    & netsh advfirewall firewall add rule name="$TKural" dir=in action=allow program="$pythonw" protocol=UDP localport=8766 profile=any 2>$null | Out-Null
    Tamam "Güvenlik duvarı izni verildi (yönetim bilgisayarını ağda bulma)"
    $wol = 0
    try {
        Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.MediaType -eq '802.3' } | ForEach-Object {
            try { Set-NetAdapterPowerManagement -Name $_.Name -WakeOnMagicPacket Enabled -ErrorAction Stop; $wol++ } catch {}
            try { Set-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*WakeOnMagicPacket' -RegistryValue 1 -ErrorAction Stop } catch {}
        }
    } catch {}
    try { Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -Value 0 -Type DWord } catch {}
    if ($wol) { Tamam "Uzaktan açma (Wake-on-LAN) kablolu ağ kartında açıldı; hızlı başlatma kapatıldı" }
    else { Uyari "Kablolu ağ kartı bulunamadı; uzaktan açma Wi-Fi ile genellikle çalışmaz (hızlı başlatma kapatıldı)" }
    try {
        New-Item -ItemType Directory -Force -Path $TMenu | Out-Null
        $kaldirArg = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $TKok 'kur.ps1')`" -Tahta -Kaldir -Bekle"
        Kisayol (Join-Path $TMenu 'Tahta programını kaldır.lnk') 'powershell.exe' $kaldirArg $TKok '' 'Tahta Yönetim tahta programını bu tahtadan kaldırır'
        New-Item -Path $TKayit -Force | Out-Null
        Set-ItemProperty $TKayit 'DisplayName' 'Tahta Yönetim (tahta programı)'
        Set-ItemProperty $TKayit 'Publisher' 'Tahta Yönetim Sistemi'
        Set-ItemProperty $TKayit 'UninstallString' "powershell.exe $kaldirArg"
        Set-ItemProperty $TKayit 'DisplayIcon' "$env:SystemRoot\System32\imageres.dll,-1023"
        Set-ItemProperty $TKayit 'NoModify' 1 -Type DWord
        Set-ItemProperty $TKayit 'NoRepair' 1 -Type DWord
    } catch {}

    Baslik "5/5  Tahta programı başlatılıyor"
    Start-ScheduledTask -TaskName $TGorev
    $hazir = $false
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Seconds 1
        try {
            $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8767/bilgi' -UseBasicParsing -TimeoutSec 2
            if ($r.StatusCode -eq 200) { $hazir = $true; break }
        } catch {}
    }
    if ($hazir) {
        Tamam "Çalışıyor"
    } else {
        Uyari "Program başlatıldı ama yanıt vermedi. Ayrıntı:"
        Get-Content (Join-Path $TVeri 'ajan.log') -Tail 15 -ErrorAction SilentlyContinue | ForEach-Object { Write-Host "     $_" -ForegroundColor Gray }
    }
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "     KURULUM TAMAMLANDI" -ForegroundColor Green
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "   Bu tahta birkaç saniye içinde yönetim panelinde görünecek$(if ($Ad) { " ($Ad)" })."
    Write-Host "   Masaüstünde '$OrtakAd' kısayolu oluşur; kilit ekranı ve duyurular bu tahtada açılır."
    Write-Host "   Kaldırmak için: Ayarlar › Uygulamalar › 'Tahta Yönetim (tahta programı)'."
    Bekle-Cik 0
}

# ═════════════════════ ÖĞRETMEN BİLGİSAYARI (ORTAK KLASÖR) ═══════════════════
if ($Istemci) {
    if ($YonetimKurulu) {
        Hata "Bu bilgisayar yönetim bilgisayarı. Ortak Klasör burada zaten var: $OrtakYol"
    }
    if (-not $Sunucu -or -not $Anahtar) {
        Baslik "1/4  Yönetim bilgisayarına bağlanılıyor"
        $eski = $null
        try { $eski = Get-Content (Join-Path $IKok 'baglanti.json') -Raw -ErrorAction Stop | ConvertFrom-Json } catch {}
        while ($true) {
            $vars = if ($eski) { ($eski.sunucu -replace '^http://', '') } else { '' }
            $adres = Read-Host "   Yönetim bilgisayarının adresi (panelde Ortak Klasör sayfasında yazar, ör. 192.168.1.10)$(if ($vars) { " [$vars]" })"
            if (-not $adres) { $adres = $vars }
            $adres = $adres.Trim() -replace '^https?://', '' -replace '/.*$', ''
            if (-not $adres) { continue }
            if ($adres -notmatch ':\d+$') { $adres = "${adres}:$Port" }
            $Sunucu = "http://$adres"
            try {
                $s = Sunucu-Istegi $Sunucu '/api/saglik' $null $null
                if ($s -like '*TahtaYonetim*') { Tamam "Bulundu: $Sunucu"; break }
            } catch {}
            Uyari "$Sunucu adresine ulaşılamadı. Yönetim bilgisayarı açık ve aynı ağda mı?"
        }
        while ($true) {
            $sifre = Read-Host "   Öğretmen şifreniz (tahta açma şifresi)" -AsSecureString
            $duz = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sifre))
            try {
                $c = Sunucu-Istegi $Sunucu '/api/o/istemci-anahtar' (@{pin = $duz} | ConvertTo-Json -Compress) $null | ConvertFrom-Json
                $Anahtar = $c.anahtar; $Kimlik = $c.kimlik
                Tamam "Şifre doğru"
                break
            } catch {
                $m = $_.Exception.Message
                if ($m -like '*429*') { Hata "Çok fazla hatalı deneme. 5 dakika sonra yeniden deneyin." }
                Uyari "Şifre hatalı, tekrar deneyin."
            }
        }
    } else {
        Baslik "1/4  Yönetim bilgisayarı: $Sunucu"
        Tamam "Bağlantı bilgileri hazır"
    }

    Baslik "2/4  Python kontrol ediliyor"
    $python = Python-Hazirla
    $pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
    if (-not (Test-Path $pythonw)) { $pythonw = $python }

    Baslik "3/4  Eşitleme programı kuruluyor"
    Surec-Durdur '*tahta-ajan.py*--istemci*'
    New-Item -ItemType Directory -Force -Path $IKok | Out-Null
    $ajan = Join-Path $IKok 'tahta-ajan.py'
    $yerel = Join-Path $Kaynak 'ajan\tahta-ajan.py'
    if (Test-Path $yerel) {
        Copy-Item $yerel $ajan -Force
    } else {
        try {
            $wc = New-Object Net.WebClient; $wc.Proxy = $null; $wc.Headers['X-Anahtar'] = $Anahtar
            $wc.DownloadFile("$Sunucu/api/a/kod", $ajan)
        } catch { Hata "Program yönetim bilgisayarından indirilemedi: $($_.Exception.Message)" }
    }
    $sunucuAd = ''
    try { $sunucuAd = (Sunucu-Istegi $Sunucu '/api/saglik' $null $null | ConvertFrom-Json).ad } catch {}
    Dosya-Yaz (Join-Path $IKok 'baglanti.json') (@{sunucu = $Sunucu; anahtar = $Anahtar; kimlik = $Kimlik; ad = $env:COMPUTERNAME; sunucu_ad = $sunucuAd} | ConvertTo-Json -Compress)
    Copy-Item $MyInvocation.MyCommand.Path (Join-Path $IKok 'kur.ps1') -Force -ErrorAction SilentlyContinue
    Get-ChildItem $IKok -File | Unblock-File -ErrorAction SilentlyContinue
    Tamam "Kuruldu: $IKok"

    Baslik "4/4  Ortak Klasör hazırlanıyor"
    Ortak-Klasor-Hazirla
    Kisayol $KisaIOto $pythonw "`"$ajan`" --istemci" $IKok '' 'Ortak Klasör eşitlemesini arka planda çalıştırır'
    New-Item -ItemType Directory -Force -Path $Menu | Out-Null
    $kaldirArg = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $IKok 'kur.ps1')`" -Kaldir -Istemci"
    Kisayol (Join-Path $Menu "Ortak Klasör'ü kaldır.lnk") 'powershell.exe' $kaldirArg $IKok '' 'Ortak Klasör eşitlemesini bu bilgisayardan kaldırır'
    try {
        New-Item -Path $KayitAnahtari -Force | Out-Null
        Set-ItemProperty $KayitAnahtari 'DisplayName' 'Ortak Klasör (Tahta Yönetim)'
        Set-ItemProperty $KayitAnahtari 'Publisher' 'Tahta Yönetim Sistemi'
        Set-ItemProperty $KayitAnahtari 'UninstallString' "powershell.exe $kaldirArg"
        Set-ItemProperty $KayitAnahtari 'DisplayIcon' "$env:SystemRoot\System32\imageres.dll,-1023"
        Set-ItemProperty $KayitAnahtari 'NoModify' 1 -Type DWord
        Set-ItemProperty $KayitAnahtari 'NoRepair' 1 -Type DWord
    } catch {}
    Start-Process $pythonw -ArgumentList "`"$ajan`" --istemci" -WorkingDirectory $IKok
    Tamam "Masaüstüne '$OrtakAd' eklendi"
    Tamam "Bilgisayar her açıldığında eşitleme kendiliğinden başlar"
    Start-Sleep -Seconds 3
    Start-Process explorer.exe $OrtakYol

    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "     KURULUM TAMAMLANDI" -ForegroundColor Green
    Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "   Klasör: $OrtakYol"
    Write-Host "   Bu klasöre koyduğunuz dosyalar tahtalarda ve diğer bilgisayarlarda görünür."
    Write-Host "   Dosyalar birkaç saniye içinde gelir; ilk eşitleme biraz sürebilir."
    Write-Host ""
    exit 0
}

# ═════════════════════════════ YÖNETİM BİLGİSAYARI ═══════════════════════════
if ($IstemciKurulu) {
    Surec-Durdur '*tahta-ajan.py*--istemci*'
    Remove-Item $KisaIOto -ErrorAction SilentlyContinue
    Remove-Item $IKok -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $KayitAnahtari -Recurse -ErrorAction SilentlyContinue
}

Baslik "1/5  Python kontrol ediliyor"
$python = Python-Hazirla
$pythonw = Join-Path (Split-Path $python) 'pythonw.exe'
if (-not (Test-Path $pythonw)) { $pythonw = $python }

Baslik "2/5  Program dosyaları kopyalanıyor"
Surec-Durdur '*TahtaYonetim*sunucu.pyw*'
New-Item -ItemType Directory -Force -Path $Hedef | Out-Null
Copy-Item -Path (Join-Path $Kaynak '*') -Destination $Hedef -Recurse -Force -Exclude '__pycache__'
Get-ChildItem $Hedef -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
Tamam "Kopyalandı: $Hedef"

Baslik "3/5  Güvenlik duvarı ve güç ayarı"
$uykuSonuc = Uyku-Ayarla
Write-Host "   Ekrana gelecek Windows onay penceresinde 'Evet'e tıklayın." -ForegroundColor Yellow
if (Guvenlik-Duvari $pythonw) {
    Tamam "Tahtalar bu bilgisayara bağlanabilir (bağlantı noktası $Port)"
} else {
    Uyari "İzin verilmedi. Tahtalar bağlanamazsa KUR.bat'ı yeniden çalıştırıp 'Evet'e tıklayın."
}
foreach ($m in $uykuSonuc) {
    if ($m -like '*onay penceresinden sonra*') {
        $g = Guc-Deger $(if ($m -like 'Hazırda*') { 'HIBERNATEIDLE' } else { 'STANDBYIDLE' })
        if ($g -eq 0 -or $g -ge ($UykuDk * 60)) { Tamam ($m -replace '; onay penceresinden sonra.*$', " → $UykuDk dakikaya çıkarıldı") }
        else { Uyari ($m -replace '; onay penceresinden sonra.*$', '; değiştirilemedi') }
    } else { Tamam $m }
}
Write-Host "   Bilgisayar uykudayken tahtalar komut alamaz ve kullanım süreleri kaydedilmez." -ForegroundColor Gray

Baslik "4/5  Kısayollar oluşturuluyor"
$sunucuPyw = Join-Path $Hedef 'sunucu.pyw'
$ikon   = Join-Path $Hedef 'ikon.ico'
Kisayol $KisaPanel $pythonw "`"$sunucuPyw`" --ac" $Hedef "$ikon,0" 'Tahta Yönetim Panelini açar'
Kisayol $KisaOto   $pythonw "`"$sunucuPyw`""      $Hedef "$ikon,0" 'Tahta Yönetim sunucusunu arka planda başlatır'
New-Item -ItemType Directory -Force -Path $Menu | Out-Null
Kisayol (Join-Path $Menu 'Tahta Yönetim Paneli.lnk') $pythonw "`"$sunucuPyw`" --ac" $Hedef "$ikon,0" 'Tahta Yönetim Panelini açar'
Kisayol (Join-Path $Menu 'Yönetici şifresini sıfırla.lnk') $python "`"$(Join-Path $Hedef 'tys.py')`" --sifre-sifirla" $Hedef "$ikon,0" 'Panel yönetici şifresini sıfırlar'
Kisayol (Join-Path $Menu 'Tahta Yönetimi kaldır.lnk') (Join-Path $Kok 'KALDIR.bat') '' $Kok "$ikon,0" 'Programı bu bilgisayardan kaldırır'
Copy-Item (Join-Path $Kaynak '..\KALDIR.bat') (Join-Path $Kok 'KALDIR.bat') -ErrorAction SilentlyContinue
# Kullanım kılavuzu panelin içinden de açılsın (Panel › Kullanım Kılavuzu)
Copy-Item (Join-Path $Kaynak '..\KURULUM_KILAVUZU.html') (Join-Path $Hedef 'web\kilavuz.html') -Force -ErrorAction SilentlyContinue
Ortak-Klasor-Hazirla
Tamam "Masaüstüne 'Tahta Yönetim Paneli' ve '$OrtakAd' kısayolları eklendi"
Tamam "Bilgisayar her açıldığında sunucu kendiliğinden başlayacak"

Baslik "5/5  Sunucu başlatılıyor"
Start-Process $pythonw -ArgumentList "`"$sunucuPyw`" --ac" -WorkingDirectory $Hedef
$hazir = $false
for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 700
    try {
        $r = Invoke-WebRequest -Uri "http://localhost:$Port/api/saglik" -UseBasicParsing -TimeoutSec 2
        if ($r.Content -like '*TahtaYonetim*') { $hazir = $true; break }
    } catch {}
}
if ($hazir) { Tamam "Sunucu çalışıyor" } else { Uyari "Sunucu yanıt vermedi. Masaüstündeki kısayola çift tıklayın. Sorun sürerse: $Kok\veri\hata.log" }

$aglar = Ag-Baglantilari
$ana = ($aglar | Where-Object { $_.Gecit -and -not $_.Sanal } | Select-Object -First 1)
if (-not $ana) { $ana = ($aglar | Where-Object { -not $_.Sanal } | Select-Object -First 1) }
if (-not $ana) { $ana = ($aglar | Select-Object -First 1) }
$ip = if ($ana) { $ana.Ip } else { $null }
if ($ana) {
    Write-Host ""
    Tamam "Tahtalar bu bilgisayara şu adresle bağlanacak: $($ana.Ip) ($($ana.Ad))"
    $gercek = @($aglar | Where-Object { -not $_.Sanal })
    $farkli = @($gercek | Where-Object { ($_.Ip -replace '\.\d+$', '') -ne ($ana.Ip -replace '\.\d+$', '') })
    if ($farkli.Count) {
        Uyari "Bu bilgisayar birden fazla ağa bağlı: $(($gercek | ForEach-Object { "$($_.Ad) $($_.Ip)" }) -join ', ')"
        Write-Host "        Tahtalar hangi ağdaysa paneldeki 'Tahta Ekle' sayfasında o adresi seçin." -ForegroundColor Gray
    }
    if ($ana.Dhcp) {
        Write-Host "   Not: Bu adres modem tarafından otomatik veriliyor. Değişirse tahtalar yeni adresi kendileri bulur;" -ForegroundColor Gray
        Write-Host "   yine de modemden bu bilgisayara sabit adres (DHCP rezervasyonu) verilmesi önerilir." -ForegroundColor Gray
    }
} else {
    Uyari "Bu bilgisayarın ağ bağlantısı bulunamadı. Ağ kablosunu kontrol edin."
}

Write-Host ""
Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "     KURULUM TAMAMLANDI" -ForegroundColor Green
Write-Host "  ════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "   Panel tarayıcıda açıldı:  http://localhost:$Port"
if ($ip) {
    Write-Host "   Telefondan / diğer bilgisayarlardan:  http://${ip}:$Port"
    Write-Host "   Öğretmenler Ortak Klasör için:        http://${ip}:$Port/ortak"
}
Write-Host "   Sonraki adım: paneldeki 'Tahta Ekle' sayfasını izleyin."
Write-Host ""
exit 0
