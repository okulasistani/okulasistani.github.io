# -*- coding: utf-8 -*-
"""
Tahta Yönetim Asistanı — küçük SSH istemcisi (yalnızca Python standart kütüphanesi)
-------------------------------------------------------------------------------------
"Ağdan Toplu Kurulum" için: ağdaki Pardus tahtalara etapadmin şifresiyle bağlanıp tahta programını kurar.

  * Anahtar değişimi: curve25519-sha256          * Şifreleme: chacha20-poly1305@openssh.com
  * Tahta kimliği: ssh-ed25519 (ya da rsa-sha2-256/512) imzası DOĞRULANIR; parmak izi yöneticiye gösterilir
  * Giriş: password ya da keyboard-interactive    * Komut: exec kanalı, girdi (stdin) gönderilebilir
Şifre yalnızca şifreli tünel içinden gönderilir; hiçbir yere kaydedilmez.
"""
import os
import time
import socket
import struct
import base64
import hashlib
import secrets

ISTEMCI_SURUM = b"SSH-2.0-TahtaYonetimAsistani_4.0"


class SSHHata(Exception):
    pass


class GirisHatasi(SSHHata):
    pass


# ── kodlama ──────────────────────────────────────────────────────────────────
def _s(b):
    if isinstance(b, str):
        b = b.encode("utf-8")
    return struct.pack(">I", len(b)) + b


def _u32(n):
    return struct.pack(">I", n)


def _mpint(n):
    if n == 0:
        return _s(b"")
    b = n.to_bytes((n.bit_length() + 8) // 8, "big")
    return _s(b)


class Okuyucu:
    def __init__(self, veri):
        self.v, self.i = veri, 0

    def bayt(self):
        x = self.v[self.i]
        self.i += 1
        return x

    def u32(self):
        x = struct.unpack(">I", self.v[self.i:self.i + 4])[0]
        self.i += 4
        return x

    def metin(self):
        n = self.u32()
        x = self.v[self.i:self.i + n]
        if len(x) != n:
            raise SSHHata("Bozuk paket")
        self.i += n
        return x

    def mpint(self):
        return int.from_bytes(self.metin(), "big", signed=True)

    def liste(self):
        return self.metin().decode("ascii", "replace").split(",")

    def bool(self):
        return self.bayt() != 0


# ── X25519 (RFC 7748) ────────────────────────────────────────────────────────
_P = 2 ** 255 - 19


def x25519(k, u):
    k = bytearray(k)
    k[0] &= 248
    k[31] &= 127
    k[31] |= 64
    k = int.from_bytes(k, "little")
    x1 = int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in range(254, -1, -1):
        kt = (k >> t) & 1
        swap ^= kt
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = kt
        a = (x2 + z2) % _P
        aa = a * a % _P
        b = (x2 - z2) % _P
        bb = b * b % _P
        e = (aa - bb) % _P
        c = (x3 + z3) % _P
        d = (x3 - z3) % _P
        da = d * a % _P
        cb = c * b % _P
        x3 = (da + cb) ** 2 % _P
        z3 = x1 * (da - cb) ** 2 % _P
        x2 = aa * bb % _P
        z2 = e * (aa + 121665 * e) % _P
    if swap:
        x2, x3, z2, z3 = x3, x2, z3, z2
    return (x2 * pow(z2, _P - 2, _P) % _P).to_bytes(32, "little")


# ── Ed25519 imza doğrulama (RFC 8032) ────────────────────────────────────────
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _xbul(y):
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if (x * x - xx) % _P:
        raise SSHHata("Geçersiz nokta")
    return x


def _topla(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = (y1 - x1) * (y2 - x2) % _P
    b = (y1 + x1) * (y2 + x2) % _P
    c = t1 * 2 * _D * t2 % _P
    d = z1 * 2 * z2 % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return e * f % _P, g * h % _P, f * g % _P, e * h % _P


def _carp(p, n):
    q = (0, 1, 1, 0)
    while n:
        if n & 1:
            q = _topla(q, p)
        p = _topla(p, p)
        n >>= 1
    return q


_BY = 4 * pow(5, _P - 2, _P) % _P
_BX = _xbul(_BY)
if _BX & 1:
    _BX = _P - _BX
_B = (_BX, _BY, 1, _BX * _BY % _P)


def _coz_nokta(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _P:
        raise SSHHata("Geçersiz nokta")
    x = _xbul(y)
    if (x & 1) != (s[31] >> 7):
        if x == 0:
            raise SSHHata("Geçersiz nokta")
        x = _P - x
    return x, y, 1, x * y % _P


def ed25519_dogrula(acik, mesaj, imza):
    if len(acik) != 32 or len(imza) != 64:
        return False
    try:
        r = _coz_nokta(imza[:32])
        a = _coz_nokta(acik)
    except SSHHata:
        return False
    s = int.from_bytes(imza[32:], "little")
    if s >= _L:
        return False
    h = int.from_bytes(hashlib.sha512(imza[:32] + acik + mesaj).digest(), "little") % _L
    p1 = _carp(_B, s)
    p2 = _topla(r, _carp(a, h))
    return (p1[0] * p2[2] - p2[0] * p1[2]) % _P == 0 and (p1[1] * p2[2] - p2[1] * p1[2]) % _P == 0


# ── RSA (rsa-sha2-256 / rsa-sha2-512) ────────────────────────────────────────
_DIGEST = {"rsa-sha2-256": (hashlib.sha256, bytes.fromhex("3031300d060960864801650304020105000420")),
           "rsa-sha2-512": (hashlib.sha512, bytes.fromhex("3051300d060960864801650304020305000440"))}


def rsa_dogrula(e, n, alg, mesaj, imza):
    if alg not in _DIGEST:
        return False
    hf, onek = _DIGEST[alg]
    k = (n.bit_length() + 7) // 8
    if len(imza) > k:
        return False
    m = pow(int.from_bytes(imza, "big"), e, n).to_bytes(k, "big")
    t = onek + hf(mesaj).digest()
    beklenen = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    return m == beklenen


# ── ChaCha20 (64 bit sayaç) ve Poly1305 ──────────────────────────────────────
def _qr(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xffffffff
    x[d] ^= x[a]
    x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xffffffff
    x[c] = (x[c] + x[d]) & 0xffffffff
    x[b] ^= x[c]
    x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xffffffff
    x[a] = (x[a] + x[b]) & 0xffffffff
    x[d] ^= x[a]
    x[d] = ((x[d] << 8) | (x[d] >> 24)) & 0xffffffff
    x[c] = (x[c] + x[d]) & 0xffffffff
    x[b] ^= x[c]
    x[b] = ((x[b] << 7) | (x[b] >> 25)) & 0xffffffff


def chacha20(anahtar, nonce8, sayac, veri):
    k = list(struct.unpack("<8I", anahtar))
    n = list(struct.unpack("<2I", nonce8))
    cikti = bytearray()
    for i in range(0, len(veri), 64):
        durum = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574] + k + [sayac & 0xffffffff, (sayac >> 32) & 0xffffffff] + n
        x = durum[:]
        for _ in range(10):
            _qr(x, 0, 4, 8, 12)
            _qr(x, 1, 5, 9, 13)
            _qr(x, 2, 6, 10, 14)
            _qr(x, 3, 7, 11, 15)
            _qr(x, 0, 5, 10, 15)
            _qr(x, 1, 6, 11, 12)
            _qr(x, 2, 7, 8, 13)
            _qr(x, 3, 4, 9, 14)
        akis = struct.pack("<16I", *((x[j] + durum[j]) & 0xffffffff for j in range(16)))
        parca = veri[i:i + 64]
        cikti += (int.from_bytes(parca, "little") ^ int.from_bytes(akis[:len(parca)], "little")).to_bytes(len(parca), "little")
        sayac += 1
    return bytes(cikti)


def poly1305(anahtar, mesaj):
    r = int.from_bytes(anahtar[:16], "little") & 0x0ffffffc0ffffffc0ffffffc0fffffff
    s = int.from_bytes(anahtar[16:32], "little")
    p = (1 << 130) - 5
    acc = 0
    for i in range(0, len(mesaj), 16):
        acc = (acc + int.from_bytes(mesaj[i:i + 16] + b"\x01", "little")) * r % p
    return ((acc + s) & ((1 << 128) - 1)).to_bytes(16, "little")


def parmak_izi(blob):
    return "SHA256:" + base64.b64encode(hashlib.sha256(blob).digest()).decode().rstrip("=")


def anahtar_turu(blob):
    try:
        return Okuyucu(blob).metin().decode()
    except Exception:
        return "?"


# ── SSH bağlantısı ───────────────────────────────────────────────────────────
class SSH:
    def __init__(self, host, port=22, zaman=10.0):
        self.host, self.port, self.zaman = host, port, zaman
        self.sock = None
        self.tampon = b""
        self.seq_g = self.seq_a = 0
        self.k_g = self.k_a = None          # 64 baytlık chacha anahtarları (gönder / al)
        self.sunucu_surum = ""
        self.anahtar_blob = None
        self.oturum_id = None
        self.siki = False

    # ── düşük seviye ──
    def _oku(self, n):
        while len(self.tampon) < n:
            try:
                p = self.sock.recv(65536)
            except socket.timeout:
                raise SSHHata("Tahta yanıt vermiyor (zaman aşımı)")
            if not p:
                raise SSHHata("Bağlantı kapandı")
            self.tampon += p
        x, self.tampon = self.tampon[:n], self.tampon[n:]
        return x

    def gonder(self, yuk):
        if self.k_g is None:
            dolgu = 8 - (5 + len(yuk)) % 8
            if dolgu < 4:
                dolgu += 8
            paket = _u32(1 + len(yuk) + dolgu) + bytes([dolgu]) + yuk + secrets.token_bytes(dolgu)
            self.sock.sendall(paket)
        else:
            dolgu = 8 - (1 + len(yuk)) % 8
            if dolgu < 4:
                dolgu += 8
            govde = bytes([dolgu]) + yuk + secrets.token_bytes(dolgu)
            nonce = struct.pack(">Q", self.seq_g)
            uzunluk = chacha20(self.k_g[32:], nonce, 0, _u32(len(govde)))
            pkey = chacha20(self.k_g[:32], nonce, 0, b"\x00" * 32)
            sifreli = chacha20(self.k_g[:32], nonce, 1, govde)
            self.sock.sendall(uzunluk + sifreli + poly1305(pkey, uzunluk + sifreli))
        self.seq_g = (self.seq_g + 1) & 0xffffffff

    def al(self):
        while True:
            if self.k_a is None:
                n = struct.unpack(">I", self._oku(4))[0]
                if n > 300000:
                    raise SSHHata("Bozuk paket")
                govde = self._oku(n)
            else:
                nonce = struct.pack(">Q", self.seq_a)
                el = self._oku(4)
                n = struct.unpack(">I", chacha20(self.k_a[32:], nonce, 0, el))[0]
                if n > 300000:
                    raise SSHHata("Bozuk paket (şifre çözülemedi)")
                sifreli = self._oku(n)
                etiket = self._oku(16)
                pkey = chacha20(self.k_a[:32], nonce, 0, b"\x00" * 32)
                if not secrets.compare_digest(poly1305(pkey, el + sifreli), etiket):
                    raise SSHHata("Paket doğrulanamadı")
                govde = chacha20(self.k_a[:32], nonce, 1, sifreli)
            self.seq_a = (self.seq_a + 1) & 0xffffffff
            yuk = govde[1:len(govde) - govde[0]]
            if not yuk:
                continue
            t = yuk[0]
            if t in (2, 4) and not (self.siki and self.k_a is None):      # IGNORE, DEBUG
                continue
            if t == 1:
                r = Okuyucu(yuk[1:])
                kod = r.u32()
                raise SSHHata("Tahta bağlantıyı kapattı: " + r.metin().decode("utf-8", "replace") + " ({})".format(kod))
            return yuk

    # ── el sıkışma ──
    def baglan(self):
        """TCP bağlantısı + anahtar değişimi. → {"tur", "parmak_izi", "surum"}"""
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=self.zaman)
        except socket.timeout:
            raise SSHHata("Tahtaya ulaşılamadı (zaman aşımı)")
        except ConnectionRefusedError:
            raise SSHHata("Tahtada SSH hizmeti kapalı (22. port)")
        except OSError as e:
            raise SSHHata("Tahtaya ulaşılamadı: {}".format(e))
        self.sock.settimeout(self.zaman)
        self.sock.sendall(ISTEMCI_SURUM + b"\r\n")
        for _ in range(50):
            satir = b""
            while not satir.endswith(b"\n"):
                satir += self._oku(1)
                if len(satir) > 1024:
                    raise SSHHata("Geçersiz SSH yanıtı")
            if satir.startswith(b"SSH-"):
                break
        else:
            raise SSHHata("SSH sunucusu değil")
        self.sunucu_surum = satir.strip().decode("utf-8", "replace")
        if not self.sunucu_surum.startswith("SSH-2.0") and not self.sunucu_surum.startswith("SSH-1.99"):
            raise SSHHata("Desteklenmeyen SSH sürümü: " + self.sunucu_surum)
        i_c = (bytes([20]) + secrets.token_bytes(16) +
               _s("curve25519-sha256,curve25519-sha256@libssh.org,kex-strict-c-v00@openssh.com") +
               _s("ssh-ed25519,rsa-sha2-512,rsa-sha2-256") +
               _s("chacha20-poly1305@openssh.com") * 2 + _s("hmac-sha2-256") * 2 + _s("none") * 2 + _s("") * 2 +
               b"\x00" + _u32(0))
        self.gonder(i_c)
        i_s = self.al()
        if i_s[0] != 20:
            raise SSHHata("Beklenmeyen paket (anahtar değişimi)")
        r = Okuyucu(i_s[17:])
        kex, hk, enc_c, enc_s = r.liste(), r.liste(), r.liste(), r.liste()
        if not ({"curve25519-sha256", "curve25519-sha256@libssh.org"} & set(kex)):
            raise SSHHata("Tahtanın SSH sürümü desteklenmiyor (curve25519 yok)")
        if "chacha20-poly1305@openssh.com" not in enc_c or "chacha20-poly1305@openssh.com" not in enc_s:
            raise SSHHata("Tahtanın SSH şifreleme ayarı desteklenmiyor (chacha20-poly1305 yok)")
        hk_sec = next((a for a in ("ssh-ed25519", "rsa-sha2-512", "rsa-sha2-256") if a in hk), None)
        if not hk_sec:
            raise SSHHata("Tahta anahtarı türü desteklenmiyor")
        self.siki = "kex-strict-s-v00@openssh.com" in kex
        gizli = secrets.token_bytes(32)
        q_c = x25519(gizli, (9).to_bytes(32, "little"))
        self.gonder(bytes([30]) + _s(q_c))
        cevap = self.al()
        if cevap[0] != 31:
            raise SSHHata("Beklenmeyen paket (anahtar değişimi yanıtı)")
        r = Okuyucu(cevap[1:])
        k_s, q_s, imza = r.metin(), r.metin(), r.metin()
        ortak = x25519(gizli, q_s)
        if ortak == b"\x00" * 32:
            raise SSHHata("Geçersiz anahtar değişimi")
        k = int.from_bytes(ortak, "big")
        h = hashlib.sha256(_s(ISTEMCI_SURUM) + _s(self.sunucu_surum.encode()) + _s(i_c) + _s(i_s) + _s(k_s) +
                           _s(q_c) + _s(q_s) + _mpint(k)).digest()
        if not self._imza_dogru(k_s, imza, h, hk_sec):
            raise SSHHata("Tahta kimliği doğrulanamadı (imza geçersiz)")
        self.anahtar_blob = k_s
        self.oturum_id = h
        self.gonder(bytes([21]))
        if self.siki:
            self.seq_g = 0
        y = self.al()
        if y[0] != 21:
            raise SSHHata("Beklenmeyen paket (NEWKEYS)")
        if self.siki:
            self.seq_a = 0
        km = _mpint(k)

        def turet(harf):
            k1 = hashlib.sha256(km + h + harf + h).digest()
            k2 = hashlib.sha256(km + h + k1).digest()
            return k1 + k2
        self.k_g, self.k_a = turet(b"C"), turet(b"D")
        return {"tur": anahtar_turu(k_s), "parmak_izi": parmak_izi(k_s), "surum": self.sunucu_surum}

    def _imza_dogru(self, k_s, imza_blob, h, beklenen):
        r = Okuyucu(k_s)
        tur = r.metin().decode()
        ri = Okuyucu(imza_blob)
        alg = ri.metin().decode()
        imza = ri.metin()
        if tur == "ssh-ed25519" and alg == "ssh-ed25519":
            return ed25519_dogrula(r.metin(), h, imza)
        if tur == "ssh-rsa" and alg in ("rsa-sha2-256", "rsa-sha2-512"):
            e, n = r.mpint(), r.mpint()
            return n.bit_length() >= 2048 and rsa_dogrula(e, n, alg, h, imza)
        return False

    # ── giriş ──
    def giris(self, kullanici, sifre):
        self.gonder(bytes([5]) + _s("ssh-userauth"))
        y = self.al()
        while y[0] == 7:                    # EXT_INFO
            y = self.al()
        if y[0] != 6:
            raise SSHHata("Giriş hizmeti açılamadı")
        self.gonder(bytes([50]) + _s(kullanici) + _s("ssh-connection") + _s("password") + b"\x00" + _s(sifre))
        yontemler = []
        while True:
            y = self.al()
            if y[0] == 53:                  # banner
                continue
            if y[0] == 52:
                return True
            if y[0] == 60:
                raise GirisHatasi("Bu kullanıcının şifresinin süresi dolmuş; tahtada bir kez giriş yapıp şifreyi yenileyin")
            if y[0] == 51:
                yontemler = Okuyucu(y[1:]).liste()
                break
            raise SSHHata("Beklenmeyen giriş yanıtı ({})".format(y[0]))
        if "keyboard-interactive" not in yontemler:
            if "password" in yontemler:
                raise GirisHatasi("Kullanıcı adı ya da şifre yanlış")
            raise GirisHatasi("Tahta şifreyle girişe izin vermiyor ({})".format(",".join(yontemler)))
        self.gonder(bytes([50]) + _s(kullanici) + _s("ssh-connection") + _s("keyboard-interactive") + _s("") + _s(""))
        while True:
            y = self.al()
            if y[0] == 53:
                continue
            if y[0] == 52:
                return True
            if y[0] == 51:
                raise GirisHatasi("Kullanıcı adı ya da şifre yanlış")
            if y[0] == 60:
                r = Okuyucu(y[1:])
                r.metin(), r.metin(), r.metin()
                n = r.u32()
                self.gonder(bytes([61]) + _u32(n) + b"".join(_s(sifre) for _ in range(n)))
                continue
            raise SSHHata("Beklenmeyen giriş yanıtı ({})".format(y[0]))

    # ── komut ──
    def calistir(self, komut, girdi=b"", zaman=300, cikti_cb=None):
        """→ (çıkış kodu, stdout, stderr)"""
        self.gonder(bytes([90]) + _s("session") + _u32(0) + _u32(2 * 1024 * 1024) + _u32(32768))
        while True:
            y = self.al()
            if y[0] == 91:
                r = Okuyucu(y[1:])
                r.u32()
                kanal = r.u32()
                pencere = r.u32()
                break
            if y[0] == 92:
                raise SSHHata("Komut kanalı açılamadı")
            if y[0] == 80:
                self._kuresel(y)
        self.gonder(bytes([98]) + _u32(kanal) + _s("exec") + b"\x01" + _s(komut))
        out, err, kod = bytearray(), bytearray(), None
        tuketilen = 0
        bitis = time.time() + zaman
        girdi_gonderildi = False
        while True:
            if time.time() > bitis:
                raise SSHHata("Komut zaman aşımına uğradı")
            y = self.al()
            t = y[0]
            r = Okuyucu(y[1:])
            if t == 99:                     # exec kabul edildi
                if girdi and not girdi_gonderildi:
                    self.gonder(bytes([94]) + _u32(kanal) + _s(girdi))
                girdi_gonderildi = True
                self.gonder(bytes([96]) + _u32(kanal))
            elif t == 100:
                raise SSHHata("Tahta komutu çalıştırmayı reddetti")
            elif t in (94, 95):
                r.u32()
                if t == 95:
                    r.u32()
                v = r.metin()
                (out if t == 94 else err).extend(v)
                if cikti_cb:
                    try:
                        cikti_cb(v)
                    except Exception:
                        pass
                tuketilen += len(v)
                if tuketilen > 1024 * 1024:
                    self.gonder(bytes([93]) + _u32(kanal) + _u32(tuketilen))
                    tuketilen = 0
            elif t == 98:
                r.u32()
                ad = r.metin()
                istek = r.bool()
                if ad == b"exit-status":
                    kod = r.u32()
                elif ad == b"exit-signal":
                    kod = 255
                if istek:
                    self.gonder(bytes([100]) + _u32(kanal))
            elif t == 97:                   # kapandı
                self.gonder(bytes([97]) + _u32(kanal))
                return kod if kod is not None else -1, bytes(out), bytes(err)
            elif t == 80:
                self._kuresel(y)
            elif t == 93:
                pass

    def _kuresel(self, y):
        r = Okuyucu(y[1:])
        r.metin()
        if r.bool():
            self.gonder(bytes([82]))

    def kapat(self):
        try:
            if self.k_g is not None:
                self.gonder(bytes([1]) + _u32(11) + _s("") + _s(""))
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


def kimlik_al(host, port=22, zaman=4.0):
    """Yalnızca tahtanın SSH sürümünü ve anahtar parmak izini alır (şifre gönderilmez)."""
    s = SSH(host, port, zaman)
    try:
        return s.baglan()
    finally:
        s.kapat()


def port_acik(host, port=22, zaman=0.8):
    try:
        with socket.create_connection((host, port), timeout=zaman):
            return True
    except OSError:
        return False
