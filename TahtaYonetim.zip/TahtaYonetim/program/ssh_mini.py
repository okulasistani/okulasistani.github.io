# -*- coding: utf-8 -*-
"""
Tahta Yönetim Asistanı — küçük SSH istemcisi (yalnızca Python standart kütüphanesi)
-------------------------------------------------------------------------------------
"Ağdan Toplu Kurulum" için: ağdaki Pardus tahtalara etapadmin şifresiyle bağlanıp tahta programını kurar.

  * Anahtar değişimi: curve25519-sha256, diffie-hellman-group14-sha256
  * Şifreleme: chacha20-poly1305@openssh.com, aes128-ctr / aes256-ctr + hmac-sha2-256/512 (-etm)
  * Tahta kimliği: ssh-ed25519 (ya da rsa-sha2-256/512) imzası DOĞRULANIR; parmak izi yöneticiye gösterilir
  * Giriş: password ya da keyboard-interactive    * Komut: exec kanalı, girdi (stdin) gönderilebilir
Şifre yalnızca şifreli tünel içinden gönderilir; hiçbir yere kaydedilmez.
"""
import os
import time
import socket
import struct
import base64
import hashlib
import secrets

ISTEMCI_SURUM = b"SSH-2.0-TahtaYonetimAsistani_4.3"


class SSHHata(Exception):
    pass


class GirisHatasi(SSHHata):
    pass


# ── kodlama ──────────────────────────────────────────────────────────────────
def _s(b):
    if isinstance(b, str):
        b = b.encode("utf-8")
    return struct.pack(">I", len(b)) + b


def _u32(n):
    return struct.pack(">I", n)


def _mpint(n):
    if n == 0:
        return _s(b"")
    b = n.to_bytes((n.bit_length() + 8) // 8, "big")
    return _s(b)


class Okuyucu:
    def __init__(self, veri):
        self.v, self.i = veri, 0

    def bayt(self):
        x = self.v[self.i]
        self.i += 1
        return x

    def u32(self):
        x = struct.unpack(">I", self.v[self.i:self.i + 4])[0]
        self.i += 4
        return x

    def metin(self):
        n = self.u32()
        x = self.v[self.i:self.i + n]
        if len(x) != n:
            raise SSHHata("Bozuk paket")
        self.i += n
        return x

    def mpint(self):
        return int.from_bytes(self.metin(), "big", signed=True)

    def liste(self):
        return self.metin().decode("ascii", "replace").split(",")

    def bool(self):
        return self.bayt() != 0


# ── X25519 (RFC 7748) ────────────────────────────────────────────────────────
_P = 2 ** 255 - 19


def x25519(k, u):
    k = bytearray(k)
    k[0] &= 248
    k[31] &= 127
    k[31] |= 64
    k = int.from_bytes(k, "little")
    x1 = int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in range(254, -1, -1):
        kt = (k >> t) & 1
        swap ^= kt
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = kt
        a = (x2 + z2) % _P
        aa = a * a % _P
        b = (x2 - z2) % _P
        bb = b * b % _P
        e = (aa - bb) % _P
        c = (x3 + z3) % _P
        d = (x3 - z3) % _P
        da = d * a % _P
        cb = c * b % _P
        x3 = (da + cb) ** 2 % _P
        z3 = x1 * (da - cb) ** 2 % _P
        x2 = aa * bb % _P
        z2 = e * (aa + 121665 * e) % _P
    if swap:
        x2, x3, z2, z3 = x3, x2, z3, z2
    return (x2 * pow(z2, _P - 2, _P) % _P).to_bytes(32, "little")


# ── Ed25519 imza doğrulama (RFC 8032) ────────────────────────────────────────
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _xbul(y):
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if (x * x - xx) % _P:
        raise SSHHata("Geçersiz nokta")
    return x


def _topla(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = (y1 - x1) * (y2 - x2) % _P
    b = (y1 + x1) * (y2 + x2) % _P
    c = t1 * 2 * _D * t2 % _P
    d = z1 * 2 * z2 % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return e * f % _P, g * h % _P, f * g % _P, e * h % _P


def _carp(p, n):
    q = (0, 1, 1, 0)
    while n:
        if n & 1:
            q = _topla(q, p)
        p = _topla(p, p)
        n >>= 1
    return q


_BY = 4 * pow(5, _P - 2, _P) % _P
_BX = _xbul(_BY)
if _BX & 1:
    _BX = _P - _BX
_B = (_BX, _BY, 1, _BX * _BY % _P)


def _coz_nokta(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _P:
        raise SSHHata("Geçersiz nokta")
    x = _xbul(y)
    if (x & 1) != (s[31] >> 7):
        if x == 0:
            raise SSHHata("Geçersiz nokta")
        x = _P - x
    return x, y, 1, x * y % _P


def ed25519_dogrula(acik, mesaj, imza):
    if len(acik) != 32 or len(imza) != 64:
        return False
    try:
        r = _coz_nokta(imza[:32])
        a = _coz_nokta(acik)
    except SSHHata:
        return False
    s = int.from_bytes(imza[32:], "little")
    if s >= _L:
        return False
    h = int.from_bytes(hashlib.sha512(imza[:32] + acik + mesaj).digest(), "little") % _L
    p1 = _carp(_B, s)
    p2 = _topla(r, _carp(a, h))
    return (p1[0] * p2[2] - p2[0] * p1[2]) % _P == 0 and (p1[1] * p2[2] - p2[1] * p1[2]) % _P == 0


# ── RSA (rsa-sha2-256 / rsa-sha2-512) ────────────────────────────────────────
_DIGEST = {"rsa-sha2-256": (hashlib.sha256, bytes.fromhex("3031300d060960864801650304020105000420")),
           "rsa-sha2-512": (hashlib.sha512, bytes.fromhex("3051300d060960864801650304020305000440"))}


def rsa_dogrula(e, n, alg, mesaj, imza):
    if alg not in _DIGEST:
        return False
    hf, onek = _DIGEST[alg]
    k = (n.bit_length() + 7) // 8
    if len(imza) > k:
        return False
    m = pow(int.from_bytes(imza, "big"), e, n).to_bytes(k, "big")
    t = onek + hf(mesaj).digest()
    beklenen = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    return m == beklenen


# ── ChaCha20 (64 bit sayaç) ve Poly1305 ──────────────────────────────────────
def _qr(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xffffffff
    x[d] ^= x[a]
    x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xffffffff
    x[c] = (x[c] + x[d]) & 0xffffffff
    x[b] ^= x[c]
    x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xffffffff
    x[a] = (x[a] + x[b]) & 0xffffffff
    x[d] ^= x[a]
    x[d] = ((x[d] << 8) | (x[d] >> 24)) & 0xffffffff
    x[c] = (x[c] + x[d]) & 0xffffffff
    x[b] ^= x[c]
    x[b] = ((x[b] << 7) | (x[b] >> 25)) & 0xffffffff


def chacha20(anahtar, nonce8, sayac, veri):
    k = list(struct.unpack("<8I", anahtar))
    n = list(struct.unpack("<2I", nonce8))
    cikti = bytearray()
    for i in range(0, len(veri), 64):
        durum = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574] + k + [sayac & 0xffffffff, (sayac >> 32) & 0xffffffff] + n
        x = durum[:]
        for _ in range(10):
            _qr(x, 0, 4, 8, 12)
            _qr(x, 1, 5, 9, 13)
            _qr(x, 2, 6, 10, 14)
            _qr(x, 3, 7, 11, 15)
            _qr(x, 0, 5, 10, 15)
            _qr(x, 1, 6, 11, 12)
            _qr(x, 2, 7, 8, 13)
            _qr(x, 3, 4, 9, 14)
        akis = struct.pack("<16I", *((x[j] + durum[j]) & 0xffffffff for j in range(16)))
        parca = veri[i:i + 64]
        cikti += (int.from_bytes(parca, "little") ^ int.from_bytes(akis[:len(parca)], "little")).to_bytes(len(parca), "little")
        sayac += 1
    return bytes(cikti)


def poly1305(anahtar, mesaj):
    r = int.from_bytes(anahtar[:16], "little") & 0x0ffffffc0ffffffc0ffffffc0fffffff
    s = int.from_bytes(anahtar[16:32], "little")
    p = (1 << 130) - 5
    acc = 0
    for i in range(0, len(mesaj), 16):
        acc = (acc + int.from_bytes(mesaj[i:i + 16] + b"\x01", "little")) * r % p
    return ((acc + s) & ((1 << 128) - 1)).to_bytes(16, "little")


# ── AES (yalnızca şifreleme yönü; CTR kipi için yeterli) ─────────────────────
def _aes_tablolar():
    sbox = [0] * 256
    p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xff) ^ (0x1b if p & 0x80 else 0)
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q &= 0xff
        if q & 0x80:
            q ^= 0x09
        x = q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4))
        sbox[p] = (x ^ 0x63) & 0xff
        if p == 1:
            break
    sbox[0] = 0x63

    def xt(a):
        return ((a << 1) ^ 0x1b) & 0xff if a & 0x80 else a << 1
    t0 = []
    for i in range(256):
        a = sbox[i]
        t0.append((xt(a) << 24) | (a << 16) | (a << 8) | (xt(a) ^ a))
    rot = lambda t, n: [((v >> n) | (v << (32 - n))) & 0xffffffff for v in t]
    return sbox, t0, rot(t0, 8), rot(t0, 16), rot(t0, 24)


_SBOX, _T0, _T1, _T2, _T3 = _aes_tablolar()


class AES:
    def __init__(self, anahtar):
        nk = len(anahtar) // 4
        self.nr = nk + 6
        w = list(struct.unpack(">%dI" % nk, anahtar))
        rcon = 1
        for i in range(nk, 4 * (self.nr + 1)):
            t = w[i - 1]
            if i % nk == 0:
                t = ((t << 8) | (t >> 24)) & 0xffffffff
                t = (_SBOX[t >> 24] << 24) | (_SBOX[(t >> 16) & 255] << 16) | (_SBOX[(t >> 8) & 255] << 8) | _SBOX[t & 255]
                t ^= rcon << 24
                rcon = ((rcon << 1) ^ 0x1b) & 0xff if rcon & 0x80 else rcon << 1
            elif nk > 6 and i % nk == 4:
                t = (_SBOX[t >> 24] << 24) | (_SBOX[(t >> 16) & 255] << 16) | (_SBOX[(t >> 8) & 255] << 8) | _SBOX[t & 255]
            w.append(w[i - nk] ^ t)
        self.w = w

    def blok(self, b):
        w, T0, T1, T2, T3, S = self.w, _T0, _T1, _T2, _T3, _SBOX
        s0, s1, s2, s3 = struct.unpack(">4I", b)
        s0 ^= w[0]; s1 ^= w[1]; s2 ^= w[2]; s3 ^= w[3]
        k = 4
        for _ in range(self.nr - 1):
            t0 = T0[s0 >> 24] ^ T1[(s1 >> 16) & 255] ^ T2[(s2 >> 8) & 255] ^ T3[s3 & 255] ^ w[k]
            t1 = T0[s1 >> 24] ^ T1[(s2 >> 16) & 255] ^ T2[(s3 >> 8) & 255] ^ T3[s0 & 255] ^ w[k + 1]
            t2 = T0[s2 >> 24] ^ T1[(s3 >> 16) & 255] ^ T2[(s0 >> 8) & 255] ^ T3[s1 & 255] ^ w[k + 2]
            t3 = T0[s3 >> 24] ^ T1[(s0 >> 16) & 255] ^ T2[(s1 >> 8) & 255] ^ T3[s2 & 255] ^ w[k + 3]
            s0, s1, s2, s3 = t0, t1, t2, t3
            k += 4
        c = []
        for a, b2, c2, d in ((s0, s1, s2, s3), (s1, s2, s3, s0), (s2, s3, s0, s1), (s3, s0, s1, s2)):
            c.append(((S[a >> 24] << 24) | (S[(b2 >> 16) & 255] << 16) | (S[(c2 >> 8) & 255] << 8) | S[d & 255]) ^ w[k])
            k += 1
        return struct.pack(">4I", *c)


class AesCtr:
    def __init__(self, anahtar, iv):
        self.aes, self.sayac, self.art = AES(anahtar), int.from_bytes(iv, "big"), b""

    def isle(self, veri):
        akis = bytearray(self.art)
        while len(akis) < len(veri):
            akis += self.aes.blok((self.sayac & ((1 << 128) - 1)).to_bytes(16, "big"))
            self.sayac += 1
        self.art = bytes(akis[len(veri):])
        return (int.from_bytes(veri, "big") ^ int.from_bytes(bytes(akis[:len(veri)]), "big")).to_bytes(len(veri), "big") if veri else b""


# ── yön başına şifre durumları ───────────────────────────────────────────────
class ChaChaYon:
    def __init__(self, k):
        self.k = k

    def paketle(self, seq, yuk):
        dolgu = 8 - (1 + len(yuk)) % 8
        if dolgu < 4:
            dolgu += 8
        govde = bytes([dolgu]) + yuk + secrets.token_bytes(dolgu)
        nonce = struct.pack(">Q", seq)
        uzunluk = chacha20(self.k[32:], nonce, 0, _u32(len(govde)))
        pkey = chacha20(self.k[:32], nonce, 0, b"\x00" * 32)
        sifreli = chacha20(self.k[:32], nonce, 1, govde)
        return uzunluk + sifreli + poly1305(pkey, uzunluk + sifreli)

    def coz(self, oku, seq):
        nonce = struct.pack(">Q", seq)
        el = oku(4)
        n = struct.unpack(">I", chacha20(self.k[32:], nonce, 0, el))[0]
        if n > 300000:
            raise SSHHata("Bozuk paket (şifre çözülemedi)")
        sifreli = oku(n)
        etiket = oku(16)
        pkey = chacha20(self.k[:32], nonce, 0, b"\x00" * 32)
        if not secrets.compare_digest(poly1305(pkey, el + sifreli), etiket):
            raise SSHHata("Paket doğrulanamadı")
        return chacha20(self.k[:32], nonce, 1, sifreli)


class AesYon:
    def __init__(self, anahtar, iv, mac_anahtar, mac_hash, etm):
        self.ctr = AesCtr(anahtar, iv)
        self.mk, self.mh, self.etm = mac_anahtar, mac_hash, etm
        self.ml = mac_hash().digest_size

    def _mac(self, seq, veri):
        import hmac as _h
        return _h.new(self.mk, _u32(seq) + veri, self.mh).digest()

    def paketle(self, seq, yuk):
        bas = 1 if self.etm else 5
        dolgu = 16 - (bas + len(yuk)) % 16
        if dolgu < 4:
            dolgu += 16
        govde = bytes([dolgu]) + yuk + secrets.token_bytes(dolgu)
        if self.etm:
            sifreli = _u32(len(govde)) + self.ctr.isle(govde)
            return sifreli + self._mac(seq, sifreli)
        duz = _u32(len(govde)) + govde
        return self.ctr.isle(duz) + self._mac(seq, duz)

    def coz(self, oku, seq):
        if self.etm:
            el = oku(4)
            n = struct.unpack(">I", el)[0]
            if n > 300000 or n % 16:
                raise SSHHata("Bozuk paket")
            sifreli = oku(n)
            if not secrets.compare_digest(self._mac(seq, el + sifreli), oku(self.ml)):
                raise SSHHata("Paket doğrulanamadı")
            return self.ctr.isle(sifreli)
        ilk = self.ctr.isle(oku(16))
        n = struct.unpack(">I", ilk[:4])[0]
        if n > 300000 or (n + 4) % 16:
            raise SSHHata("Bozuk paket (şifre çözülemedi)")
        duz = ilk + self.ctr.isle(oku(n + 4 - 16))
        if not secrets.compare_digest(self._mac(seq, duz), oku(self.ml)):
            raise SSHHata("Paket doğrulanamadı")
        return duz[4:]


SIFRELER = ["chacha20-poly1305@openssh.com", "aes128-ctr", "aes256-ctr"]
MACLER = {"hmac-sha2-256-etm@openssh.com": (hashlib.sha256, True), "hmac-sha2-512-etm@openssh.com": (hashlib.sha512, True),
          "hmac-sha2-256": (hashlib.sha256, False), "hmac-sha2-512": (hashlib.sha512, False)}
_G14 = int("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF", 16)


def _sec(istemci, sunucu):
    return next((a for a in istemci if a in sunucu), None)


def parmak_izi(blob):
    return "SHA256:" + base64.b64encode(hashlib.sha256(blob).digest()).decode().rstrip("=")


def anahtar_turu(blob):
    try:
        return Okuyucu(blob).metin().decode()
    except Exception:
        return "?"


# ── SSH bağlantısı ───────────────────────────────────────────────────────────
class SSH:
    def __init__(self, host, port=22, zaman=10.0):
        self.host, self.port, self.zaman = host, port, zaman
        self.sock = None
        self.tampon = b""
        self.seq_g = self.seq_a = 0
        self.k_g = self.k_a = None          # yön başına şifre durumu (gönder / al)
        self.secilen = {}
        self.sunucu_surum = ""
        self.anahtar_blob = None
        self.oturum_id = None
        self.siki = False

    # ── düşük seviye ──
    def _oku(self, n):
        while len(self.tampon) < n:
            try:
                p = self.sock.recv(65536)
            except socket.timeout:
                raise SSHHata("Tahta yanıt vermiyor (zaman aşımı)")
            if not p:
                raise SSHHata("Bağlantı kapandı")
            self.tampon += p
        x, self.tampon = self.tampon[:n], self.tampon[n:]
        return x

    def gonder(self, yuk):
        if self.k_g is None:
            dolgu = 8 - (5 + len(yuk)) % 8
            if dolgu < 4:
                dolgu += 8
            paket = _u32(1 + len(yuk) + dolgu) + bytes([dolgu]) + yuk + secrets.token_bytes(dolgu)
            self.sock.sendall(paket)
        else:
            self.sock.sendall(self.k_g.paketle(self.seq_g, yuk))
        self.seq_g = (self.seq_g + 1) & 0xffffffff

    def al(self):
        while True:
            if self.k_a is None:
                n = struct.unpack(">I", self._oku(4))[0]
                if n > 300000:
                    raise SSHHata("Bozuk paket")
                govde = self._oku(n)
            else:
                govde = self.k_a.coz(self._oku, self.seq_a)
            self.seq_a = (self.seq_a + 1) & 0xffffffff
            yuk = govde[1:len(govde) - govde[0]]
            if not yuk:
                continue
            t = yuk[0]
            if t in (2, 4) and not (self.siki and self.k_a is None):      # IGNORE, DEBUG
                continue
            if t == 1:
                r = Okuyucu(yuk[1:])
                kod = r.u32()
                raise SSHHata("Tahta bağlantıyı kapattı: " + r.metin().decode("utf-8", "replace") + " ({})".format(kod))
            return yuk

    # ── el sıkışma ──
    def baglan(self):
        """TCP bağlantısı + anahtar değişimi. → {"tur", "parmak_izi", "surum"}"""
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=self.zaman)
        except socket.timeout:
            raise SSHHata("Tahtaya ulaşılamadı (zaman aşımı)")
        except ConnectionRefusedError:
            raise SSHHata("Tahtada SSH hizmeti kapalı (22. port)")
        except OSError as e:
            raise SSHHata("Tahtaya ulaşılamadı: {}".format(e))
        self.sock.settimeout(self.zaman)
        self.sock.sendall(ISTEMCI_SURUM + b"\r\n")
        for _ in range(50):
            satir = b""
            while not satir.endswith(b"\n"):
                satir += self._oku(1)
                if len(satir) > 1024:
                    raise SSHHata("Geçersiz SSH yanıtı")
            if satir.startswith(b"SSH-"):
                break
        else:
            raise SSHHata("SSH sunucusu değil")
        self.sunucu_surum = satir.strip().decode("utf-8", "replace")
        if not self.sunucu_surum.startswith("SSH-2.0") and not self.sunucu_surum.startswith("SSH-1.99"):
            raise SSHHata("Desteklenmeyen SSH sürümü: " + self.sunucu_surum)
        i_c = (bytes([20]) + secrets.token_bytes(16) +
               _s("curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group14-sha256,kex-strict-c-v00@openssh.com") +
               _s("ssh-ed25519,rsa-sha2-512,rsa-sha2-256") +
               _s(",".join(SIFRELER)) * 2 + _s(",".join(MACLER)) * 2 + _s("none") * 2 + _s("") * 2 +
               b"\x00" + _u32(0))
        self.gonder(i_c)
        i_s = self.al()
        if i_s[0] != 20:
            raise SSHHata("Beklenmeyen paket (anahtar değişimi)")
        r = Okuyucu(i_s[17:])
        kex, hk, enc_c, enc_s, mac_c, mac_s = r.liste(), r.liste(), r.liste(), r.liste(), r.liste(), r.liste()
        kex_sec = _sec(["curve25519-sha256", "curve25519-sha256@libssh.org", "diffie-hellman-group14-sha256"], kex)
        if not kex_sec:
            raise SSHHata("Cihazın SSH anahtar değişimi desteklenmiyor ({})".format(",".join(kex[:4])))
        sif_g, sif_a = _sec(SIFRELER, enc_c), _sec(SIFRELER, enc_s)
        if not sif_g or not sif_a:
            raise SSHHata("Cihazın SSH şifreleme türü desteklenmiyor ({})".format(",".join(enc_c[:4])))
        mac_g, mac_a = _sec(list(MACLER), mac_c), _sec(list(MACLER), mac_s)
        if (not sif_g.startswith("chacha") and not mac_g) or (not sif_a.startswith("chacha") and not mac_a):
            raise SSHHata("Cihazın SSH bütünlük denetimi desteklenmiyor ({})".format(",".join(mac_c[:4])))
        self.secilen = {"kex": kex_sec, "sifre": sif_g, "mac": mac_g}
        hk_sec = next((a for a in ("ssh-ed25519", "rsa-sha2-512", "rsa-sha2-256") if a in hk), None)
        if not hk_sec:
            raise SSHHata("Tahta anahtarı türü desteklenmiyor")
        self.siki = "kex-strict-s-v00@openssh.com" in kex
        if kex_sec.startswith("curve25519"):
            gizli = secrets.token_bytes(32)
            q_c = x25519(gizli, (9).to_bytes(32, "little"))
            self.gonder(bytes([30]) + _s(q_c))
            cevap = self.al()
            if cevap[0] != 31:
                raise SSHHata("Beklenmeyen paket (anahtar değişimi yanıtı)")
            r = Okuyucu(cevap[1:])
            k_s, q_s, imza = r.metin(), r.metin(), r.metin()
            ortak = x25519(gizli, q_s)
            if ortak == b"\x00" * 32:
                raise SSHHata("Geçersiz anahtar değişimi")
            k = int.from_bytes(ortak, "big")
            ek = _s(q_c) + _s(q_s)
        else:
            x = secrets.randbits(512) | 1
            e = pow(2, x, _G14)
            self.gonder(bytes([30]) + _mpint(e))
            cevap = self.al()
            if cevap[0] != 31:
                raise SSHHata("Beklenmeyen paket (anahtar değişimi yanıtı)")
            r = Okuyucu(cevap[1:])
            k_s, f, imza = r.metin(), r.mpint(), r.metin()
            if not 1 < f < _G14 - 1:
                raise SSHHata("Geçersiz anahtar değişimi")
            k = pow(f, x, _G14)
            ek = _mpint(e) + _mpint(f)
        h = hashlib.sha256(_s(ISTEMCI_SURUM) + _s(self.sunucu_surum.encode()) + _s(i_c) + _s(i_s) + _s(k_s) +
                           ek + _mpint(k)).digest()
        if not self._imza_dogru(k_s, imza, h, hk_sec):
            raise SSHHata("Tahta kimliği doğrulanamadı (imza geçersiz)")
        self.anahtar_blob = k_s
        self.oturum_id = h
        self.gonder(bytes([21]))
        if self.siki:
            self.seq_g = 0
        y = self.al()
        if y[0] != 21:
            raise SSHHata("Beklenmeyen paket (NEWKEYS)")
        if self.siki:
            self.seq_a = 0
        km = _mpint(k)

        def turet(harf):
            k1 = hashlib.sha256(km + h + harf + h).digest()
            k2 = hashlib.sha256(km + h + k1).digest()
            return k1 + k2
        def yon(sifre, mac, iv_h, k_h, m_h):
            if sifre.startswith("chacha"):
                return ChaChaYon(turet(k_h))
            uz = 16 if sifre == "aes128-ctr" else 32
            mh, etm = MACLER[mac]
            return AesYon(turet(k_h)[:uz], turet(iv_h)[:16], turet(m_h)[:mh().digest_size], mh, etm)
        self.k_g = yon(sif_g, mac_g, b"A", b"C", b"E")
        self.k_a = yon(sif_a, mac_a, b"B", b"D", b"F")
        return {"tur": anahtar_turu(k_s), "parmak_izi": parmak_izi(k_s), "surum": self.sunucu_surum}

    def _imza_dogru(self, k_s, imza_blob, h, beklenen):
        r = Okuyucu(k_s)
        tur = r.metin().decode()
        ri = Okuyucu(imza_blob)
        alg = ri.metin().decode()
        imza = ri.metin()
        if tur == "ssh-ed25519" and alg == "ssh-ed25519":
            return ed25519_dogrula(r.metin(), h, imza)
        if tur == "ssh-rsa" and alg in ("rsa-sha2-256", "rsa-sha2-512"):
            e, n = r.mpint(), r.mpint()
            return n.bit_length() >= 2048 and rsa_dogrula(e, n, alg, h, imza)
        return False

    # ── giriş ──
    def giris(self, kullanici, sifre):
        self.gonder(bytes([5]) + _s("ssh-userauth"))
        y = self.al()
        while y[0] == 7:                    # EXT_INFO
            y = self.al()
        if y[0] != 6:
            raise SSHHata("Giriş hizmeti açılamadı")
        self.gonder(bytes([50]) + _s(kullanici) + _s("ssh-connection") + _s("password") + b"\x00" + _s(sifre))
        yontemler = []
        while True:
            y = self.al()
            if y[0] == 53:                  # banner
                continue
            if y[0] == 52:
                return True
            if y[0] == 60:
                raise GirisHatasi("Bu kullanıcının şifresinin süresi dolmuş; tahtada bir kez giriş yapıp şifreyi yenileyin")
            if y[0] == 51:
                yontemler = Okuyucu(y[1:]).liste()
                break
            raise SSHHata("Beklenmeyen giriş yanıtı ({})".format(y[0]))
        if "keyboard-interactive" not in yontemler:
            if "password" in yontemler:
                raise GirisHatasi("Kullanıcı adı ya da şifre yanlış")
            raise GirisHatasi("Tahta şifreyle girişe izin vermiyor ({})".format(",".join(yontemler)))
        self.gonder(bytes([50]) + _s(kullanici) + _s("ssh-connection") + _s("keyboard-interactive") + _s("") + _s(""))
        while True:
            y = self.al()
            if y[0] == 53:
                continue
            if y[0] == 52:
                return True
            if y[0] == 51:
                raise GirisHatasi("Kullanıcı adı ya da şifre yanlış")
            if y[0] == 60:
                r = Okuyucu(y[1:])
                r.metin(), r.metin(), r.metin()
                n = r.u32()
                self.gonder(bytes([61]) + _u32(n) + b"".join(_s(sifre) for _ in range(n)))
                continue
            raise SSHHata("Beklenmeyen giriş yanıtı ({})".format(y[0]))

    # ── komut ──
    def calistir(self, komut, girdi=b"", zaman=300, cikti_cb=None):
        """→ (çıkış kodu, stdout, stderr)"""
        self.gonder(bytes([90]) + _s("session") + _u32(0) + _u32(2 * 1024 * 1024) + _u32(32768))
        while True:
            y = self.al()
            if y[0] == 91:
                r = Okuyucu(y[1:])
                r.u32()
                kanal = r.u32()
                pencere = r.u32()
                break
            if y[0] == 92:
                raise SSHHata("Komut kanalı açılamadı")
            if y[0] == 80:
                self._kuresel(y)
        self.gonder(bytes([98]) + _u32(kanal) + _s("exec") + b"\x01" + _s(komut))
        out, err, kod = bytearray(), bytearray(), None
        tuketilen = 0
        bitis = time.time() + zaman
        girdi_gonderildi = False
        while True:
            if time.time() > bitis:
                raise SSHHata("Komut zaman aşımına uğradı")
            y = self.al()
            t = y[0]
            r = Okuyucu(y[1:])
            if t == 99:                     # exec kabul edildi
                if girdi and not girdi_gonderildi:
                    self.gonder(bytes([94]) + _u32(kanal) + _s(girdi))
                girdi_gonderildi = True
                self.gonder(bytes([96]) + _u32(kanal))
            elif t == 100:
                raise SSHHata("Tahta komutu çalıştırmayı reddetti")
            elif t in (94, 95):
                r.u32()
                if t == 95:
                    r.u32()
                v = r.metin()
                (out if t == 94 else err).extend(v)
                if cikti_cb:
                    try:
                        cikti_cb(v)
                    except Exception:
                        pass
                tuketilen += len(v)
                if tuketilen > 1024 * 1024:
                    self.gonder(bytes([93]) + _u32(kanal) + _u32(tuketilen))
                    tuketilen = 0
            elif t == 98:
                r.u32()
                ad = r.metin()
                istek = r.bool()
                if ad == b"exit-status":
                    kod = r.u32()
                elif ad == b"exit-signal":
                    kod = 255
                if istek:
                    self.gonder(bytes([100]) + _u32(kanal))
            elif t == 97:                   # kapandı
                self.gonder(bytes([97]) + _u32(kanal))
                return kod if kod is not None else -1, bytes(out), bytes(err)
            elif t == 80:
                self._kuresel(y)
            elif t == 93:
                pass

    def _kuresel(self, y):
        r = Okuyucu(y[1:])
        r.metin()
        if r.bool():
            self.gonder(bytes([82]))

    def kapat(self):
        try:
            if self.k_g is not None:
                self.gonder(bytes([1]) + _u32(11) + _s("") + _s(""))
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


def kimlik_al(host, port=22, zaman=4.0):
    """Yalnızca tahtanın SSH sürümünü ve anahtar parmak izini alır (şifre gönderilmez)."""
    s = SSH(host, port, zaman)
    try:
        return s.baglan()
    except SSHHata as e:
        e.surum = s.sunucu_surum
        raise
    except (OSError, ValueError, struct.error) as e:
        # Bağlantı ortada kesildi (ör. cihaz anahtar değişiminde kapattı): sürümü yine de bildir
        h = SSHHata(ag_hata_yazi(e))
        h.surum = s.sunucu_surum
        raise h
    finally:
        s.kapat()


def ag_hata_yazi(e):
    """Ağ hatalarını sade Türkçe açıklamaya çevirir (Windows'un yerel dildeki uzun iletileri yerine)."""
    if isinstance(e, socket.timeout):
        return "Cihaz yanıt vermeyi bıraktı (zaman aşımı)"
    if isinstance(e, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
        return "Cihaz bağlantıyı kendisi kapattı"
    if isinstance(e, ConnectionRefusedError):
        return "Cihaz bağlantıyı reddetti"
    return "Bağlantı hatası: {}".format(e)


def port_acik(host, port=22, zaman=0.8):
    try:
        with socket.create_connection((host, port), timeout=zaman):
            return True
    except OSError:
        return False
